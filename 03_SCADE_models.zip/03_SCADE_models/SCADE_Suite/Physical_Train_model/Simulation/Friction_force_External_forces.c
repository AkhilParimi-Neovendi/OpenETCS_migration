/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Friction_force_External_forces.h"

/* External_forces::Friction_force/ */
void Friction_force_External_forces(
  /* Mass/ */
  kcg_float32 Mass,
  outC_Friction_force_External_forces *outC)
{
  outC->_L7 = Theta;
  outC->_L10 = /* _L10=(mathext::CosR#1)/ */
    CosR32_mathext_mathextimpl(outC->_L7);
  outC->_L6 = Mass;
  outC->_L4 = Mue_k;
  outC->_L3 = g;
  outC->_L1 = outC->_L6 * outC->_L3 * outC->_L4 * outC->_L10;
  outC->Friction_Force = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void Friction_force_init_External_forces(
  outC_Friction_force_External_forces *outC)
{
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->Friction_Force = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Friction_force_reset_External_forces(
  outC_Friction_force_External_forces *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Friction_force_External_forces.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

