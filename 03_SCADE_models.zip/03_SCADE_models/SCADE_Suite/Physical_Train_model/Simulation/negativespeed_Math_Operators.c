/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "negativespeed_Math_Operators.h"

/* Math_Operators::negativespeed/ */
void negativespeed_Math_Operators(
  /* acceleration/ */
  kcg_float32 acceleration,
  /* speed/ */
  kcg_float32 speed,
  outC_negativespeed_Math_Operators *outC)
{
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L2 = acceleration;
  outC->_L12 = outC->_L2 < outC->_L4;
  outC->_L1 = speed;
  outC->_L11 = outC->_L1 < outC->_L4;
  outC->_L9 = speed;
  /* _L8= */
  if (outC->_L11) {
    outC->_L8 = outC->_L4;
  }
  else {
    outC->_L8 = outC->_L9;
  }
  outC->ospeed = outC->_L8;
  outC->_L10 = acceleration;
  outC->_L6 = outC->_L11 & outC->_L12;
  /* _L7= */
  if (outC->_L6) {
    outC->_L7 = outC->_L4;
  }
  else {
    outC->_L7 = outC->_L10;
  }
  outC->oacceleration = outC->_L7;
}

#ifndef KCG_USER_DEFINED_INIT
void negativespeed_init_Math_Operators(outC_negativespeed_Math_Operators *outC)
{
  outC->_L12 = kcg_true;
  outC->_L11 = kcg_true;
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L9 = kcg_lit_float32(0.0);
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_true;
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->ospeed = kcg_lit_float32(0.0);
  outC->oacceleration = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void negativespeed_reset_Math_Operators(outC_negativespeed_Math_Operators *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** negativespeed_Math_Operators.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

