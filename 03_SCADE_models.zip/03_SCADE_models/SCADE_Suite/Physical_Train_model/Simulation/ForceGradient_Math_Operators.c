/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ForceGradient_Math_Operators.h"

/* Math_Operators::ForceGradient/ */
void ForceGradient_Math_Operators(
  /* Input/ */
  kcg_float32 Input,
  outC_ForceGradient_Math_Operators *outC)
{
  outC->_L8 = TCYCLE;
  outC->_L10 = force_gradient;
  outC->_L4 = outC->_L10 * outC->_L8;
  outC->_L7 = outC->_L5;
  outC->_L6 = outC->_L7 - outC->_L4;
  outC->_L3 = outC->_L7 + outC->_L4;
  outC->_L13 = kcg_lit_float32(0.01);
  outC->_L12 = Max_Traction_and_Braking;
  outC->_L1 = Input;
  outC->_L11 = outC->_L1 * outC->_L12 * outC->_L13;
  outC->_L2 = outC->_L7 < outC->_L11;
  /* _L9= */
  if (outC->_L2) {
    outC->_L9 = outC->_L3;
  }
  else {
    outC->_L9 = outC->_L6;
  }
  outC->_L14 = outC->_L7 == outC->_L11;
  /* _L15= */
  if (outC->_L14) {
    outC->_L15 = outC->_L7;
  }
  else {
    outC->_L15 = outC->_L9;
  }
  /* _L5= */
  if (outC->init) {
    outC->_L5 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L5 = outC->_L15;
  }
  outC->Output1 = outC->_L5;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void ForceGradient_init_Math_Operators(outC_ForceGradient_Math_Operators *outC)
{
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_true;
  outC->_L13 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = kcg_lit_float32(0.0);
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L9 = kcg_lit_float32(0.0);
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->init = kcg_true;
  outC->Output1 = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ForceGradient_reset_Math_Operators(outC_ForceGradient_Math_Operators *outC)
{
  outC->init = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ForceGradient_Math_Operators.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

