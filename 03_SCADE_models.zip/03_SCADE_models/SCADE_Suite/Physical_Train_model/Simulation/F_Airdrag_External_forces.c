/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "F_Airdrag_External_forces.h"

/* External_forces::F_Airdrag/ */
void F_Airdrag_External_forces(
  /* Train_Speed/ */
  kcg_float32 Train_Speed,
  outC_F_Airdrag_External_forces *outC)
{
  outC->_L1 = Train_Speed;
  /* _L2=(mathext::Square#1)/ */
  Square_mathext_float32(outC->_L1, &outC->Context_Square_1);
  outC->_L2 = outC->Context_Square_1.Square_Out_float32;
  outC->_L4 = C_d;
  outC->_L5 = rho;
  outC->_L6 = A;
  outC->_L7 = kcg_lit_float32(0.5);
  outC->_L3 = outC->_L7 * outC->_L6 * outC->_L5 * outC->_L4 * outC->_L2;
  outC->F_Air = outC->_L3;
}

#ifndef KCG_USER_DEFINED_INIT
void F_Airdrag_init_External_forces(outC_F_Airdrag_External_forces *outC)
{
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->F_Air = kcg_lit_float32(0.0);
  /* _L2=(mathext::Square#1)/ */
  Square_init_mathext_float32(&outC->Context_Square_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void F_Airdrag_reset_External_forces(outC_F_Airdrag_External_forces *outC)
{
  /* _L2=(mathext::Square#1)/ */
  Square_reset_mathext_float32(&outC->Context_Square_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** F_Airdrag_External_forces.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

