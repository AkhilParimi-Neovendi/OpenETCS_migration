/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Shift_Array_Math_Operators.h"

/* Math_Operators::Shift_Array/ */
void Shift_Array_Math_Operators(
  /* InputArray/ */
  array_float32_5 *InputArray,
  outC_Shift_Array_Math_Operators *outC)
{
  outC->_L24[0] = kcg_lit_float32(0.0);
  kcg_copy_array_float32_5(&outC->_L15, InputArray);
  kcg_copy_array_float32_4(&outC->_L22, (array_float32_4 *) &outC->_L15[0]);
  outC->_L23[0] = outC->_L24[0];
  kcg_copy_array_float32_4(&outC->_L23[1], &outC->_L22);
  kcg_copy_array_float32_5(&outC->OutputArray, &outC->_L23);
}

#ifndef KCG_USER_DEFINED_INIT
void Shift_Array_init_Math_Operators(outC_Shift_Array_Math_Operators *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;
  kcg_size idx3;
  kcg_size idx4;

  for (idx = 0; idx < 1; idx++) {
    outC->_L24[idx] = kcg_lit_float32(0.0);
  }
  for (idx1 = 0; idx1 < 5; idx1++) {
    outC->_L23[idx1] = kcg_lit_float32(0.0);
  }
  for (idx2 = 0; idx2 < 4; idx2++) {
    outC->_L22[idx2] = kcg_lit_float32(0.0);
  }
  for (idx3 = 0; idx3 < 5; idx3++) {
    outC->_L15[idx3] = kcg_lit_float32(0.0);
  }
  for (idx4 = 0; idx4 < 5; idx4++) {
    outC->OutputArray[idx4] = kcg_lit_float32(0.0);
  }
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Shift_Array_reset_Math_Operators(outC_Shift_Array_Math_Operators *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Shift_Array_Math_Operators.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

