/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */
#ifndef _ForceGradient_Math_Operators_H_
#define _ForceGradient_Math_Operators_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* Output1/ */ Output1;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_float32 /* _L5/ */ _L5;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_float32 /* _L3/ */ _L3;
  kcg_float32 /* _L4/ */ _L4;
  kcg_float32 /* _L6/ */ _L6;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
  kcg_float32 /* _L9/ */ _L9;
  kcg_float32 /* _L10/ */ _L10;
  kcg_float32 /* _L11/ */ _L11;
  kcg_float32 /* _L12/ */ _L12;
  kcg_float32 /* _L13/ */ _L13;
  kcg_bool /* _L14/ */ _L14;
  kcg_float32 /* _L15/ */ _L15;
} outC_ForceGradient_Math_Operators;

/* ===========  node initialization and cycle functions  =========== */
/* Math_Operators::ForceGradient/ */
extern void ForceGradient_Math_Operators(
  /* Input/ */
  kcg_float32 Input,
  outC_ForceGradient_Math_Operators *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void ForceGradient_reset_Math_Operators(
  outC_ForceGradient_Math_Operators *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void ForceGradient_init_Math_Operators(
  outC_ForceGradient_Math_Operators *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _ForceGradient_Math_Operators_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ForceGradient_Math_Operators.h
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

