/* Train_model_mapping.c */

#include "Train_model_type.h"
#include "Train_model_interface.h"
#include "Train_model_mapping.h"

#include "SmuTypes.h"
#include "SmuMapping.h"

#include "kcg_sensors.h"

/* mapping declaration */

#define DECL_ITER(name) extern const MappingIterator iter_##name

DECL_ITER(fold_5);
DECL_ITER(array_1);
DECL_ITER(array_4);
DECL_ITER(map_5);
DECL_ITER(array_5);

#define DECL_SCOPE(name, count) extern const MappingEntry name##_entries[count]; extern const MappingScope name

DECL_SCOPE(scope_34, 16);
DECL_SCOPE(scope_33, 13);
DECL_SCOPE(scope_32, 8);
DECL_SCOPE(scope_31, 1);
DECL_SCOPE(scope_30, 1);
DECL_SCOPE(scope_29, 1);
DECL_SCOPE(scope_28, 1);
DECL_SCOPE(scope_27, 35);
DECL_SCOPE(scope_26, 1);
DECL_SCOPE(scope_25, 1);
DECL_SCOPE(scope_24, 5);
DECL_SCOPE(scope_23, 3);
DECL_SCOPE(scope_22, 3);
DECL_SCOPE(scope_21, 19);
DECL_SCOPE(scope_20, 3);
DECL_SCOPE(scope_19, 22);
DECL_SCOPE(scope_18, 6);
DECL_SCOPE(scope_17, 29);
DECL_SCOPE(scope_16, 1);
DECL_SCOPE(scope_15, 1);
DECL_SCOPE(scope_14, 30);
DECL_SCOPE(scope_13, 8);
DECL_SCOPE(scope_12, 7);
DECL_SCOPE(scope_11, 6);
DECL_SCOPE(scope_10, 3);
DECL_SCOPE(scope_9, 9);
DECL_SCOPE(scope_8, 10);
DECL_SCOPE(scope_7, 12);
DECL_SCOPE(scope_6, 3);
DECL_SCOPE(scope_5, 24);
DECL_SCOPE(scope_4, 21);
DECL_SCOPE(scope_3, 1);
DECL_SCOPE(scope_2, 1);
DECL_SCOPE(scope_1, 27);
DECL_SCOPE(scope_0, 1);

/* clock definition */


/* mapping definition */

const MappingIterator iter_fold_5 = { "fold", 5, 5, NULL };
const MappingIterator iter_array_1 = { "array", 1, 1, NULL };
const MappingIterator iter_array_4 = { "array", 4, 4, NULL };
const MappingIterator iter_map_5 = { "map", 5, 5, NULL };
const MappingIterator iter_array_5 = { "array", 5, 5, NULL };

const MappingEntry scope_34_entries[16] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, Output1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Math_Operators, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Math_Operators, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 }
};
const MappingScope scope_34 = {
    "Math_Operators::ForceGradient/ ForceGradient_Math_Operators",
    scope_34_entries, 16
};

const MappingEntry scope_33_entries[13] = {
    /* 0 */ { MAP_OUTPUT, "TractionForce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, TractionForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "BrakingFroce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, BrakingFroce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_T_B_Lever_Math_Operators, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L27), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L40), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L41), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_INSTANCE, "Math_Operators::ForceGradient 2", NULL, sizeof(outC_ForceGradient_Math_Operators), offsetof(outC_T_B_Lever_Math_Operators, Context_ForceGradient_2), NULL, NULL, NULL, &scope_34, 1, 11 },
    /* 12 */ { MAP_INSTANCE, "Math_Operators::ForceGradient 3", NULL, sizeof(outC_ForceGradient_Math_Operators), offsetof(outC_T_B_Lever_Math_Operators, Context_ForceGradient_3), NULL, NULL, NULL, &scope_34, 1, 12 }
};
const MappingScope scope_33 = {
    "Math_Operators::T_B_Lever/ T_B_Lever_Math_Operators",
    scope_33_entries, 13
};

const MappingEntry scope_32_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Sum_of_traction_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, Sum_of_traction_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Sum_of_Braking_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, Sum_of_Braking_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Math_Operators, _L6), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Math_Operators, _L7), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 7 }
};
const MappingScope scope_32 = {
    "Math_Operators::Sum_of_Forces/ Sum_of_Forces_Math_Operators",
    scope_32_entries, 8
};

const MappingEntry scope_31_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_31 = {
    "array_bool_4",
    scope_31_entries, 1
};

const MappingEntry scope_30_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_30 = {
    "array_bool_1",
    scope_30_entries, 1
};

const MappingEntry scope_29_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_29 = {
    "array_int32_4",
    scope_29_entries, 1
};

const MappingEntry scope_28_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_28 = {
    "array_int32_1",
    scope_28_entries, 1
};

const MappingEntry scope_27_entries[35] = {
    /* 0 */ { MAP_OUTPUT, "Traction_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Traction_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Braking_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Braking_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Speed_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Speed_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Accelartion_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Accelartion_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "Mass_Array", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Mass_Array), &_Type_array_int32_5_Utils, NULL, NULL, &scope_15, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "brakelinepressurearray", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, brakelinepressurearray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "holdingbrakestatus", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Math_Operators, holdingbrakestatus), &_Type_array_bool_5_Utils, NULL, NULL, &scope_16, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L4), &_Type_array_float32_1_Utils, NULL, NULL, &scope_26, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L3", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L3), &_Type_array_float32_4_Utils, NULL, NULL, &scope_25, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L8), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L7), &_Type_array_float32_1_Utils, NULL, NULL, &scope_26, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L6), &_Type_array_float32_4_Utils, NULL, NULL, &scope_25, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_int32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L13), &_Type_array_int32_1_Utils, NULL, NULL, &scope_28, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L11", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L11), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Math_Operators, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L18), &_Type_array_int32_5_Utils, NULL, NULL, &scope_15, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_int32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L19), &_Type_array_int32_4_Utils, NULL, NULL, &scope_29, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Math_Operators, _L20), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Math_Operators, _L28), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L33", NULL, sizeof(array_bool_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L33), &_Type_array_bool_1_Utils, NULL, NULL, &scope_30, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L32", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L32), &_Type_array_bool_5_Utils, NULL, NULL, &scope_16, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_bool_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L31), &_Type_array_bool_4_Utils, NULL, NULL, &scope_31, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Math_Operators, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L44", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L44), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L41", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L41), &_Type_array_float32_4_Utils, NULL, NULL, &scope_25, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L40", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L40), &_Type_array_float32_1_Utils, NULL, NULL, &scope_26, 1, 34 }
};
const MappingScope scope_27 = {
    "Math_Operators::TrainConfiguration0/ TrainConfiguration0_Math_Operators",
    scope_27_entries, 35
};

const MappingEntry scope_26_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_26 = {
    "array_float32_1",
    scope_26_entries, 1
};

const MappingEntry scope_25_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_25 = {
    "array_float32_4",
    scope_25_entries, 1
};

const MappingEntry scope_24_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "OutputArray", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, OutputArray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L15", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, _L15), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L22", NULL, sizeof(array_float32_4), offsetof(outC_Shift_Array_Math_Operators, _L22), &_Type_array_float32_4_Utils, NULL, NULL, &scope_25, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L23", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, _L23), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L24", NULL, sizeof(array_float32_1), offsetof(outC_Shift_Array_Math_Operators, _L24), &_Type_array_float32_1_Utils, NULL, NULL, &scope_26, 1, 4 }
};
const MappingScope scope_24 = {
    "Math_Operators::Shift_Array/ Shift_Array_Math_Operators",
    scope_24_entries, 5
};

const MappingEntry scope_23_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, Output1_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L1_NumericToFloat32_1_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L2_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_23 = {
    "Math_Operators::LCF_Calculation/ LCF_Calculation_Math_Operators/math::NumericToFloat32 1",
    scope_23_entries, 3
};

const MappingEntry scope_22_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_22 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes/math::NumericToFloat32 2",
    scope_22_entries, 3
};

const MappingEntry scope_21_entries[19] = {
    /* 0 */ { MAP_OUTPUT, "AppliedPneumaticBrakingforce", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, AppliedPneumaticBrakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Brakepressure", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Brakepressure), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L18), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_22, 1, 18 }
};
const MappingScope scope_21 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes",
    scope_21_entries, 19
};

const MappingEntry scope_20_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Holding_brake_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_20 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes/math::NumericToFloat32 2",
    scope_20_entries, 3
};

const MappingEntry scope_19_entries[22] = {
    /* 0 */ { MAP_OUTPUT, "AppliedHoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, AppliedHoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Max_HoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Max_HoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L21), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_20, 1, 21 }
};
const MappingScope scope_19 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes",
    scope_19_entries, 22
};

const MappingEntry scope_18_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "outbraking", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, outbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeedcorrection_Math_Operators, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_18 = {
    "Math_Operators::negativespeedcorrection/ negativespeedcorrection_Math_Operators",
    scope_18_entries, 6
};

const MappingEntry scope_17_entries[29] = {
    /* 0 */ { MAP_OUTPUT, "unit_traction", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, unit_traction), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "unittotalbraking", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, unittotalbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "L_Couplingforce", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, L_Couplingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L12), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_LCF_Calculation_Math_Operators, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L27), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_LCF_Calculation_Math_Operators, Context_Resistance_force_1), NULL, NULL, NULL, &scope_8, 1, 24 },
    /* 25 */ { MAP_INSTANCE, "Math_Operators::negativespeedcorrection 1", NULL, sizeof(outC_negativespeedcorrection_Math_Operators), offsetof(outC_LCF_Calculation_Math_Operators, Context_negativespeedcorrection_1), NULL, NULL, NULL, &scope_18, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Brakes::Holding_brake 1", NULL, sizeof(outC_Holding_brake_Brakes), offsetof(outC_LCF_Calculation_Math_Operators, Context_Holding_brake_1), NULL, NULL, NULL, &scope_19, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Brakes::Pneumaticbrakes 1", NULL, sizeof(outC_Pneumaticbrakes_Brakes), offsetof(outC_LCF_Calculation_Math_Operators, Context_Pneumaticbrakes_1), NULL, NULL, NULL, &scope_21, 1, 27 },
    /* 28 */ { MAP_EXPANDED, "math::NumericToFloat32 1", NULL, 0, 0, NULL, NULL, NULL, &scope_23, 1, 28 }
};
const MappingScope scope_17 = {
    "Math_Operators::LCF_Calculation/ LCF_Calculation_Math_Operators",
    scope_17_entries, 29
};

const MappingEntry scope_16_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_16 = {
    "array_bool_5",
    scope_16_entries, 1
};

const MappingEntry scope_15_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_15 = {
    "array_int32_5",
    scope_15_entries, 1
};

const MappingEntry scope_14_entries[30] = {
    /* 0 */ { MAP_OUTPUT, "LCF_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, LCF_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Total_Tractionforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Tractionforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Total_Brakingforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Brakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L13), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L14", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L14), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L16", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L16), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration_And_LCF, _L21), &_Type_array_int32_5_Utils, NULL, NULL, &scope_15, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L20", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L20), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L19), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L18), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L17", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L17), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration_And_LCF, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L28", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L28), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L29", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration_And_LCF, _L29), &_Type_array_bool_5_Utils, NULL, NULL, &scope_16, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L30", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L30), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L31), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Math_Operators::LCF_Calculation 1", &iter_map_5, sizeof(outC_LCF_Calculation_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_LCF_Calculation_1), NULL, NULL, NULL, &scope_17, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Math_Operators::Shift_Array 1", NULL, sizeof(outC_Shift_Array_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_Shift_Array_1), NULL, NULL, NULL, &scope_24, 1, 27 },
    /* 28 */ { MAP_INSTANCE, "Math_Operators::TrainConfiguration0 1", NULL, sizeof(outC_TrainConfiguration0_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_TrainConfiguration0_1), NULL, NULL, NULL, &scope_27, 1, 28 },
    /* 29 */ { MAP_INSTANCE, "Math_Operators::Sum_of_Forces 1", NULL, sizeof(outC_Sum_of_Forces_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_Sum_of_Forces_1), NULL, NULL, NULL, &scope_32, 1, 29 }
};
const MappingScope scope_14 = {
    "TrainConfiguration_And_LCF/ TrainConfiguration_And_LCF",
    scope_14_entries, 30
};

const MappingEntry scope_13_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Distance_travelled", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, Distance_travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_13 = {
    "Distance_Calculation/ Distance_Calculation",
    scope_13_entries, 8
};

const MappingEntry scope_12_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "Friction_Force", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, Friction_Force), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_12 = {
    "External_forces::Friction_force/ Friction_force_External_forces",
    scope_12_entries, 7
};

const MappingEntry scope_11_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "F_Gradient", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, F_Gradient), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_11 = {
    "External_forces::F_gradient/ F_gradient_External_forces",
    scope_11_entries, 6
};

const MappingEntry scope_10_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Square_Out", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, Square_Out_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L1_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L2_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_10 = {
    "mathext::Square/ Square_mathext_float32",
    scope_10_entries, 3
};

const MappingEntry scope_9_entries[9] = {
    /* 0 */ { MAP_OUTPUT, "F_Air", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, F_Air), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "mathext::Square 1", NULL, sizeof(outC_Square_mathext_float32), offsetof(outC_F_Airdrag_External_forces, Context_Square_1), NULL, NULL, NULL, &scope_10, 1, 8 }
};
const MappingScope scope_9 = {
    "External_forces::F_Airdrag/ F_Airdrag_External_forces",
    scope_9_entries, 9
};

const MappingEntry scope_8_entries[10] = {
    /* 0 */ { MAP_OUTPUT, "Total_resistance", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, Total_resistance), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_INSTANCE, "External_forces::F_Airdrag 1", NULL, sizeof(outC_F_Airdrag_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_Airdrag_1), NULL, NULL, NULL, &scope_9, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "External_forces::F_gradient 1", NULL, sizeof(outC_F_gradient_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_gradient_1), NULL, NULL, NULL, &scope_11, 1, 8 },
    /* 9 */ { MAP_INSTANCE, "External_forces::Friction_force 1", NULL, sizeof(outC_Friction_force_External_forces), offsetof(outC_Resistance_force_External_forces, Context_Friction_force_1), NULL, NULL, NULL, &scope_12, 1, 9 }
};
const MappingScope scope_8 = {
    "External_forces::Resistance_force/ Resistance_force_External_forces",
    scope_8_entries, 10
};

const MappingEntry scope_7_entries[12] = {
    /* 0 */ { MAP_OUTPUT, "oacceleration", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, oacceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "ospeed", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, ospeed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 }
};
const MappingScope scope_7 = {
    "Math_Operators::negativespeed/ negativespeed_Math_Operators",
    scope_7_entries, 12
};

const MappingEntry scope_6_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Output1_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L1_NumericToFloat32_3_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_6 = {
    "Train_dynamics/ Train_dynamics/math::NumericToFloat32 3",
    scope_6_entries, 3
};

const MappingEntry scope_5_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "train_speed", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Distance_Travelled", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Distance_Travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L25), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L29), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L30), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L31), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_EXPANDED, "math::NumericToFloat32 3", NULL, 0, 0, NULL, NULL, NULL, &scope_6, 1, 20 },
    /* 21 */ { MAP_INSTANCE, "Math_Operators::negativespeed 1", NULL, sizeof(outC_negativespeed_Math_Operators), offsetof(outC_Train_dynamics, Context_negativespeed_1), NULL, NULL, NULL, &scope_7, 1, 21 },
    /* 22 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_Train_dynamics, Context_Resistance_force_1), NULL, NULL, NULL, &scope_8, 1, 22 },
    /* 23 */ { MAP_INSTANCE, "Distance_Calculation 1", NULL, sizeof(outC_Distance_Calculation), offsetof(outC_Train_dynamics, Context_Distance_Calculation_1), NULL, NULL, NULL, &scope_13, 1, 23 }
};
const MappingScope scope_5 = {
    "Train_dynamics/ Train_dynamics",
    scope_5_entries, 24
};

const MappingEntry scope_4_entries[21] = {
    /* 0 */ { MAP_OUTPUT, "Train_Speed", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_Speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "LCF_Values", NULL, sizeof(LCF_Data), offsetof(outC_Train, LCF_Values), &_Type_LCF_Data_Utils, NULL, NULL, &scope_2, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Distance_Travelled_by_Train", NULL, sizeof(kcg_float32), offsetof(outC_Train, Distance_Travelled_by_Train), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L34), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L35), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L60", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L60), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L59", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L59), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L62", NULL, sizeof(array_float32_5), offsetof(outC_Train, _L62), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L64", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L64), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L65), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L67), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L66", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L66), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_Train, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L70), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L71", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L71), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L72", NULL, sizeof(LCF_Data), offsetof(outC_Train, _L72), &_Type_LCF_Data_Utils, NULL, NULL, &scope_2, 1, 18 },
    /* 19 */ { MAP_INSTANCE, "Train_dynamics 1", NULL, sizeof(outC_Train_dynamics), offsetof(outC_Train, Context_Train_dynamics_1), NULL, NULL, NULL, &scope_5, 1, 19 },
    /* 20 */ { MAP_INSTANCE, "TrainConfiguration_And_LCF", NULL, sizeof(outC_TrainConfiguration_And_LCF), offsetof(outC_Train, Context_TrainConfiguration_And_LCF), NULL, NULL, NULL, &scope_14, 1, 20 }
};
const MappingScope scope_4 = {
    "Train/ Train",
    scope_4_entries, 21
};

const MappingEntry scope_3_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_3 = {
    "array_float32_5",
    scope_3_entries, 1
};

const MappingEntry scope_2_entries[1] = {
    /* 0 */ { MAP_FIELD, ".LCF_Values", NULL, sizeof(array_float32_5), offsetof(LCF_Data, LCF_Values), &_Type_array_float32_5_Utils, NULL, NULL, &scope_3, 1, 0 }
};
const MappingScope scope_2 = {
    "LCF_Data",
    scope_2_entries, 1
};

const MappingEntry scope_1_entries[27] = {
    /* 0 */ { MAP_OUTPUT, "Distance_Covered", NULL, sizeof(kcg_int16), (size_t)&outputs_ctx.Distance_Covered, &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Current_TrainSpeed", NULL, sizeof(kcg_int16), (size_t)&outputs_ctx.Current_TrainSpeed, &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "CurrentTrainAcceleration", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx.CurrentTrainAcceleration, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_INPUT, "T_B_LeverInput", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.T_B_LeverInput, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_INPUT, "HoldingBrakeSwitch", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.HoldingBrakeSwitch, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_INPUT, "TrainBrakeLeverInput", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.TrainBrakeLeverInput, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L4, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L3", NULL, sizeof(LCF_Data), (size_t)&outputs_ctx._L3, &_Type_LCF_Data_Utils, NULL, NULL, &scope_2, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L2, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L1, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L6, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L5, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L7, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L8, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L10, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L11, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L12, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L13, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L14, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L15, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int16), (size_t)&outputs_ctx._L17, &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int16), (size_t)&outputs_ctx._L18, &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L20, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L24, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), (size_t)&outputs_ctx._L25, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 24 },
    /* 25 */ { MAP_INSTANCE, "Train 1", NULL, sizeof(outC_Train), (size_t)&outputs_ctx.Context_Train_1, NULL, NULL, NULL, &scope_4, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Math_Operators::T_B_Lever 1", NULL, sizeof(outC_T_B_Lever_Math_Operators), (size_t)&outputs_ctx.Context_T_B_Lever_1, NULL, NULL, NULL, &scope_33, 1, 26 }
};
const MappingScope scope_1 = {
    "Train_with_TandB_Lever/ Train_with_TandB_Lever",
    scope_1_entries, 27
};

const MappingEntry scope_0_entries[1] = {
    /* 0 */ { MAP_ROOT, "Train_with_TandB_Lever", NULL, 0, 0, NULL, NULL, NULL, &scope_1, 1, 0 }
};
const MappingScope scope_0 = {
    "",
    scope_0_entries, 1
};

/* entry point */
const MappingScope* pTop = &scope_0;
