/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train_dynamics.h"

/* Train_dynamics/ */
void Train_dynamics(
  /* total_traction_force/ */
  kcg_float32 total_traction_force,
  /* total_braking_force/ */
  kcg_float32 total_braking_force,
  outC_Train_dynamics *outC)
{
  outC->_L25 = MASS;
  outC->Input1_NumericToFloat32_3_int32 = outC->_L25;
  outC->_L1_NumericToFloat32_3_int32 = outC->Input1_NumericToFloat32_3_int32;
  outC->_L2_NumericToFloat32_3_int32 = /* @1/_L2= */(kcg_float32)
      outC->_L1_NumericToFloat32_3_int32;
  outC->Output1_NumericToFloat32_3_int32 = outC->_L2_NumericToFloat32_3_int32;
  outC->_L7 = outC->_L29;
  outC->_L24 = outC->Output1_NumericToFloat32_3_int32;
  /* _L6= */
  if (outC->init) {
    outC->_L6 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L6 = outC->_L7;
  }
  /* _L30=(External_forces::Resistance_force#1)/ */
  Resistance_force_External_forces(
    outC->_L6,
    outC->_L24,
    &outC->Context_Resistance_force_1);
  outC->_L30 = outC->Context_Resistance_force_1.Total_resistance;
  outC->_L15 = total_braking_force;
  outC->_L31 = outC->_L15 + outC->_L30;
  outC->_L1 = total_traction_force;
  outC->_L10 = outC->_L1 - outC->_L31;
  outC->_L4 = outC->_L10 / outC->_L24;
  outC->_L8 = mps2kmph;
  outC->_L3 = TCYCLE;
  outC->_L2 = outC->_L4 * outC->_L3 * outC->_L8;
  outC->_L5 = outC->_L2 + outC->_L6;
  /* _L28=(Math_Operators::negativespeed#1)/ */
  negativespeed_Math_Operators(
    outC->_L4,
    outC->_L5,
    &outC->Context_negativespeed_1);
  outC->_L28 = outC->Context_negativespeed_1.oacceleration;
  outC->_L29 = outC->Context_negativespeed_1.ospeed;
  /* _L32=(Distance_Calculation#1)/ */
  Distance_Calculation(outC->_L29, &outC->Context_Distance_Calculation_1);
  outC->_L32 = outC->Context_Distance_Calculation_1.Distance_travelled;
  outC->Distance_Travelled = outC->_L32;
  outC->train_acceleration = outC->_L28;
  outC->train_speed = outC->_L29;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void Train_dynamics_init(outC_Train_dynamics *outC)
{
  outC->_L32 = kcg_lit_float32(0.0);
  outC->_L31 = kcg_lit_float32(0.0);
  outC->_L30 = kcg_lit_float32(0.0);
  outC->_L28 = kcg_lit_float32(0.0);
  outC->_L25 = kcg_lit_int32(0);
  outC->_L24 = kcg_lit_float32(0.0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L1_NumericToFloat32_3_int32 = kcg_lit_int32(0);
  outC->_L2_NumericToFloat32_3_int32 = kcg_lit_float32(0.0);
  outC->Input1_NumericToFloat32_3_int32 = kcg_lit_int32(0);
  outC->Output1_NumericToFloat32_3_int32 = kcg_lit_float32(0.0);
  outC->_L29 = kcg_lit_float32(0.0);
  outC->init = kcg_true;
  outC->train_acceleration = kcg_lit_float32(0.0);
  outC->Distance_Travelled = kcg_lit_float32(0.0);
  outC->train_speed = kcg_lit_float32(0.0);
  /* _L32=(Distance_Calculation#1)/ */
  Distance_Calculation_init(&outC->Context_Distance_Calculation_1);
  /* _L28=(Math_Operators::negativespeed#1)/ */
  negativespeed_init_Math_Operators(&outC->Context_negativespeed_1);
  /* _L30=(External_forces::Resistance_force#1)/ */
  Resistance_force_init_External_forces(&outC->Context_Resistance_force_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_dynamics_reset(outC_Train_dynamics *outC)
{
  outC->init = kcg_true;
  /* _L32=(Distance_Calculation#1)/ */
  Distance_Calculation_reset(&outC->Context_Distance_Calculation_1);
  /* _L28=(Math_Operators::negativespeed#1)/ */
  negativespeed_reset_Math_Operators(&outC->Context_negativespeed_1);
  /* _L30=(External_forces::Resistance_force#1)/ */
  Resistance_force_reset_External_forces(&outC->Context_Resistance_force_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: Train_dynamics/
  @1: (math::NumericToFloat32#3)
*/

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_dynamics.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

