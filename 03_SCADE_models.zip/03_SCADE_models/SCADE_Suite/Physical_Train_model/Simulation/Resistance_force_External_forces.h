/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */
#ifndef _Resistance_force_External_forces_H_
#define _Resistance_force_External_forces_H_

#include "kcg_types.h"
#include "Friction_force_External_forces.h"
#include "F_gradient_External_forces.h"
#include "F_Airdrag_External_forces.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* Total_resistance/ */ Total_resistance;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Friction_force_External_forces /* _L6=(External_forces::Friction_force#1)/ */ Context_Friction_force_1;
  outC_F_gradient_External_forces /* _L5=(External_forces::F_gradient#1)/ */ Context_F_gradient_1;
  outC_F_Airdrag_External_forces /* _L4=(External_forces::F_Airdrag#1)/ */ Context_F_Airdrag_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L4/ */ _L4;
  kcg_float32 /* _L5/ */ _L5;
  kcg_float32 /* _L6/ */ _L6;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
} outC_Resistance_force_External_forces;

/* ===========  node initialization and cycle functions  =========== */
/* External_forces::Resistance_force/ */
extern void Resistance_force_External_forces(
  /* Current_speed/ */
  kcg_float32 Current_speed,
  /* Mass/ */
  kcg_float32 Mass,
  outC_Resistance_force_External_forces *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Resistance_force_reset_External_forces(
  outC_Resistance_force_External_forces *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Resistance_force_init_External_forces(
  outC_Resistance_force_External_forces *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Resistance_force_External_forces_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Resistance_force_External_forces.h
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

