/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */
#ifndef _KCG_IMPORTED_FUNCTIONS_H_
#define _KCG_IMPORTED_FUNCTIONS_H_

#include "kcg_types.h"

#ifndef CosR32_mathext_mathextimpl
/* mathext::mathextimpl::CosR32/ */
extern kcg_float32 CosR32_mathext_mathextimpl(/* i/ */ kcg_float32 i);
#endif /* CosR32_mathext_mathextimpl */

#ifndef SinR32_mathext_mathextimpl
/* mathext::mathextimpl::SinR32/ */
extern kcg_float32 SinR32_mathext_mathextimpl(/* i/ */ kcg_float32 i);
#endif /* SinR32_mathext_mathextimpl */

#endif /* _KCG_IMPORTED_FUNCTIONS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_imported_functions.h
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

