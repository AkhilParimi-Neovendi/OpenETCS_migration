/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train_with_TandB_Lever.h"

/* Train_with_TandB_Lever/ */
void Train_with_TandB_Lever(
  inC_Train_with_TandB_Lever *inC,
  outC_Train_with_TandB_Lever *outC)
{
  LCF_Data noname;

  outC->_L10 = inC->TrainBrakeLeverInput;
  outC->_L25 = /* _L25= */(kcg_float32) outC->_L10;
  outC->_L24 = kcg_lit_float32(10.0);
  outC->_L20 = outC->_L25 / outC->_L24;
  outC->_L7 = inC->T_B_LeverInput;
  outC->_L15 = /* _L15= */(kcg_float32) outC->_L7;
  /* _L5=(Math_Operators::T_B_Lever#1)/ */
  T_B_Lever_Math_Operators(outC->_L15, &outC->Context_T_B_Lever_1);
  outC->_L5 = outC->Context_T_B_Lever_1.TractionForce;
  outC->_L6 = outC->Context_T_B_Lever_1.BrakingFroce;
  outC->_L8 = inC->HoldingBrakeSwitch;
  outC->_L14 = Default_trainbrake;
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = outC->_L20 != outC->_L12;
  /* _L13= */
  if (outC->_L11) {
    outC->_L13 = outC->_L20;
  }
  else {
    outC->_L13 = outC->_L14;
  }
  /* _L1=(Train#1)/ */
  Train(outC->_L5, outC->_L6, outC->_L8, outC->_L13, &outC->Context_Train_1);
  outC->_L1 = outC->Context_Train_1.Train_Speed;
  outC->_L2 = outC->Context_Train_1.Train_acceleration;
  kcg_copy_LCF_Data(&outC->_L3, &outC->Context_Train_1.LCF_Values);
  outC->_L4 = outC->Context_Train_1.Distance_Travelled_by_Train;
  outC->_L18 = /* _L18= */(kcg_int16) outC->_L4;
  outC->_L17 = /* _L17= */(kcg_int16) outC->_L1;
  outC->CurrentTrainAcceleration = outC->_L2;
  outC->Current_TrainSpeed = outC->_L17;
  kcg_copy_LCF_Data(&noname, &outC->_L3);
  outC->Distance_Covered = outC->_L18;
}

#ifndef KCG_USER_DEFINED_INIT
void Train_with_TandB_Lever_init(outC_Train_with_TandB_Lever *outC)
{
  kcg_size idx;

  outC->_L25 = kcg_lit_float32(0.0);
  outC->_L24 = kcg_lit_float32(0.0);
  outC->_L20 = kcg_lit_float32(0.0);
  outC->_L18 = kcg_lit_int16(0);
  outC->_L17 = kcg_lit_int16(0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_lit_float32(0.0);
  outC->_L13 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = kcg_true;
  outC->_L10 = kcg_lit_int8(0);
  outC->_L8 = kcg_true;
  outC->_L7 = kcg_lit_int8(0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  for (idx = 0; idx < 5; idx++) {
    outC->_L3.LCF_Values[idx] = kcg_lit_float32(0.0);
  }
  outC->_L4 = kcg_lit_float32(0.0);
  outC->CurrentTrainAcceleration = kcg_lit_float32(0.0);
  outC->Current_TrainSpeed = kcg_lit_int16(0);
  outC->Distance_Covered = kcg_lit_int16(0);
  /* _L1=(Train#1)/ */ Train_init(&outC->Context_Train_1);
  /* _L5=(Math_Operators::T_B_Lever#1)/ */
  T_B_Lever_init_Math_Operators(&outC->Context_T_B_Lever_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_with_TandB_Lever_reset(outC_Train_with_TandB_Lever *outC)
{
  /* _L1=(Train#1)/ */ Train_reset(&outC->Context_Train_1);
  /* _L5=(Math_Operators::T_B_Lever#1)/ */
  T_B_Lever_reset_Math_Operators(&outC->Context_T_B_Lever_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_with_TandB_Lever.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

