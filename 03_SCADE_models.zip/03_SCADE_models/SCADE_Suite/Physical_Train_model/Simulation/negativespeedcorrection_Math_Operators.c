/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "negativespeedcorrection_Math_Operators.h"

/* Math_Operators::negativespeedcorrection/ */
void negativespeedcorrection_Math_Operators(
  /* unitBraking/ */
  kcg_float32 unitBraking,
  /* speed/ */
  kcg_float32 speed,
  outC_negativespeedcorrection_Math_Operators *outC)
{
  outC->_L1 = unitBraking;
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L2 = speed;
  outC->_L6 = outC->_L2 <= outC->_L4;
  /* _L3= */
  if (outC->_L6) {
    outC->_L3 = outC->_L4;
  }
  else {
    outC->_L3 = outC->_L1;
  }
  outC->outbraking = outC->_L3;
}

#ifndef KCG_USER_DEFINED_INIT
void negativespeedcorrection_init_Math_Operators(
  outC_negativespeedcorrection_Math_Operators *outC)
{
  outC->_L6 = kcg_true;
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->outbraking = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void negativespeedcorrection_reset_Math_Operators(
  outC_negativespeedcorrection_Math_Operators *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** negativespeedcorrection_Math_Operators.c
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

