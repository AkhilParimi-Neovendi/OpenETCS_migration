/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */
#ifndef _Shift_Array_Math_Operators_H_
#define _Shift_Array_Math_Operators_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  array_float32_5 /* OutputArray/ */ OutputArray;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  array_float32_5 /* _L15/ */ _L15;
  array_float32_4 /* _L22/ */ _L22;
  array_float32_5 /* _L23/ */ _L23;
  array_float32_1 /* _L24/ */ _L24;
} outC_Shift_Array_Math_Operators;

/* ===========  node initialization and cycle functions  =========== */
/* Math_Operators::Shift_Array/ */
extern void Shift_Array_Math_Operators(
  /* InputArray/ */
  array_float32_5 *InputArray,
  outC_Shift_Array_Math_Operators *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Shift_Array_reset_Math_Operators(
  outC_Shift_Array_Math_Operators *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Shift_Array_init_Math_Operators(
  outC_Shift_Array_Math_Operators *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Shift_Array_Math_Operators_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Shift_Array_Math_Operators.h
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

