/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Physical_Train_model/Simulation/config.txt
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */
#ifndef _Train_H_
#define _Train_H_

#include "kcg_types.h"
#include "TrainConfiguration_And_LCF.h"
#include "Train_dynamics.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* Train_Speed/ */ Train_Speed;
  kcg_float32 /* Train_acceleration/ */ Train_acceleration;
  LCF_Data /* LCF_Values/ */ LCF_Values;
  kcg_float32 /* Distance_Travelled_by_Train/ */ Distance_Travelled_by_Train;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_float32 /* _L34/ */ _L34;
  kcg_float32 /* _L35/ */ _L35;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Train_dynamics /* _L35=(Train_dynamics#1)/ */ Context_Train_dynamics_1;
  outC_TrainConfiguration_And_LCF /* _L62=(TrainConfiguration_And_LCF)/ */ Context_TrainConfiguration_And_LCF;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L60/ */ _L60;
  kcg_float32 /* _L59/ */ _L59;
  array_float32_5 /* _L62/ */ _L62;
  kcg_float32 /* _L64/ */ _L64;
  kcg_float32 /* _L65/ */ _L65;
  kcg_float32 /* _L67/ */ _L67;
  kcg_float32 /* _L66/ */ _L66;
  kcg_bool /* _L69/ */ _L69;
  kcg_float32 /* _L70/ */ _L70;
  kcg_float32 /* _L71/ */ _L71;
  LCF_Data /* _L72/ */ _L72;
} outC_Train;

/* ===========  node initialization and cycle functions  =========== */
/* Train/ */
extern void Train(
  /* Traction_Force/ */
  kcg_float32 Traction_Force,
  /* Dynamic_Braking_Force/ */
  kcg_float32 Dynamic_Braking_Force,
  /* Holdingbrakestatus/ */
  kcg_bool Holdingbrakestatus,
  /* pneumaticbrakepressure/ */
  kcg_float32 pneumaticbrakepressure,
  outC_Train *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Train_reset(outC_Train *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Train_init(outC_Train *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Train_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train.h
** Generation date: 2023-11-01T15:57:31
*************************************************************$ */

