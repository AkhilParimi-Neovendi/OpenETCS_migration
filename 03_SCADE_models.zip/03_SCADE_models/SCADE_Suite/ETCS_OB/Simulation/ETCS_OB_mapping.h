/* ETCS_OB_mapping.h */
