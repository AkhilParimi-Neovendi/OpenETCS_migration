/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ETCS_OB/Simulation/config.txt
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "SetETCSMode.h"

/* SetETCSMode/ */
void SetETCSMode(inC_SetETCSMode *inC, outC_SetETCSMode *outC)
{
  ETCS_HMI_MsgHeaders noname;
  ETCS_HMI_Msgs _1_noname;
  ATO_modes _2_noname;
  /* temp_ETCSMode/ */
  ETCS_modes last_temp_ETCSMode;

  last_temp_ETCSMode = outC->temp_ETCSMode;
  outC->_L6 = last_temp_ETCSMode;
  kcg_copy_ETCSHMIPacket(&outC->_L1, &inC->Input);
  outC->_L3 = outC->_L1.currentETCSmode;
  outC->_L15 = outC->_L3 != outC->_L6;
  outC->_L7 = ETCS_unknownmode;
  outC->_L14 = outC->_L7 != outC->_L3;
  outC->_L16 = outC->_L14 & outC->_L15;
  /* _L13= */
  if (outC->_L16) {
    outC->_L13 = outC->_L3;
  }
  else {
    outC->_L13 = outC->_L6;
  }
  outC->temp_ETCSMode = outC->_L13;
  outC->_L12 = outC->temp_ETCSMode;
  outC->ETCSMode = outC->_L12;
  outC->_L2 = outC->_L1.currentATOmode;
  _2_noname = outC->_L2;
  outC->_L4 = outC->_L1.Message;
  _1_noname = outC->_L4;
  outC->_L5 = outC->_L1.Header;
  noname = outC->_L5;
}

#ifndef KCG_USER_DEFINED_INIT
void SetETCSMode_init(outC_SetETCSMode *outC)
{
  outC->_L14 = kcg_true;
  outC->_L15 = kcg_true;
  outC->_L16 = kcg_true;
  outC->_L13 = ETCS_unknownmode;
  outC->_L12 = ETCS_unknownmode;
  outC->_L7 = ETCS_unknownmode;
  outC->_L6 = ETCS_unknownmode;
  outC->_L2 = ATO_unknownmode;
  outC->_L3 = ETCS_unknownmode;
  outC->_L4 = Null;
  outC->_L5 = EmptyMsgHeader;
  outC->_L1.Header = EmptyMsgHeader;
  outC->_L1.Message = Null;
  outC->_L1.currentETCSmode = ETCS_unknownmode;
  outC->_L1.currentATOmode = ATO_unknownmode;
  outC->ETCSMode = ETCS_unknownmode;
  outC->temp_ETCSMode = ETCS_unknownmode;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void SetETCSMode_reset(outC_SetETCSMode *outC)
{
  outC->temp_ETCSMode = ETCS_unknownmode;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SetETCSMode.c
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */

