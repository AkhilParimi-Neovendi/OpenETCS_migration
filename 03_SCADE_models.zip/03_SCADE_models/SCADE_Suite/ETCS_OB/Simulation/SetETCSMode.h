/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ETCS_OB/Simulation/config.txt
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */
#ifndef _SetETCSMode_H_
#define _SetETCSMode_H_

#include "kcg_types.h"

/* ========================  input structure  ====================== */
typedef struct { ETCSHMIPacket /* Input/ */ Input; } inC_SetETCSMode;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ETCS_modes /* ETCSMode/ */ ETCSMode;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  ETCS_modes /* temp_ETCSMode/ */ temp_ETCSMode;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  ETCSHMIPacket /* _L1/ */ _L1;
  ETCS_HMI_MsgHeaders /* _L5/ */ _L5;
  ETCS_HMI_Msgs /* _L4/ */ _L4;
  ETCS_modes /* _L3/ */ _L3;
  ATO_modes /* _L2/ */ _L2;
  ETCS_modes /* _L6/ */ _L6;
  ETCS_modes /* _L7/ */ _L7;
  ETCS_modes /* _L12/ */ _L12;
  ETCS_modes /* _L13/ */ _L13;
  kcg_bool /* _L16/ */ _L16;
  kcg_bool /* _L15/ */ _L15;
  kcg_bool /* _L14/ */ _L14;
} outC_SetETCSMode;

/* ===========  node initialization and cycle functions  =========== */
/* SetETCSMode/ */
extern void SetETCSMode(inC_SetETCSMode *inC, outC_SetETCSMode *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void SetETCSMode_reset(outC_SetETCSMode *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void SetETCSMode_init(outC_SetETCSMode *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _SetETCSMode_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SetETCSMode.h
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */

