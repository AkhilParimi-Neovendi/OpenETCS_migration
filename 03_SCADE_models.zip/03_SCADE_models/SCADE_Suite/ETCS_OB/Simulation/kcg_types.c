/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ETCS_OB/Simulation/config.txt
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */

#include "kcg_types.h"

#ifdef kcg_use_ETCSHMIPacket
kcg_bool kcg_comp_ETCSHMIPacket(ETCSHMIPacket *kcg_c1, ETCSHMIPacket *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->currentATOmode == kcg_c2->currentATOmode);
  kcg_equ = kcg_equ & (kcg_c1->currentETCSmode == kcg_c2->currentETCSmode);
  kcg_equ = kcg_equ & (kcg_c1->Message == kcg_c2->Message);
  kcg_equ = kcg_equ & (kcg_c1->Header == kcg_c2->Header);
  return kcg_equ;
}
#endif /* kcg_use_ETCSHMIPacket */

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.c
** Generation date: 2023-10-24T15:53:25
*************************************************************$ */

