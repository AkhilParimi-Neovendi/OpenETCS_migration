/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _F_gradient_External_forces_H_
#define _F_gradient_External_forces_H_

#include "kcg_types.h"
#include "kcg_imported_functions.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* F_Gradient/ */ F_Gradient;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L5/ */ _L5;
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L3/ */ _L3;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
} outC_F_gradient_External_forces;

/* ===========  node initialization and cycle functions  =========== */
/* External_forces::F_gradient/ */
extern void F_gradient_External_forces(
  /* Mass/ */
  kcg_float32 Mass,
  outC_F_gradient_External_forces *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void F_gradient_reset_External_forces(
  outC_F_gradient_External_forces *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void F_gradient_init_External_forces(
  outC_F_gradient_External_forces *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _F_gradient_External_forces_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** F_gradient_External_forces.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

