/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _Train_dynamics_H_
#define _Train_dynamics_H_

#include "kcg_types.h"
#include "Distance_Calculation.h"
#include "Resistance_force_External_forces.h"
#include "negativespeed_Op.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* train_speed/ */ train_speed;
  kcg_float32 /* Distance_Travelled/ */ Distance_Travelled;
  kcg_float32 /* train_acceleration/ */ train_acceleration;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_float32 /* _L29/ */ _L29;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Distance_Calculation /* _L32=(Distance_Calculation#1)/ */ Context_Distance_Calculation_1;
  outC_negativespeed_Op /* _L28=(Op::negativespeed#1)/ */ Context_negativespeed_1;
  outC_Resistance_force_External_forces /* _L30=(External_forces::Resistance_force#1)/ */ Context_Resistance_force_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* @1/Output1/ */ Output1_NumericToFloat32_3_int32;
  kcg_int32 /* @1/Input1/ */ Input1_NumericToFloat32_3_int32;
  kcg_float32 /* @1/_L2/ */ _L2_NumericToFloat32_3_int32;
  kcg_int32 /* @1/_L1/ */ _L1_NumericToFloat32_3_int32;
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L3/ */ _L3;
  kcg_float32 /* _L4/ */ _L4;
  kcg_float32 /* _L5/ */ _L5;
  kcg_float32 /* _L6/ */ _L6;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
  kcg_float32 /* _L10/ */ _L10;
  kcg_float32 /* _L15/ */ _L15;
  kcg_float32 /* _L24/ */ _L24;
  kcg_int32 /* _L25/ */ _L25;
  kcg_float32 /* _L28/ */ _L28;
  kcg_float32 /* _L30/ */ _L30;
  kcg_float32 /* _L31/ */ _L31;
  kcg_float32 /* _L32/ */ _L32;
} outC_Train_dynamics;

/* ===========  node initialization and cycle functions  =========== */
/* Train_dynamics/ */
extern void Train_dynamics(
  /* total_traction_force/ */
  kcg_float32 total_traction_force,
  /* total_braking_force/ */
  kcg_float32 total_braking_force,
  outC_Train_dynamics *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Train_dynamics_reset(outC_Train_dynamics *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Train_dynamics_init(outC_Train_dynamics *outC);
#endif /* KCG_USER_DEFINED_INIT */

/*
  Expanded instances for: Train_dynamics/
  @1: (math::NumericToFloat32#3)
*/

#endif /* _Train_dynamics_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_dynamics.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

