/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "T_B_Lever_Op.h"

/* Op::T_B_Lever/ */
void T_B_Lever_Op(
  /* LeverInput/ */
  kcg_float32 LeverInput,
  outC_T_B_Lever_Op *outC)
{
  outC->_L37 = LeverInput;
  outC->_L27 = kcg_lit_float32(-1.0);
  outC->_L25 = outC->_L27 * outC->_L37;
  outC->_L23 = kcg_lit_float32(0.0);
  outC->_L20 = outC->_L37 >= outC->_L23;
  /* _L24= */
  if (outC->_L20) {
    outC->_L24 = outC->_L23;
  }
  else {
    outC->_L24 = outC->_L25;
  }
  /* _L41=(Op::ForceGradient#3)/ */
  ForceGradient_Op(outC->_L24, &outC->Context_ForceGradient_3);
  outC->_L41 = outC->Context_ForceGradient_3.Output1;
  /* _L19= */
  if (outC->_L20) {
    outC->_L19 = outC->_L37;
  }
  else {
    outC->_L19 = outC->_L23;
  }
  /* _L40=(Op::ForceGradient#2)/ */
  ForceGradient_Op(outC->_L19, &outC->Context_ForceGradient_2);
  outC->_L40 = outC->Context_ForceGradient_2.Output1;
  outC->BrakingFroce = outC->_L41;
  outC->TractionForce = outC->_L40;
}

#ifndef KCG_USER_DEFINED_INIT
void T_B_Lever_init_Op(outC_T_B_Lever_Op *outC)
{
  outC->_L41 = kcg_lit_float32(0.0);
  outC->_L40 = kcg_lit_float32(0.0);
  outC->_L37 = kcg_lit_float32(0.0);
  outC->_L27 = kcg_lit_float32(0.0);
  outC->_L25 = kcg_lit_float32(0.0);
  outC->_L24 = kcg_lit_float32(0.0);
  outC->_L23 = kcg_lit_float32(0.0);
  outC->_L20 = kcg_true;
  outC->_L19 = kcg_lit_float32(0.0);
  outC->BrakingFroce = kcg_lit_float32(0.0);
  outC->TractionForce = kcg_lit_float32(0.0);
  /* _L40=(Op::ForceGradient#2)/ */
  ForceGradient_init_Op(&outC->Context_ForceGradient_2);
  /* _L41=(Op::ForceGradient#3)/ */
  ForceGradient_init_Op(&outC->Context_ForceGradient_3);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void T_B_Lever_reset_Op(outC_T_B_Lever_Op *outC)
{
  /* _L40=(Op::ForceGradient#2)/ */
  ForceGradient_reset_Op(&outC->Context_ForceGradient_2);
  /* _L41=(Op::ForceGradient#3)/ */
  ForceGradient_reset_Op(&outC->Context_ForceGradient_3);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** T_B_Lever_Op.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

