/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train_Driver.h"

/* Train_Driver/ */
void Train_Driver(inC_Train_Driver *inC, outC_Train_Driver *outC)
{
  /* Local1/ */
  kcg_int8 Local1_partial;
  /* Local2/ */
  kcg_bool Local2_partial;
  /* Local3/ */
  kcg_int8 Local3_partial;
  /* Local1/ */
  kcg_int8 _1_Local1_partial;
  /* Local2/ */
  kcg_bool _2_Local2_partial;
  /* Local3/ */
  kcg_int8 _3_Local3_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket to_ETCS_OB_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket _4_to_ETCS_OB_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket _5_to_ETCS_OB_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket _6_to_ETCS_OB_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket _7_to_ETCS_OB_partial;
  /* to_ETCS_OB/ */
  ETCSHMIPacket _8_to_ETCS_OB_partial;

  outC->_L5 = inC->ATORSCSwitch_Position;
  outC->Local_OverrideSwitchPosition = outC->_L5;
  outC->IfBlock2_clock = outC->Local_OverrideSwitchPosition == kcg_lit_int8(0);
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L3_then_IfBlock2 = inC->TrainBrakeLever;
    Local3_partial = outC->_L3_then_IfBlock2;
    outC->Local3 = Local3_partial;
  }
  else {
    outC->_L7_else_IfBlock2 = kcg_lit_int8(34);
    _3_Local3_partial = outC->_L7_else_IfBlock2;
    outC->Local3 = _3_Local3_partial;
  }
  outC->_L44 = outC->Local3;
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L1_then_IfBlock2 = inC->Apply_HoldingBrake;
    Local2_partial = outC->_L1_then_IfBlock2;
    outC->Local2 = Local2_partial;
  }
  else {
    outC->_L6_else_IfBlock2 = kcg_true;
    _2_Local2_partial = outC->_L6_else_IfBlock2;
    outC->Local2 = _2_Local2_partial;
  }
  outC->_L43 = outC->Local2;
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L4_then_IfBlock2 = inC->ThrottleBrakeLever_Position;
    Local1_partial = outC->_L4_then_IfBlock2;
    outC->Local1 = Local1_partial;
  }
  else {
    outC->_L5_else_IfBlock2 = kcg_lit_int8(0);
    _1_Local1_partial = outC->_L5_else_IfBlock2;
    outC->Local1 = _1_Local1_partial;
  }
  outC->_L42 = outC->Local1;
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_Train(
    outC->_L42,
    outC->_L43,
    outC->_L44,
    &outC->Context_Train_Physics_3);
  kcg_copy_Tain_Physics_Outputs(
    &outC->_L41,
    &outC->Context_Train_Physics_3.Train_Outputs);
  kcg_copy_Tain_Physics_Outputs(&outC->Train_Physics_Output, &outC->_L41);
  kcg_copy_ETCSHMIPacket(&outC->_L2, &inC->from_ETCS_OB);
  outC->_L32 = inC->SendMessage;
  /* _L39=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_ETCSHMI_Functions(
    &outC->_L2,
    outC->_L32,
    &outC->Context_Read_and_Send_ETCSOB_Data);
  outC->_L39 = outC->Context_Read_and_Send_ETCSOB_Data.Out_ETCS_HMI_Msg;
  kcg_copy_array_char_30(
    &outC->_L40,
    &outC->Context_Read_and_Send_ETCSOB_Data.HMI_Display_Textbox);
  kcg_copy_array_char_30(&outC->ETCSHMI_TextBox, &outC->_L40);
  outC->HMItoETCSOB_Message = outC->_L39;
  outC->IfBlock1_clock = inC->ETCS_FS_mode_button;
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    outC->_L8_then_IfBlock1 = outC->HMItoETCSOB_Message;
    outC->_L5_then_IfBlock1 = kcg_lit_int8(0);
    outC->_L2_then_IfBlock1 = kcg_lit_int8(1);
    outC->_L7_then_IfBlock1 = kcg_lit_int8(0);
    outC->_L4_then_IfBlock1.Header = outC->_L5_then_IfBlock1;
    outC->_L4_then_IfBlock1.Message = outC->_L8_then_IfBlock1;
    outC->_L4_then_IfBlock1.currentETCSmode = outC->_L2_then_IfBlock1;
    outC->_L4_then_IfBlock1.currentATOmode = outC->_L7_then_IfBlock1;
    kcg_copy_ETCSHMIPacket(&to_ETCS_OB_partial, &outC->_L4_then_IfBlock1);
    kcg_copy_ETCSHMIPacket(&outC->to_ETCS_OB, &to_ETCS_OB_partial);
  }
  else {
    outC->else_clock_IfBlock1 = inC->ATO_GoA2_mode_button;
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      outC->_L17_then_else_IfBlock1 = outC->HMItoETCSOB_Message;
      outC->_L16_then_else_IfBlock1 = kcg_lit_int8(0);
      outC->_L14_then_else_IfBlock1 = kcg_lit_int8(0);
      outC->_L12_then_else_IfBlock1 = kcg_lit_int8(1);
      outC->_L13_then_else_IfBlock1.Header = outC->_L14_then_else_IfBlock1;
      outC->_L13_then_else_IfBlock1.Message = outC->_L17_then_else_IfBlock1;
      outC->_L13_then_else_IfBlock1.currentETCSmode = outC->_L16_then_else_IfBlock1;
      outC->_L13_then_else_IfBlock1.currentATOmode = outC->_L12_then_else_IfBlock1;
      kcg_copy_ETCSHMIPacket(&_8_to_ETCS_OB_partial, &outC->_L13_then_else_IfBlock1);
      kcg_copy_ETCSHMIPacket(&_4_to_ETCS_OB_partial, &_8_to_ETCS_OB_partial);
    }
    else {
      outC->else_clock_else_IfBlock1 = inC->ATO_GoA4_mode_button;
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L13_then_else_else_IfBlock1 = outC->HMItoETCSOB_Message;
        outC->_L10_then_else_else_IfBlock1 = kcg_lit_int8(0);
        outC->_L8_then_else_else_IfBlock1 = kcg_lit_int8(0);
        outC->_L12_then_else_else_IfBlock1 = kcg_lit_int8(2);
        outC->_L11_then_else_else_IfBlock1.Header = outC->_L10_then_else_else_IfBlock1;
        outC->_L11_then_else_else_IfBlock1.Message = outC->_L13_then_else_else_IfBlock1;
        outC->_L11_then_else_else_IfBlock1.currentETCSmode =
          outC->_L8_then_else_else_IfBlock1;
        outC->_L11_then_else_else_IfBlock1.currentATOmode =
          outC->_L12_then_else_else_IfBlock1;
        kcg_copy_ETCSHMIPacket(
          &_5_to_ETCS_OB_partial,
          &outC->_L11_then_else_else_IfBlock1);
        kcg_copy_ETCSHMIPacket(&_7_to_ETCS_OB_partial, &_5_to_ETCS_OB_partial);
      }
      else {
        outC->_L24_else_else_else_IfBlock1 = outC->HMItoETCSOB_Message;
        outC->_L20_else_else_else_IfBlock1 = kcg_lit_int8(2);
        outC->_L14_else_else_else_IfBlock1 = kcg_lit_int8(0);
        outC->_L21_else_else_else_IfBlock1.Header = outC->_L20_else_else_else_IfBlock1;
        outC->_L21_else_else_else_IfBlock1.Message = outC->_L24_else_else_else_IfBlock1;
        outC->_L21_else_else_else_IfBlock1.currentETCSmode =
          outC->_L14_else_else_else_IfBlock1;
        outC->_L21_else_else_else_IfBlock1.currentATOmode =
          outC->_L14_else_else_else_IfBlock1;
        kcg_copy_ETCSHMIPacket(
          &_6_to_ETCS_OB_partial,
          &outC->_L21_else_else_else_IfBlock1);
        kcg_copy_ETCSHMIPacket(&_7_to_ETCS_OB_partial, &_6_to_ETCS_OB_partial);
      }
      kcg_copy_ETCSHMIPacket(&_4_to_ETCS_OB_partial, &_7_to_ETCS_OB_partial);
    }
    kcg_copy_ETCSHMIPacket(&outC->to_ETCS_OB, &_4_to_ETCS_OB_partial);
  }
  kcg_copy_ExternalindicatorStates(&outC->_L4, &inC->from_FVA);
  kcg_copy_ExternalindicatorStates(&outC->External_ATORSC_Status, &outC->_L4);
  outC->to_FVA = outC->_L5;
}

#ifndef KCG_USER_DEFINED_INIT
void Train_Driver_init(outC_Train_Driver *outC)
{
  kcg_size idx;
  kcg_size idx1;

  outC->_L44 = kcg_lit_int8(0);
  outC->_L43 = kcg_true;
  outC->_L42 = kcg_lit_int8(0);
  outC->_L41.Distance_Covered = kcg_lit_int16(0);
  outC->_L41.Train_Speed = kcg_lit_int16(0);
  outC->_L41.Train_Acceleration = kcg_lit_float32(0.0);
  for (idx = 0; idx < 30; idx++) {
    outC->_L40[idx] = ' ';
  }
  outC->_L39 = kcg_lit_int8(0);
  outC->_L32 = kcg_true;
  outC->_L5 = kcg_lit_int8(0);
  outC->_L4.IndicatorState = kcg_lit_int8(0);
  outC->_L4.RedLight = kcg_true;
  outC->_L4.GreenLight = kcg_true;
  outC->_L2.Header = kcg_lit_int8(0);
  outC->_L2.Message = kcg_lit_int8(0);
  outC->_L2.currentETCSmode = kcg_lit_int8(0);
  outC->_L2.currentATOmode = kcg_lit_int8(0);
  outC->Local3 = kcg_lit_int8(0);
  outC->Local2 = kcg_true;
  outC->Local1 = kcg_lit_int8(0);
  outC->Local_OverrideSwitchPosition = kcg_lit_int8(0);
  outC->HMItoETCSOB_Message = kcg_lit_int8(0);
  outC->IfBlock1_clock = kcg_true;
  outC->IfBlock2_clock = kcg_true;
  outC->_L17_then_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L12_then_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L13_then_else_IfBlock1.Header = kcg_lit_int8(0);
  outC->_L13_then_else_IfBlock1.Message = kcg_lit_int8(0);
  outC->_L13_then_else_IfBlock1.currentETCSmode = kcg_lit_int8(0);
  outC->_L13_then_else_IfBlock1.currentATOmode = kcg_lit_int8(0);
  outC->_L14_then_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L16_then_else_IfBlock1 = kcg_lit_int8(0);
  outC->else_clock_else_IfBlock1 = kcg_true;
  outC->_L21_else_else_else_IfBlock1.Header = kcg_lit_int8(0);
  outC->_L21_else_else_else_IfBlock1.Message = kcg_lit_int8(0);
  outC->_L21_else_else_else_IfBlock1.currentETCSmode = kcg_lit_int8(0);
  outC->_L21_else_else_else_IfBlock1.currentATOmode = kcg_lit_int8(0);
  outC->_L20_else_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L14_else_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L24_else_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L12_then_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L11_then_else_else_IfBlock1.Header = kcg_lit_int8(0);
  outC->_L11_then_else_else_IfBlock1.Message = kcg_lit_int8(0);
  outC->_L11_then_else_else_IfBlock1.currentETCSmode = kcg_lit_int8(0);
  outC->_L11_then_else_else_IfBlock1.currentATOmode = kcg_lit_int8(0);
  outC->_L10_then_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L8_then_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L13_then_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->else_clock_IfBlock1 = kcg_true;
  outC->_L7_then_IfBlock1 = kcg_lit_int8(0);
  outC->_L5_then_IfBlock1 = kcg_lit_int8(0);
  outC->_L4_then_IfBlock1.Header = kcg_lit_int8(0);
  outC->_L4_then_IfBlock1.Message = kcg_lit_int8(0);
  outC->_L4_then_IfBlock1.currentETCSmode = kcg_lit_int8(0);
  outC->_L4_then_IfBlock1.currentATOmode = kcg_lit_int8(0);
  outC->_L2_then_IfBlock1 = kcg_lit_int8(0);
  outC->_L8_then_IfBlock1 = kcg_lit_int8(0);
  outC->_L5_else_IfBlock2 = kcg_lit_int8(0);
  outC->_L6_else_IfBlock2 = kcg_true;
  outC->_L7_else_IfBlock2 = kcg_lit_int8(0);
  outC->_L4_then_IfBlock2 = kcg_lit_int8(0);
  outC->_L3_then_IfBlock2 = kcg_lit_int8(0);
  outC->_L1_then_IfBlock2 = kcg_true;
  outC->Train_Physics_Output.Distance_Covered = kcg_lit_int16(0);
  outC->Train_Physics_Output.Train_Speed = kcg_lit_int16(0);
  outC->Train_Physics_Output.Train_Acceleration = kcg_lit_float32(0.0);
  for (idx1 = 0; idx1 < 30; idx1++) {
    outC->ETCSHMI_TextBox[idx1] = ' ';
  }
  outC->External_ATORSC_Status.IndicatorState = kcg_lit_int8(0);
  outC->External_ATORSC_Status.RedLight = kcg_true;
  outC->External_ATORSC_Status.GreenLight = kcg_true;
  outC->to_ETCS_OB.Header = kcg_lit_int8(0);
  outC->to_ETCS_OB.Message = kcg_lit_int8(0);
  outC->to_ETCS_OB.currentETCSmode = kcg_lit_int8(0);
  outC->to_ETCS_OB.currentATOmode = kcg_lit_int8(0);
  outC->to_FVA = kcg_lit_int8(0);
  /* _L39=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_init_ETCSHMI_Functions(
    &outC->Context_Read_and_Send_ETCSOB_Data);
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_init_Train(&outC->Context_Train_Physics_3);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_Driver_reset(outC_Train_Driver *outC)
{
  /* _L39=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_reset_ETCSHMI_Functions(
    &outC->Context_Read_and_Send_ETCSOB_Data);
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_reset_Train(&outC->Context_Train_Physics_3);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Driver.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

