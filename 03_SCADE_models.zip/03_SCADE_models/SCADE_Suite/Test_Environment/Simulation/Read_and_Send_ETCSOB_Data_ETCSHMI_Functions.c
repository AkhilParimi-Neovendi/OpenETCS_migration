/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Read_and_Send_ETCSOB_Data_ETCSHMI_Functions.h"

/* ETCSHMI_Functions::Read_and_Send_ETCSOB_Data/ */
void Read_and_Send_ETCSOB_Data_ETCSHMI_Functions(
  /* InputData/ */
  ETCSHMIPacket *InputData,
  /* Input2/ */
  kcg_bool Input2,
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC)
{
  ETCS_modes noname;
  ATO_modes _1_noname;

  outC->_L19[0] = 'E';
  outC->_L19[1] = 'N';
  outC->_L19[2] = 'T';
  outC->_L19[3] = 'E';
  outC->_L19[4] = 'R';
  outC->_L19[5] = ' ';
  outC->_L19[6] = 'T';
  outC->_L19[7] = 'R';
  outC->_L19[8] = 'A';
  outC->_L19[9] = 'I';
  outC->_L19[10] = 'N';
  outC->_L19[11] = ' ';
  outC->_L19[12] = 'D';
  outC->_L19[13] = 'A';
  outC->_L19[14] = 'T';
  outC->_L19[15] = 'A';
  outC->_L19[16] = ' ';
  outC->_L19[17] = ' ';
  outC->_L19[18] = ' ';
  outC->_L19[19] = ' ';
  outC->_L19[20] = ' ';
  outC->_L19[21] = ' ';
  outC->_L19[22] = ' ';
  outC->_L19[23] = ' ';
  outC->_L19[24] = ' ';
  outC->_L19[25] = ' ';
  outC->_L19[26] = ' ';
  outC->_L19[27] = ' ';
  outC->_L19[28] = ' ';
  outC->_L19[29] = ' ';
  outC->_L24[0] = ' ';
  outC->_L24[1] = ' ';
  outC->_L24[2] = ' ';
  outC->_L24[3] = ' ';
  outC->_L24[4] = ' ';
  outC->_L24[5] = ' ';
  outC->_L24[6] = ' ';
  outC->_L24[7] = ' ';
  outC->_L24[8] = ' ';
  outC->_L24[9] = ' ';
  outC->_L24[10] = ' ';
  outC->_L24[11] = ' ';
  outC->_L24[12] = ' ';
  outC->_L24[13] = ' ';
  outC->_L24[14] = ' ';
  outC->_L24[15] = ' ';
  outC->_L24[16] = ' ';
  outC->_L24[17] = ' ';
  outC->_L24[18] = ' ';
  outC->_L24[19] = ' ';
  outC->_L24[20] = ' ';
  outC->_L24[21] = ' ';
  outC->_L24[22] = ' ';
  outC->_L24[23] = ' ';
  outC->_L24[24] = ' ';
  outC->_L24[25] = ' ';
  outC->_L24[26] = ' ';
  outC->_L24[27] = ' ';
  outC->_L24[28] = ' ';
  outC->_L24[29] = ' ';
  outC->_L23[0] = 'A';
  outC->_L23[1] = 'C';
  outC->_L23[2] = 'K';
  outC->_L23[3] = 'N';
  outC->_L23[4] = 'O';
  outC->_L23[5] = 'W';
  outC->_L23[6] = 'L';
  outC->_L23[7] = 'E';
  outC->_L23[8] = 'D';
  outC->_L23[9] = 'G';
  outC->_L23[10] = 'E';
  outC->_L23[11] = ' ';
  outC->_L23[12] = 'A';
  outC->_L23[13] = 'T';
  outC->_L23[14] = 'O';
  outC->_L23[15] = ' ';
  outC->_L23[16] = ' ';
  outC->_L23[17] = 'D';
  outC->_L23[18] = 'A';
  outC->_L23[19] = 'T';
  outC->_L23[20] = 'A';
  outC->_L23[21] = ' ';
  outC->_L23[22] = ' ';
  outC->_L23[23] = ' ';
  outC->_L23[24] = ' ';
  outC->_L23[25] = ' ';
  outC->_L23[26] = ' ';
  outC->_L23[27] = ' ';
  outC->_L23[28] = ' ';
  outC->_L23[29] = ' ';
  outC->_L22[0] = 'A';
  outC->_L22[1] = 'C';
  outC->_L22[2] = 'K';
  outC->_L22[3] = 'N';
  outC->_L22[4] = 'O';
  outC->_L22[5] = 'W';
  outC->_L22[6] = 'L';
  outC->_L22[7] = 'E';
  outC->_L22[8] = 'D';
  outC->_L22[9] = 'G';
  outC->_L22[10] = 'E';
  outC->_L22[11] = ' ';
  outC->_L22[12] = 'E';
  outC->_L22[13] = 'T';
  outC->_L22[14] = 'C';
  outC->_L22[15] = 'S';
  outC->_L22[16] = ' ';
  outC->_L22[17] = 'D';
  outC->_L22[18] = 'A';
  outC->_L22[19] = 'T';
  outC->_L22[20] = 'A';
  outC->_L22[21] = ' ';
  outC->_L22[22] = ' ';
  outC->_L22[23] = ' ';
  outC->_L22[24] = ' ';
  outC->_L22[25] = ' ';
  outC->_L22[26] = ' ';
  outC->_L22[27] = ' ';
  outC->_L22[28] = ' ';
  outC->_L22[29] = ' ';
  outC->_L10 = kcg_lit_int8(0);
  kcg_copy_ETCSHMIPacket(&outC->_L1, InputData);
  outC->_L4 = outC->_L1.Message;
  outC->_L3 = outC->_L1.Header;
  outC->_L9 = kcg_lit_int8(1);
  outC->_L8 = outC->_L9 == outC->_L3;
  /* _L7= */
  if (outC->_L8) {
    outC->_L7 = outC->_L4;
  }
  else {
    outC->_L7 = outC->_L10;
  }
  /* _L18= */
  switch (outC->_L7) {
    case kcg_lit_int8(1) :
      kcg_copy_array_char_30(&outC->_L18, &outC->_L19);
      break;
    case kcg_lit_int8(3) :
      kcg_copy_array_char_30(&outC->_L18, &outC->_L22);
      break;
    case kcg_lit_int8(5) :
      kcg_copy_array_char_30(&outC->_L18, &outC->_L23);
      break;
    default :
      kcg_copy_array_char_30(&outC->_L18, &outC->_L24);
      break;
  }
  kcg_copy_array_char_30(&outC->HMI_Display_Textbox, &outC->_L18);
  outC->_L17 = kcg_lit_int8(6);
  outC->_L16 = kcg_lit_int8(4);
  outC->_L15 = kcg_lit_int8(0);
  outC->_L14 = kcg_lit_int8(2);
  /* _L13= */
  switch (outC->_L7) {
    case kcg_lit_int8(1) :
      outC->_L13 = outC->_L14;
      break;
    case kcg_lit_int8(3) :
      outC->_L13 = outC->_L16;
      break;
    case kcg_lit_int8(5) :
      outC->_L13 = outC->_L17;
      break;
    default :
      outC->_L13 = outC->_L15;
      break;
  }
  outC->_L12 = kcg_lit_int8(0);
  outC->_L2 = Input2;
  /* _L11= */
  if (outC->_L2) {
    outC->_L11 = outC->_L13;
  }
  else {
    outC->_L11 = outC->_L12;
  }
  outC->_L6 = outC->_L1.currentATOmode;
  _1_noname = outC->_L6;
  outC->_L5 = outC->_L1.currentETCSmode;
  noname = outC->_L5;
  outC->Out_ETCS_HMI_Msg = outC->_L11;
}

#ifndef KCG_USER_DEFINED_INIT
void Read_and_Send_ETCSOB_Data_init_ETCSHMI_Functions(
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;
  kcg_size idx3;
  kcg_size idx4;
  kcg_size idx5;

  for (idx = 0; idx < 30; idx++) {
    outC->_L19[idx] = ' ';
  }
  for (idx1 = 0; idx1 < 30; idx1++) {
    outC->_L24[idx1] = ' ';
  }
  for (idx2 = 0; idx2 < 30; idx2++) {
    outC->_L23[idx2] = ' ';
  }
  for (idx3 = 0; idx3 < 30; idx3++) {
    outC->_L22[idx3] = ' ';
  }
  for (idx4 = 0; idx4 < 30; idx4++) {
    outC->_L18[idx4] = ' ';
  }
  outC->_L17 = kcg_lit_int8(0);
  outC->_L16 = kcg_lit_int8(0);
  outC->_L15 = kcg_lit_int8(0);
  outC->_L14 = kcg_lit_int8(0);
  outC->_L13 = kcg_lit_int8(0);
  outC->_L12 = kcg_lit_int8(0);
  outC->_L11 = kcg_lit_int8(0);
  outC->_L10 = kcg_lit_int8(0);
  outC->_L9 = kcg_lit_int8(0);
  outC->_L8 = kcg_true;
  outC->_L7 = kcg_lit_int8(0);
  outC->_L6 = kcg_lit_int8(0);
  outC->_L5 = kcg_lit_int8(0);
  outC->_L4 = kcg_lit_int8(0);
  outC->_L3 = kcg_lit_int8(0);
  outC->_L1.Header = kcg_lit_int8(0);
  outC->_L1.Message = kcg_lit_int8(0);
  outC->_L1.currentETCSmode = kcg_lit_int8(0);
  outC->_L1.currentATOmode = kcg_lit_int8(0);
  outC->_L2 = kcg_true;
  for (idx5 = 0; idx5 < 30; idx5++) {
    outC->HMI_Display_Textbox[idx5] = ' ';
  }
  outC->Out_ETCS_HMI_Msg = kcg_lit_int8(0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Read_and_Send_ETCSOB_Data_reset_ETCSHMI_Functions(
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Read_and_Send_ETCSOB_Data_ETCSHMI_Functions.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

