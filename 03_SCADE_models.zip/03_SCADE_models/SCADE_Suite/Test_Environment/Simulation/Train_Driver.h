/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _Train_Driver_H_
#define _Train_Driver_H_

#include "kcg_types.h"
#include "Train_Physics_Train.h"
#include "Read_and_Send_ETCSOB_Data_ETCSHMI_Functions.h"

/* ========================  input structure  ====================== */
typedef struct {
  ExternalindicatorStates /* from_FVA/ */ from_FVA;
  ETCSHMIPacket /* from_ETCS_OB/ */ from_ETCS_OB;
  OverrideSwitchPosition /* ATORSCSwitch_Position/ */ ATORSCSwitch_Position;
  kcg_bool /* SendMessage/ */ SendMessage;
  kcg_bool /* ATO_GoA4_mode_button/ */ ATO_GoA4_mode_button;
  kcg_bool /* ATO_GoA2_mode_button/ */ ATO_GoA2_mode_button;
  kcg_bool /* ETCS_FS_mode_button/ */ ETCS_FS_mode_button;
  kcg_int8 /* ThrottleBrakeLever_Position/ */ ThrottleBrakeLever_Position;
  kcg_bool /* Apply_HoldingBrake/ */ Apply_HoldingBrake;
  kcg_int8 /* TrainBrakeLever/ */ TrainBrakeLever;
} inC_Train_Driver;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  OverrideSwitchPosition /* to_FVA/ */ to_FVA;
  ETCSHMIPacket /* to_ETCS_OB/ */ to_ETCS_OB;
  ExternalindicatorStates /* External_ATORSC_Status/ */ External_ATORSC_Status;
  array_char_30 /* ETCSHMI_TextBox/ */ ETCSHMI_TextBox;
  Tain_Physics_Outputs /* Train_Physics_Output/ */ Train_Physics_Output;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions /* _L39=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */ Context_Read_and_Send_ETCSOB_Data;
  outC_Train_Physics_Train /* _L41=(Train::Train_Physics#3)/ */ Context_Train_Physics_3;
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* IfBlock1:else: */ else_clock_IfBlock1;
  kcg_bool /* IfBlock1:else:else: */ else_clock_else_IfBlock1;
  kcg_bool /* IfBlock2: */ IfBlock2_clock;
  kcg_bool /* IfBlock1: */ IfBlock1_clock;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* IfBlock2:then:_L1/ */ _L1_then_IfBlock2;
  kcg_int8 /* IfBlock2:then:_L3/ */ _L3_then_IfBlock2;
  kcg_int8 /* IfBlock2:then:_L4/ */ _L4_then_IfBlock2;
  kcg_int8 /* IfBlock2:else:_L7/ */ _L7_else_IfBlock2;
  kcg_bool /* IfBlock2:else:_L6/ */ _L6_else_IfBlock2;
  kcg_int8 /* IfBlock2:else:_L5/ */ _L5_else_IfBlock2;
  ETCS_HMI_Msgs /* IfBlock1:then:_L8/ */ _L8_then_IfBlock1;
  ETCS_modes /* IfBlock1:then:_L2/ */ _L2_then_IfBlock1;
  ETCSHMIPacket /* IfBlock1:then:_L4/ */ _L4_then_IfBlock1;
  ETCS_HMI_MsgHeaders /* IfBlock1:then:_L5/ */ _L5_then_IfBlock1;
  ATO_modes /* IfBlock1:then:_L7/ */ _L7_then_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:else:then:_L13/ */ _L13_then_else_else_IfBlock1;
  ETCS_modes /* IfBlock1:else:else:then:_L8/ */ _L8_then_else_else_IfBlock1;
  ETCS_HMI_MsgHeaders /* IfBlock1:else:else:then:_L10/ */ _L10_then_else_else_IfBlock1;
  ETCSHMIPacket /* IfBlock1:else:else:then:_L11/ */ _L11_then_else_else_IfBlock1;
  ATO_modes /* IfBlock1:else:else:then:_L12/ */ _L12_then_else_else_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:else:else:_L24/ */ _L24_else_else_else_IfBlock1;
  ETCS_modes /* IfBlock1:else:else:else:_L14/ */ _L14_else_else_else_IfBlock1;
  ETCS_HMI_MsgHeaders /* IfBlock1:else:else:else:_L20/ */ _L20_else_else_else_IfBlock1;
  ETCSHMIPacket /* IfBlock1:else:else:else:_L21/ */ _L21_else_else_else_IfBlock1;
  ETCS_modes /* IfBlock1:else:then:_L16/ */ _L16_then_else_IfBlock1;
  ETCS_HMI_MsgHeaders /* IfBlock1:else:then:_L14/ */ _L14_then_else_IfBlock1;
  ETCSHMIPacket /* IfBlock1:else:then:_L13/ */ _L13_then_else_IfBlock1;
  ATO_modes /* IfBlock1:else:then:_L12/ */ _L12_then_else_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:then:_L17/ */ _L17_then_else_IfBlock1;
  ETCS_HMI_Msgs /* HMItoETCSOB_Message/ */ HMItoETCSOB_Message;
  OverrideSwitchPosition /* Local_OverrideSwitchPosition/ */ Local_OverrideSwitchPosition;
  kcg_int8 /* Local1/ */ Local1;
  kcg_bool /* Local2/ */ Local2;
  kcg_int8 /* Local3/ */ Local3;
  ETCSHMIPacket /* _L2/ */ _L2;
  ExternalindicatorStates /* _L4/ */ _L4;
  OverrideSwitchPosition /* _L5/ */ _L5;
  kcg_bool /* _L32/ */ _L32;
  ETCS_HMI_Msgs /* _L39/ */ _L39;
  array_char_30 /* _L40/ */ _L40;
  Tain_Physics_Outputs /* _L41/ */ _L41;
  kcg_int8 /* _L42/ */ _L42;
  kcg_bool /* _L43/ */ _L43;
  kcg_int8 /* _L44/ */ _L44;
} outC_Train_Driver;

/* ===========  node initialization and cycle functions  =========== */
/* Train_Driver/ */
extern void Train_Driver(inC_Train_Driver *inC, outC_Train_Driver *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Train_Driver_reset(outC_Train_Driver *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Train_Driver_init(outC_Train_Driver *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Train_Driver_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Driver.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

