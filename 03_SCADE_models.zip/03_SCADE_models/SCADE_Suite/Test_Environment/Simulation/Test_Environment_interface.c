#include "Test_Environment_interface.h"
#include "Test_Environment_type.h"
#include "Test_Environment_mapping.h"
#include "SmuVTable.h"
#include <string.h>

#define UNUSED(x) (void)(x)
/* context */

inC_Train_Driver inputs_ctx;
static inC_Train_Driver inputs_ctx_execute;
outC_Train_Driver outputs_ctx;

static void _SCSIM_RestoreInterface(void) {
    init_ExternalindicatorStates(&inputs_ctx.from_FVA);
    init_ExternalindicatorStates(&inputs_ctx_execute.from_FVA);
    init_ETCSHMIPacket(&inputs_ctx.from_ETCS_OB);
    init_ETCSHMIPacket(&inputs_ctx_execute.from_ETCS_OB);
    init_OverrideSwitchPosition(&inputs_ctx.ATORSCSwitch_Position);
    init_OverrideSwitchPosition(&inputs_ctx_execute.ATORSCSwitch_Position);
    init_kcg_bool(&inputs_ctx.SendMessage);
    init_kcg_bool(&inputs_ctx_execute.SendMessage);
    init_kcg_bool(&inputs_ctx.ATO_GoA4_mode_button);
    init_kcg_bool(&inputs_ctx_execute.ATO_GoA4_mode_button);
    init_kcg_bool(&inputs_ctx.ATO_GoA2_mode_button);
    init_kcg_bool(&inputs_ctx_execute.ATO_GoA2_mode_button);
    init_kcg_bool(&inputs_ctx.ETCS_FS_mode_button);
    init_kcg_bool(&inputs_ctx_execute.ETCS_FS_mode_button);
    init_kcg_int8(&inputs_ctx.ThrottleBrakeLever_Position);
    init_kcg_int8(&inputs_ctx_execute.ThrottleBrakeLever_Position);
    init_kcg_bool(&inputs_ctx.Apply_HoldingBrake);
    init_kcg_bool(&inputs_ctx_execute.Apply_HoldingBrake);
    init_kcg_int8(&inputs_ctx.TrainBrakeLever);
    init_kcg_int8(&inputs_ctx_execute.TrainBrakeLever);
    memset((void*)&outputs_ctx, 0, sizeof(outputs_ctx));
}

static void _SCSIM_ExecuteInterface(void) {
    pSimulator->m_pfnAcquireValueMutex(pSimulator);
    kcg_copy_ExternalindicatorStates(&inputs_ctx_execute.from_FVA, &inputs_ctx.from_FVA);
    kcg_copy_ETCSHMIPacket(&inputs_ctx_execute.from_ETCS_OB, &inputs_ctx.from_ETCS_OB);
    inputs_ctx_execute.ATORSCSwitch_Position = inputs_ctx.ATORSCSwitch_Position;
    inputs_ctx_execute.SendMessage = inputs_ctx.SendMessage;
    inputs_ctx_execute.ATO_GoA4_mode_button = inputs_ctx.ATO_GoA4_mode_button;
    inputs_ctx_execute.ATO_GoA2_mode_button = inputs_ctx.ATO_GoA2_mode_button;
    inputs_ctx_execute.ETCS_FS_mode_button = inputs_ctx.ETCS_FS_mode_button;
    inputs_ctx_execute.ThrottleBrakeLever_Position = inputs_ctx.ThrottleBrakeLever_Position;
    inputs_ctx_execute.Apply_HoldingBrake = inputs_ctx.Apply_HoldingBrake;
    inputs_ctx_execute.TrainBrakeLever = inputs_ctx.TrainBrakeLever;
    pSimulator->m_pfnReleaseValueMutex(pSimulator);
}

#ifdef __cplusplus
extern "C" {
#endif

const int  rt_version = Srtv62;

const char* _SCSIM_CheckSum = "476fa57e975c5b325c5de164fecb5bec";
const char* _SCSIM_SmuTypesCheckSum = "e199405d867d4446e9a5ba6df64b408e";

/* simulation */

int SimInit(void) {
    int nRet = 0;
    _SCSIM_RestoreInterface();
#ifdef EXTENDED_SIM
    BeforeSimInit();
#endif
#ifndef KCG_USER_DEFINED_INIT
    Train_Driver_init(&outputs_ctx);
    nRet = 1;
#else
    nRet = 0;
#endif
#ifdef EXTENDED_SIM
    AfterSimInit();
#endif
    return nRet;
}

int SimReset(void) {
    int nRet = 0;
    _SCSIM_RestoreInterface();
#ifdef EXTENDED_SIM
    BeforeSimInit();
#endif
#ifndef KCG_NO_EXTERN_CALL_TO_RESET
    Train_Driver_reset(&outputs_ctx);
    nRet = 1;
#else
    nRet = 0;
#endif
#ifdef EXTENDED_SIM
    AfterSimInit();
#endif
    return nRet;
}

#ifdef __cplusplus
    #ifdef pSimoutC_Train_DriverCIVTable_defined
        extern struct SimCustomInitVTable *pSimoutC_Train_DriverCIVTable;
    #else 
        struct SimCustomInitVTable *pSimoutC_Train_DriverCIVTable = NULL;
    #endif
#else
    struct SimCustomInitVTable *pSimoutC_Train_DriverCIVTable;
#endif

int SimCustomInit(void) {
    int nRet = 0;
    if (pSimoutC_Train_DriverCIVTable != NULL && 
        pSimoutC_Train_DriverCIVTable->m_pfnCustomInit != NULL) {
        /* VTable function provided => call it */
        nRet = pSimoutC_Train_DriverCIVTable->m_pfnCustomInit ((void*)&outputs_ctx);
    }
    else {
        /* VTable misssing => error */
        nRet = 0;
    }
    return nRet;
}

#ifdef EXTENDED_SIM
    int GraphicalInputsConnected = 1;
#endif

int SimStep(void) {
#ifdef EXTENDED_SIM
    if (GraphicalInputsConnected)
        BeforeSimStep();
#endif
    _SCSIM_ExecuteInterface();
    Train_Driver(&inputs_ctx_execute, &outputs_ctx);
#ifdef EXTENDED_SIM
    AfterSimStep();
#endif
    return 1;
}

int SimStop(void) {
#ifdef EXTENDED_SIM
    ExtendedSimStop();
#endif
    return 1;
}

void SsmUpdateValues(void) {
#ifdef EXTENDED_SIM
    UpdateValues();
#endif
}

void SsmConnectExternalInputs(int bConnect) {
#ifdef EXTENDED_SIM
    GraphicalInputsConnected = bConnect;
#else
    UNUSED(bConnect);
#endif
}

/* dump */

int SsmGetDumpSize(void) {
    int nSize = 0;
    nSize += sizeof(inC_Train_Driver);
    nSize += sizeof(outC_Train_Driver);
#ifdef EXTENDED_SIM
    nSize += ExtendedGetDumpSize();
#endif
    return nSize;
}

void SsmGatherDumpData(char * pData) {
    char* pCurrent = pData;
    memcpy(pCurrent, &inputs_ctx, sizeof(inC_Train_Driver));
    pCurrent += sizeof(inC_Train_Driver);
    memcpy(pCurrent, &outputs_ctx, sizeof(outC_Train_Driver));
    pCurrent += sizeof(outC_Train_Driver);
#ifdef EXTENDED_SIM
    ExtendedGatherDumpData(pCurrent);
#endif
}

void SsmRestoreDumpData(const char * pData) {
    const char* pCurrent = pData;
    memcpy(&inputs_ctx, pCurrent, sizeof(inC_Train_Driver));
    pCurrent += sizeof(inC_Train_Driver);
    memcpy(&outputs_ctx, pCurrent, sizeof(outC_Train_Driver));
    pCurrent += sizeof(outC_Train_Driver);
#ifdef EXTENDED_SIM
    ExtendedRestoreDumpData(pCurrent);
#endif
}

/* snapshot */

int SsmSaveSnapshot(const char * szFilePath, size_t nCycle) {
    /* Test Services API not available */
    UNUSED(szFilePath);
    UNUSED(nCycle);
    return 0;
}

int SsmLoadSnapshot(const char * szFilePath, size_t *nCycle) {
    /* Test Services API not available */
    UNUSED(szFilePath);
    UNUSED(nCycle);
    return 0;
}

/* checksum */

const char * SsmGetCheckSum() {
    return _SCSIM_CheckSum;
}

const char * SsmGetSmuTypesCheckSum() {
    return _SCSIM_SmuTypesCheckSum;
}

#ifdef __cplusplus
} /* "C" */
#endif

