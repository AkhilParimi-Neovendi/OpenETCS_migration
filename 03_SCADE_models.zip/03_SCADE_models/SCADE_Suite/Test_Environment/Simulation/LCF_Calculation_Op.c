/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "LCF_Calculation_Op.h"

/* Op::LCF_Calculation/ */
void LCF_Calculation_Op(
  /* Unit_Traction/ */
  kcg_float32 Unit_Traction,
  /* Unit_dynbrakingforce/ */
  kcg_float32 Unit_dynbrakingforce,
  /* unit_speed/ */
  kcg_float32 unit_speed,
  /* unit_acceleration/ */
  kcg_float32 unit_acceleration,
  /* Unit_Mass/ */
  kcg_int32 Unit_Mass,
  /* Unit_brakelinepressure/ */
  kcg_float32 Unit_brakelinepressure,
  /* Unit_holdingbrakestatus/ */
  kcg_bool Unit_holdingbrakestatus,
  /* R_Coupling_force/ */
  kcg_float32 R_Coupling_force,
  outC_LCF_Calculation_Op *outC)
{
  outC->_L12 = Unit_Mass;
  outC->Input1_NumericToFloat32_1_int32 = outC->_L12;
  outC->_L1_NumericToFloat32_1_int32 = outC->Input1_NumericToFloat32_1_int32;
  outC->_L2_NumericToFloat32_1_int32 = /* @1/_L2= */(kcg_float32)
      outC->_L1_NumericToFloat32_1_int32;
  outC->Output1_NumericToFloat32_1_int32 = outC->_L2_NumericToFloat32_1_int32;
  outC->_L26 = Unit_brakelinepressure;
  outC->_L27 = Unit_Mass;
  /* _L24=(Brakes::Pneumaticbrakes#1)/ */
  Pneumaticbrakes_Brakes(
    outC->_L26,
    outC->_L27,
    &outC->Context_Pneumaticbrakes_1);
  outC->_L24 = outC->Context_Pneumaticbrakes_1.AppliedPneumaticBrakingforce;
  outC->_L25 = Unit_holdingbrakestatus;
  /* _L17=(Brakes::Holding_brake#1)/ */
  Holding_brake_Brakes(outC->_L25, &outC->Context_Holding_brake_1);
  outC->_L17 = outC->Context_Holding_brake_1.AppliedHoldingBrakeForce;
  outC->_L2 = Unit_dynbrakingforce;
  outC->_L16 = outC->_L2 + outC->_L17 + outC->_L24;
  outC->unittotalbraking = outC->_L16;
  outC->_L1 = Unit_Traction;
  outC->unit_traction = outC->_L1;
  outC->_L28 = outC->Output1_NumericToFloat32_1_int32;
  outC->_L15 = unit_speed;
  outC->_L11 = R_Coupling_force;
  outC->_L4 = unit_acceleration;
  outC->_L8 = outC->_L28 * outC->_L4;
  outC->_L3 = unit_speed;
  /* _L13=(External_forces::Resistance_force#1)/ */
  Resistance_force_External_forces(
    outC->_L3,
    outC->_L28,
    &outC->Context_Resistance_force_1);
  outC->_L13 = outC->Context_Resistance_force_1.Total_resistance;
  outC->_L6 = outC->_L16 + outC->_L13;
  outC->_L5 = outC->_L1 - outC->_L6;
  outC->_L7 = outC->_L5 - outC->_L8;
  outC->_L10 = outC->_L7 + outC->_L11;
  /* _L14=(Op::negativespeedcorrection#1)/ */
  negativespeedcorrection_Op(
    outC->_L10,
    outC->_L15,
    &outC->Context_negativespeedcorrection_1);
  outC->_L14 = outC->Context_negativespeedcorrection_1.outbraking;
  outC->L_Couplingforce = outC->_L14;
}

#ifndef KCG_USER_DEFINED_INIT
void LCF_Calculation_init_Op(outC_LCF_Calculation_Op *outC)
{
  outC->_L28 = kcg_lit_float32(0.0);
  outC->_L27 = kcg_lit_int32(0);
  outC->_L26 = kcg_lit_float32(0.0);
  outC->_L25 = kcg_true;
  outC->_L24 = kcg_lit_float32(0.0);
  outC->_L17 = kcg_lit_float32(0.0);
  outC->_L16 = kcg_lit_float32(0.0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_lit_float32(0.0);
  outC->_L13 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_int32(0);
  outC->_L11 = kcg_lit_float32(0.0);
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L1_NumericToFloat32_1_int32 = kcg_lit_int32(0);
  outC->_L2_NumericToFloat32_1_int32 = kcg_lit_float32(0.0);
  outC->Input1_NumericToFloat32_1_int32 = kcg_lit_int32(0);
  outC->Output1_NumericToFloat32_1_int32 = kcg_lit_float32(0.0);
  outC->L_Couplingforce = kcg_lit_float32(0.0);
  outC->unittotalbraking = kcg_lit_float32(0.0);
  outC->unit_traction = kcg_lit_float32(0.0);
  /* _L14=(Op::negativespeedcorrection#1)/ */
  negativespeedcorrection_init_Op(&outC->Context_negativespeedcorrection_1);
  /* _L13=(External_forces::Resistance_force#1)/ */
  Resistance_force_init_External_forces(&outC->Context_Resistance_force_1);
  /* _L17=(Brakes::Holding_brake#1)/ */
  Holding_brake_init_Brakes(&outC->Context_Holding_brake_1);
  /* _L24=(Brakes::Pneumaticbrakes#1)/ */
  Pneumaticbrakes_init_Brakes(&outC->Context_Pneumaticbrakes_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void LCF_Calculation_reset_Op(outC_LCF_Calculation_Op *outC)
{
  /* _L14=(Op::negativespeedcorrection#1)/ */
  negativespeedcorrection_reset_Op(&outC->Context_negativespeedcorrection_1);
  /* _L13=(External_forces::Resistance_force#1)/ */
  Resistance_force_reset_External_forces(&outC->Context_Resistance_force_1);
  /* _L17=(Brakes::Holding_brake#1)/ */
  Holding_brake_reset_Brakes(&outC->Context_Holding_brake_1);
  /* _L24=(Brakes::Pneumaticbrakes#1)/ */
  Pneumaticbrakes_reset_Brakes(&outC->Context_Pneumaticbrakes_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: Op::LCF_Calculation/
  @1: (math::NumericToFloat32#1)
*/

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** LCF_Calculation_Op.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

