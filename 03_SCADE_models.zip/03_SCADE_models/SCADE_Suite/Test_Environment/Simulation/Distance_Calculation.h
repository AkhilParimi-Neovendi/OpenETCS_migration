/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _Distance_Calculation_H_
#define _Distance_Calculation_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* Distance_travelled/ */ Distance_travelled;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_float32 /* _L6/ */ _L6;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L10/ */ _L10;
  kcg_float32 /* _L11/ */ _L11;
  kcg_float32 /* _L12/ */ _L12;
  kcg_float32 /* _L13/ */ _L13;
  kcg_float32 /* _L14/ */ _L14;
  kcg_float32 /* _L15/ */ _L15;
} outC_Distance_Calculation;

/* ===========  node initialization and cycle functions  =========== */
/* Distance_Calculation/ */
extern void Distance_Calculation(
  /* Speed/ */
  kcg_float32 Speed,
  outC_Distance_Calculation *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Distance_Calculation_reset(outC_Distance_Calculation *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Distance_Calculation_init(outC_Distance_Calculation *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Distance_Calculation_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Distance_Calculation.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

