/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _KCG_TYPES_H_
#define _KCG_TYPES_H_

#include "stddef.h"

#define KCG_MAPW_CPY

#include "./user_macros.h"

#ifndef kcg_char
#define kcg_char kcg_char
typedef char kcg_char;
#endif /* kcg_char */

#ifndef kcg_bool
#define kcg_bool kcg_bool
typedef unsigned char kcg_bool;
#endif /* kcg_bool */

#ifndef kcg_float32
#define kcg_float32 kcg_float32
typedef float kcg_float32;
#endif /* kcg_float32 */

#ifndef kcg_float64
#define kcg_float64 kcg_float64
typedef double kcg_float64;
#endif /* kcg_float64 */

#ifndef kcg_size
#define kcg_size kcg_size
typedef ptrdiff_t kcg_size;
#endif /* kcg_size */

#ifndef kcg_uint64
#define kcg_uint64 kcg_uint64
typedef unsigned long long kcg_uint64;
#endif /* kcg_uint64 */

#ifndef kcg_uint32
#define kcg_uint32 kcg_uint32
typedef unsigned long kcg_uint32;
#endif /* kcg_uint32 */

#ifndef kcg_uint16
#define kcg_uint16 kcg_uint16
typedef unsigned short kcg_uint16;
#endif /* kcg_uint16 */

#ifndef kcg_uint8
#define kcg_uint8 kcg_uint8
typedef unsigned char kcg_uint8;
#endif /* kcg_uint8 */

#ifndef kcg_int64
#define kcg_int64 kcg_int64
typedef signed long long kcg_int64;
#endif /* kcg_int64 */

#ifndef kcg_int32
#define kcg_int32 kcg_int32
typedef signed long kcg_int32;
#endif /* kcg_int32 */

#ifndef kcg_int16
#define kcg_int16 kcg_int16
typedef signed short kcg_int16;
#endif /* kcg_int16 */

#ifndef kcg_int8
#define kcg_int8 kcg_int8
typedef signed char kcg_int8;
#endif /* kcg_int8 */

#ifndef kcg_lit_float32
#define kcg_lit_float32(kcg_C1) ((kcg_float32) (kcg_C1))
#endif /* kcg_lit_float32 */

#ifndef kcg_lit_float64
#define kcg_lit_float64(kcg_C1) ((kcg_float64) (kcg_C1))
#endif /* kcg_lit_float64 */

#ifndef kcg_lit_size
#define kcg_lit_size(kcg_C1) ((kcg_size) (kcg_C1))
#endif /* kcg_lit_size */

#ifndef kcg_lit_uint64
#define kcg_lit_uint64(kcg_C1) ((kcg_uint64) (kcg_C1))
#endif /* kcg_lit_uint64 */

#ifndef kcg_lit_uint32
#define kcg_lit_uint32(kcg_C1) ((kcg_uint32) (kcg_C1))
#endif /* kcg_lit_uint32 */

#ifndef kcg_lit_uint16
#define kcg_lit_uint16(kcg_C1) ((kcg_uint16) (kcg_C1))
#endif /* kcg_lit_uint16 */

#ifndef kcg_lit_uint8
#define kcg_lit_uint8(kcg_C1) ((kcg_uint8) (kcg_C1))
#endif /* kcg_lit_uint8 */

#ifndef kcg_lit_int64
#define kcg_lit_int64(kcg_C1) ((kcg_int64) (kcg_C1))
#endif /* kcg_lit_int64 */

#ifndef kcg_lit_int32
#define kcg_lit_int32(kcg_C1) ((kcg_int32) (kcg_C1))
#endif /* kcg_lit_int32 */

#ifndef kcg_lit_int16
#define kcg_lit_int16(kcg_C1) ((kcg_int16) (kcg_C1))
#endif /* kcg_lit_int16 */

#ifndef kcg_lit_int8
#define kcg_lit_int8(kcg_C1) ((kcg_int8) (kcg_C1))
#endif /* kcg_lit_int8 */

#ifndef kcg_false
#define kcg_false ((kcg_bool) 0)
#endif /* kcg_false */

#ifndef kcg_true
#define kcg_true ((kcg_bool) 1)
#endif /* kcg_true */

#ifndef kcg_lsl_uint64
#define kcg_lsl_uint64(kcg_C1, kcg_C2)                                        \
  ((kcg_uint64) ((kcg_C1) << (kcg_C2)) & 0xffffffffffffffff)
#endif /* kcg_lsl_uint64 */

#ifndef kcg_lsl_uint32
#define kcg_lsl_uint32(kcg_C1, kcg_C2)                                        \
  ((kcg_uint32) ((kcg_C1) << (kcg_C2)) & 0xffffffff)
#endif /* kcg_lsl_uint32 */

#ifndef kcg_lsl_uint16
#define kcg_lsl_uint16(kcg_C1, kcg_C2)                                        \
  ((kcg_uint16) ((kcg_C1) << (kcg_C2)) & 0xffff)
#endif /* kcg_lsl_uint16 */

#ifndef kcg_lsl_uint8
#define kcg_lsl_uint8(kcg_C1, kcg_C2)                                         \
  ((kcg_uint8) ((kcg_C1) << (kcg_C2)) & 0xff)
#endif /* kcg_lsl_uint8 */

#ifndef kcg_lnot_uint64
#define kcg_lnot_uint64(kcg_C1) ((kcg_C1) ^ 0xffffffffffffffff)
#endif /* kcg_lnot_uint64 */

#ifndef kcg_lnot_uint32
#define kcg_lnot_uint32(kcg_C1) ((kcg_C1) ^ 0xffffffff)
#endif /* kcg_lnot_uint32 */

#ifndef kcg_lnot_uint16
#define kcg_lnot_uint16(kcg_C1) ((kcg_C1) ^ 0xffff)
#endif /* kcg_lnot_uint16 */

#ifndef kcg_lnot_uint8
#define kcg_lnot_uint8(kcg_C1) ((kcg_C1) ^ 0xff)
#endif /* kcg_lnot_uint8 */

#ifndef kcg_assign
#include "kcg_assign.h"
#endif /* kcg_assign */

#ifndef kcg_assign_struct
#define kcg_assign_struct kcg_assign
#endif /* kcg_assign_struct */

#ifndef kcg_assign_array
#define kcg_assign_array kcg_assign
#endif /* kcg_assign_array */

typedef kcg_char array_char_30[30];

typedef kcg_bool array_bool_4[4];

typedef kcg_bool array_bool_5[5];

typedef kcg_bool array_bool_1[1];

typedef kcg_float32 array_float32_5[5];

/* LCF_Data/ */
typedef struct kcg_tag_LCF_Data { array_float32_5 LCF_Values; } LCF_Data;

typedef kcg_float32 array_float32_1[1];

typedef kcg_float32 array_float32_4[4];

typedef kcg_int32 array_int32_5[5];

typedef kcg_int32 array_int32_1[1];

typedef kcg_int32 array_int32_4[4];

/* Tain_Physics_Outputs/ */
typedef struct kcg_tag_Tain_Physics_Outputs {
  kcg_int16 Distance_Covered;
  kcg_int16 Train_Speed;
  kcg_float32 Train_Acceleration;
} Tain_Physics_Outputs;

/* OverrideSwitchPosition/ */
typedef kcg_int8 OverrideSwitchPosition;

/* ATO_modes/ */
typedef kcg_int8 ATO_modes;

/* ETCS_modes/ */
typedef kcg_int8 ETCS_modes;

/* ETCS_HMI_Msgs/ */
typedef kcg_int8 ETCS_HMI_Msgs;

/* ETCS_HMI_MsgHeaders/ */
typedef kcg_int8 ETCS_HMI_MsgHeaders;

/* ETCSHMIPacket/ */
typedef struct kcg_tag_ETCSHMIPacket {
  ETCS_HMI_MsgHeaders Header;
  ETCS_HMI_Msgs Message;
  ETCS_modes currentETCSmode;
  ATO_modes currentATOmode;
} ETCSHMIPacket;

/* ExternalindicatorStates/ */
typedef struct kcg_tag_ExternalindicatorStates {
  kcg_int8 IndicatorState;
  kcg_bool RedLight;
  kcg_bool GreenLight;
} ExternalindicatorStates;

#ifndef kcg_copy_Tain_Physics_Outputs
#define kcg_copy_Tain_Physics_Outputs(kcg_C1, kcg_C2)                         \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (Tain_Physics_Outputs)))
#endif /* kcg_copy_Tain_Physics_Outputs */

#ifndef kcg_copy_LCF_Data
#define kcg_copy_LCF_Data(kcg_C1, kcg_C2)                                     \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (LCF_Data)))
#endif /* kcg_copy_LCF_Data */

#ifndef kcg_copy_ExternalindicatorStates
#define kcg_copy_ExternalindicatorStates(kcg_C1, kcg_C2)                      \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ExternalindicatorStates)))
#endif /* kcg_copy_ExternalindicatorStates */

#ifndef kcg_copy_ETCSHMIPacket
#define kcg_copy_ETCSHMIPacket(kcg_C1, kcg_C2)                                \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ETCSHMIPacket)))
#endif /* kcg_copy_ETCSHMIPacket */

#ifndef kcg_copy_array_int32_4
#define kcg_copy_array_int32_4(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_4)))
#endif /* kcg_copy_array_int32_4 */

#ifndef kcg_copy_array_float32_4
#define kcg_copy_array_float32_4(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_4)))
#endif /* kcg_copy_array_float32_4 */

#ifndef kcg_copy_array_int32_1
#define kcg_copy_array_int32_1(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_1)))
#endif /* kcg_copy_array_int32_1 */

#ifndef kcg_copy_array_bool_1
#define kcg_copy_array_bool_1(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_1)))
#endif /* kcg_copy_array_bool_1 */

#ifndef kcg_copy_array_float32_1
#define kcg_copy_array_float32_1(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_1)))
#endif /* kcg_copy_array_float32_1 */

#ifndef kcg_copy_array_bool_5
#define kcg_copy_array_bool_5(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_5)))
#endif /* kcg_copy_array_bool_5 */

#ifndef kcg_copy_array_char_30
#define kcg_copy_array_char_30(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_char_30)))
#endif /* kcg_copy_array_char_30 */

#ifndef kcg_copy_array_bool_4
#define kcg_copy_array_bool_4(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_4)))
#endif /* kcg_copy_array_bool_4 */

#ifndef kcg_copy_array_int32_5
#define kcg_copy_array_int32_5(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_5)))
#endif /* kcg_copy_array_int32_5 */

#ifndef kcg_copy_array_float32_5
#define kcg_copy_array_float32_5(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_5)))
#endif /* kcg_copy_array_float32_5 */

#ifdef kcg_use_Tain_Physics_Outputs
#ifndef kcg_comp_Tain_Physics_Outputs
extern kcg_bool kcg_comp_Tain_Physics_Outputs(
  Tain_Physics_Outputs *kcg_c1,
  Tain_Physics_Outputs *kcg_c2);
#endif /* kcg_comp_Tain_Physics_Outputs */
#endif /* kcg_use_Tain_Physics_Outputs */

#ifdef kcg_use_LCF_Data
#ifndef kcg_comp_LCF_Data
extern kcg_bool kcg_comp_LCF_Data(LCF_Data *kcg_c1, LCF_Data *kcg_c2);
#endif /* kcg_comp_LCF_Data */
#endif /* kcg_use_LCF_Data */

#ifdef kcg_use_ExternalindicatorStates
#ifndef kcg_comp_ExternalindicatorStates
extern kcg_bool kcg_comp_ExternalindicatorStates(
  ExternalindicatorStates *kcg_c1,
  ExternalindicatorStates *kcg_c2);
#endif /* kcg_comp_ExternalindicatorStates */
#endif /* kcg_use_ExternalindicatorStates */

#ifdef kcg_use_ETCSHMIPacket
#ifndef kcg_comp_ETCSHMIPacket
extern kcg_bool kcg_comp_ETCSHMIPacket(
  ETCSHMIPacket *kcg_c1,
  ETCSHMIPacket *kcg_c2);
#endif /* kcg_comp_ETCSHMIPacket */
#endif /* kcg_use_ETCSHMIPacket */

#ifdef kcg_use_array_int32_4
#ifndef kcg_comp_array_int32_4
extern kcg_bool kcg_comp_array_int32_4(
  array_int32_4 *kcg_c1,
  array_int32_4 *kcg_c2);
#endif /* kcg_comp_array_int32_4 */
#endif /* kcg_use_array_int32_4 */

#ifdef kcg_use_array_float32_4
#ifndef kcg_comp_array_float32_4
extern kcg_bool kcg_comp_array_float32_4(
  array_float32_4 *kcg_c1,
  array_float32_4 *kcg_c2);
#endif /* kcg_comp_array_float32_4 */
#endif /* kcg_use_array_float32_4 */

#ifdef kcg_use_array_int32_1
#ifndef kcg_comp_array_int32_1
extern kcg_bool kcg_comp_array_int32_1(
  array_int32_1 *kcg_c1,
  array_int32_1 *kcg_c2);
#endif /* kcg_comp_array_int32_1 */
#endif /* kcg_use_array_int32_1 */

#ifdef kcg_use_array_bool_1
#ifndef kcg_comp_array_bool_1
extern kcg_bool kcg_comp_array_bool_1(
  array_bool_1 *kcg_c1,
  array_bool_1 *kcg_c2);
#endif /* kcg_comp_array_bool_1 */
#endif /* kcg_use_array_bool_1 */

#ifdef kcg_use_array_float32_1
#ifndef kcg_comp_array_float32_1
extern kcg_bool kcg_comp_array_float32_1(
  array_float32_1 *kcg_c1,
  array_float32_1 *kcg_c2);
#endif /* kcg_comp_array_float32_1 */
#endif /* kcg_use_array_float32_1 */

#ifdef kcg_use_array_bool_5
#ifndef kcg_comp_array_bool_5
extern kcg_bool kcg_comp_array_bool_5(
  array_bool_5 *kcg_c1,
  array_bool_5 *kcg_c2);
#endif /* kcg_comp_array_bool_5 */
#endif /* kcg_use_array_bool_5 */

#ifdef kcg_use_array_char_30
#ifndef kcg_comp_array_char_30
extern kcg_bool kcg_comp_array_char_30(
  array_char_30 *kcg_c1,
  array_char_30 *kcg_c2);
#endif /* kcg_comp_array_char_30 */
#endif /* kcg_use_array_char_30 */

#ifdef kcg_use_array_bool_4
#ifndef kcg_comp_array_bool_4
extern kcg_bool kcg_comp_array_bool_4(
  array_bool_4 *kcg_c1,
  array_bool_4 *kcg_c2);
#endif /* kcg_comp_array_bool_4 */
#endif /* kcg_use_array_bool_4 */

#ifdef kcg_use_array_int32_5
#ifndef kcg_comp_array_int32_5
extern kcg_bool kcg_comp_array_int32_5(
  array_int32_5 *kcg_c1,
  array_int32_5 *kcg_c2);
#endif /* kcg_comp_array_int32_5 */
#endif /* kcg_use_array_int32_5 */

#ifdef kcg_use_array_float32_5
#ifndef kcg_comp_array_float32_5
extern kcg_bool kcg_comp_array_float32_5(
  array_float32_5 *kcg_c1,
  array_float32_5 *kcg_c2);
#endif /* kcg_comp_array_float32_5 */
#endif /* kcg_use_array_float32_5 */

#endif /* _KCG_TYPES_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

