/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _Read_and_Send_ETCSOB_Data_ETCSHMI_Functions_H_
#define _Read_and_Send_ETCSOB_Data_ETCSHMI_Functions_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ETCS_HMI_Msgs /* Out_ETCS_HMI_Msg/ */ Out_ETCS_HMI_Msg;
  array_char_30 /* HMI_Display_Textbox/ */ HMI_Display_Textbox;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L2/ */ _L2;
  ETCSHMIPacket /* _L1/ */ _L1;
  ETCS_HMI_MsgHeaders /* _L3/ */ _L3;
  ETCS_HMI_Msgs /* _L4/ */ _L4;
  ETCS_modes /* _L5/ */ _L5;
  ATO_modes /* _L6/ */ _L6;
  ETCS_HMI_Msgs /* _L7/ */ _L7;
  kcg_bool /* _L8/ */ _L8;
  ETCS_HMI_MsgHeaders /* _L9/ */ _L9;
  ETCS_HMI_Msgs /* _L10/ */ _L10;
  ETCS_HMI_Msgs /* _L11/ */ _L11;
  ETCS_HMI_Msgs /* _L12/ */ _L12;
  ETCS_HMI_Msgs /* _L13/ */ _L13;
  ETCS_HMI_Msgs /* _L14/ */ _L14;
  ETCS_HMI_Msgs /* _L15/ */ _L15;
  ETCS_HMI_Msgs /* _L16/ */ _L16;
  ETCS_HMI_Msgs /* _L17/ */ _L17;
  array_char_30 /* _L18/ */ _L18;
  array_char_30 /* _L22/ */ _L22;
  array_char_30 /* _L23/ */ _L23;
  array_char_30 /* _L24/ */ _L24;
  array_char_30 /* _L19/ */ _L19;
} outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions;

/* ===========  node initialization and cycle functions  =========== */
/* ETCSHMI_Functions::Read_and_Send_ETCSOB_Data/ */
extern void Read_and_Send_ETCSOB_Data_ETCSHMI_Functions(
  /* InputData/ */
  ETCSHMIPacket *InputData,
  /* Input2/ */
  kcg_bool Input2,
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Read_and_Send_ETCSOB_Data_reset_ETCSHMI_Functions(
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Read_and_Send_ETCSOB_Data_init_ETCSHMI_Functions(
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Read_and_Send_ETCSOB_Data_ETCSHMI_Functions_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Read_and_Send_ETCSOB_Data_ETCSHMI_Functions.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

