/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */
#ifndef _TrainConfiguration_And_LCF_H_
#define _TrainConfiguration_And_LCF_H_

#include "kcg_types.h"
#include "Sum_of_Forces_Op.h"
#include "TrainConfiguration0_Op.h"
#include "Shift_Array_Op.h"
#include "LCF_Calculation_Op.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  array_float32_5 /* LCF_Array/ */ LCF_Array;
  kcg_float32 /* Total_Tractionforce/ */ Total_Tractionforce;
  kcg_float32 /* Total_Brakingforce/ */ Total_Brakingforce;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  array_float32_5 /* _L5/ */ _L5;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Sum_of_Forces_Op /* _L23=(Op::Sum_of_Forces#1)/ */ Context_Sum_of_Forces_1;
  outC_LCF_Calculation_Op /* _L30=(Op::LCF_Calculation#1)/ */ Context_LCF_Calculation_1[5];
  outC_Shift_Array_Op /* _L16=(Op::Shift_Array#1)/ */ Context_Shift_Array_1;
  outC_TrainConfiguration0_Op /* _L17=(Op::TrainConfiguration0#1)/ */ Context_TrainConfiguration0_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L4/ */ _L4;
  kcg_float32 /* _L3/ */ _L3;
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L1/ */ _L1;
  array_float32_5 /* _L12/ */ _L12;
  array_float32_5 /* _L13/ */ _L13;
  array_float32_5 /* _L14/ */ _L14;
  kcg_float32 /* _L15/ */ _L15;
  array_float32_5 /* _L16/ */ _L16;
  array_int32_5 /* _L21/ */ _L21;
  array_float32_5 /* _L20/ */ _L20;
  array_float32_5 /* _L19/ */ _L19;
  array_float32_5 /* _L18/ */ _L18;
  array_float32_5 /* _L17/ */ _L17;
  kcg_float32 /* _L23/ */ _L23;
  kcg_float32 /* _L22/ */ _L22;
  kcg_float32 /* _L26/ */ _L26;
  kcg_bool /* _L27/ */ _L27;
  array_float32_5 /* _L28/ */ _L28;
  array_bool_5 /* _L29/ */ _L29;
  array_float32_5 /* _L30/ */ _L30;
  array_float32_5 /* _L31/ */ _L31;
} outC_TrainConfiguration_And_LCF;

/* ===========  node initialization and cycle functions  =========== */
/* TrainConfiguration_And_LCF/ */
extern void TrainConfiguration_And_LCF(
  /* Unit_Speed/ */
  kcg_float32 Unit_Speed,
  /* Unit_traction_force/ */
  kcg_float32 Unit_traction_force,
  /* Unit_braking_force/ */
  kcg_float32 Unit_braking_force,
  /* holdingbrakestatus/ */
  kcg_bool holdingbrakestatus,
  /* BrakelinePressure/ */
  kcg_float32 BrakelinePressure,
  /* Unit_Acceleration/ */
  kcg_float32 Unit_Acceleration,
  outC_TrainConfiguration_And_LCF *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void TrainConfiguration_And_LCF_reset(
  outC_TrainConfiguration_And_LCF *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void TrainConfiguration_And_LCF_init(
  outC_TrainConfiguration_And_LCF *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _TrainConfiguration_And_LCF_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** TrainConfiguration_And_LCF.h
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

