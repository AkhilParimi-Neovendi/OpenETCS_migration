/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Distance_Calculation.h"

/* Distance_Calculation/ */
void Distance_Calculation(
  /* Speed/ */
  kcg_float32 Speed,
  outC_Distance_Calculation *outC)
{
  outC->_L15 = kmph2mps;
  outC->_L13 = outC->_L6;
  /* _L14= */
  if (outC->init) {
    outC->_L14 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L14 = outC->_L13;
  }
  outC->_L12 = TCYCLE;
  outC->_L10 = Speed;
  outC->_L11 = outC->_L10 * outC->_L12 * outC->_L15;
  outC->_L6 = outC->_L14 + outC->_L11;
  outC->Distance_travelled = outC->_L6;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void Distance_Calculation_init(outC_Distance_Calculation *outC)
{
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_lit_float32(0.0);
  outC->_L13 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = kcg_lit_float32(0.0);
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->init = kcg_true;
  outC->Distance_travelled = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Distance_Calculation_reset(outC_Distance_Calculation *outC)
{
  outC->init = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Distance_Calculation.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

