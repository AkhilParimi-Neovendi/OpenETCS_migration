/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Resistance_force_External_forces.h"

/* External_forces::Resistance_force/ */
void Resistance_force_External_forces(
  /* Current_speed/ */
  kcg_float32 Current_speed,
  /* Mass/ */
  kcg_float32 Mass,
  outC_Resistance_force_External_forces *outC)
{
  outC->_L8 = Mass;
  outC->_L1 = Current_speed;
  /* _L4=(External_forces::F_Airdrag#1)/ */
  F_Airdrag_External_forces(outC->_L1, &outC->Context_F_Airdrag_1);
  outC->_L4 = outC->Context_F_Airdrag_1.F_Air;
  /* _L5=(External_forces::F_gradient#1)/ */
  F_gradient_External_forces(outC->_L8, &outC->Context_F_gradient_1);
  outC->_L5 = outC->Context_F_gradient_1.F_Gradient;
  /* _L6=(External_forces::Friction_force#1)/ */
  Friction_force_External_forces(outC->_L8, &outC->Context_Friction_force_1);
  outC->_L6 = outC->Context_Friction_force_1.Friction_Force;
  outC->_L7 = outC->_L6 + outC->_L5 + outC->_L4;
  outC->Total_resistance = outC->_L7;
}

#ifndef KCG_USER_DEFINED_INIT
void Resistance_force_init_External_forces(
  outC_Resistance_force_External_forces *outC)
{
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->Total_resistance = kcg_lit_float32(0.0);
  /* _L6=(External_forces::Friction_force#1)/ */
  Friction_force_init_External_forces(&outC->Context_Friction_force_1);
  /* _L5=(External_forces::F_gradient#1)/ */
  F_gradient_init_External_forces(&outC->Context_F_gradient_1);
  /* _L4=(External_forces::F_Airdrag#1)/ */
  F_Airdrag_init_External_forces(&outC->Context_F_Airdrag_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Resistance_force_reset_External_forces(
  outC_Resistance_force_External_forces *outC)
{
  /* _L6=(External_forces::Friction_force#1)/ */
  Friction_force_reset_External_forces(&outC->Context_Friction_force_1);
  /* _L5=(External_forces::F_gradient#1)/ */
  F_gradient_reset_External_forces(&outC->Context_F_gradient_1);
  /* _L4=(External_forces::F_Airdrag#1)/ */
  F_Airdrag_reset_External_forces(&outC->Context_F_Airdrag_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Resistance_force_External_forces.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

