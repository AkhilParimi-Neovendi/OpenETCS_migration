/* Test_Environment_mapping.c */

#include "Test_Environment_type.h"
#include "Test_Environment_interface.h"
#include "Test_Environment_mapping.h"

#include "SmuTypes.h"
#include "SmuMapping.h"

#include "kcg_sensors.h"

/* mapping declaration */

#define DECL_ITER(name) extern const MappingIterator iter_##name

DECL_ITER(fold_5);
DECL_ITER(array_1);
DECL_ITER(array_4);
DECL_ITER(map_5);
DECL_ITER(array_5);
DECL_ITER(array_30);

#define DECL_SCOPE(name, count) extern const MappingEntry name##_entries[count]; extern const MappingScope name

DECL_SCOPE(scope_51, 16);
DECL_SCOPE(scope_50, 13);
DECL_SCOPE(scope_49, 8);
DECL_SCOPE(scope_48, 1);
DECL_SCOPE(scope_47, 1);
DECL_SCOPE(scope_46, 1);
DECL_SCOPE(scope_45, 1);
DECL_SCOPE(scope_44, 35);
DECL_SCOPE(scope_43, 1);
DECL_SCOPE(scope_42, 1);
DECL_SCOPE(scope_41, 5);
DECL_SCOPE(scope_40, 3);
DECL_SCOPE(scope_39, 3);
DECL_SCOPE(scope_38, 19);
DECL_SCOPE(scope_37, 3);
DECL_SCOPE(scope_36, 22);
DECL_SCOPE(scope_35, 6);
DECL_SCOPE(scope_34, 29);
DECL_SCOPE(scope_33, 1);
DECL_SCOPE(scope_32, 1);
DECL_SCOPE(scope_31, 30);
DECL_SCOPE(scope_30, 8);
DECL_SCOPE(scope_29, 7);
DECL_SCOPE(scope_28, 6);
DECL_SCOPE(scope_27, 3);
DECL_SCOPE(scope_26, 9);
DECL_SCOPE(scope_25, 10);
DECL_SCOPE(scope_24, 12);
DECL_SCOPE(scope_23, 3);
DECL_SCOPE(scope_22, 24);
DECL_SCOPE(scope_21, 21);
DECL_SCOPE(scope_20, 1);
DECL_SCOPE(scope_19, 1);
DECL_SCOPE(scope_18, 24);
DECL_SCOPE(scope_17, 9);
DECL_SCOPE(scope_16, 3);
DECL_SCOPE(scope_15, 3);
DECL_SCOPE(scope_14, 3);
DECL_SCOPE(scope_13, 24);
DECL_SCOPE(scope_12, 5);
DECL_SCOPE(scope_11, 5);
DECL_SCOPE(scope_10, 5);
DECL_SCOPE(scope_9, 4);
DECL_SCOPE(scope_8, 3);
DECL_SCOPE(scope_7, 3);
DECL_SCOPE(scope_6, 3);
DECL_SCOPE(scope_5, 3);
DECL_SCOPE(scope_4, 1);
DECL_SCOPE(scope_3, 3);
DECL_SCOPE(scope_2, 4);
DECL_SCOPE(scope_1, 34);
DECL_SCOPE(scope_0, 1);

/* clock definition */

static int isActive_kcg_bool_kcg_false(void* pHandle) { return *(kcg_bool*)pHandle == kcg_false; }
static int isActive_kcg_bool_kcg_true(void* pHandle) { return *(kcg_bool*)pHandle == kcg_true; }

/* mapping definition */

const MappingIterator iter_fold_5 = { "fold", 5, 5, NULL };
const MappingIterator iter_array_1 = { "array", 1, 1, NULL };
const MappingIterator iter_array_4 = { "array", 4, 4, NULL };
const MappingIterator iter_map_5 = { "map", 5, 5, NULL };
const MappingIterator iter_array_5 = { "array", 5, 5, NULL };
const MappingIterator iter_array_30 = { "array", 30, 30, NULL };

const MappingEntry scope_51_entries[16] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, Output1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Op, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Op, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Op, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 }
};
const MappingScope scope_51 = {
    "Op::ForceGradient/ ForceGradient_Op",
    scope_51_entries, 16
};

const MappingEntry scope_50_entries[13] = {
    /* 0 */ { MAP_OUTPUT, "TractionForce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, TractionForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "BrakingFroce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, BrakingFroce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_T_B_Lever_Op, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L27), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L40), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Op, _L41), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_INSTANCE, "Op::ForceGradient 2", NULL, sizeof(outC_ForceGradient_Op), offsetof(outC_T_B_Lever_Op, Context_ForceGradient_2), NULL, NULL, NULL, &scope_51, 1, 11 },
    /* 12 */ { MAP_INSTANCE, "Op::ForceGradient 3", NULL, sizeof(outC_ForceGradient_Op), offsetof(outC_T_B_Lever_Op, Context_ForceGradient_3), NULL, NULL, NULL, &scope_51, 1, 12 }
};
const MappingScope scope_50 = {
    "Op::T_B_Lever/ T_B_Lever_Op",
    scope_50_entries, 13
};

const MappingEntry scope_49_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Sum_of_traction_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, Sum_of_traction_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Sum_of_Braking_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, Sum_of_Braking_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Op, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Op, _L6), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Op, _L7), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 7 }
};
const MappingScope scope_49 = {
    "Op::Sum_of_Forces/ Sum_of_Forces_Op",
    scope_49_entries, 8
};

const MappingEntry scope_48_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_48 = {
    "array_bool_4",
    scope_48_entries, 1
};

const MappingEntry scope_47_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_47 = {
    "array_bool_1",
    scope_47_entries, 1
};

const MappingEntry scope_46_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_46 = {
    "array_int32_4",
    scope_46_entries, 1
};

const MappingEntry scope_45_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_45 = {
    "array_int32_1",
    scope_45_entries, 1
};

const MappingEntry scope_44_entries[35] = {
    /* 0 */ { MAP_OUTPUT, "Traction_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, Traction_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Braking_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, Braking_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Speed_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, Speed_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Accelartion_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, Accelartion_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "Mass_Array", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Op, Mass_Array), &_Type_array_int32_5_Utils, NULL, NULL, &scope_32, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "brakelinepressurearray", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, brakelinepressurearray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "holdingbrakestatus", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Op, holdingbrakestatus), &_Type_array_bool_5_Utils, NULL, NULL, &scope_33, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Op, _L4), &_Type_array_float32_1_Utils, NULL, NULL, &scope_43, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L3", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Op, _L3), &_Type_array_float32_4_Utils, NULL, NULL, &scope_42, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, _L8), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Op, _L7), &_Type_array_float32_1_Utils, NULL, NULL, &scope_43, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Op, _L6), &_Type_array_float32_4_Utils, NULL, NULL, &scope_42, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_int32_1), offsetof(outC_TrainConfiguration0_Op, _L13), &_Type_array_int32_1_Utils, NULL, NULL, &scope_45, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L11", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, _L11), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Op, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Op, _L18), &_Type_array_int32_5_Utils, NULL, NULL, &scope_32, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_int32_4), offsetof(outC_TrainConfiguration0_Op, _L19), &_Type_array_int32_4_Utils, NULL, NULL, &scope_46, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Op, _L20), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Op, _L28), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L33", NULL, sizeof(array_bool_1), offsetof(outC_TrainConfiguration0_Op, _L33), &_Type_array_bool_1_Utils, NULL, NULL, &scope_47, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L32", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Op, _L32), &_Type_array_bool_5_Utils, NULL, NULL, &scope_33, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_bool_4), offsetof(outC_TrainConfiguration0_Op, _L31), &_Type_array_bool_4_Utils, NULL, NULL, &scope_48, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Op, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Op, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L44", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Op, _L44), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L41", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Op, _L41), &_Type_array_float32_4_Utils, NULL, NULL, &scope_42, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L40", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Op, _L40), &_Type_array_float32_1_Utils, NULL, NULL, &scope_43, 1, 34 }
};
const MappingScope scope_44 = {
    "Op::TrainConfiguration0/ TrainConfiguration0_Op",
    scope_44_entries, 35
};

const MappingEntry scope_43_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_43 = {
    "array_float32_1",
    scope_43_entries, 1
};

const MappingEntry scope_42_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_42 = {
    "array_float32_4",
    scope_42_entries, 1
};

const MappingEntry scope_41_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "OutputArray", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Op, OutputArray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L15", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Op, _L15), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L22", NULL, sizeof(array_float32_4), offsetof(outC_Shift_Array_Op, _L22), &_Type_array_float32_4_Utils, NULL, NULL, &scope_42, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L23", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Op, _L23), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L24", NULL, sizeof(array_float32_1), offsetof(outC_Shift_Array_Op, _L24), &_Type_array_float32_1_Utils, NULL, NULL, &scope_43, 1, 4 }
};
const MappingScope scope_41 = {
    "Op::Shift_Array/ Shift_Array_Op",
    scope_41_entries, 5
};

const MappingEntry scope_40_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, Output1_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Op, _L1_NumericToFloat32_1_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L2_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_40 = {
    "Op::LCF_Calculation/ LCF_Calculation_Op/math::NumericToFloat32 1",
    scope_40_entries, 3
};

const MappingEntry scope_39_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_39 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes/math::NumericToFloat32 2",
    scope_39_entries, 3
};

const MappingEntry scope_38_entries[19] = {
    /* 0 */ { MAP_OUTPUT, "AppliedPneumaticBrakingforce", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, AppliedPneumaticBrakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Brakepressure", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Brakepressure), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L18), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_39, 1, 18 }
};
const MappingScope scope_38 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes",
    scope_38_entries, 19
};

const MappingEntry scope_37_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Holding_brake_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_37 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes/math::NumericToFloat32 2",
    scope_37_entries, 3
};

const MappingEntry scope_36_entries[22] = {
    /* 0 */ { MAP_OUTPUT, "AppliedHoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, AppliedHoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Max_HoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Max_HoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L21), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_37, 1, 21 }
};
const MappingScope scope_36 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes",
    scope_36_entries, 22
};

const MappingEntry scope_35_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "outbraking", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Op, outbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Op, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Op, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Op, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeedcorrection_Op, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_35 = {
    "Op::negativespeedcorrection/ negativespeedcorrection_Op",
    scope_35_entries, 6
};

const MappingEntry scope_34_entries[29] = {
    /* 0 */ { MAP_OUTPUT, "unit_traction", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, unit_traction), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "unittotalbraking", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, unittotalbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "L_Couplingforce", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, L_Couplingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Op, _L12), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_LCF_Calculation_Op, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Op, _L27), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Op, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_LCF_Calculation_Op, Context_Resistance_force_1), NULL, NULL, NULL, &scope_25, 1, 24 },
    /* 25 */ { MAP_INSTANCE, "Op::negativespeedcorrection 1", NULL, sizeof(outC_negativespeedcorrection_Op), offsetof(outC_LCF_Calculation_Op, Context_negativespeedcorrection_1), NULL, NULL, NULL, &scope_35, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Brakes::Holding_brake 1", NULL, sizeof(outC_Holding_brake_Brakes), offsetof(outC_LCF_Calculation_Op, Context_Holding_brake_1), NULL, NULL, NULL, &scope_36, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Brakes::Pneumaticbrakes 1", NULL, sizeof(outC_Pneumaticbrakes_Brakes), offsetof(outC_LCF_Calculation_Op, Context_Pneumaticbrakes_1), NULL, NULL, NULL, &scope_38, 1, 27 },
    /* 28 */ { MAP_EXPANDED, "math::NumericToFloat32 1", NULL, 0, 0, NULL, NULL, NULL, &scope_40, 1, 28 }
};
const MappingScope scope_34 = {
    "Op::LCF_Calculation/ LCF_Calculation_Op",
    scope_34_entries, 29
};

const MappingEntry scope_33_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_33 = {
    "array_bool_5",
    scope_33_entries, 1
};

const MappingEntry scope_32_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_32 = {
    "array_int32_5",
    scope_32_entries, 1
};

const MappingEntry scope_31_entries[30] = {
    /* 0 */ { MAP_OUTPUT, "LCF_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, LCF_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Total_Tractionforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Tractionforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Total_Brakingforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Brakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L13), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L14", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L14), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L16", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L16), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration_And_LCF, _L21), &_Type_array_int32_5_Utils, NULL, NULL, &scope_32, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L20", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L20), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L19), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L18), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L17", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L17), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration_And_LCF, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L28", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L28), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L29", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration_And_LCF, _L29), &_Type_array_bool_5_Utils, NULL, NULL, &scope_33, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L30", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L30), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L31), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Op::LCF_Calculation 1", &iter_map_5, sizeof(outC_LCF_Calculation_Op), offsetof(outC_TrainConfiguration_And_LCF, Context_LCF_Calculation_1), NULL, NULL, NULL, &scope_34, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Op::Shift_Array 1", NULL, sizeof(outC_Shift_Array_Op), offsetof(outC_TrainConfiguration_And_LCF, Context_Shift_Array_1), NULL, NULL, NULL, &scope_41, 1, 27 },
    /* 28 */ { MAP_INSTANCE, "Op::TrainConfiguration0 1", NULL, sizeof(outC_TrainConfiguration0_Op), offsetof(outC_TrainConfiguration_And_LCF, Context_TrainConfiguration0_1), NULL, NULL, NULL, &scope_44, 1, 28 },
    /* 29 */ { MAP_INSTANCE, "Op::Sum_of_Forces 1", NULL, sizeof(outC_Sum_of_Forces_Op), offsetof(outC_TrainConfiguration_And_LCF, Context_Sum_of_Forces_1), NULL, NULL, NULL, &scope_49, 1, 29 }
};
const MappingScope scope_31 = {
    "TrainConfiguration_And_LCF/ TrainConfiguration_And_LCF",
    scope_31_entries, 30
};

const MappingEntry scope_30_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Distance_travelled", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, Distance_travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_30 = {
    "Distance_Calculation/ Distance_Calculation",
    scope_30_entries, 8
};

const MappingEntry scope_29_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "Friction_Force", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, Friction_Force), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_29 = {
    "External_forces::Friction_force/ Friction_force_External_forces",
    scope_29_entries, 7
};

const MappingEntry scope_28_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "F_Gradient", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, F_Gradient), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_28 = {
    "External_forces::F_gradient/ F_gradient_External_forces",
    scope_28_entries, 6
};

const MappingEntry scope_27_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Square_Out", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, Square_Out_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L1_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L2_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_27 = {
    "mathext::Square/ Square_mathext_float32",
    scope_27_entries, 3
};

const MappingEntry scope_26_entries[9] = {
    /* 0 */ { MAP_OUTPUT, "F_Air", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, F_Air), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "mathext::Square 1", NULL, sizeof(outC_Square_mathext_float32), offsetof(outC_F_Airdrag_External_forces, Context_Square_1), NULL, NULL, NULL, &scope_27, 1, 8 }
};
const MappingScope scope_26 = {
    "External_forces::F_Airdrag/ F_Airdrag_External_forces",
    scope_26_entries, 9
};

const MappingEntry scope_25_entries[10] = {
    /* 0 */ { MAP_OUTPUT, "Total_resistance", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, Total_resistance), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_INSTANCE, "External_forces::F_Airdrag 1", NULL, sizeof(outC_F_Airdrag_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_Airdrag_1), NULL, NULL, NULL, &scope_26, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "External_forces::F_gradient 1", NULL, sizeof(outC_F_gradient_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_gradient_1), NULL, NULL, NULL, &scope_28, 1, 8 },
    /* 9 */ { MAP_INSTANCE, "External_forces::Friction_force 1", NULL, sizeof(outC_Friction_force_External_forces), offsetof(outC_Resistance_force_External_forces, Context_Friction_force_1), NULL, NULL, NULL, &scope_29, 1, 9 }
};
const MappingScope scope_25 = {
    "External_forces::Resistance_force/ Resistance_force_External_forces",
    scope_25_entries, 10
};

const MappingEntry scope_24_entries[12] = {
    /* 0 */ { MAP_OUTPUT, "oacceleration", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, oacceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "ospeed", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, ospeed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Op, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Op, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Op, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Op, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 }
};
const MappingScope scope_24 = {
    "Op::negativespeed/ negativespeed_Op",
    scope_24_entries, 12
};

const MappingEntry scope_23_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Output1_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L1_NumericToFloat32_3_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_23 = {
    "Train_dynamics/ Train_dynamics/math::NumericToFloat32 3",
    scope_23_entries, 3
};

const MappingEntry scope_22_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "train_speed", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Distance_Travelled", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Distance_Travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L25), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L29), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L30), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L31), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_EXPANDED, "math::NumericToFloat32 3", NULL, 0, 0, NULL, NULL, NULL, &scope_23, 1, 20 },
    /* 21 */ { MAP_INSTANCE, "Op::negativespeed 1", NULL, sizeof(outC_negativespeed_Op), offsetof(outC_Train_dynamics, Context_negativespeed_1), NULL, NULL, NULL, &scope_24, 1, 21 },
    /* 22 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_Train_dynamics, Context_Resistance_force_1), NULL, NULL, NULL, &scope_25, 1, 22 },
    /* 23 */ { MAP_INSTANCE, "Distance_Calculation 1", NULL, sizeof(outC_Distance_Calculation), offsetof(outC_Train_dynamics, Context_Distance_Calculation_1), NULL, NULL, NULL, &scope_30, 1, 23 }
};
const MappingScope scope_22 = {
    "Train_dynamics/ Train_dynamics",
    scope_22_entries, 24
};

const MappingEntry scope_21_entries[21] = {
    /* 0 */ { MAP_OUTPUT, "Train_Speed", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_Speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "LCF_Values", NULL, sizeof(LCF_Data), offsetof(outC_Train, LCF_Values), &_Type_LCF_Data_Utils, NULL, NULL, &scope_19, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Distance_Travelled_by_Train", NULL, sizeof(kcg_float32), offsetof(outC_Train, Distance_Travelled_by_Train), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L34), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L35), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L60", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L60), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L59", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L59), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L62", NULL, sizeof(array_float32_5), offsetof(outC_Train, _L62), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L64", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L64), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L65), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L67), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L66", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L66), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_Train, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L70), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L71", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L71), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L72", NULL, sizeof(LCF_Data), offsetof(outC_Train, _L72), &_Type_LCF_Data_Utils, NULL, NULL, &scope_19, 1, 18 },
    /* 19 */ { MAP_INSTANCE, "Train_dynamics 1", NULL, sizeof(outC_Train_dynamics), offsetof(outC_Train, Context_Train_dynamics_1), NULL, NULL, NULL, &scope_22, 1, 19 },
    /* 20 */ { MAP_INSTANCE, "TrainConfiguration_And_LCF", NULL, sizeof(outC_TrainConfiguration_And_LCF), offsetof(outC_Train, Context_TrainConfiguration_And_LCF), NULL, NULL, NULL, &scope_31, 1, 20 }
};
const MappingScope scope_21 = {
    "Train/ Train",
    scope_21_entries, 21
};

const MappingEntry scope_20_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_20 = {
    "array_float32_5",
    scope_20_entries, 1
};

const MappingEntry scope_19_entries[1] = {
    /* 0 */ { MAP_FIELD, ".LCF_Values", NULL, sizeof(array_float32_5), offsetof(LCF_Data, LCF_Values), &_Type_array_float32_5_Utils, NULL, NULL, &scope_20, 1, 0 }
};
const MappingScope scope_19 = {
    "LCF_Data",
    scope_19_entries, 1
};

const MappingEntry scope_18_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "Distance_Covered", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, Distance_Covered), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Current_TrainSpeed", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, Current_TrainSpeed), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "CurrentTrainAcceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, CurrentTrainAcceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(LCF_Data), offsetof(outC_Train_with_TandB_Lever, _L3), &_Type_LCF_Data_Utils, NULL, NULL, &scope_19, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int8), offsetof(outC_Train_with_TandB_Lever, _L7), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Train_with_TandB_Lever, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int8), offsetof(outC_Train_with_TandB_Lever, _L10), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_Train_with_TandB_Lever, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, _L17), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, _L18), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L20), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_INSTANCE, "Train 1", NULL, sizeof(outC_Train), offsetof(outC_Train_with_TandB_Lever, Context_Train_1), NULL, NULL, NULL, &scope_21, 1, 22 },
    /* 23 */ { MAP_INSTANCE, "Op::T_B_Lever 1", NULL, sizeof(outC_T_B_Lever_Op), offsetof(outC_Train_with_TandB_Lever, Context_T_B_Lever_1), NULL, NULL, NULL, &scope_50, 1, 23 }
};
const MappingScope scope_18 = {
    "Train_with_TandB_Lever/ Train_with_TandB_Lever",
    scope_18_entries, 24
};

const MappingEntry scope_17_entries[9] = {
    /* 0 */ { MAP_OUTPUT, "Train_Outputs", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Physics_Train, Train_Outputs), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_5, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L29", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Physics_Train, _L29), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_5, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_Train_Physics_Train, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int16), offsetof(outC_Train_Physics_Train, _L24), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int16), offsetof(outC_Train_Physics_Train, _L23), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int8), offsetof(outC_Train_Physics_Train, _L30), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_Train_Physics_Train, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int8), offsetof(outC_Train_Physics_Train, _L32), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "Train_with_TandB_Lever 4", NULL, sizeof(outC_Train_with_TandB_Lever), offsetof(outC_Train_Physics_Train, Context_Train_with_TandB_Lever_4), NULL, NULL, NULL, &scope_18, 1, 8 }
};
const MappingScope scope_17 = {
    "Train::Train_Physics/ Train_Physics_Train",
    scope_17_entries, 9
};

const MappingEntry scope_16_entries[3] = {
    /* 0 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L4_then_IfBlock2, &_Type_kcg_int8_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L3_then_IfBlock2, &_Type_kcg_int8_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1_then_IfBlock2, &_Type_kcg_bool_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 }
};
const MappingScope scope_16 = {
    "Train_Driver/ Train_DriverIfBlock2:then:",
    scope_16_entries, 3
};

const MappingEntry scope_15_entries[3] = {
    /* 0 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L5_else_IfBlock2, &_Type_kcg_int8_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L6_else_IfBlock2, &_Type_kcg_bool_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L7_else_IfBlock2, &_Type_kcg_int8_Utils, &scope_14_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 2 }
};
const MappingScope scope_15 = {
    "Train_Driver/ Train_DriverIfBlock2:else:",
    scope_15_entries, 3
};

const MappingEntry scope_14_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.IfBlock2_clock, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_14_entries[0], isActive_kcg_bool_kcg_false, &scope_15, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_14_entries[0], isActive_kcg_bool_kcg_true, &scope_16, 1, 2 }
};
const MappingScope scope_14 = {
    "Train_Driver/ Train_DriverIfBlock2:",
    scope_14_entries, 3
};

const MappingEntry scope_13_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "Out_ETCS_HMI_Msg", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, Out_ETCS_HMI_Msg), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "HMI_Display_Textbox", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, HMI_Display_Textbox), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L1), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_2, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L3), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L4), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_modes), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L5), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(ATO_modes), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L6), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L7), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L9), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L10), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L11), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L12), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L13), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L14), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L15), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L16", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L16), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L17", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L17), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L18), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L22", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L22), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L23", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L23), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L24", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L24), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L19), &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 23 }
};
const MappingScope scope_13 = {
    "ETCSHMI_Functions::Read_and_Send_ETCSOB_Data/ Read_and_Send_ETCSOB_Data_ETCSHMI_Functions",
    scope_13_entries, 24
};

const MappingEntry scope_12_entries[5] = {
    /* 0 */ { MAP_LOCAL, "_L7", NULL, sizeof(ATO_modes), (size_t)&outputs_ctx._L7_then_IfBlock1, &_Type_ATO_modes_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_HMI_MsgHeaders), (size_t)&outputs_ctx._L5_then_IfBlock1, &_Type_ETCS_HMI_MsgHeaders_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L4_then_IfBlock1, &_Type_ETCSHMIPacket_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, &scope_2, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(ETCS_modes), (size_t)&outputs_ctx._L2_then_IfBlock1, &_Type_ETCS_modes_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L8", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx._L8_then_IfBlock1, &_Type_ETCS_HMI_Msgs_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 }
};
const MappingScope scope_12 = {
    "Train_Driver/ Train_DriverIfBlock1:then:",
    scope_12_entries, 5
};

const MappingEntry scope_11_entries[5] = {
    /* 0 */ { MAP_LOCAL, "_L16", NULL, sizeof(ETCS_modes), (size_t)&outputs_ctx._L16_then_else_IfBlock1, &_Type_ETCS_modes_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L14", NULL, sizeof(ETCS_HMI_MsgHeaders), (size_t)&outputs_ctx._L14_then_else_IfBlock1, &_Type_ETCS_HMI_MsgHeaders_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L13", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L13_then_else_IfBlock1, &_Type_ETCSHMIPacket_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_true, &scope_2, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(ATO_modes), (size_t)&outputs_ctx._L12_then_else_IfBlock1, &_Type_ATO_modes_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L17", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx._L17_then_else_IfBlock1, &_Type_ETCS_HMI_Msgs_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 }
};
const MappingScope scope_11 = {
    "Train_Driver/ Train_DriverIfBlock1:else:then:",
    scope_11_entries, 5
};

const MappingEntry scope_10_entries[5] = {
    /* 0 */ { MAP_LOCAL, "_L12", NULL, sizeof(ATO_modes), (size_t)&outputs_ctx._L12_then_else_else_IfBlock1, &_Type_ATO_modes_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L11", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L11_then_else_else_IfBlock1, &_Type_ETCSHMIPacket_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_true, &scope_2, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(ETCS_HMI_MsgHeaders), (size_t)&outputs_ctx._L10_then_else_else_IfBlock1, &_Type_ETCS_HMI_MsgHeaders_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L8", NULL, sizeof(ETCS_modes), (size_t)&outputs_ctx._L8_then_else_else_IfBlock1, &_Type_ETCS_modes_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx._L13_then_else_else_IfBlock1, &_Type_ETCS_HMI_Msgs_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 }
};
const MappingScope scope_10 = {
    "Train_Driver/ Train_DriverIfBlock1:else:else:then:",
    scope_10_entries, 5
};

const MappingEntry scope_9_entries[4] = {
    /* 0 */ { MAP_LOCAL, "_L21", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L21_else_else_else_IfBlock1, &_Type_ETCSHMIPacket_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_false, &scope_2, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L20", NULL, sizeof(ETCS_HMI_MsgHeaders), (size_t)&outputs_ctx._L20_else_else_else_IfBlock1, &_Type_ETCS_HMI_MsgHeaders_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L14", NULL, sizeof(ETCS_modes), (size_t)&outputs_ctx._L14_else_else_else_IfBlock1, &_Type_ETCS_modes_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L24", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx._L24_else_else_else_IfBlock1, &_Type_ETCS_HMI_Msgs_Utils, &scope_8_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 3 }
};
const MappingScope scope_9 = {
    "Train_Driver/ Train_DriverIfBlock1:else:else:else:",
    scope_9_entries, 4
};

const MappingEntry scope_8_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.else_clock_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_7_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_8_entries[0], isActive_kcg_bool_kcg_false, &scope_9, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_8_entries[0], isActive_kcg_bool_kcg_true, &scope_10, 1, 2 }
};
const MappingScope scope_8 = {
    "Train_Driver/ Train_DriverIfBlock1:else:else:",
    scope_8_entries, 3
};

const MappingEntry scope_7_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.else_clock_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_7_entries[0], isActive_kcg_bool_kcg_false, &scope_8, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_7_entries[0], isActive_kcg_bool_kcg_true, &scope_11, 1, 2 }
};
const MappingScope scope_7 = {
    "Train_Driver/ Train_DriverIfBlock1:else:",
    scope_7_entries, 3
};

const MappingEntry scope_6_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.IfBlock1_clock, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_6_entries[0], isActive_kcg_bool_kcg_false, &scope_7, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_6_entries[0], isActive_kcg_bool_kcg_true, &scope_12, 1, 2 }
};
const MappingScope scope_6 = {
    "Train_Driver/ Train_DriverIfBlock1:",
    scope_6_entries, 3
};

const MappingEntry scope_5_entries[3] = {
    /* 0 */ { MAP_FIELD, ".Distance_Covered", NULL, sizeof(kcg_int16), offsetof(Tain_Physics_Outputs, Distance_Covered), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".Train_Speed", NULL, sizeof(kcg_int16), offsetof(Tain_Physics_Outputs, Train_Speed), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".Train_Acceleration", NULL, sizeof(kcg_float32), offsetof(Tain_Physics_Outputs, Train_Acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_5 = {
    "Tain_Physics_Outputs",
    scope_5_entries, 3
};

const MappingEntry scope_4_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_30, sizeof(kcg_char), 0, &_Type_kcg_char_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_4 = {
    "array_char_30",
    scope_4_entries, 1
};

const MappingEntry scope_3_entries[3] = {
    /* 0 */ { MAP_FIELD, ".IndicatorState", NULL, sizeof(kcg_int8), offsetof(ExternalindicatorStates, IndicatorState), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".RedLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, RedLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".GreenLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, GreenLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_3 = {
    "ExternalindicatorStates",
    scope_3_entries, 3
};

const MappingEntry scope_2_entries[4] = {
    /* 0 */ { MAP_FIELD, ".Header", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(ETCSHMIPacket, Header), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".Message", NULL, sizeof(ETCS_HMI_Msgs), offsetof(ETCSHMIPacket, Message), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".currentETCSmode", NULL, sizeof(ETCS_modes), offsetof(ETCSHMIPacket, currentETCSmode), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_FIELD, ".currentATOmode", NULL, sizeof(ATO_modes), offsetof(ETCSHMIPacket, currentATOmode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 3 }
};
const MappingScope scope_2 = {
    "ETCSHMIPacket",
    scope_2_entries, 4
};

const MappingEntry scope_1_entries[34] = {
    /* 0 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(OverrideSwitchPosition), (size_t)&outputs_ctx.to_FVA, &_Type_OverrideSwitchPosition_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx.to_ETCS_OB, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_2, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "External_ATORSC_Status", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx.External_ATORSC_Status, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_3, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "ETCSHMI_TextBox", NULL, sizeof(array_char_30), (size_t)&outputs_ctx.ETCSHMI_TextBox, &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "Train_Physics_Output", NULL, sizeof(Tain_Physics_Outputs), (size_t)&outputs_ctx.Train_Physics_Output, &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_5, 1, 4 },
    /* 5 */ { MAP_INPUT, "from_FVA", NULL, sizeof(ExternalindicatorStates), (size_t)&inputs_ctx.from_FVA, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_3, 1, 5 },
    /* 6 */ { MAP_INPUT, "from_ETCS_OB", NULL, sizeof(ETCSHMIPacket), (size_t)&inputs_ctx.from_ETCS_OB, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_2, 1, 6 },
    /* 7 */ { MAP_INPUT, "ATORSCSwitch_Position", NULL, sizeof(OverrideSwitchPosition), (size_t)&inputs_ctx.ATORSCSwitch_Position, &_Type_OverrideSwitchPosition_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INPUT, "SendMessage", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.SendMessage, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_INPUT, "ATO_GoA4_mode_button", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.ATO_GoA4_mode_button, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_INPUT, "ATO_GoA2_mode_button", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.ATO_GoA2_mode_button, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_INPUT, "ETCS_FS_mode_button", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.ETCS_FS_mode_button, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_INPUT, "ThrottleBrakeLever_Position", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.ThrottleBrakeLever_Position, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_INPUT, "Apply_HoldingBrake", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.Apply_HoldingBrake, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_INPUT, "TrainBrakeLever", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.TrainBrakeLever, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "HMItoETCSOB_Message", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx.HMItoETCSOB_Message, &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "Local_OverrideSwitchPosition", NULL, sizeof(OverrideSwitchPosition), (size_t)&outputs_ctx.Local_OverrideSwitchPosition, &_Type_OverrideSwitchPosition_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "Local1", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx.Local1, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "Local2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Local2, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "Local3", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx.Local3, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L2", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L2, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_2, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L4", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx._L4, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_3, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L5", NULL, sizeof(OverrideSwitchPosition), (size_t)&outputs_ctx._L5, &_Type_OverrideSwitchPosition_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L32, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L39", NULL, sizeof(ETCS_HMI_Msgs), (size_t)&outputs_ctx._L39, &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L40", NULL, sizeof(array_char_30), (size_t)&outputs_ctx._L40, &_Type_array_char_30_Utils, NULL, NULL, &scope_4, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L41", NULL, sizeof(Tain_Physics_Outputs), (size_t)&outputs_ctx._L41, &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_5, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L42, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L43, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L44, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 29 },
    /* 30 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_6, 1, 30 },
    /* 31 */ { MAP_INSTANCE, "ETCSHMI_Functions::Read_and_Send_ETCSOB_Data", NULL, sizeof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions), (size_t)&outputs_ctx.Context_Read_and_Send_ETCSOB_Data, NULL, NULL, NULL, &scope_13, 1, 31 },
    /* 32 */ { MAP_IF, "IfBlock2:", NULL, 0, 0, NULL, NULL, NULL, &scope_14, 1, 32 },
    /* 33 */ { MAP_INSTANCE, "Train::Train_Physics 3", NULL, sizeof(outC_Train_Physics_Train), (size_t)&outputs_ctx.Context_Train_Physics_3, NULL, NULL, NULL, &scope_17, 1, 33 }
};
const MappingScope scope_1 = {
    "Train_Driver/ Train_Driver",
    scope_1_entries, 34
};

const MappingEntry scope_0_entries[1] = {
    /* 0 */ { MAP_ROOT, "Train_Driver", NULL, 0, 0, NULL, NULL, NULL, &scope_1, 1, 0 }
};
const MappingScope scope_0 = {
    "",
    scope_0_entries, 1
};

/* entry point */
const MappingScope* pTop = &scope_0;
