/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Test_Environment/Simulation/config.txt
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Sum_of_Forces_Op.h"

/* Op::Sum_of_Forces/ */
void Sum_of_Forces_Op(
  /* Traction_forces_Array/ */
  array_float32_5 *Traction_forces_Array,
  /* Braking_forces_Array/ */
  array_float32_5 *Braking_forces_Array,
  outC_Sum_of_Forces_Op *outC)
{
  kcg_float32 acc;
  kcg_size idx;
  kcg_float32 acc1;
  kcg_size idx2;

  outC->_L2 = kcg_lit_float32(0.0);
  kcg_copy_array_float32_5(&outC->_L7, Traction_forces_Array);
  outC->_L1 = outC->_L2;
  /* _L1= */
  for (idx = 0; idx < 5; idx++) {
    acc = outC->_L1;
    outC->_L1 = acc + outC->_L7[idx];
  }
  outC->Sum_of_traction_forces = outC->_L1;
  kcg_copy_array_float32_5(&outC->_L6, Braking_forces_Array);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = outC->_L5;
  /* _L4= */
  for (idx2 = 0; idx2 < 5; idx2++) {
    acc1 = outC->_L4;
    outC->_L4 = acc1 + outC->_L6[idx2];
  }
  outC->Sum_of_Braking_forces = outC->_L4;
}

#ifndef KCG_USER_DEFINED_INIT
void Sum_of_Forces_init_Op(outC_Sum_of_Forces_Op *outC)
{
  kcg_size idx;
  kcg_size idx1;

  for (idx = 0; idx < 5; idx++) {
    outC->_L7[idx] = kcg_lit_float32(0.0);
  }
  for (idx1 = 0; idx1 < 5; idx1++) {
    outC->_L6[idx1] = kcg_lit_float32(0.0);
  }
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->Sum_of_Braking_forces = kcg_lit_float32(0.0);
  outC->Sum_of_traction_forces = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Sum_of_Forces_reset_Op(outC_Sum_of_Forces_Op *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Sum_of_Forces_Op.c
** Generation date: 2023-10-30T10:44:23
*************************************************************$ */

