/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Vehicle_Management_System.h"

/* Vehicle_Management_System/ */
void Vehicle_Management_System(
  /* from_FVA/ */
  kcg_bool from_FVA,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_ClassB_Systems/ */
  kcg_bool from_ClassB_Systems,
  outC_Vehicle_Management_System *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;
  kcg_bool _2_noname;

  outC->_L4 = kcg_false;
  outC->to_ClassB_Systems = outC->_L4;
  outC->to_ETCS_OB = outC->_L4;
  outC->to_FVA = outC->_L4;
  outC->_L3 = from_ClassB_Systems;
  _2_noname = outC->_L3;
  outC->_L2 = from_ETCS_OB;
  _1_noname = outC->_L2;
  outC->_L1 = from_FVA;
  noname = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void Vehicle_Management_System_init(outC_Vehicle_Management_System *outC)
{
  outC->_L4 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_ClassB_Systems = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->to_FVA = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Vehicle_Management_System_reset(outC_Vehicle_Management_System *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Vehicle_Management_System.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

