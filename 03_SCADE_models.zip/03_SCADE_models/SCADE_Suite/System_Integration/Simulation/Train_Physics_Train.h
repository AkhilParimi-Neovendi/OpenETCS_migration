/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Train_Physics_Train_H_
#define _Train_Physics_Train_H_

#include "kcg_types.h"
#include "Train_with_TandB_Lever.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Tain_Physics_Outputs /* Train_Outputs/ */ Train_Outputs;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Train_with_TandB_Lever /* _L23=(Train_with_TandB_Lever#4)/ */ Context_Train_with_TandB_Lever_4;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  Tain_Physics_Outputs /* _L29/ */ _L29;
  kcg_float32 /* _L25/ */ _L25;
  kcg_int16 /* _L24/ */ _L24;
  kcg_int16 /* _L23/ */ _L23;
  kcg_int8 /* _L30/ */ _L30;
  kcg_bool /* _L31/ */ _L31;
  kcg_int8 /* _L32/ */ _L32;
} outC_Train_Physics_Train;

/* ===========  node initialization and cycle functions  =========== */
/* Train::Train_Physics/ */
extern void Train_Physics_Train(
  /* T_B_Lever/ */
  kcg_int8 T_B_Lever,
  /* HoldingBrakeSwitch/ */
  kcg_bool HoldingBrakeSwitch,
  /* TrainBrakeLever/ */
  kcg_int8 TrainBrakeLever,
  outC_Train_Physics_Train *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Train_Physics_reset_Train(outC_Train_Physics_Train *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Train_Physics_init_Train(outC_Train_Physics_Train *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Train_Physics_Train_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Physics_Train.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

