/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ATO_OB.h"

/* ATO_OB/ */
void ATO_OB(
  /* OnSwitch_GUI/ */
  kcg_bool OnSwitch_GUI,
  /* from_ETCS_OB/ */
  ETCSATOPacket *from_ETCS_OB,
  /* from_Driving_Style_Engine_C15/ */
  kcg_bool from_Driving_Style_Engine_C15,
  /* from_Driving_Style_Engine_ss139/ */
  kcg_bool from_Driving_Style_Engine_ss139,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_RM/ */
  ATO_Packet *from_RM,
  outC_ATO_OB *outC)
{
  /* ATO_State/ */
  kcg_int8 ATO_State_partial;
  /* SM1: */
  _2_SSM_ST_SM1 SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool SM1_reset_nxt_partial;
  /* SM1: */
  _3_SSM_TR_SM1 SM1_fired_partial;
  /* ATO_State/ */
  kcg_int8 _1_ATO_State_partial;
  /* SM1: */
  _2_SSM_ST_SM1 _2_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _3_SM1_reset_nxt_partial;
  /* SM1: */
  _3_SSM_TR_SM1 _4_SM1_fired_partial;
  /* SM1:Power_On:SM2: */
  kcg_bool SM2_reset_prv_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool SM2_reset_sel_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Disengaging:<1> */
  kcg_bool tr_1_guard_ATO_Disengaging_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Disengaging:<2> */
  kcg_bool tr_2_guard_ATO_Disengaging_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Engaged:<1> */
  kcg_bool tr_1_guard_ATO_Engaged_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Engaged:<2> */
  kcg_bool tr_2_guard_ATO_Engaged_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Engaged:<3> */
  kcg_bool tr_3_guard_ATO_Engaged_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _5_SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _6_SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _7_SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Ready:<1> */
  kcg_bool tr_1_guard_ATO_Ready_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Ready:<2> */
  kcg_bool tr_2_guard_ATO_Ready_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Ready:<3> */
  kcg_bool tr_3_guard_ATO_Ready_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _8_SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _9_SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _10_SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Available:<1> */
  kcg_bool tr_1_guard_ATO_Available_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _11_SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _12_SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _13_SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _14_SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _15_SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _16_SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _17_SM2_fired_strong_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _18_SM2_reset_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _19_SM2_state_act_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _20_ATO_State_partial;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _21_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _22_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _23_SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _24_ATO_State_partial;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _25_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _26_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _27_SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _28_ATO_State_partial;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _29_SM2_state_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _30_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _31_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _32_SM2_state_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _33_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _34_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Available:<2> */
  kcg_bool tr_2_guard_ATO_Available_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _35_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _36_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _37_SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _38_ATO_State_partial;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _39_SM2_state_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _40_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _41_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _42_SM2_state_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _43_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _44_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2:ATO_Not_Available:<1> */
  kcg_bool tr_1_guard_ATO_Not_Available_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _45_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _46_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _47_SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _48_ATO_State_partial;
  /* SM1:Power_On:SM2:ATO_Configuration:<1> */
  kcg_bool tr_1_guard_ATO_Configuration_SM2_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_TR_SM2_Power_On_SM1 _49_SM2_fired_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  kcg_bool _50_SM2_reset_nxt_partial_Power_On_SM1;
  /* SM1:Power_On:SM2: */
  SSM_ST_SM2_Power_On_SM1 _51_SM2_state_nxt_partial_Power_On_SM1;
  /* ATO_State/ */
  kcg_int8 _52_ATO_State_partial;
  /* ATO_State/ */
  kcg_int8 _53_ATO_State_partial;
  /* SM1: */
  _2_SSM_ST_SM1 _54_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _55_SM1_reset_nxt_partial;
  /* SM1: */
  _3_SSM_TR_SM1 _56_SM1_fired_partial;
  /* SM1: */
  _2_SSM_ST_SM1 SM1_state_act_partial;
  /* SM1: */
  kcg_bool SM1_reset_act_partial;
  /* SM1: */
  _3_SSM_TR_SM1 SM1_fired_strong_partial;
  /* SM1:No_Power:<1> */
  kcg_bool tr_1_guard_No_Power_SM1;
  /* SM1: */
  _2_SSM_ST_SM1 _57_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _58_SM1_reset_act_partial;
  /* SM1: */
  _3_SSM_TR_SM1 _59_SM1_fired_strong_partial;
  /* SM1:Power_On:<2> */
  kcg_bool tr_2_guard_Power_On_SM1;
  /* SM1:Power_On:<1> */
  kcg_bool tr_1_guard_Power_On_SM1;
  /* SM1: */
  _2_SSM_ST_SM1 _60_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _61_SM1_reset_act_partial;
  /* SM1: */
  _3_SSM_TR_SM1 _62_SM1_fired_strong_partial;
  /* SM1:ATO_Failure:<1> */
  kcg_bool tr_1_guard_ATO_Failure_SM1;
  kcg_bool noname;
  kcg_bool _63_noname;
  kcg_bool _64_noname;
  /* ATO_Mode_Selected/ */
  kcg_int8 last_ATO_Mode_Selected;
  /* Journey_Profile_Received/ */
  kcg_bool last_Journey_Profile_Received;
  /* Override_Switch_State/ */
  kcg_bool last_Override_Switch_State;
  /* ATO_Data_Received/ */
  kcg_bool last_ATO_Data_Received;
  /* ATO_State/ */
  kcg_int8 last_ATO_State;
  /* SM1: */
  kcg_bool SM1_reset_sel;
  /* SM1: */
  kcg_bool SM1_reset_prv;

  last_ATO_Mode_Selected = outC->ATO_Mode_Selected;
  last_Journey_Profile_Received = outC->Journey_Profile_Received;
  last_Override_Switch_State = outC->Override_Switch_State;
  last_ATO_Data_Received = outC->ATO_Data_Received;
  last_ATO_State = outC->ATO_State;
  kcg_copy_ETCSATOPacket(&outC->_L3, from_ETCS_OB);
  outC->_L46 = outC->_L3.ATO_selected_mode;
  outC->_L45 = outC->_L3.ATO_DataAcknowledged;
  outC->_L47 = outC->_L3.temp_Override_SwitchState;
  outC->_L43 = kcg_true;
  outC->ATO_Active_VM = outC->_L43;
  outC->_L41 = OnSwitch_GUI;
  outC->ATO_Power_On = outC->_L41;
  outC->_L40 = kcg_false;
  kcg_copy_ATO_Packet(&outC->_L14, from_RM);
  outC->_L35 = outC->_L14.Value;
  outC->_L36 = outC->_L14.Header;
  outC->_L38 = kcg_lit_int8(2);
  outC->_L37 = outC->_L38 == outC->_L36;
  /* _L39= */
  if (outC->_L37) {
    outC->_L39 = outC->_L35;
  }
  else {
    outC->_L39 = outC->_L40;
  }
  outC->_L34 = kcg_lit_int8(1);
  outC->_L32 = kcg_false;
  outC->_L31 = kcg_true;
  outC->_L29 = last_ATO_State;
  outC->_L30 = kcg_lit_int8(2);
  outC->_L28 = outC->_L30 == outC->_L29;
  /* _L27= */
  if (outC->_L28) {
    outC->_L27 = outC->_L31;
  }
  else {
    outC->_L27 = outC->_L32;
  }
  outC->_L33.Header = outC->_L34;
  outC->_L33.Value = outC->_L27;
  outC->ATO_Mode_Selected = outC->_L46;
  outC->Journey_Profile_Received = outC->_L39;
  outC->Override_Switch_State = outC->_L47;
  outC->ATO_Data_Received = outC->_L45;
  kcg_copy_ATO_Packet(&outC->to_RM, &outC->_L33);
  outC->SM1_state_sel = outC->SM1_state_nxt;
  /* SM1: */
  switch (outC->SM1_state_sel) {
    case SSM_st_ATO_Failure_SM1 :
      tr_1_guard_ATO_Failure_SM1 = kcg_false;
      if (tr_1_guard_ATO_Failure_SM1) {
        _60_SM1_state_act_partial = SSM_st_No_Power_SM1;
      }
      else {
        _60_SM1_state_act_partial = SSM_st_ATO_Failure_SM1;
      }
      outC->SM1_state_act = _60_SM1_state_act_partial;
      if (tr_1_guard_ATO_Failure_SM1) {
        _62_SM1_fired_strong_partial = SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1;
      }
      else {
        _62_SM1_fired_strong_partial = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _62_SM1_fired_strong_partial;
      break;
    case SSM_st_Power_On_SM1 :
      tr_2_guard_Power_On_SM1 = kcg_false;
      tr_1_guard_Power_On_SM1 = outC->ATO_Power_On == kcg_false;
      if (tr_1_guard_Power_On_SM1) {
        _57_SM1_state_act_partial = SSM_st_No_Power_SM1;
      }
      else if (tr_2_guard_Power_On_SM1) {
        _57_SM1_state_act_partial = SSM_st_ATO_Failure_SM1;
      }
      else {
        _57_SM1_state_act_partial = SSM_st_Power_On_SM1;
      }
      outC->SM1_state_act = _57_SM1_state_act_partial;
      if (tr_1_guard_Power_On_SM1) {
        _59_SM1_fired_strong_partial = SSM_TR_Power_On_No_Power_1_Power_On_SM1;
      }
      else if (tr_2_guard_Power_On_SM1) {
        _59_SM1_fired_strong_partial = SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1;
      }
      else {
        _59_SM1_fired_strong_partial = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _59_SM1_fired_strong_partial;
      break;
    case SSM_st_No_Power_SM1 :
      tr_1_guard_No_Power_SM1 = outC->ATO_Power_On == kcg_true;
      if (tr_1_guard_No_Power_SM1) {
        SM1_state_act_partial = SSM_st_Power_On_SM1;
      }
      else {
        SM1_state_act_partial = SSM_st_No_Power_SM1;
      }
      outC->SM1_state_act = SM1_state_act_partial;
      if (tr_1_guard_No_Power_SM1) {
        SM1_fired_strong_partial = SSM_TR_No_Power_Power_On_1_No_Power_SM1;
      }
      else {
        SM1_fired_strong_partial = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = SM1_fired_strong_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  switch (outC->SM1_state_act) {
    case SSM_st_ATO_Failure_SM1 :
      _56_SM1_fired_partial = outC->SM1_fired_strong;
      _55_SM1_reset_nxt_partial = kcg_false;
      _54_SM1_state_nxt_partial = SSM_st_ATO_Failure_SM1;
      outC->_L2_ATO_Failure_SM1 = kcg_lit_int8(7);
      _53_ATO_State_partial = outC->_L2_ATO_Failure_SM1;
      break;
    case SSM_st_Power_On_SM1 :
      _4_SM1_fired_partial = outC->SM1_fired_strong;
      _3_SM1_reset_nxt_partial = kcg_false;
      _2_SM1_state_nxt_partial = SSM_st_Power_On_SM1;
      break;
    default :
      /* this branch is empty */
      break;
  }
  SM1_reset_prv = outC->SM1_reset_act;
  /* SM1: */
  switch (outC->SM1_state_sel) {
    case SSM_st_ATO_Failure_SM1 :
      _61_SM1_reset_act_partial = tr_1_guard_ATO_Failure_SM1;
      outC->SM1_reset_act = _61_SM1_reset_act_partial;
      break;
    case SSM_st_Power_On_SM1 :
      if (tr_1_guard_Power_On_SM1) {
        _58_SM1_reset_act_partial = kcg_true;
      }
      else {
        _58_SM1_reset_act_partial = tr_2_guard_Power_On_SM1;
      }
      outC->SM1_reset_act = _58_SM1_reset_act_partial;
      break;
    case SSM_st_No_Power_SM1 :
      SM1_reset_act_partial = tr_1_guard_No_Power_SM1;
      outC->SM1_reset_act = SM1_reset_act_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  /* SM1: */
  switch (outC->SM1_state_act) {
    case SSM_st_ATO_Failure_SM1 :
      outC->ATO_State = _53_ATO_State_partial;
      outC->SM1_state_nxt = _54_SM1_state_nxt_partial;
      break;
    case SSM_st_Power_On_SM1 :
      if (outC->SM1_reset_act) {
        outC->init = kcg_true;
      }
      /* SM1:Power_On:SM2: */
      if (outC->init) {
        outC->SM2_state_sel_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
      }
      else {
        outC->SM2_state_sel_Power_On_SM1 = outC->SM2_state_nxt_Power_On_SM1;
      }
      outC->SM2_clock_Power_On_SM1 = outC->SM2_state_sel_Power_On_SM1;
      /* SM1:Power_On:SM2: */
      switch (outC->SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          tr_2_guard_ATO_Disengaging_SM2_Power_On_SM1 = kcg_false;
          tr_1_guard_ATO_Disengaging_SM2_Power_On_SM1 = kcg_false;
          if (tr_1_guard_ATO_Disengaging_SM2_Power_On_SM1) {
            SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Engaged_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Disengaging_SM2_Power_On_SM1) {
            SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          }
          else {
            SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Disengaging_SM2_Power_On_SM1;
          }
          outC->SM2_state_act_Power_On_SM1 = SM2_state_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          tr_3_guard_ATO_Engaged_SM2_Power_On_SM1 = kcg_false;
          tr_2_guard_ATO_Engaged_SM2_Power_On_SM1 = kcg_false;
          tr_1_guard_ATO_Engaged_SM2_Power_On_SM1 = kcg_false;
          if (tr_1_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _7_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Disengaging_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _7_SM2_state_act_partial_Power_On_SM1 =
              SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          }
          else if (tr_3_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _7_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
          }
          else {
            _7_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Engaged_SM2_Power_On_SM1;
          }
          outC->SM2_state_act_Power_On_SM1 = _7_SM2_state_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          tr_3_guard_ATO_Ready_SM2_Power_On_SM1 = kcg_false;
          tr_2_guard_ATO_Ready_SM2_Power_On_SM1 = kcg_false;
          tr_1_guard_ATO_Ready_SM2_Power_On_SM1 = !outC->Override_Switch_State;
          if (tr_1_guard_ATO_Ready_SM2_Power_On_SM1) {
            _10_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Engaged_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Ready_SM2_Power_On_SM1) {
            _10_SM2_state_act_partial_Power_On_SM1 =
              SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          }
          else if (tr_3_guard_ATO_Ready_SM2_Power_On_SM1) {
            _10_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
          }
          else {
            _10_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Ready_SM2_Power_On_SM1;
          }
          outC->SM2_state_act_Power_On_SM1 = _10_SM2_state_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          tr_1_guard_ATO_Available_SM2_Power_On_SM1 = kcg_false;
          if (tr_1_guard_ATO_Available_SM2_Power_On_SM1) {
            _13_SM2_state_act_partial_Power_On_SM1 =
              SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          }
          else {
            _13_SM2_state_act_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
          }
          outC->SM2_state_act_Power_On_SM1 = _13_SM2_state_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          _16_SM2_state_act_partial_Power_On_SM1 =
            SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          outC->SM2_state_act_Power_On_SM1 = _16_SM2_state_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          _19_SM2_state_act_partial_Power_On_SM1 =
            SSM_st_ATO_Configuration_SM2_Power_On_SM1;
          outC->SM2_state_act_Power_On_SM1 = _19_SM2_state_act_partial_Power_On_SM1;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      outC->_1_SM2_clock_Power_On_SM1 = outC->SM2_state_act_Power_On_SM1;
      /* SM1:Power_On:SM2: */
      switch (outC->SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Disengaging_SM2_Power_On_SM1) {
            SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Disengaging_SM2_Power_On_SM1) {
            SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1;
          }
          else {
            SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          }
          outC->SM2_fired_strong_Power_On_SM1 = SM2_fired_strong_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _5_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _5_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1;
          }
          else if (tr_3_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _5_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1;
          }
          else {
            _5_SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          }
          outC->SM2_fired_strong_Power_On_SM1 = _5_SM2_fired_strong_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Ready_SM2_Power_On_SM1) {
            _8_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1;
          }
          else if (tr_2_guard_ATO_Ready_SM2_Power_On_SM1) {
            _8_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1;
          }
          else if (tr_3_guard_ATO_Ready_SM2_Power_On_SM1) {
            _8_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1;
          }
          else {
            _8_SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          }
          outC->SM2_fired_strong_Power_On_SM1 = _8_SM2_fired_strong_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Available_SM2_Power_On_SM1) {
            _11_SM2_fired_strong_partial_Power_On_SM1 =
              SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1;
          }
          else {
            _11_SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          }
          outC->SM2_fired_strong_Power_On_SM1 = _11_SM2_fired_strong_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          _14_SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          outC->SM2_fired_strong_Power_On_SM1 = _14_SM2_fired_strong_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          _17_SM2_fired_strong_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          outC->SM2_fired_strong_Power_On_SM1 = _17_SM2_fired_strong_partial_Power_On_SM1;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      /* SM1:Power_On:SM2: */
      switch (outC->_1_SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          SM2_fired_partial_Power_On_SM1 = outC->SM2_fired_strong_Power_On_SM1;
          SM2_reset_nxt_partial_Power_On_SM1 = kcg_false;
          SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Disengaging_SM2_Power_On_SM1;
          outC->_L2_ATO_Disengaging_SM2_Power_On_SM1 = kcg_lit_int8(6);
          _20_ATO_State_partial = outC->_L2_ATO_Disengaging_SM2_Power_On_SM1;
          _1_ATO_State_partial = _20_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = SM2_state_nxt_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          _21_SM2_fired_partial_Power_On_SM1 = outC->SM2_fired_strong_Power_On_SM1;
          _22_SM2_reset_nxt_partial_Power_On_SM1 = kcg_false;
          _23_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Engaged_SM2_Power_On_SM1;
          outC->_L2_ATO_Engaged_SM2_Power_On_SM1 = kcg_lit_int8(5);
          _24_ATO_State_partial = outC->_L2_ATO_Engaged_SM2_Power_On_SM1;
          _1_ATO_State_partial = _24_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = _23_SM2_state_nxt_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          _25_SM2_fired_partial_Power_On_SM1 = outC->SM2_fired_strong_Power_On_SM1;
          _26_SM2_reset_nxt_partial_Power_On_SM1 = kcg_false;
          _27_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Ready_SM2_Power_On_SM1;
          outC->_L3_ATO_Ready_SM2_Power_On_SM1 = kcg_lit_int8(4);
          _28_ATO_State_partial = outC->_L3_ATO_Ready_SM2_Power_On_SM1;
          _1_ATO_State_partial = _28_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = _27_SM2_state_nxt_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          outC->ATO_Available_weakb_clock_SM2_Power_On_SM1 =
            outC->SM2_fired_strong_Power_On_SM1 != SSM_TR_no_trans_SM2_Power_On_SM1;
          /* SM1:Power_On:SM2:ATO_Available: */
          if (outC->ATO_Available_weakb_clock_SM2_Power_On_SM1) {
            _31_SM2_fired_partial_Power_On_SM1 = outC->SM2_fired_strong_Power_On_SM1;
            _30_SM2_reset_nxt_partial_Power_On_SM1 = kcg_false;
            _29_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
            _37_SM2_state_nxt_partial_Power_On_SM1 = _29_SM2_state_nxt_partial_Power_On_SM1;
            _36_SM2_reset_nxt_partial_Power_On_SM1 = _30_SM2_reset_nxt_partial_Power_On_SM1;
            _35_SM2_fired_partial_Power_On_SM1 = _31_SM2_fired_partial_Power_On_SM1;
          }
          else {
            tr_2_guard_ATO_Available_SM2_Power_On_SM1 =
              (outC->ATO_Mode_Selected == kcg_lit_int8(2)) & outC->ATO_Active_VM;
            if (tr_2_guard_ATO_Available_SM2_Power_On_SM1) {
              _34_SM2_fired_partial_Power_On_SM1 =
                SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1;
            }
            else {
              _34_SM2_fired_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
            }
            _33_SM2_reset_nxt_partial_Power_On_SM1 =
              tr_2_guard_ATO_Available_SM2_Power_On_SM1;
            if (tr_2_guard_ATO_Available_SM2_Power_On_SM1) {
              _32_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Ready_SM2_Power_On_SM1;
            }
            else {
              _32_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
            }
            _37_SM2_state_nxt_partial_Power_On_SM1 = _32_SM2_state_nxt_partial_Power_On_SM1;
            _36_SM2_reset_nxt_partial_Power_On_SM1 = _33_SM2_reset_nxt_partial_Power_On_SM1;
            _35_SM2_fired_partial_Power_On_SM1 = _34_SM2_fired_partial_Power_On_SM1;
          }
          outC->_L4_ATO_Available_SM2_Power_On_SM1 = kcg_lit_int8(3);
          _38_ATO_State_partial = outC->_L4_ATO_Available_SM2_Power_On_SM1;
          _1_ATO_State_partial = _38_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = _37_SM2_state_nxt_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          outC->ATO_Not_Available_weakb_clock_SM2_Power_On_SM1 =
            outC->SM2_fired_strong_Power_On_SM1 != SSM_TR_no_trans_SM2_Power_On_SM1;
          /* SM1:Power_On:SM2:ATO_Not_Available: */
          if (outC->ATO_Not_Available_weakb_clock_SM2_Power_On_SM1) {
            _41_SM2_fired_partial_Power_On_SM1 = outC->SM2_fired_strong_Power_On_SM1;
            _40_SM2_reset_nxt_partial_Power_On_SM1 = kcg_false;
            _39_SM2_state_nxt_partial_Power_On_SM1 =
              SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
            _47_SM2_state_nxt_partial_Power_On_SM1 = _39_SM2_state_nxt_partial_Power_On_SM1;
            _46_SM2_reset_nxt_partial_Power_On_SM1 = _40_SM2_reset_nxt_partial_Power_On_SM1;
            _45_SM2_fired_partial_Power_On_SM1 = _41_SM2_fired_partial_Power_On_SM1;
          }
          else {
            tr_1_guard_ATO_Not_Available_SM2_Power_On_SM1 = outC->Journey_Profile_Received;
            if (tr_1_guard_ATO_Not_Available_SM2_Power_On_SM1) {
              _44_SM2_fired_partial_Power_On_SM1 =
                SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1;
            }
            else {
              _44_SM2_fired_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
            }
            _43_SM2_reset_nxt_partial_Power_On_SM1 =
              tr_1_guard_ATO_Not_Available_SM2_Power_On_SM1;
            if (tr_1_guard_ATO_Not_Available_SM2_Power_On_SM1) {
              _42_SM2_state_nxt_partial_Power_On_SM1 = SSM_st_ATO_Available_SM2_Power_On_SM1;
            }
            else {
              _42_SM2_state_nxt_partial_Power_On_SM1 =
                SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
            }
            _47_SM2_state_nxt_partial_Power_On_SM1 = _42_SM2_state_nxt_partial_Power_On_SM1;
            _46_SM2_reset_nxt_partial_Power_On_SM1 = _43_SM2_reset_nxt_partial_Power_On_SM1;
            _45_SM2_fired_partial_Power_On_SM1 = _44_SM2_fired_partial_Power_On_SM1;
          }
          outC->_L2_ATO_Not_Available_SM2_Power_On_SM1 = kcg_lit_int8(2);
          _48_ATO_State_partial = outC->_L2_ATO_Not_Available_SM2_Power_On_SM1;
          _1_ATO_State_partial = _48_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = _47_SM2_state_nxt_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          tr_1_guard_ATO_Configuration_SM2_Power_On_SM1 = outC->ATO_Data_Received;
          if (tr_1_guard_ATO_Configuration_SM2_Power_On_SM1) {
            _49_SM2_fired_partial_Power_On_SM1 =
              SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1;
          }
          else {
            _49_SM2_fired_partial_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
          }
          _50_SM2_reset_nxt_partial_Power_On_SM1 =
            tr_1_guard_ATO_Configuration_SM2_Power_On_SM1;
          if (tr_1_guard_ATO_Configuration_SM2_Power_On_SM1) {
            _51_SM2_state_nxt_partial_Power_On_SM1 =
              SSM_st_ATO_Not_Available_SM2_Power_On_SM1;
          }
          else {
            _51_SM2_state_nxt_partial_Power_On_SM1 =
              SSM_st_ATO_Configuration_SM2_Power_On_SM1;
          }
          outC->_L3_ATO_Configuration_SM2_Power_On_SM1 = kcg_lit_int8(1);
          _52_ATO_State_partial = outC->_L3_ATO_Configuration_SM2_Power_On_SM1;
          _1_ATO_State_partial = _52_ATO_State_partial;
          outC->SM2_state_nxt_Power_On_SM1 = _51_SM2_state_nxt_partial_Power_On_SM1;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      /* SM1:Power_On:SM2: */
      if (outC->init) {
        SM2_reset_sel_Power_On_SM1 = kcg_false;
      }
      else {
        SM2_reset_sel_Power_On_SM1 = outC->SM2_reset_nxt_Power_On_SM1;
      }
      /* SM1:Power_On:SM2: */
      switch (outC->_1_SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = SM2_fired_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = _22_SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = _21_SM2_fired_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = _26_SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = _25_SM2_fired_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = _36_SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = _35_SM2_fired_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = _46_SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = _45_SM2_fired_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          outC->SM2_reset_nxt_Power_On_SM1 = _50_SM2_reset_nxt_partial_Power_On_SM1;
          outC->SM2_fired_Power_On_SM1 = _49_SM2_fired_partial_Power_On_SM1;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      switch (outC->SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Disengaging_SM2_Power_On_SM1) {
            SM2_reset_act_partial_Power_On_SM1 = kcg_true;
          }
          else {
            SM2_reset_act_partial_Power_On_SM1 =
              tr_2_guard_ATO_Disengaging_SM2_Power_On_SM1;
          }
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _6_SM2_reset_act_partial_Power_On_SM1 = kcg_true;
          }
          else if (tr_2_guard_ATO_Engaged_SM2_Power_On_SM1) {
            _6_SM2_reset_act_partial_Power_On_SM1 = kcg_true;
          }
          else {
            _6_SM2_reset_act_partial_Power_On_SM1 = tr_3_guard_ATO_Engaged_SM2_Power_On_SM1;
          }
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          if (tr_1_guard_ATO_Ready_SM2_Power_On_SM1) {
            _9_SM2_reset_act_partial_Power_On_SM1 = kcg_true;
          }
          else if (tr_2_guard_ATO_Ready_SM2_Power_On_SM1) {
            _9_SM2_reset_act_partial_Power_On_SM1 = kcg_true;
          }
          else {
            _9_SM2_reset_act_partial_Power_On_SM1 = tr_3_guard_ATO_Ready_SM2_Power_On_SM1;
          }
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          _12_SM2_reset_act_partial_Power_On_SM1 =
            tr_1_guard_ATO_Available_SM2_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          _15_SM2_reset_act_partial_Power_On_SM1 = kcg_false;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          _18_SM2_reset_act_partial_Power_On_SM1 = kcg_false;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      /* SM1:Power_On:SM2: */
      if (outC->init) {
        SM2_reset_prv_Power_On_SM1 = kcg_false;
      }
      else {
        SM2_reset_prv_Power_On_SM1 = outC->SM2_reset_act_Power_On_SM1;
      }
      /* SM1:Power_On:SM2: */
      switch (outC->SM2_clock_Power_On_SM1) {
        case SSM_st_ATO_Disengaging_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = SM2_reset_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Engaged_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = _6_SM2_reset_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Ready_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = _9_SM2_reset_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Available_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = _12_SM2_reset_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Not_Available_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = _15_SM2_reset_act_partial_Power_On_SM1;
          break;
        case SSM_st_ATO_Configuration_SM2_Power_On_SM1 :
          outC->SM2_reset_act_Power_On_SM1 = _18_SM2_reset_act_partial_Power_On_SM1;
          break;
        default :
          /* this default branch is unreachable */
          break;
      }
      outC->ATO_State = _1_ATO_State_partial;
      outC->SM1_state_nxt = _2_SM1_state_nxt_partial;
      break;
    case SSM_st_No_Power_SM1 :
      SM1_fired_partial = outC->SM1_fired_strong;
      SM1_reset_nxt_partial = kcg_false;
      SM1_state_nxt_partial = SSM_st_No_Power_SM1;
      outC->_L2_No_Power_SM1 = kcg_lit_int8(0);
      ATO_State_partial = outC->_L2_No_Power_SM1;
      outC->ATO_State = ATO_State_partial;
      outC->SM1_state_nxt = SM1_state_nxt_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  SM1_reset_sel = outC->SM1_reset_nxt;
  /* SM1: */
  switch (outC->SM1_state_act) {
    case SSM_st_ATO_Failure_SM1 :
      outC->SM1_reset_nxt = _55_SM1_reset_nxt_partial;
      outC->SM1_fired = _56_SM1_fired_partial;
      break;
    case SSM_st_Power_On_SM1 :
      outC->SM1_reset_nxt = _3_SM1_reset_nxt_partial;
      outC->SM1_fired = _4_SM1_fired_partial;
      break;
    case SSM_st_No_Power_SM1 :
      outC->SM1_reset_nxt = SM1_reset_nxt_partial;
      outC->SM1_fired = SM1_fired_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  outC->_L5 = from_Driving_Style_Engine_C15;
  _64_noname = outC->_L5;
  outC->_L4 = from_Diagnostic_Platform;
  _63_noname = outC->_L4;
  outC->_L1 = from_Driving_Style_Engine_ss139;
  noname = outC->_L1;
  outC->_L2 = kcg_false;
  outC->to_Driving_Style_Engine_C15 = outC->_L2;
  outC->to_Diagnostic_Platform = outC->_L2;
  outC->to_Driving_Style_Engine_ss139 = outC->_L2;
  outC->to_ETCS_OB = outC->_L2;
  switch (outC->SM1_state_act) {
    case SSM_st_Power_On_SM1 :
      outC->init = kcg_false;
      break;
    default :
      /* this branch is empty */
      break;
  }
}

#ifndef KCG_USER_DEFINED_INIT
void ATO_OB_init(outC_ATO_OB *outC)
{
  outC->_L47 = kcg_true;
  outC->_L45 = kcg_true;
  outC->_L46 = kcg_lit_int8(0);
  outC->_L43 = kcg_true;
  outC->_L41 = kcg_true;
  outC->_L40 = kcg_true;
  outC->_L39 = kcg_true;
  outC->_L38 = kcg_lit_int8(0);
  outC->_L37 = kcg_true;
  outC->_L35 = kcg_true;
  outC->_L36 = kcg_lit_int8(0);
  outC->_L34 = kcg_lit_int8(0);
  outC->_L33.Header = kcg_lit_int8(0);
  outC->_L33.Value = kcg_true;
  outC->_L27 = kcg_true;
  outC->_L28 = kcg_true;
  outC->_L29 = kcg_lit_int8(0);
  outC->_L30 = kcg_lit_int8(0);
  outC->_L31 = kcg_true;
  outC->_L32 = kcg_true;
  outC->_L14.Header = kcg_lit_int8(0);
  outC->_L14.Value = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L3.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L3.ATO_DataAcknowledged = kcg_true;
  outC->_L3.temp_Override_SwitchState = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->ATO_Active_VM = kcg_true;
  outC->ATO_Power_On = kcg_true;
  outC->SM1_fired = SSM_TR_no_trans_SM1;
  outC->SM1_fired_strong = SSM_TR_no_trans_SM1;
  outC->SM1_state_act = SSM_st_No_Power_SM1;
  outC->SM1_state_sel = SSM_st_No_Power_SM1;
  outC->_L2_ATO_Failure_SM1 = kcg_lit_int8(0);
  outC->_L3_ATO_Configuration_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->_L2_ATO_Not_Available_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->ATO_Not_Available_weakb_clock_SM2_Power_On_SM1 = kcg_true;
  outC->_L4_ATO_Available_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->ATO_Available_weakb_clock_SM2_Power_On_SM1 = kcg_true;
  outC->_L3_ATO_Ready_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->_L2_ATO_Engaged_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->_L2_ATO_Disengaging_SM2_Power_On_SM1 = kcg_lit_int8(0);
  outC->_1_SM2_clock_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
  outC->SM2_clock_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
  outC->SM2_state_sel_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
  outC->SM2_state_act_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
  outC->SM2_fired_strong_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
  outC->SM2_fired_Power_On_SM1 = SSM_TR_no_trans_SM2_Power_On_SM1;
  outC->_L2_No_Power_SM1 = kcg_lit_int8(0);
  outC->SM2_state_nxt_Power_On_SM1 = SSM_st_ATO_Configuration_SM2_Power_On_SM1;
  outC->SM2_reset_act_Power_On_SM1 = kcg_true;
  outC->SM2_reset_nxt_Power_On_SM1 = kcg_true;
  outC->init = kcg_true;
  outC->to_RM.Header = kcg_lit_int8(0);
  outC->to_RM.Value = kcg_true;
  outC->to_Driving_Style_Engine_C15 = kcg_true;
  outC->to_Diagnostic_Platform = kcg_true;
  outC->to_Driving_Style_Engine_ss139 = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->SM1_reset_nxt = kcg_false;
  outC->SM1_reset_act = kcg_false;
  outC->SM1_state_nxt = SSM_st_No_Power_SM1;
  outC->ATO_State = int8init;
  outC->ATO_Data_Received = boolinit;
  outC->Override_Switch_State = boolinit;
  outC->Journey_Profile_Received = boolinit;
  outC->ATO_Mode_Selected = int8init;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ATO_OB_reset(outC_ATO_OB *outC)
{
  outC->init = kcg_true;
  outC->SM1_reset_nxt = kcg_false;
  outC->SM1_reset_act = kcg_false;
  outC->SM1_state_nxt = SSM_st_No_Power_SM1;
  outC->ATO_State = int8init;
  outC->ATO_Data_Received = boolinit;
  outC->Override_Switch_State = boolinit;
  outC->Journey_Profile_Received = boolinit;
  outC->ATO_Mode_Selected = int8init;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ATO_OB.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

