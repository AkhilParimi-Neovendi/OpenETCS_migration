/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _KCG_TYPES_H_
#define _KCG_TYPES_H_

#include "stddef.h"

#define KCG_MAPW_CPY

#include "./user_macros.h"

#ifndef kcg_char
#define kcg_char kcg_char
typedef char kcg_char;
#endif /* kcg_char */

#ifndef kcg_bool
#define kcg_bool kcg_bool
typedef unsigned char kcg_bool;
#endif /* kcg_bool */

#ifndef kcg_float32
#define kcg_float32 kcg_float32
typedef float kcg_float32;
#endif /* kcg_float32 */

#ifndef kcg_float64
#define kcg_float64 kcg_float64
typedef double kcg_float64;
#endif /* kcg_float64 */

#ifndef kcg_size
#define kcg_size kcg_size
typedef ptrdiff_t kcg_size;
#endif /* kcg_size */

#ifndef kcg_uint64
#define kcg_uint64 kcg_uint64
typedef unsigned long long kcg_uint64;
#endif /* kcg_uint64 */

#ifndef kcg_uint32
#define kcg_uint32 kcg_uint32
typedef unsigned long kcg_uint32;
#endif /* kcg_uint32 */

#ifndef kcg_uint16
#define kcg_uint16 kcg_uint16
typedef unsigned short kcg_uint16;
#endif /* kcg_uint16 */

#ifndef kcg_uint8
#define kcg_uint8 kcg_uint8
typedef unsigned char kcg_uint8;
#endif /* kcg_uint8 */

#ifndef kcg_int64
#define kcg_int64 kcg_int64
typedef signed long long kcg_int64;
#endif /* kcg_int64 */

#ifndef kcg_int32
#define kcg_int32 kcg_int32
typedef signed long kcg_int32;
#endif /* kcg_int32 */

#ifndef kcg_int16
#define kcg_int16 kcg_int16
typedef signed short kcg_int16;
#endif /* kcg_int16 */

#ifndef kcg_int8
#define kcg_int8 kcg_int8
typedef signed char kcg_int8;
#endif /* kcg_int8 */

#ifndef kcg_lit_float32
#define kcg_lit_float32(kcg_C1) ((kcg_float32) (kcg_C1))
#endif /* kcg_lit_float32 */

#ifndef kcg_lit_float64
#define kcg_lit_float64(kcg_C1) ((kcg_float64) (kcg_C1))
#endif /* kcg_lit_float64 */

#ifndef kcg_lit_size
#define kcg_lit_size(kcg_C1) ((kcg_size) (kcg_C1))
#endif /* kcg_lit_size */

#ifndef kcg_lit_uint64
#define kcg_lit_uint64(kcg_C1) ((kcg_uint64) (kcg_C1))
#endif /* kcg_lit_uint64 */

#ifndef kcg_lit_uint32
#define kcg_lit_uint32(kcg_C1) ((kcg_uint32) (kcg_C1))
#endif /* kcg_lit_uint32 */

#ifndef kcg_lit_uint16
#define kcg_lit_uint16(kcg_C1) ((kcg_uint16) (kcg_C1))
#endif /* kcg_lit_uint16 */

#ifndef kcg_lit_uint8
#define kcg_lit_uint8(kcg_C1) ((kcg_uint8) (kcg_C1))
#endif /* kcg_lit_uint8 */

#ifndef kcg_lit_int64
#define kcg_lit_int64(kcg_C1) ((kcg_int64) (kcg_C1))
#endif /* kcg_lit_int64 */

#ifndef kcg_lit_int32
#define kcg_lit_int32(kcg_C1) ((kcg_int32) (kcg_C1))
#endif /* kcg_lit_int32 */

#ifndef kcg_lit_int16
#define kcg_lit_int16(kcg_C1) ((kcg_int16) (kcg_C1))
#endif /* kcg_lit_int16 */

#ifndef kcg_lit_int8
#define kcg_lit_int8(kcg_C1) ((kcg_int8) (kcg_C1))
#endif /* kcg_lit_int8 */

#ifndef kcg_false
#define kcg_false ((kcg_bool) 0)
#endif /* kcg_false */

#ifndef kcg_true
#define kcg_true ((kcg_bool) 1)
#endif /* kcg_true */

#ifndef kcg_lsl_uint64
#define kcg_lsl_uint64(kcg_C1, kcg_C2)                                        \
  ((kcg_uint64) ((kcg_C1) << (kcg_C2)) & 0xffffffffffffffff)
#endif /* kcg_lsl_uint64 */

#ifndef kcg_lsl_uint32
#define kcg_lsl_uint32(kcg_C1, kcg_C2)                                        \
  ((kcg_uint32) ((kcg_C1) << (kcg_C2)) & 0xffffffff)
#endif /* kcg_lsl_uint32 */

#ifndef kcg_lsl_uint16
#define kcg_lsl_uint16(kcg_C1, kcg_C2)                                        \
  ((kcg_uint16) ((kcg_C1) << (kcg_C2)) & 0xffff)
#endif /* kcg_lsl_uint16 */

#ifndef kcg_lsl_uint8
#define kcg_lsl_uint8(kcg_C1, kcg_C2)                                         \
  ((kcg_uint8) ((kcg_C1) << (kcg_C2)) & 0xff)
#endif /* kcg_lsl_uint8 */

#ifndef kcg_lnot_uint64
#define kcg_lnot_uint64(kcg_C1) ((kcg_C1) ^ 0xffffffffffffffff)
#endif /* kcg_lnot_uint64 */

#ifndef kcg_lnot_uint32
#define kcg_lnot_uint32(kcg_C1) ((kcg_C1) ^ 0xffffffff)
#endif /* kcg_lnot_uint32 */

#ifndef kcg_lnot_uint16
#define kcg_lnot_uint16(kcg_C1) ((kcg_C1) ^ 0xffff)
#endif /* kcg_lnot_uint16 */

#ifndef kcg_lnot_uint8
#define kcg_lnot_uint8(kcg_C1) ((kcg_C1) ^ 0xff)
#endif /* kcg_lnot_uint8 */

#ifndef kcg_assign
#include "kcg_assign.h"
#endif /* kcg_assign */

#ifndef kcg_assign_struct
#define kcg_assign_struct kcg_assign
#endif /* kcg_assign_struct */

#ifndef kcg_assign_array
#define kcg_assign_array kcg_assign
#endif /* kcg_assign_array */

/* ATO_OB/SM1: */
typedef enum kcg_tag__3_SSM_TR_SM1 {
  SSM_TR_no_trans_SM1,
  SSM_TR_No_Power_Power_On_1_No_Power_SM1,
  SSM_TR_Power_On_No_Power_1_Power_On_SM1,
  SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1,
  SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1
} _3_SSM_TR_SM1;
/* ATO_OB/SM1: */
typedef enum kcg_tag__2_SSM_ST_SM1 {
  SSM_st_No_Power_SM1,
  SSM_st_Power_On_SM1,
  SSM_st_ATO_Failure_SM1
} _2_SSM_ST_SM1;
/* ATO_OB/SM1:Power_On:SM2: */
typedef enum kcg_tag_SSM_TR_SM2_Power_On_SM1 {
  SSM_TR_no_trans_SM2_Power_On_SM1,
  SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1,
  SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1,
  SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1,
  SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1,
  SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1,
  SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1,
  SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1,
  SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1,
  SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1,
  SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1,
  SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1,
  SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1
} SSM_TR_SM2_Power_On_SM1;
/* ATO_OB/SM1:Power_On:SM2: */
typedef enum kcg_tag_SSM_ST_SM2_Power_On_SM1 {
  SSM_st_ATO_Configuration_SM2_Power_On_SM1,
  SSM_st_ATO_Not_Available_SM2_Power_On_SM1,
  SSM_st_ATO_Available_SM2_Power_On_SM1,
  SSM_st_ATO_Ready_SM2_Power_On_SM1,
  SSM_st_ATO_Engaged_SM2_Power_On_SM1,
  SSM_st_ATO_Disengaging_SM2_Power_On_SM1
} SSM_ST_SM2_Power_On_SM1;
/* Functional_Vehicle_Adapter/OverrideSwitch_SM: */
typedef enum kcg_tag_SSM_TR_OverrideSwitch_SM {
  SSM_TR_no_trans_OverrideSwitch_SM,
  SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM,
  SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM,
  SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM,
  SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM,
  SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM,
  SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM
} SSM_TR_OverrideSwitch_SM;
/* Functional_Vehicle_Adapter/OverrideSwitch_SM: */
typedef enum kcg_tag_SSM_ST_OverrideSwitch_SM {
  SSM_st_Manual_Mode_OverrideSwitch_SM,
  SSM_st_ATO_Mode_OverrideSwitch_SM,
  SSM_st_RSC_Mode_OverrideSwitch_SM
} SSM_ST_OverrideSwitch_SM;
/* RSC_OB/SM1: */
typedef enum kcg_tag_SSM_TR_SM1 {
  _4_SSM_TR_no_trans_SM1,
  SSM_TR_Connecting_Available_1_Connecting_SM1,
  SSM_TR_Available_Remote_Supervision_1_Available_SM1,
  SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1,
  SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1,
  SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1,
  SSM_TR_Remote_Control_Available_1_Remote_Control_SM1,
  SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1,
  SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1,
  SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1,
  _7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1,
  SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1,
  _5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1,
  _6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1,
  SSM_TR_Intitial_Connecting_1_Intitial_SM1
} SSM_TR_SM1;
/* RSC_OB/SM1: */
typedef enum kcg_tag_SSM_ST_SM1 {
  SSM_st_Connecting_SM1,
  SSM_st_Available_SM1,
  SSM_st_Remote_Supervision_SM1,
  SSM_st_Remote_Control_SM1,
  SSM_st_InterruptedRemoteSupervision_SM1,
  SSM_st_InterruptedRemoteControl_SM1,
  SSM_st_Intitial_SM1
} SSM_ST_SM1;
typedef kcg_char array_char_30[30];

/* Override_Switch_State/ */
typedef kcg_bool Override_Switch_State;

typedef kcg_bool array_bool_3[3];

typedef kcg_bool array_bool_4[4];

typedef kcg_bool array_bool_5[5];

typedef kcg_bool array_bool_1[1];

typedef kcg_bool array_bool_6[6];

typedef kcg_float32 array_float32_5[5];

/* LCF_Data/ */
typedef struct kcg_tag_LCF_Data { array_float32_5 LCF_Values; } LCF_Data;

typedef kcg_float32 array_float32_1[1];

typedef kcg_float32 array_float32_4[4];

typedef struct kcg_tag_struct_11590 {
  kcg_size idx;
  array_bool_6 items;
} struct_11590;

typedef struct kcg_tag_struct_11492 {
  kcg_size idx;
  array_bool_3 items;
} struct_11492;

typedef kcg_int32 array_int32_5[5];

typedef kcg_int32 array_int32_1[1];

typedef kcg_int32 array_int32_4[4];

/* Tain_Physics_Outputs/ */
typedef struct kcg_tag_Tain_Physics_Outputs {
  kcg_int16 Distance_Covered;
  kcg_int16 Train_Speed;
  kcg_float32 Train_Acceleration;
} Tain_Physics_Outputs;

/* ATORSCSwitchPosition/ */
typedef kcg_int8 ATORSCSwitchPosition;

/* FVAHMIPacket/ */
typedef struct kcg_tag_FVAHMIPacket {
  Override_Switch_State OverrideSwitch;
  ATORSCSwitchPosition ATORSCSwitch;
} FVAHMIPacket;

/* ETCS_modes/ */
typedef kcg_int8 ETCS_modes;

/* ETCS_HMI_Msgs/ */
typedef kcg_int8 ETCS_HMI_Msgs;

/* ETCS_HMI_MsgHeaders/ */
typedef kcg_int8 ETCS_HMI_MsgHeaders;

/* ATO_modes/ */
typedef kcg_int8 ATO_modes;

/* ETCSATOPacket/ */
typedef struct kcg_tag_ETCSATOPacket {
  ATO_modes ATO_selected_mode;
  kcg_bool ATO_DataAcknowledged;
  kcg_bool temp_Override_SwitchState;
} ETCSATOPacket;

/* ETCSHMIPacketDataType/ */
typedef struct kcg_tag_ETCSHMIPacketDataType {
  kcg_int8 label1;
  kcg_int8 label2;
  kcg_int8 label3;
  kcg_int8 label4;
  kcg_int8 label5;
  kcg_int8 label6;
  kcg_int16 label7;
  kcg_int16 label8;
} ETCSHMIPacketDataType;

/* ETCSHMIPacket/ */
typedef struct kcg_tag_ETCSHMIPacket {
  kcg_bool isvalid;
  ETCS_HMI_MsgHeaders Header;
  ETCS_HMI_Msgs Message;
  ETCS_modes currentETCSmode;
  ATO_modes currentATOmode;
  ETCSHMIPacketDataType ETCSHMIPacketData;
} ETCSHMIPacket;

/* ExternalindicatorStates/ */
typedef struct kcg_tag_ExternalindicatorStates {
  kcg_int8 IndicatorState;
  kcg_bool RedLight;
  kcg_bool GreenLight;
} ExternalindicatorStates;

/* ATO_Packet/ */
typedef struct kcg_tag_ATO_Packet {
  kcg_int8 Header;
  kcg_bool Value;
} ATO_Packet;

#ifndef kcg_copy_struct_11492
#define kcg_copy_struct_11492(kcg_C1, kcg_C2)                                 \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct_11492)))
#endif /* kcg_copy_struct_11492 */

#ifndef kcg_copy_ATO_Packet
#define kcg_copy_ATO_Packet(kcg_C1, kcg_C2)                                   \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ATO_Packet)))
#endif /* kcg_copy_ATO_Packet */

#ifndef kcg_copy_ETCSATOPacket
#define kcg_copy_ETCSATOPacket(kcg_C1, kcg_C2)                                \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ETCSATOPacket)))
#endif /* kcg_copy_ETCSATOPacket */

#ifndef kcg_copy_Tain_Physics_Outputs
#define kcg_copy_Tain_Physics_Outputs(kcg_C1, kcg_C2)                         \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (Tain_Physics_Outputs)))
#endif /* kcg_copy_Tain_Physics_Outputs */

#ifndef kcg_copy_struct_11590
#define kcg_copy_struct_11590(kcg_C1, kcg_C2)                                 \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct_11590)))
#endif /* kcg_copy_struct_11590 */

#ifndef kcg_copy_FVAHMIPacket
#define kcg_copy_FVAHMIPacket(kcg_C1, kcg_C2)                                 \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (FVAHMIPacket)))
#endif /* kcg_copy_FVAHMIPacket */

#ifndef kcg_copy_ETCSHMIPacket
#define kcg_copy_ETCSHMIPacket(kcg_C1, kcg_C2)                                \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ETCSHMIPacket)))
#endif /* kcg_copy_ETCSHMIPacket */

#ifndef kcg_copy_LCF_Data
#define kcg_copy_LCF_Data(kcg_C1, kcg_C2)                                     \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (LCF_Data)))
#endif /* kcg_copy_LCF_Data */

#ifndef kcg_copy_ExternalindicatorStates
#define kcg_copy_ExternalindicatorStates(kcg_C1, kcg_C2)                      \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ExternalindicatorStates)))
#endif /* kcg_copy_ExternalindicatorStates */

#ifndef kcg_copy_ETCSHMIPacketDataType
#define kcg_copy_ETCSHMIPacketDataType(kcg_C1, kcg_C2)                        \
  (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (ETCSHMIPacketDataType)))
#endif /* kcg_copy_ETCSHMIPacketDataType */

#ifndef kcg_copy_array_int32_4
#define kcg_copy_array_int32_4(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_4)))
#endif /* kcg_copy_array_int32_4 */

#ifndef kcg_copy_array_bool_6
#define kcg_copy_array_bool_6(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_6)))
#endif /* kcg_copy_array_bool_6 */

#ifndef kcg_copy_array_float32_4
#define kcg_copy_array_float32_4(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_4)))
#endif /* kcg_copy_array_float32_4 */

#ifndef kcg_copy_array_int32_1
#define kcg_copy_array_int32_1(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_1)))
#endif /* kcg_copy_array_int32_1 */

#ifndef kcg_copy_array_bool_1
#define kcg_copy_array_bool_1(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_1)))
#endif /* kcg_copy_array_bool_1 */

#ifndef kcg_copy_array_float32_1
#define kcg_copy_array_float32_1(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_1)))
#endif /* kcg_copy_array_float32_1 */

#ifndef kcg_copy_array_bool_5
#define kcg_copy_array_bool_5(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_5)))
#endif /* kcg_copy_array_bool_5 */

#ifndef kcg_copy_array_char_30
#define kcg_copy_array_char_30(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_char_30)))
#endif /* kcg_copy_array_char_30 */

#ifndef kcg_copy_array_bool_4
#define kcg_copy_array_bool_4(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_4)))
#endif /* kcg_copy_array_bool_4 */

#ifndef kcg_copy_array_int32_5
#define kcg_copy_array_int32_5(kcg_C1, kcg_C2)                                \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int32_5)))
#endif /* kcg_copy_array_int32_5 */

#ifndef kcg_copy_array_float32_5
#define kcg_copy_array_float32_5(kcg_C1, kcg_C2)                              \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_float32_5)))
#endif /* kcg_copy_array_float32_5 */

#ifndef kcg_copy_array_bool_3
#define kcg_copy_array_bool_3(kcg_C1, kcg_C2)                                 \
  (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_3)))
#endif /* kcg_copy_array_bool_3 */

#ifdef kcg_use_struct_11492
#ifndef kcg_comp_struct_11492
extern kcg_bool kcg_comp_struct_11492(
  struct_11492 *kcg_c1,
  struct_11492 *kcg_c2);
#endif /* kcg_comp_struct_11492 */
#endif /* kcg_use_struct_11492 */

#ifdef kcg_use_ATO_Packet
#ifndef kcg_comp_ATO_Packet
extern kcg_bool kcg_comp_ATO_Packet(ATO_Packet *kcg_c1, ATO_Packet *kcg_c2);
#endif /* kcg_comp_ATO_Packet */
#endif /* kcg_use_ATO_Packet */

#ifdef kcg_use_ETCSATOPacket
#ifndef kcg_comp_ETCSATOPacket
extern kcg_bool kcg_comp_ETCSATOPacket(
  ETCSATOPacket *kcg_c1,
  ETCSATOPacket *kcg_c2);
#endif /* kcg_comp_ETCSATOPacket */
#endif /* kcg_use_ETCSATOPacket */

#ifdef kcg_use_Tain_Physics_Outputs
#ifndef kcg_comp_Tain_Physics_Outputs
extern kcg_bool kcg_comp_Tain_Physics_Outputs(
  Tain_Physics_Outputs *kcg_c1,
  Tain_Physics_Outputs *kcg_c2);
#endif /* kcg_comp_Tain_Physics_Outputs */
#endif /* kcg_use_Tain_Physics_Outputs */

#ifdef kcg_use_struct_11590
#ifndef kcg_comp_struct_11590
extern kcg_bool kcg_comp_struct_11590(
  struct_11590 *kcg_c1,
  struct_11590 *kcg_c2);
#endif /* kcg_comp_struct_11590 */
#endif /* kcg_use_struct_11590 */

#ifdef kcg_use_FVAHMIPacket
#ifndef kcg_comp_FVAHMIPacket
extern kcg_bool kcg_comp_FVAHMIPacket(
  FVAHMIPacket *kcg_c1,
  FVAHMIPacket *kcg_c2);
#endif /* kcg_comp_FVAHMIPacket */
#endif /* kcg_use_FVAHMIPacket */

#ifdef kcg_use_ETCSHMIPacket
#ifndef kcg_comp_ETCSHMIPacket
extern kcg_bool kcg_comp_ETCSHMIPacket(
  ETCSHMIPacket *kcg_c1,
  ETCSHMIPacket *kcg_c2);
#endif /* kcg_comp_ETCSHMIPacket */
#endif /* kcg_use_ETCSHMIPacket */

#ifdef kcg_use_LCF_Data
#ifndef kcg_comp_LCF_Data
extern kcg_bool kcg_comp_LCF_Data(LCF_Data *kcg_c1, LCF_Data *kcg_c2);
#endif /* kcg_comp_LCF_Data */
#endif /* kcg_use_LCF_Data */

#ifdef kcg_use_ExternalindicatorStates
#ifndef kcg_comp_ExternalindicatorStates
extern kcg_bool kcg_comp_ExternalindicatorStates(
  ExternalindicatorStates *kcg_c1,
  ExternalindicatorStates *kcg_c2);
#endif /* kcg_comp_ExternalindicatorStates */
#endif /* kcg_use_ExternalindicatorStates */

#ifdef kcg_use_ETCSHMIPacketDataType
#ifndef kcg_comp_ETCSHMIPacketDataType
extern kcg_bool kcg_comp_ETCSHMIPacketDataType(
  ETCSHMIPacketDataType *kcg_c1,
  ETCSHMIPacketDataType *kcg_c2);
#endif /* kcg_comp_ETCSHMIPacketDataType */
#endif /* kcg_use_ETCSHMIPacketDataType */

#ifdef kcg_use_array_int32_4
#ifndef kcg_comp_array_int32_4
extern kcg_bool kcg_comp_array_int32_4(
  array_int32_4 *kcg_c1,
  array_int32_4 *kcg_c2);
#endif /* kcg_comp_array_int32_4 */
#endif /* kcg_use_array_int32_4 */

#ifdef kcg_use_array_bool_6
#ifndef kcg_comp_array_bool_6
extern kcg_bool kcg_comp_array_bool_6(
  array_bool_6 *kcg_c1,
  array_bool_6 *kcg_c2);
#endif /* kcg_comp_array_bool_6 */
#endif /* kcg_use_array_bool_6 */

#ifdef kcg_use_array_float32_4
#ifndef kcg_comp_array_float32_4
extern kcg_bool kcg_comp_array_float32_4(
  array_float32_4 *kcg_c1,
  array_float32_4 *kcg_c2);
#endif /* kcg_comp_array_float32_4 */
#endif /* kcg_use_array_float32_4 */

#ifdef kcg_use_array_int32_1
#ifndef kcg_comp_array_int32_1
extern kcg_bool kcg_comp_array_int32_1(
  array_int32_1 *kcg_c1,
  array_int32_1 *kcg_c2);
#endif /* kcg_comp_array_int32_1 */
#endif /* kcg_use_array_int32_1 */

#ifdef kcg_use_array_bool_1
#ifndef kcg_comp_array_bool_1
extern kcg_bool kcg_comp_array_bool_1(
  array_bool_1 *kcg_c1,
  array_bool_1 *kcg_c2);
#endif /* kcg_comp_array_bool_1 */
#endif /* kcg_use_array_bool_1 */

#ifdef kcg_use_array_float32_1
#ifndef kcg_comp_array_float32_1
extern kcg_bool kcg_comp_array_float32_1(
  array_float32_1 *kcg_c1,
  array_float32_1 *kcg_c2);
#endif /* kcg_comp_array_float32_1 */
#endif /* kcg_use_array_float32_1 */

#ifdef kcg_use_array_bool_5
#ifndef kcg_comp_array_bool_5
extern kcg_bool kcg_comp_array_bool_5(
  array_bool_5 *kcg_c1,
  array_bool_5 *kcg_c2);
#endif /* kcg_comp_array_bool_5 */
#endif /* kcg_use_array_bool_5 */

#ifdef kcg_use_array_char_30
#ifndef kcg_comp_array_char_30
extern kcg_bool kcg_comp_array_char_30(
  array_char_30 *kcg_c1,
  array_char_30 *kcg_c2);
#endif /* kcg_comp_array_char_30 */
#endif /* kcg_use_array_char_30 */

#ifdef kcg_use_array_bool_4
#ifndef kcg_comp_array_bool_4
extern kcg_bool kcg_comp_array_bool_4(
  array_bool_4 *kcg_c1,
  array_bool_4 *kcg_c2);
#endif /* kcg_comp_array_bool_4 */
#endif /* kcg_use_array_bool_4 */

#ifdef kcg_use_array_int32_5
#ifndef kcg_comp_array_int32_5
extern kcg_bool kcg_comp_array_int32_5(
  array_int32_5 *kcg_c1,
  array_int32_5 *kcg_c2);
#endif /* kcg_comp_array_int32_5 */
#endif /* kcg_use_array_int32_5 */

#ifdef kcg_use_array_float32_5
#ifndef kcg_comp_array_float32_5
extern kcg_bool kcg_comp_array_float32_5(
  array_float32_5 *kcg_c1,
  array_float32_5 *kcg_c2);
#endif /* kcg_comp_array_float32_5 */
#endif /* kcg_use_array_float32_5 */

#ifdef kcg_use_array_bool_3
#ifndef kcg_comp_array_bool_3
extern kcg_bool kcg_comp_array_bool_3(
  array_bool_3 *kcg_c1,
  array_bool_3 *kcg_c2);
#endif /* kcg_comp_array_bool_3 */
#endif /* kcg_use_array_bool_3 */

#endif /* _KCG_TYPES_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

