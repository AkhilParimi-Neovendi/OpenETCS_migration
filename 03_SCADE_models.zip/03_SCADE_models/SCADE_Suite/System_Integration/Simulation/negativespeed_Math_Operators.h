/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _negativespeed_Math_Operators_H_
#define _negativespeed_Math_Operators_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* oacceleration/ */ oacceleration;
  kcg_float32 /* ospeed/ */ ospeed;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L4/ */ _L4;
  kcg_bool /* _L6/ */ _L6;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
  kcg_float32 /* _L9/ */ _L9;
  kcg_float32 /* _L10/ */ _L10;
  kcg_bool /* _L11/ */ _L11;
  kcg_bool /* _L12/ */ _L12;
} outC_negativespeed_Math_Operators;

/* ===========  node initialization and cycle functions  =========== */
/* Math_Operators::negativespeed/ */
extern void negativespeed_Math_Operators(
  /* acceleration/ */
  kcg_float32 acceleration,
  /* speed/ */
  kcg_float32 speed,
  outC_negativespeed_Math_Operators *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void negativespeed_reset_Math_Operators(
  outC_negativespeed_Math_Operators *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void negativespeed_init_Math_Operators(
  outC_negativespeed_Math_Operators *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _negativespeed_Math_Operators_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** negativespeed_Math_Operators.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

