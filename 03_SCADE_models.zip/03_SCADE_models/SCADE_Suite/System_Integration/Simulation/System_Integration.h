/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _System_Integration_H_
#define _System_Integration_H_

#include "kcg_types.h"
#include "Vehicle_EmergencyBrake_EB_Train.h"
#include "OpenIO_Interface_Train.h"
#include "RollingStock_Operating_System_Train.h"
#include "ClassB_Systems_Train.h"
#include "Train_Driver.h"
#include "Signal_Operator.h"
#include "RSC_Operator.h"
#include "Vehicle_Management_System.h"
#include "RSC_TS.h"
#include "RSC_OB.h"
#include "Radio_Management.h"
#include "Perception_TS.h"
#include "Perception_OB.h"
#include "Functional_Vehicle_Adapter.h"
#include "ETCS_TS.h"
#include "ETCS_OB.h"
#include "Driving_Style_Engine.h"
#include "Diagnostics_TS.h"
#include "Diagnostic_Platform.h"
#include "ATO_TS.h"
#include "ATO_OB.h"

/* ========================  input structure  ====================== */
typedef struct {
  kcg_bool /* SystemtoSignalOperator/ */ SystemtoSignalOperator;
  kcg_bool /* ATO_ONSwitch_GUI/ */ ATO_ONSwitch_GUI;
  kcg_bool /* RSC_ONSwitch_GUI/ */ RSC_ONSwitch_GUI;
  ATORSCSwitchPosition /* ATORSC_SwitchPosition/ */ ATORSC_SwitchPosition;
  kcg_bool /* SendMsgto_ETCS_HMI/ */ SendMsgto_ETCS_HMI;
  kcg_bool /* FSbutton_ETCS_HMI/ */ FSbutton_ETCS_HMI;
  kcg_bool /* GoA2button_ETCS_HMI/ */ GoA2button_ETCS_HMI;
  kcg_bool /* GoA4button_ETCs_HMI/ */ GoA4button_ETCs_HMI;
  kcg_int8 /* T_B_Lever/ */ T_B_Lever;
  kcg_int8 /* Train_Brake_Lever/ */ Train_Brake_Lever;
  kcg_bool /* ApplyHoldingBrake/ */ ApplyHoldingBrake;
  ETCSHMIPacketDataType /* ETCS_HMI_Data_in/ */ ETCS_HMI_Data_in;
  kcg_bool /* OverrideSwitch/ */ OverrideSwitch;
} inC_System_Integration;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ExternalindicatorStates /* External_Status_Indication_Status/ */ External_Status_Indication_Status;
  array_char_30 /* ETCSHMI_TextBox/ */ ETCSHMI_TextBox;
  ETCSHMIPacketDataType /* ETCS_HMI_Data_Out/ */ ETCS_HMI_Data_Out;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool /* ATO_OBtoETCS_OB/ */ ATO_OBtoETCS_OB;
  kcg_bool /* ATO_OBtoDSE_ss139/ */ ATO_OBtoDSE_ss139;
  kcg_bool /* ATO_OBtoDiagnosticPlatfom/ */ ATO_OBtoDiagnosticPlatfom;
  kcg_bool /* ATO_OBtoDSE_C15/ */ ATO_OBtoDSE_C15;
  ATO_Packet /* ATO_TStoRM_ss126/ */ ATO_TStoRM_ss126;
  kcg_bool /* Diagnostic_PlatformtoRM/ */ Diagnostic_PlatformtoRM;
  kcg_bool /* Diagnostic_PlatformtoATO_OB/ */ Diagnostic_PlatformtoATO_OB;
  kcg_bool /* Diagnostic_PlatformtoRSC_OB/ */ Diagnostic_PlatformtoRSC_OB;
  kcg_bool /* Diagnostic_PlatformtoFVA/ */ Diagnostic_PlatformtoFVA;
  kcg_bool /* Diagnostic_PlatformtoETCS_OB/ */ Diagnostic_PlatformtoETCS_OB;
  kcg_bool /* Dianostics_TStoRM/ */ Dianostics_TStoRM;
  kcg_bool /* DSEtoFVA/ */ DSEtoFVA;
  kcg_bool /* DSEtoATO_OB_ss139/ */ DSEtoATO_OB_ss139;
  kcg_bool /* DSEtoATO_OB_C15/ */ DSEtoATO_OB_C15;
  ETCSATOPacket /* ETCS_OBtoATO_OB/ */ ETCS_OBtoATO_OB;
  ETCSHMIPacket /* ETCS_OBtoTrainDriver/ */ ETCS_OBtoTrainDriver;
  kcg_bool /* ETCS_OBtoEmergencyBrake_EB/ */ ETCS_OBtoEmergencyBrake_EB;
  kcg_bool /* ETCS_OBtoOpenIO_Interface/ */ ETCS_OBtoOpenIO_Interface;
  kcg_bool /* ETCS_OBtoVehicle_Management/ */ ETCS_OBtoVehicle_Management;
  kcg_bool /* ETCS_OBtoDiagnostic_Platform/ */ ETCS_OBtoDiagnostic_Platform;
  kcg_bool /* ETCS_OBtoRM/ */ ETCS_OBtoRM;
  kcg_bool /* ETCS_OBtoRSC_OB/ */ ETCS_OBtoRSC_OB;
  kcg_bool /* ETCS_OBtoFVA/ */ ETCS_OBtoFVA;
  kcg_bool /* ETCS_TStoRM/ */ ETCS_TStoRM;
  kcg_bool /* FVAtoPerception_OB/ */ FVAtoPerception_OB;
  ExternalindicatorStates /* FVAtoTrainDriver/ */ FVAtoTrainDriver;
  kcg_bool /* FVAtoETCSOB/ */ FVAtoETCSOB;
  kcg_bool /* FVAtoDSE/ */ FVAtoDSE;
  kcg_bool /* FVAtoOpenIO_Interface/ */ FVAtoOpenIO_Interface;
  kcg_bool /* FVAtoVehicleMangement/ */ FVAtoVehicleMangement;
  kcg_bool /* FVAtoDiagnostic_Platform/ */ FVAtoDiagnostic_Platform;
  kcg_bool /* FVAtoRollingStock_OperatingSystem/ */ FVAtoRollingStock_OperatingSystem;
  kcg_bool /* FVAtoRSC_OB_int2/ */ FVAtoRSC_OB_int2;
  kcg_bool /* FVAtoRSC_OB_ss139/ */ FVAtoRSC_OB_ss139;
  kcg_bool /* Perception_OBtoPerception_TS/ */ Perception_OBtoPerception_TS;
  kcg_bool /* Perception_OBtoEmergencyBrake_EB/ */ Perception_OBtoEmergencyBrake_EB;
  kcg_bool /* Perception_OBtoFVA/ */ Perception_OBtoFVA;
  kcg_bool /* Perception_TStoRSC_Operator/ */ Perception_TStoRSC_Operator;
  kcg_bool /* Perception_TStoPerception_OB/ */ Perception_TStoPerception_OB;
  ATO_Packet /* RMtoATO_OB/ */ RMtoATO_OB;
  kcg_bool /* RMtoRSC_TS/ */ RMtoRSC_TS;
  kcg_bool /* RMtoETCS_OB/ */ RMtoETCS_OB;
  kcg_bool /* RMtoDiagnosticPlatform/ */ RMtoDiagnosticPlatform;
  kcg_bool /* RMtoDiagnostic_TS/ */ RMtoDiagnostic_TS;
  kcg_bool /* RMtoETCS_TS/ */ RMtoETCS_TS;
  kcg_bool /* RSC_OBtoFVA_ss139/ */ RSC_OBtoFVA_ss139;
  kcg_bool /* RSC_OBtoFVA_int2/ */ RSC_OBtoFVA_int2;
  kcg_bool /* RSC_OBtoETCS_OB/ */ RSC_OBtoETCS_OB;
  kcg_bool /* RSC_OBtoDiagnostic_Platform/ */ RSC_OBtoDiagnostic_Platform;
  kcg_bool /* RSC_TStoRSC_Operator/ */ RSC_TStoRSC_Operator;
  kcg_bool /* RSC_TStoRM/ */ RSC_TStoRM;
  kcg_bool /* Vehicle_Management_toFVA/ */ Vehicle_Management_toFVA;
  kcg_bool /* Vehicle_ManagementtoETCS_OB/ */ Vehicle_ManagementtoETCS_OB;
  kcg_bool /* Vehicle_ManagementtoClassB_Systems/ */ Vehicle_ManagementtoClassB_Systems;
  kcg_bool /* RSC_OperatortoPerception_TS/ */ RSC_OperatortoPerception_TS;
  kcg_bool /* RSC_OperatortoRSC_TS/ */ RSC_OperatortoRSC_TS;
  FVAHMIPacket /* TrainDriver_to_FVA/ */ TrainDriver_to_FVA;
  ETCSHMIPacket /* TrainDriver_to_ETCS_OB/ */ TrainDriver_to_ETCS_OB;
  kcg_bool /* ClassB_Systems_to_VehicleManagement/ */ ClassB_Systems_to_VehicleManagement;
  kcg_bool /* RollingStock_OperatingSystemtoFVA/ */ RollingStock_OperatingSystemtoFVA;
  kcg_bool /* OpenIO_InterfacetoETCS_OB/ */ OpenIO_InterfacetoETCS_OB;
  kcg_bool /* OpenIO_InterfacetoFVA/ */ OpenIO_InterfacetoFVA;
  kcg_bool /* Vehicle_EmergencyBrake_EBto_ETCS_OB/ */ Vehicle_EmergencyBrake_EBto_ETCS_OB;
  kcg_bool /* VehicleEmergencyBrake_EB_to_Perception_OB/ */ VehicleEmergencyBrake_EB_to_Perception_OB;
  ATO_Packet /* ATO_OBtoRM/ */ ATO_OBtoRM;
  ATO_Packet /* RMtoATO_TS/ */ RMtoATO_TS;
  kcg_bool /* RMtoRSC_OB/ */ RMtoRSC_OB;
  kcg_bool /* RSC_OBtoRM/ */ RSC_OBtoRM;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_ATO_TS /* _L5=(ATO_TS#1)/ */ Context_ATO_TS_1;
  outC_Diagnostic_Platform /* _L7=(Diagnostic_Platform#1)/ */ Context_Diagnostic_Platform_1;
  outC_Diagnostics_TS /* _L12=(Diagnostics_TS#1)/ */ Context_Diagnostics_TS_1;
  outC_Driving_Style_Engine /* _L13=(Driving_Style_Engine#1)/ */ Context_Driving_Style_Engine_1;
  outC_ETCS_OB /* _L16=(ETCS_OB#1)/ */ Context_ETCS_OB_1;
  outC_ETCS_TS /* _L25=(ETCS_TS#1)/ */ Context_ETCS_TS_1;
  outC_Functional_Vehicle_Adapter /* _L26=(Functional_Vehicle_Adapter#1)/ */ Context_Functional_Vehicle_Adapter_1;
  outC_Perception_OB /* _L37=(Perception_OB#1)/ */ Context_Perception_OB_1;
  outC_Perception_TS /* _L42=(Perception_TS#1)/ */ Context_Perception_TS_1;
  outC_RSC_TS /* _L64=(RSC_TS#1)/ */ Context_RSC_TS_1;
  outC_Vehicle_Management_System /* _L68=(Vehicle_Management_System#1)/ */ Context_Vehicle_Management_System_1;
  outC_RSC_Operator /* _L71=(RSC_Operator#1)/ */ Context_RSC_Operator_1;
  outC_Signal_Operator /* _L73=(Signal_Operator#1)/ */ Context_Signal_Operator_1;
  outC_ClassB_Systems_Train /* _L76=(Train::ClassB_Systems#1)/ */ Context_ClassB_Systems_1;
  outC_RollingStock_Operating_System_Train /* _L77=(Train::RollingStock_Operating_System#1)/ */ Context_RollingStock_Operating_System_1;
  outC_OpenIO_Interface_Train /* _L78=(Train::OpenIO_Interface#1)/ */ Context_OpenIO_Interface_1;
  outC_Vehicle_EmergencyBrake_EB_Train /* _L80=(Train::Vehicle_EmergencyBrake_EB#1)/ */ Context_Vehicle_EmergencyBrake_EB_1;
  outC_ATO_OB /* _L1=(ATO_OB#1)/ */ Context_ATO_OB_1;
  outC_Radio_Management /* _L47=(Radio_Management#1)/ */ Context_Radio_Management_1;
  outC_RSC_OB /* _L55=(RSC_OB#1)/ */ Context_RSC_OB_1;
  outC_Train_Driver /* _L74=(Train_Driver#1)/ */ Context_Train_Driver_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* Signal_OperatortoSystem/ */ Signal_OperatortoSystem;
  Tain_Physics_Outputs /* Train_PhysicsOutputs/ */ Train_PhysicsOutputs;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L3/ */ _L3;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L1/ */ _L1;
  ATO_Packet /* _L5/ */ _L5;
  kcg_bool /* _L11/ */ _L11;
  kcg_bool /* _L10/ */ _L10;
  kcg_bool /* _L9/ */ _L9;
  kcg_bool /* _L8/ */ _L8;
  kcg_bool /* _L7/ */ _L7;
  kcg_bool /* _L12/ */ _L12;
  kcg_bool /* _L15/ */ _L15;
  kcg_bool /* _L14/ */ _L14;
  kcg_bool /* _L13/ */ _L13;
  kcg_bool /* _L24/ */ _L24;
  kcg_bool /* _L23/ */ _L23;
  kcg_bool /* _L22/ */ _L22;
  kcg_bool /* _L21/ */ _L21;
  kcg_bool /* _L20/ */ _L20;
  kcg_bool /* _L19/ */ _L19;
  kcg_bool /* _L18/ */ _L18;
  ETCSHMIPacket /* _L17/ */ _L17;
  ETCSATOPacket /* _L16/ */ _L16;
  kcg_bool /* _L25/ */ _L25;
  kcg_bool /* _L35/ */ _L35;
  kcg_bool /* _L34/ */ _L34;
  kcg_bool /* _L33/ */ _L33;
  kcg_bool /* _L32/ */ _L32;
  kcg_bool /* _L31/ */ _L31;
  kcg_bool /* _L30/ */ _L30;
  kcg_bool /* _L29/ */ _L29;
  kcg_bool /* _L28/ */ _L28;
  ExternalindicatorStates /* _L27/ */ _L27;
  kcg_bool /* _L26/ */ _L26;
  kcg_bool /* _L39/ */ _L39;
  kcg_bool /* _L38/ */ _L38;
  kcg_bool /* _L37/ */ _L37;
  kcg_bool /* _L43/ */ _L43;
  kcg_bool /* _L42/ */ _L42;
  kcg_bool /* _L53/ */ _L53;
  kcg_bool /* _L52/ */ _L52;
  kcg_bool /* _L51/ */ _L51;
  kcg_bool /* _L50/ */ _L50;
  kcg_bool /* _L49/ */ _L49;
  ATO_Packet /* _L48/ */ _L48;
  ATO_Packet /* _L47/ */ _L47;
  kcg_bool /* _L59/ */ _L59;
  kcg_bool /* _L58/ */ _L58;
  kcg_bool /* _L57/ */ _L57;
  kcg_bool /* _L56/ */ _L56;
  kcg_bool /* _L55/ */ _L55;
  kcg_bool /* _L65/ */ _L65;
  kcg_bool /* _L64/ */ _L64;
  kcg_bool /* _L70/ */ _L70;
  kcg_bool /* _L69/ */ _L69;
  kcg_bool /* _L68/ */ _L68;
  kcg_bool /* _L72/ */ _L72;
  kcg_bool /* _L71/ */ _L71;
  kcg_bool /* _L73/ */ _L73;
  ETCSHMIPacket /* _L75/ */ _L75;
  FVAHMIPacket /* _L74/ */ _L74;
  kcg_bool /* _L76/ */ _L76;
  kcg_bool /* _L77/ */ _L77;
  kcg_bool /* _L79/ */ _L79;
  kcg_bool /* _L78/ */ _L78;
  kcg_bool /* _L81/ */ _L81;
  kcg_bool /* _L80/ */ _L80;
  kcg_bool /* _L85/ */ _L85;
  kcg_bool /* _L86/ */ _L86;
  kcg_bool /* _L87/ */ _L87;
  ExternalindicatorStates /* _L88/ */ _L88;
  ETCSHMIPacket /* _L89/ */ _L89;
  kcg_bool /* _L90/ */ _L90;
  kcg_bool /* _L91/ */ _L91;
  kcg_bool /* _L92/ */ _L92;
  kcg_bool /* _L93/ */ _L93;
  kcg_bool /* _L94/ */ _L94;
  kcg_bool /* _L95/ */ _L95;
  kcg_bool /* _L96/ */ _L96;
  ETCSATOPacket /* _L97/ */ _L97;
  kcg_bool /* _L98/ */ _L98;
  kcg_bool /* _L99/ */ _L99;
  kcg_bool /* _L100/ */ _L100;
  kcg_bool /* _L101/ */ _L101;
  kcg_bool /* _L102/ */ _L102;
  kcg_bool /* _L103/ */ _L103;
  kcg_bool /* _L106/ */ _L106;
  kcg_bool /* _L108/ */ _L108;
  kcg_bool /* _L109/ */ _L109;
  kcg_bool /* _L110/ */ _L110;
  kcg_bool /* _L111/ */ _L111;
  kcg_bool /* _L112/ */ _L112;
  kcg_bool /* _L113/ */ _L113;
  kcg_bool /* _L115/ */ _L115;
  kcg_bool /* _L117/ */ _L117;
  kcg_bool /* _L118/ */ _L118;
  kcg_bool /* _L119/ */ _L119;
  kcg_bool /* _L120/ */ _L120;
  kcg_bool /* _L121/ */ _L121;
  ATO_Packet /* _L123/ */ _L123;
  kcg_bool /* _L124/ */ _L124;
  kcg_bool /* _L125/ */ _L125;
  kcg_bool /* _L126/ */ _L126;
  kcg_bool /* _L127/ */ _L127;
  kcg_bool /* _L128/ */ _L128;
  kcg_bool /* _L129/ */ _L129;
  kcg_bool /* _L130/ */ _L130;
  kcg_bool /* _L131/ */ _L131;
  kcg_bool /* _L132/ */ _L132;
  kcg_bool /* _L133/ */ _L133;
  kcg_bool /* _L134/ */ _L134;
  FVAHMIPacket /* _L135/ */ _L135;
  kcg_bool /* _L136/ */ _L136;
  kcg_bool /* _L137/ */ _L137;
  kcg_bool /* _L138/ */ _L138;
  kcg_bool /* _L139/ */ _L139;
  kcg_bool /* _L140/ */ _L140;
  kcg_bool /* _L141/ */ _L141;
  kcg_bool /* _L142/ */ _L142;
  kcg_bool /* _L143/ */ _L143;
  kcg_bool /* _L144/ */ _L144;
  kcg_bool /* _L145/ */ _L145;
  ETCSHMIPacket /* _L146/ */ _L146;
  kcg_bool /* _L147/ */ _L147;
  kcg_bool /* _L148/ */ _L148;
  kcg_bool /* _L149/ */ _L149;
  kcg_bool /* _L150/ */ _L150;
  kcg_bool /* _L151/ */ _L151;
  kcg_bool /* _L152/ */ _L152;
  kcg_bool /* _L153/ */ _L153;
  kcg_bool /* _L154/ */ _L154;
  kcg_bool /* _L155/ */ _L155;
  kcg_bool /* _L156/ */ _L156;
  ExternalindicatorStates /* _L157/ */ _L157;
  ATORSCSwitchPosition /* _L158/ */ _L158;
  kcg_bool /* _L159/ */ _L159;
  kcg_bool /* _L168/ */ _L168;
  kcg_bool /* _L169/ */ _L169;
  kcg_bool /* _L167/ */ _L167;
  ATO_Packet /* _L170/ */ _L170;
  kcg_bool /* _L171/ */ _L171;
  ATO_Packet /* _L172/ */ _L172;
  ATO_Packet /* _L173/ */ _L173;
  ATO_Packet /* _L174/ */ _L174;
  kcg_bool /* _L175/ */ _L175;
  kcg_bool /* _L176/ */ _L176;
  array_char_30 /* _L177/ */ _L177;
  Tain_Physics_Outputs /* _L179/ */ _L179;
  kcg_int8 /* _L180/ */ _L180;
  kcg_int8 /* _L181/ */ _L181;
  kcg_bool /* _L182/ */ _L182;
  ETCSHMIPacketDataType /* _L183/ */ _L183;
  ETCSHMIPacketDataType /* _L184/ */ _L184;
  kcg_bool /* _L185/ */ _L185;
} outC_System_Integration;

/* ===========  node initialization and cycle functions  =========== */
/* System_Integration/ */
extern void System_Integration(
  inC_System_Integration *inC,
  outC_System_Integration *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void System_Integration_reset(outC_System_Integration *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void System_Integration_init(outC_System_Integration *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _System_Integration_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** System_Integration.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

