/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Vehicle_EmergencyBrake_EB_Train_H_
#define _Vehicle_EmergencyBrake_EB_Train_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_ETCS_OB/ */ to_ETCS_OB;
  kcg_bool /* to_Perception_OB/ */ to_Perception_OB;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L3/ */ _L3;
} outC_Vehicle_EmergencyBrake_EB_Train;

/* ===========  node initialization and cycle functions  =========== */
/* Train::Vehicle_EmergencyBrake_EB/ */
extern void Vehicle_EmergencyBrake_EB_Train(
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_Perception_OB/ */
  kcg_bool from_Perception_OB,
  outC_Vehicle_EmergencyBrake_EB_Train *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Vehicle_EmergencyBrake_EB_reset_Train(
  outC_Vehicle_EmergencyBrake_EB_Train *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Vehicle_EmergencyBrake_EB_init_Train(
  outC_Vehicle_EmergencyBrake_EB_Train *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Vehicle_EmergencyBrake_EB_Train_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Vehicle_EmergencyBrake_EB_Train.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

