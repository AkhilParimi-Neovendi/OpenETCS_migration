/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _RSC_Operator_H_
#define _RSC_Operator_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_Perception_TS/ */ to_Perception_TS;
  kcg_bool /* to_RSC_TS/ */ to_RSC_TS;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L3/ */ _L3;
} outC_RSC_Operator;

/* ===========  node initialization and cycle functions  =========== */
/* RSC_Operator/ */
extern void RSC_Operator(
  /* from_Perception_TS/ */
  kcg_bool from_Perception_TS,
  /* from_RSC_TS/ */
  kcg_bool from_RSC_TS,
  outC_RSC_Operator *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void RSC_Operator_reset(outC_RSC_Operator *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void RSC_Operator_init(outC_RSC_Operator *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _RSC_Operator_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RSC_Operator.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

