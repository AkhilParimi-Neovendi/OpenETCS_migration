/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Diagnostic_Platform.h"

/* Diagnostic_Platform/ */
void Diagnostic_Platform(
  /* from_RM/ */
  kcg_bool from_RM,
  /* from_ATO_OB/ */
  kcg_bool from_ATO_OB,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  /* from_FVA/ */
  kcg_bool from_FVA,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  outC_Diagnostic_Platform *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;
  kcg_bool _2_noname;
  kcg_bool _3_noname;
  kcg_bool _4_noname;

  outC->_L6 = kcg_false;
  outC->to_ETCS_OB = outC->_L6;
  outC->_L7 = from_ETCS_OB;
  _4_noname = outC->_L7;
  outC->_L5 = from_FVA;
  _3_noname = outC->_L5;
  outC->_L4 = from_RSC_OB;
  _2_noname = outC->_L4;
  outC->_L2 = from_ATO_OB;
  _1_noname = outC->_L2;
  outC->_L1 = from_RM;
  noname = outC->_L1;
  outC->to_FVA = outC->_L6;
  outC->to_RSC_OB = outC->_L6;
  outC->to_ATO_OB = outC->_L6;
  outC->to_RM = outC->_L6;
}

#ifndef KCG_USER_DEFINED_INIT
void Diagnostic_Platform_init(outC_Diagnostic_Platform *outC)
{
  outC->_L7 = kcg_true;
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->to_FVA = kcg_true;
  outC->to_RSC_OB = kcg_true;
  outC->to_ATO_OB = kcg_true;
  outC->to_RM = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Diagnostic_Platform_reset(outC_Diagnostic_Platform *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Diagnostic_Platform.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

