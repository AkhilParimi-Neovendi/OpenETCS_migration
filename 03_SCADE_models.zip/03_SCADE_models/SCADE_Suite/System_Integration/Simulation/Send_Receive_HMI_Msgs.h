/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Send_Receive_HMI_Msgs_H_
#define _Send_Receive_HMI_Msgs_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ETCSHMIPacket /* Send_HMI_Packet/ */ Send_HMI_Packet;
  kcg_bool /* to_ATO_TBD/ */ to_ATO_TBD;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  ETCSHMIPacketDataType /* to_HMI_Data/ */ to_HMI_Data;
  ETCSHMIPacketDataType /* TrainData_from_HMI/ */ TrainData_from_HMI;
  kcg_bool /* ATO_Data_Acknowledged/ */ ATO_Data_Acknowledged;
  kcg_bool /* ETCS_Data_Acknowledged/ */ ETCS_Data_Acknowledged;
  kcg_bool /* TrainDataAvailable/ */ TrainDataAvailable;
  kcg_bool /* MessageCondition/ */ MessageCondition;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* IfBlock1:else: */ else_clock_IfBlock1;
  kcg_bool /* IfBlock1:else:else: */ else_clock_else_IfBlock1;
  kcg_bool /* IfBlock1: */ IfBlock1_clock;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* IfBlock1:then:_L7/ */ _L7_then_IfBlock1;
  kcg_bool /* IfBlock1:then:_L2/ */ _L2_then_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:then:_L4/ */ _L4_then_IfBlock1;
  ETCSHMIPacketDataType /* IfBlock1:else:else:then:_L7/ */ _L7_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L6/ */ _L6_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L1/ */ _L1_then_else_else_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:else:then:_L4/ */ _L4_then_else_else_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:else:else:_L19/ */ _L19_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:_L16/ */ _L16_else_else_else_IfBlock1;
  ETCS_HMI_Msgs /* IfBlock1:else:then:_L3/ */ _L3_then_else_IfBlock1;
  kcg_bool /* IfBlock1:else:then:_L1/ */ _L1_then_else_IfBlock1;
  kcg_bool /* IfBlock1:else:then:_L6/ */ _L6_then_else_IfBlock1;
  ETCSHMIPacketDataType /* IfBlock1:else:then:_L7/ */ _L7_then_else_IfBlock1;
  kcg_bool /* UpdatedMsgCondition/ */ UpdatedMsgCondition;
  kcg_int8 /* Msg/ */ Msg;
  kcg_bool /* _L16/ */ _L16;
  kcg_bool /* _L15/ */ _L15;
  ETCS_HMI_MsgHeaders /* _L14/ */ _L14;
  ETCS_HMI_Msgs /* _L12/ */ _L12;
  kcg_bool /* _L11/ */ _L11;
  ETCS_HMI_Msgs /* _L10/ */ _L10;
  ETCS_HMI_MsgHeaders /* _L8/ */ _L8;
  ETCS_HMI_Msgs /* _L9/ */ _L9;
  ETCS_HMI_Msgs /* _L17/ */ _L17;
  ETCS_HMI_Msgs /* _L18/ */ _L18;
  ETCS_HMI_Msgs /* _L20/ */ _L20;
  ETCS_HMI_Msgs /* _L21/ */ _L21;
  ETCS_HMI_Msgs /* _L22/ */ _L22;
  ETCSHMIPacket /* _L25/ */ _L25;
  ATO_modes /* _L27/ */ _L27;
  ETCS_modes /* _L26/ */ _L26;
  ETCSHMIPacketDataType /* _L32/ */ _L32;
  kcg_bool /* _L31/ */ _L31;
  kcg_bool /* _L33/ */ _L33;
  ETCSHMIPacket /* _L34/ */ _L34;
  kcg_bool /* _L40/ */ _L40;
  ETCS_HMI_MsgHeaders /* _L39/ */ _L39;
  ETCS_HMI_Msgs /* _L38/ */ _L38;
  ETCS_modes /* _L37/ */ _L37;
  ATO_modes /* _L36/ */ _L36;
  ETCSHMIPacketDataType /* _L35/ */ _L35;
  kcg_bool /* _L41/ */ _L41;
  kcg_int8 /* _L42/ */ _L42;
  kcg_bool /* _L43/ */ _L43;
  kcg_bool /* _L44/ */ _L44;
  kcg_int8 /* _L45/ */ _L45;
  ETCSHMIPacketDataType /* _L46/ */ _L46;
  kcg_int8 /* _L62/ */ _L62;
  kcg_bool /* _L64/ */ _L64;
  kcg_int8 /* _L73/ */ _L73;
  kcg_bool /* _L72/ */ _L72;
  kcg_bool /* _L70/ */ _L70;
  kcg_int8 /* _L69/ */ _L69;
  kcg_int8 /* _L68/ */ _L68;
  kcg_int8 /* _L67/ */ _L67;
  ETCSHMIPacket /* _L66/ */ _L66;
  kcg_int8 /* _L65/ */ _L65;
  ETCSHMIPacketDataType /* _L76/ */ _L76;
  ETCSHMIPacketDataType /* _L71/ */ _L71;
  kcg_bool /* _L77/ */ _L77;
} outC_Send_Receive_HMI_Msgs;

/* ===========  node initialization and cycle functions  =========== */
/* Send_Receive_HMI_Msgs/ */
extern void Send_Receive_HMI_Msgs(
  /* Receive_HMI_Packet/ */
  ETCSHMIPacket *Receive_HMI_Packet,
  outC_Send_Receive_HMI_Msgs *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Send_Receive_HMI_Msgs_reset(outC_Send_Receive_HMI_Msgs *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Send_Receive_HMI_Msgs_init(outC_Send_Receive_HMI_Msgs *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Send_Receive_HMI_Msgs_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Send_Receive_HMI_Msgs.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

