/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train_Driver.h"

/* Train_Driver/ */
void Train_Driver(
  /* from_FVA/ */
  ExternalindicatorStates *from_FVA,
  /* from_ETCS_OB/ */
  ETCSHMIPacket *from_ETCS_OB,
  /* ATORSCSwitch_Position/ */
  ATORSCSwitchPosition ATORSCSwitch_Position,
  /* SendMessage/ */
  kcg_bool SendMessage,
  /* ATO_GoA4_mode_button/ */
  kcg_bool ATO_GoA4_mode_button,
  /* ATO_GoA2_mode_button/ */
  kcg_bool ATO_GoA2_mode_button,
  /* ETCS_FS_mode_button/ */
  kcg_bool ETCS_FS_mode_button,
  /* ThrottleBrakeLever_Position/ */
  kcg_int8 ThrottleBrakeLever_Position,
  /* Apply_HoldingBrake/ */
  kcg_bool Apply_HoldingBrake,
  /* TrainBrakeLever/ */
  kcg_int8 TrainBrakeLever,
  /* ETCSHMIData_in/ */
  ETCSHMIPacketDataType *ETCSHMIData_in,
  /* External_Override_Switch/ */
  kcg_bool External_Override_Switch,
  outC_Train_Driver *outC)
{
  /* T_B_Leverinput/ */
  kcg_int8 T_B_Leverinput_partial;
  /* HoldingBrakeApplied/ */
  kcg_bool HoldingBrakeApplied_partial;
  /* TrainBrakePos/ */
  kcg_int8 TrainBrakePos_partial;
  /* T_B_Leverinput/ */
  kcg_int8 _1_T_B_Leverinput_partial;
  /* HoldingBrakeApplied/ */
  kcg_bool _2_HoldingBrakeApplied_partial;
  /* TrainBrakePos/ */
  kcg_int8 _3_TrainBrakePos_partial;

  outC->_L70 = External_Override_Switch;
  outC->_L5 = ATORSCSwitch_Position;
  outC->_L71.OverrideSwitch = outC->_L70;
  outC->_L71.ATORSCSwitch = outC->_L5;
  outC->_L32 = SendMessage;
  kcg_copy_ETCSHMIPacket(&outC->_L2, from_ETCS_OB);
  kcg_copy_ETCSHMIPacketDataType(&outC->_L69, ETCSHMIData_in);
  /* _L40=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_ETCSHMI_Functions(
    outC->_L32,
    &outC->_L2,
    &outC->_L69,
    &outC->Context_Read_and_Send_ETCSOB_Data);
  kcg_copy_array_char_30(
    &outC->_L40,
    &outC->Context_Read_and_Send_ETCSOB_Data.HMI_Display_Textbox);
  kcg_copy_ETCSHMIPacket(
    &outC->_L59,
    &outC->Context_Read_and_Send_ETCSOB_Data.Out_ETCS_OB);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->_L68,
    &outC->Context_Read_and_Send_ETCSOB_Data.ETCS_HMI_Data);
  kcg_copy_ETCSHMIPacketDataType(&outC->ETCSHMI_Data_Out, &outC->_L68);
  kcg_copy_ETCSHMIPacket(&outC->_L64, (ETCSHMIPacket *) &ETCS_HMI_Packetinit);
  /* _L67= */
  if (outC->_L32) {
    kcg_copy_ETCSHMIPacket(&outC->_L67, &outC->_L59);
  }
  else {
    kcg_copy_ETCSHMIPacket(&outC->_L67, &outC->_L64);
  }
  outC->_L56 = ATO_GoA4_mode_button;
  /* _L57=(ETCSHMI_Functions::Send_GoA4_Selected#1)/ */
  Send_GoA4_Selected_ETCSHMI_Functions(
    outC->_L56,
    &outC->Context_Send_GoA4_Selected_1);
  kcg_copy_ETCSHMIPacket(
    &outC->_L57,
    &outC->Context_Send_GoA4_Selected_1.Out_ETCS_Packet);
  /* _L58= */
  if (outC->_L56) {
    kcg_copy_ETCSHMIPacket(&outC->_L58, &outC->_L57);
  }
  else {
    kcg_copy_ETCSHMIPacket(&outC->_L58, &outC->_L67);
  }
  outC->_L53 = ATO_GoA2_mode_button;
  /* _L55=(ETCSHMI_Functions::Send_GoA2_Selected#1)/ */
  Send_GoA2_Selected_ETCSHMI_Functions(
    outC->_L53,
    &outC->Context_Send_GoA2_Selected_1);
  kcg_copy_ETCSHMIPacket(
    &outC->_L55,
    &outC->Context_Send_GoA2_Selected_1.Out_ETCS_Packet);
  /* _L54= */
  if (outC->_L53) {
    kcg_copy_ETCSHMIPacket(&outC->_L54, &outC->_L55);
  }
  else {
    kcg_copy_ETCSHMIPacket(&outC->_L54, &outC->_L58);
  }
  outC->_L51 = ETCS_FS_mode_button;
  /* _L45=(ETCSHMI_Functions::Send_FS_Selected#1)/ */
  Send_FS_Selected_ETCSHMI_Functions(
    outC->_L51,
    &outC->Context_Send_FS_Selected_1);
  kcg_copy_ETCSHMIPacket(
    &outC->_L45,
    &outC->Context_Send_FS_Selected_1.Out_ETCS_Packet);
  /* _L52= */
  if (outC->_L51) {
    kcg_copy_ETCSHMIPacket(&outC->_L52, &outC->_L45);
  }
  else {
    kcg_copy_ETCSHMIPacket(&outC->_L52, &outC->_L54);
  }
  kcg_copy_ETCSHMIPacket(&outC->to_ETCS_OB, &outC->_L52);
  outC->Local_ATORSCSwitchPosition = outC->_L5;
  outC->IfBlock2_clock = outC->Local_ATORSCSwitchPosition == kcg_lit_int8(0);
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L3_then_IfBlock2 = TrainBrakeLever;
    TrainBrakePos_partial = outC->_L3_then_IfBlock2;
    outC->TrainBrakePos = TrainBrakePos_partial;
  }
  else {
    outC->_L7_else_IfBlock2 = kcg_lit_int8(34);
    _3_TrainBrakePos_partial = outC->_L7_else_IfBlock2;
    outC->TrainBrakePos = _3_TrainBrakePos_partial;
  }
  outC->_L44 = outC->TrainBrakePos;
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L1_then_IfBlock2 = Apply_HoldingBrake;
    HoldingBrakeApplied_partial = outC->_L1_then_IfBlock2;
    outC->HoldingBrakeApplied = HoldingBrakeApplied_partial;
  }
  else {
    outC->_L6_else_IfBlock2 = kcg_true;
    _2_HoldingBrakeApplied_partial = outC->_L6_else_IfBlock2;
    outC->HoldingBrakeApplied = _2_HoldingBrakeApplied_partial;
  }
  outC->_L43 = outC->HoldingBrakeApplied;
  /* IfBlock2: */
  if (outC->IfBlock2_clock) {
    outC->_L4_then_IfBlock2 = ThrottleBrakeLever_Position;
    T_B_Leverinput_partial = outC->_L4_then_IfBlock2;
    outC->T_B_Leverinput = T_B_Leverinput_partial;
  }
  else {
    outC->_L5_else_IfBlock2 = kcg_lit_int8(0);
    _1_T_B_Leverinput_partial = outC->_L5_else_IfBlock2;
    outC->T_B_Leverinput = _1_T_B_Leverinput_partial;
  }
  outC->_L42 = outC->T_B_Leverinput;
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_Train(
    outC->_L42,
    outC->_L43,
    outC->_L44,
    &outC->Context_Train_Physics_3);
  kcg_copy_Tain_Physics_Outputs(
    &outC->_L41,
    &outC->Context_Train_Physics_3.Train_Outputs);
  kcg_copy_Tain_Physics_Outputs(&outC->Train_Physics_Output, &outC->_L41);
  kcg_copy_array_char_30(&outC->ETCSHMI_TextBox, &outC->_L40);
  kcg_copy_ExternalindicatorStates(&outC->_L4, from_FVA);
  kcg_copy_ExternalindicatorStates(&outC->External_ATORSC_Status, &outC->_L4);
  kcg_copy_FVAHMIPacket(&outC->to_FVA, &outC->_L71);
}

#ifndef KCG_USER_DEFINED_INIT
void Train_Driver_init(outC_Train_Driver *outC)
{
  kcg_size idx;
  kcg_size idx1;

  outC->_L71.OverrideSwitch = kcg_true;
  outC->_L71.ATORSCSwitch = kcg_lit_int8(0);
  outC->_L70 = kcg_true;
  outC->_L69.label1 = kcg_lit_int8(0);
  outC->_L69.label2 = kcg_lit_int8(0);
  outC->_L69.label3 = kcg_lit_int8(0);
  outC->_L69.label4 = kcg_lit_int8(0);
  outC->_L69.label5 = kcg_lit_int8(0);
  outC->_L69.label6 = kcg_lit_int8(0);
  outC->_L69.label7 = kcg_lit_int16(0);
  outC->_L69.label8 = kcg_lit_int16(0);
  outC->_L68.label1 = kcg_lit_int8(0);
  outC->_L68.label2 = kcg_lit_int8(0);
  outC->_L68.label3 = kcg_lit_int8(0);
  outC->_L68.label4 = kcg_lit_int8(0);
  outC->_L68.label5 = kcg_lit_int8(0);
  outC->_L68.label6 = kcg_lit_int8(0);
  outC->_L68.label7 = kcg_lit_int16(0);
  outC->_L68.label8 = kcg_lit_int16(0);
  outC->_L67.isvalid = kcg_true;
  outC->_L67.Header = kcg_lit_int8(0);
  outC->_L67.Message = kcg_lit_int8(0);
  outC->_L67.currentETCSmode = kcg_lit_int8(0);
  outC->_L67.currentATOmode = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L67.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L67.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L64.isvalid = kcg_true;
  outC->_L64.Header = kcg_lit_int8(0);
  outC->_L64.Message = kcg_lit_int8(0);
  outC->_L64.currentETCSmode = kcg_lit_int8(0);
  outC->_L64.currentATOmode = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L64.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L64.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L59.isvalid = kcg_true;
  outC->_L59.Header = kcg_lit_int8(0);
  outC->_L59.Message = kcg_lit_int8(0);
  outC->_L59.currentETCSmode = kcg_lit_int8(0);
  outC->_L59.currentATOmode = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L59.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L59.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L58.isvalid = kcg_true;
  outC->_L58.Header = kcg_lit_int8(0);
  outC->_L58.Message = kcg_lit_int8(0);
  outC->_L58.currentETCSmode = kcg_lit_int8(0);
  outC->_L58.currentATOmode = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L58.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L58.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L57.isvalid = kcg_true;
  outC->_L57.Header = kcg_lit_int8(0);
  outC->_L57.Message = kcg_lit_int8(0);
  outC->_L57.currentETCSmode = kcg_lit_int8(0);
  outC->_L57.currentATOmode = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L57.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L57.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L56 = kcg_true;
  outC->_L55.isvalid = kcg_true;
  outC->_L55.Header = kcg_lit_int8(0);
  outC->_L55.Message = kcg_lit_int8(0);
  outC->_L55.currentETCSmode = kcg_lit_int8(0);
  outC->_L55.currentATOmode = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L55.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L55.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L54.isvalid = kcg_true;
  outC->_L54.Header = kcg_lit_int8(0);
  outC->_L54.Message = kcg_lit_int8(0);
  outC->_L54.currentETCSmode = kcg_lit_int8(0);
  outC->_L54.currentATOmode = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L54.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L54.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L53 = kcg_true;
  outC->_L52.isvalid = kcg_true;
  outC->_L52.Header = kcg_lit_int8(0);
  outC->_L52.Message = kcg_lit_int8(0);
  outC->_L52.currentETCSmode = kcg_lit_int8(0);
  outC->_L52.currentATOmode = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L52.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L52.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L51 = kcg_true;
  outC->_L45.isvalid = kcg_true;
  outC->_L45.Header = kcg_lit_int8(0);
  outC->_L45.Message = kcg_lit_int8(0);
  outC->_L45.currentETCSmode = kcg_lit_int8(0);
  outC->_L45.currentATOmode = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L45.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L45.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L44 = kcg_lit_int8(0);
  outC->_L43 = kcg_true;
  outC->_L42 = kcg_lit_int8(0);
  outC->_L41.Distance_Covered = kcg_lit_int16(0);
  outC->_L41.Train_Speed = kcg_lit_int16(0);
  outC->_L41.Train_Acceleration = kcg_lit_float32(0.0);
  for (idx = 0; idx < 30; idx++) {
    outC->_L40[idx] = ' ';
  }
  outC->_L32 = kcg_true;
  outC->_L5 = kcg_lit_int8(0);
  outC->_L4.IndicatorState = kcg_lit_int8(0);
  outC->_L4.RedLight = kcg_true;
  outC->_L4.GreenLight = kcg_true;
  outC->_L2.isvalid = kcg_true;
  outC->_L2.Header = kcg_lit_int8(0);
  outC->_L2.Message = kcg_lit_int8(0);
  outC->_L2.currentETCSmode = kcg_lit_int8(0);
  outC->_L2.currentATOmode = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L2.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L2.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->TrainBrakePos = kcg_lit_int8(0);
  outC->HoldingBrakeApplied = kcg_true;
  outC->T_B_Leverinput = kcg_lit_int8(0);
  outC->Local_ATORSCSwitchPosition = kcg_lit_int8(0);
  outC->IfBlock2_clock = kcg_true;
  outC->_L5_else_IfBlock2 = kcg_lit_int8(0);
  outC->_L6_else_IfBlock2 = kcg_true;
  outC->_L7_else_IfBlock2 = kcg_lit_int8(0);
  outC->_L4_then_IfBlock2 = kcg_lit_int8(0);
  outC->_L3_then_IfBlock2 = kcg_lit_int8(0);
  outC->_L1_then_IfBlock2 = kcg_true;
  outC->ETCSHMI_Data_Out.label1 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label2 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label3 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label4 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label5 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label6 = kcg_lit_int8(0);
  outC->ETCSHMI_Data_Out.label7 = kcg_lit_int16(0);
  outC->ETCSHMI_Data_Out.label8 = kcg_lit_int16(0);
  outC->Train_Physics_Output.Distance_Covered = kcg_lit_int16(0);
  outC->Train_Physics_Output.Train_Speed = kcg_lit_int16(0);
  outC->Train_Physics_Output.Train_Acceleration = kcg_lit_float32(0.0);
  for (idx1 = 0; idx1 < 30; idx1++) {
    outC->ETCSHMI_TextBox[idx1] = ' ';
  }
  outC->External_ATORSC_Status.IndicatorState = kcg_lit_int8(0);
  outC->External_ATORSC_Status.RedLight = kcg_true;
  outC->External_ATORSC_Status.GreenLight = kcg_true;
  outC->to_ETCS_OB.isvalid = kcg_true;
  outC->to_ETCS_OB.Header = kcg_lit_int8(0);
  outC->to_ETCS_OB.Message = kcg_lit_int8(0);
  outC->to_ETCS_OB.currentETCSmode = kcg_lit_int8(0);
  outC->to_ETCS_OB.currentATOmode = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->to_ETCS_OB.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->to_FVA.OverrideSwitch = kcg_true;
  outC->to_FVA.ATORSCSwitch = kcg_lit_int8(0);
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_init_Train(&outC->Context_Train_Physics_3);
  /* _L45=(ETCSHMI_Functions::Send_FS_Selected#1)/ */
  Send_FS_Selected_init_ETCSHMI_Functions(&outC->Context_Send_FS_Selected_1);
  /* _L55=(ETCSHMI_Functions::Send_GoA2_Selected#1)/ */
  Send_GoA2_Selected_init_ETCSHMI_Functions(
    &outC->Context_Send_GoA2_Selected_1);
  /* _L57=(ETCSHMI_Functions::Send_GoA4_Selected#1)/ */
  Send_GoA4_Selected_init_ETCSHMI_Functions(
    &outC->Context_Send_GoA4_Selected_1);
  /* _L40=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_init_ETCSHMI_Functions(
    &outC->Context_Read_and_Send_ETCSOB_Data);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_Driver_reset(outC_Train_Driver *outC)
{
  /* _L41=(Train::Train_Physics#3)/ */
  Train_Physics_reset_Train(&outC->Context_Train_Physics_3);
  /* _L45=(ETCSHMI_Functions::Send_FS_Selected#1)/ */
  Send_FS_Selected_reset_ETCSHMI_Functions(&outC->Context_Send_FS_Selected_1);
  /* _L55=(ETCSHMI_Functions::Send_GoA2_Selected#1)/ */
  Send_GoA2_Selected_reset_ETCSHMI_Functions(
    &outC->Context_Send_GoA2_Selected_1);
  /* _L57=(ETCSHMI_Functions::Send_GoA4_Selected#1)/ */
  Send_GoA4_Selected_reset_ETCSHMI_Functions(
    &outC->Context_Send_GoA4_Selected_1);
  /* _L40=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */
  Read_and_Send_ETCSOB_Data_reset_ETCSHMI_Functions(
    &outC->Context_Read_and_Send_ETCSOB_Data);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Driver.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

