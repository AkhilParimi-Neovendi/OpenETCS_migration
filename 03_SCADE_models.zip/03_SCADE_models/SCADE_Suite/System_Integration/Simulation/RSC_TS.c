/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "RSC_TS.h"

/* RSC_TS/ */
void RSC_TS(
  /* from_RSC_Operator/ */
  kcg_bool from_RSC_Operator,
  /* from_RM/ */
  kcg_bool from_RM,
  outC_RSC_TS *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;

  outC->_L2 = kcg_false;
  outC->to_RM = outC->_L2;
  outC->_L4 = from_RM;
  _1_noname = outC->_L4;
  outC->_L1 = from_RSC_Operator;
  noname = outC->_L1;
  outC->to_RSC_Operator = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void RSC_TS_init(outC_RSC_TS *outC)
{
  outC->_L4 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_RM = kcg_true;
  outC->to_RSC_Operator = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void RSC_TS_reset(outC_RSC_TS *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RSC_TS.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

