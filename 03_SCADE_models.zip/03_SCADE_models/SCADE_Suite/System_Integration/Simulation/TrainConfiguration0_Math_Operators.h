/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _TrainConfiguration0_Math_Operators_H_
#define _TrainConfiguration0_Math_Operators_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  array_float32_5 /* Traction_force_Array/ */ Traction_force_Array;
  array_float32_5 /* Braking_force_Array/ */ Braking_force_Array;
  array_float32_5 /* Speed_Array/ */ Speed_Array;
  array_float32_5 /* Accelartion_Array/ */ Accelartion_Array;
  array_int32_5 /* Mass_Array/ */ Mass_Array;
  array_float32_5 /* brakelinepressurearray/ */ brakelinepressurearray;
  array_bool_5 /* holdingbrakestatus/ */ holdingbrakestatus;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L2/ */ _L2;
  array_float32_5 /* _L5/ */ _L5;
  array_float32_1 /* _L4/ */ _L4;
  array_float32_4 /* _L3/ */ _L3;
  array_float32_5 /* _L8/ */ _L8;
  array_float32_1 /* _L7/ */ _L7;
  array_float32_4 /* _L6/ */ _L6;
  kcg_float32 /* _L9/ */ _L9;
  kcg_float32 /* _L10/ */ _L10;
  array_int32_1 /* _L13/ */ _L13;
  array_float32_5 /* _L12/ */ _L12;
  array_float32_5 /* _L11/ */ _L11;
  kcg_float32 /* _L14/ */ _L14;
  kcg_float32 /* _L15/ */ _L15;
  kcg_int32 /* _L17/ */ _L17;
  array_int32_5 /* _L18/ */ _L18;
  array_int32_4 /* _L19/ */ _L19;
  kcg_int32 /* _L20/ */ _L20;
  kcg_bool /* _L28/ */ _L28;
  array_bool_1 /* _L33/ */ _L33;
  array_bool_5 /* _L32/ */ _L32;
  array_bool_4 /* _L31/ */ _L31;
  kcg_bool /* _L35/ */ _L35;
  kcg_float32 /* _L37/ */ _L37;
  array_float32_5 /* _L44/ */ _L44;
  array_float32_4 /* _L41/ */ _L41;
  array_float32_1 /* _L40/ */ _L40;
} outC_TrainConfiguration0_Math_Operators;

/* ===========  node initialization and cycle functions  =========== */
/* Math_Operators::TrainConfiguration0/ */
extern void TrainConfiguration0_Math_Operators(
  /* Scalar_Traction_force/ */
  kcg_float32 Scalar_Traction_force,
  /* Scalar_DynamicBrakingForce/ */
  kcg_float32 Scalar_DynamicBrakingForce,
  /* Scalar_Speed/ */
  kcg_float32 Scalar_Speed,
  /* Scalar_Acceleration/ */
  kcg_float32 Scalar_Acceleration,
  /* Holding_brakestatus/ */
  kcg_bool Holding_brakestatus,
  /* brakelinepressure/ */
  kcg_float32 brakelinepressure,
  outC_TrainConfiguration0_Math_Operators *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void TrainConfiguration0_reset_Math_Operators(
  outC_TrainConfiguration0_Math_Operators *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void TrainConfiguration0_init_Math_Operators(
  outC_TrainConfiguration0_Math_Operators *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _TrainConfiguration0_Math_Operators_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** TrainConfiguration0_Math_Operators.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

