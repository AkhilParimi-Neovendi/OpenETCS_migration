/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Train_Driver_H_
#define _Train_Driver_H_

#include "kcg_types.h"
#include "Send_GoA4_Selected_ETCSHMI_Functions.h"
#include "Send_GoA2_Selected_ETCSHMI_Functions.h"
#include "Send_FS_Selected_ETCSHMI_Functions.h"
#include "Train_Physics_Train.h"
#include "Read_and_Send_ETCSOB_Data_ETCSHMI_Functions.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  FVAHMIPacket /* to_FVA/ */ to_FVA;
  ETCSHMIPacket /* to_ETCS_OB/ */ to_ETCS_OB;
  ExternalindicatorStates /* External_ATORSC_Status/ */ External_ATORSC_Status;
  array_char_30 /* ETCSHMI_TextBox/ */ ETCSHMI_TextBox;
  Tain_Physics_Outputs /* Train_Physics_Output/ */ Train_Physics_Output;
  ETCSHMIPacketDataType /* ETCSHMI_Data_Out/ */ ETCSHMI_Data_Out;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_Train_Physics_Train /* _L41=(Train::Train_Physics#3)/ */ Context_Train_Physics_3;
  outC_Send_FS_Selected_ETCSHMI_Functions /* _L45=(ETCSHMI_Functions::Send_FS_Selected#1)/ */ Context_Send_FS_Selected_1;
  outC_Send_GoA2_Selected_ETCSHMI_Functions /* _L55=(ETCSHMI_Functions::Send_GoA2_Selected#1)/ */ Context_Send_GoA2_Selected_1;
  outC_Send_GoA4_Selected_ETCSHMI_Functions /* _L57=(ETCSHMI_Functions::Send_GoA4_Selected#1)/ */ Context_Send_GoA4_Selected_1;
  outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions /* _L40=(ETCSHMI_Functions::Read_and_Send_ETCSOB_Data)/ */ Context_Read_and_Send_ETCSOB_Data;
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* IfBlock2: */ IfBlock2_clock;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* IfBlock2:then:_L1/ */ _L1_then_IfBlock2;
  kcg_int8 /* IfBlock2:then:_L3/ */ _L3_then_IfBlock2;
  kcg_int8 /* IfBlock2:then:_L4/ */ _L4_then_IfBlock2;
  kcg_int8 /* IfBlock2:else:_L7/ */ _L7_else_IfBlock2;
  kcg_bool /* IfBlock2:else:_L6/ */ _L6_else_IfBlock2;
  kcg_int8 /* IfBlock2:else:_L5/ */ _L5_else_IfBlock2;
  ATORSCSwitchPosition /* Local_ATORSCSwitchPosition/ */ Local_ATORSCSwitchPosition;
  kcg_int8 /* T_B_Leverinput/ */ T_B_Leverinput;
  kcg_bool /* HoldingBrakeApplied/ */ HoldingBrakeApplied;
  kcg_int8 /* TrainBrakePos/ */ TrainBrakePos;
  ETCSHMIPacket /* _L2/ */ _L2;
  ExternalindicatorStates /* _L4/ */ _L4;
  ATORSCSwitchPosition /* _L5/ */ _L5;
  kcg_bool /* _L32/ */ _L32;
  array_char_30 /* _L40/ */ _L40;
  Tain_Physics_Outputs /* _L41/ */ _L41;
  kcg_int8 /* _L42/ */ _L42;
  kcg_bool /* _L43/ */ _L43;
  kcg_int8 /* _L44/ */ _L44;
  ETCSHMIPacket /* _L45/ */ _L45;
  kcg_bool /* _L51/ */ _L51;
  ETCSHMIPacket /* _L52/ */ _L52;
  kcg_bool /* _L53/ */ _L53;
  ETCSHMIPacket /* _L54/ */ _L54;
  ETCSHMIPacket /* _L55/ */ _L55;
  kcg_bool /* _L56/ */ _L56;
  ETCSHMIPacket /* _L57/ */ _L57;
  ETCSHMIPacket /* _L58/ */ _L58;
  ETCSHMIPacket /* _L59/ */ _L59;
  ETCSHMIPacket /* _L64/ */ _L64;
  ETCSHMIPacket /* _L67/ */ _L67;
  ETCSHMIPacketDataType /* _L68/ */ _L68;
  ETCSHMIPacketDataType /* _L69/ */ _L69;
  kcg_bool /* _L70/ */ _L70;
  FVAHMIPacket /* _L71/ */ _L71;
} outC_Train_Driver;

/* ===========  node initialization and cycle functions  =========== */
/* Train_Driver/ */
extern void Train_Driver(
  /* from_FVA/ */
  ExternalindicatorStates *from_FVA,
  /* from_ETCS_OB/ */
  ETCSHMIPacket *from_ETCS_OB,
  /* ATORSCSwitch_Position/ */
  ATORSCSwitchPosition ATORSCSwitch_Position,
  /* SendMessage/ */
  kcg_bool SendMessage,
  /* ATO_GoA4_mode_button/ */
  kcg_bool ATO_GoA4_mode_button,
  /* ATO_GoA2_mode_button/ */
  kcg_bool ATO_GoA2_mode_button,
  /* ETCS_FS_mode_button/ */
  kcg_bool ETCS_FS_mode_button,
  /* ThrottleBrakeLever_Position/ */
  kcg_int8 ThrottleBrakeLever_Position,
  /* Apply_HoldingBrake/ */
  kcg_bool Apply_HoldingBrake,
  /* TrainBrakeLever/ */
  kcg_int8 TrainBrakeLever,
  /* ETCSHMIData_in/ */
  ETCSHMIPacketDataType *ETCSHMIData_in,
  /* External_Override_Switch/ */
  kcg_bool External_Override_Switch,
  outC_Train_Driver *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Train_Driver_reset(outC_Train_Driver *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Train_Driver_init(outC_Train_Driver *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Train_Driver_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Driver.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

