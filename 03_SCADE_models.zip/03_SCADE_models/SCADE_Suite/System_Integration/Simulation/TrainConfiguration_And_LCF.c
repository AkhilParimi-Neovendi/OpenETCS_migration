/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "TrainConfiguration_And_LCF.h"

/* TrainConfiguration_And_LCF/ */
void TrainConfiguration_And_LCF(
  /* Unit_Speed/ */
  kcg_float32 Unit_Speed,
  /* Unit_traction_force/ */
  kcg_float32 Unit_traction_force,
  /* Unit_braking_force/ */
  kcg_float32 Unit_braking_force,
  /* holdingbrakestatus/ */
  kcg_bool holdingbrakestatus,
  /* BrakelinePressure/ */
  kcg_float32 BrakelinePressure,
  /* Unit_Acceleration/ */
  kcg_float32 Unit_Acceleration,
  outC_TrainConfiguration_And_LCF *outC)
{
  kcg_size idx;
  kcg_size idx1;

  outC->_L27 = holdingbrakestatus;
  outC->_L26 = BrakelinePressure;
  kcg_copy_array_float32_5(&outC->_L12, &outC->_L5);
  outC->_L1 = Unit_traction_force;
  outC->_L2 = Unit_braking_force;
  outC->_L3 = Unit_Speed;
  outC->_L4 = Unit_Acceleration;
  /* _L17=(Math_Operators::TrainConfiguration0#1)/ */
  TrainConfiguration0_Math_Operators(
    outC->_L1,
    outC->_L2,
    outC->_L3,
    outC->_L4,
    outC->_L27,
    outC->_L26,
    &outC->Context_TrainConfiguration0_1);
  kcg_copy_array_float32_5(
    &outC->_L17,
    &outC->Context_TrainConfiguration0_1.Traction_force_Array);
  kcg_copy_array_float32_5(
    &outC->_L18,
    &outC->Context_TrainConfiguration0_1.Braking_force_Array);
  kcg_copy_array_float32_5(
    &outC->_L19,
    &outC->Context_TrainConfiguration0_1.Speed_Array);
  kcg_copy_array_float32_5(
    &outC->_L20,
    &outC->Context_TrainConfiguration0_1.Accelartion_Array);
  kcg_copy_array_int32_5(
    &outC->_L21,
    &outC->Context_TrainConfiguration0_1.Mass_Array);
  kcg_copy_array_float32_5(
    &outC->_L28,
    &outC->Context_TrainConfiguration0_1.brakelinepressurearray);
  kcg_copy_array_bool_5(
    &outC->_L29,
    &outC->Context_TrainConfiguration0_1.holdingbrakestatus);
  outC->_L15 = kcg_lit_float32(0.0);
  /* _L14/ */
  for (idx = 0; idx < 5; idx++) {
    outC->_L14[idx] = outC->_L15;
  }
  /* _L13= */
  if (outC->init) {
    kcg_copy_array_float32_5(&outC->_L13, &outC->_L14);
  }
  else {
    kcg_copy_array_float32_5(&outC->_L13, &outC->_L12);
  }
  /* _L16=(Math_Operators::Shift_Array#1)/ */
  Shift_Array_Math_Operators(&outC->_L13, &outC->Context_Shift_Array_1);
  kcg_copy_array_float32_5(&outC->_L16, &outC->Context_Shift_Array_1.OutputArray);
  /* _L30= */
  for (idx1 = 0; idx1 < 5; idx1++) {
    /* _L30=(Math_Operators::LCF_Calculation#1)/ */
    LCF_Calculation_Math_Operators(
      outC->_L17[idx1],
      outC->_L18[idx1],
      outC->_L19[idx1],
      outC->_L20[idx1],
      outC->_L21[idx1],
      outC->_L28[idx1],
      outC->_L29[idx1],
      outC->_L16[idx1],
      &outC->Context_LCF_Calculation_1[idx1]);
    outC->_L30[idx1] = outC->Context_LCF_Calculation_1[idx1].unit_traction;
    outC->_L31[idx1] = outC->Context_LCF_Calculation_1[idx1].unittotalbraking;
    outC->_L5[idx1] = outC->Context_LCF_Calculation_1[idx1].L_Couplingforce;
  }
  /* _L23=(Math_Operators::Sum_of_Forces#1)/ */
  Sum_of_Forces_Math_Operators(
    &outC->_L30,
    &outC->_L31,
    &outC->Context_Sum_of_Forces_1);
  outC->_L23 = outC->Context_Sum_of_Forces_1.Sum_of_traction_forces;
  outC->_L22 = outC->Context_Sum_of_Forces_1.Sum_of_Braking_forces;
  outC->Total_Brakingforce = outC->_L22;
  outC->Total_Tractionforce = outC->_L23;
  kcg_copy_array_float32_5(&outC->LCF_Array, &outC->_L5);
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void TrainConfiguration_And_LCF_init(outC_TrainConfiguration_And_LCF *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;
  kcg_size idx3;
  kcg_size idx4;
  kcg_size idx5;
  kcg_size idx6;
  kcg_size idx7;
  kcg_size idx8;
  kcg_size idx9;
  kcg_size idx10;
  kcg_size idx11;
  kcg_size idx12;
  kcg_size idx13;
  kcg_size idx14;
  kcg_size idx15;

  for (idx1 = 0; idx1 < 5; idx1++) {
    outC->_L31[idx1] = kcg_lit_float32(0.0);
  }
  for (idx2 = 0; idx2 < 5; idx2++) {
    outC->_L30[idx2] = kcg_lit_float32(0.0);
  }
  for (idx3 = 0; idx3 < 5; idx3++) {
    outC->_L29[idx3] = kcg_true;
  }
  for (idx4 = 0; idx4 < 5; idx4++) {
    outC->_L28[idx4] = kcg_lit_float32(0.0);
  }
  outC->_L27 = kcg_true;
  outC->_L26 = kcg_lit_float32(0.0);
  outC->_L22 = kcg_lit_float32(0.0);
  outC->_L23 = kcg_lit_float32(0.0);
  for (idx5 = 0; idx5 < 5; idx5++) {
    outC->_L17[idx5] = kcg_lit_float32(0.0);
  }
  for (idx6 = 0; idx6 < 5; idx6++) {
    outC->_L18[idx6] = kcg_lit_float32(0.0);
  }
  for (idx7 = 0; idx7 < 5; idx7++) {
    outC->_L19[idx7] = kcg_lit_float32(0.0);
  }
  for (idx8 = 0; idx8 < 5; idx8++) {
    outC->_L20[idx8] = kcg_lit_float32(0.0);
  }
  for (idx9 = 0; idx9 < 5; idx9++) {
    outC->_L21[idx9] = kcg_lit_int32(0);
  }
  for (idx10 = 0; idx10 < 5; idx10++) {
    outC->_L16[idx10] = kcg_lit_float32(0.0);
  }
  outC->_L15 = kcg_lit_float32(0.0);
  for (idx11 = 0; idx11 < 5; idx11++) {
    outC->_L14[idx11] = kcg_lit_float32(0.0);
  }
  for (idx12 = 0; idx12 < 5; idx12++) {
    outC->_L13[idx12] = kcg_lit_float32(0.0);
  }
  for (idx13 = 0; idx13 < 5; idx13++) {
    outC->_L12[idx13] = kcg_lit_float32(0.0);
  }
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  for (idx14 = 0; idx14 < 5; idx14++) {
    outC->_L5[idx14] = kcg_lit_float32(0.0);
  }
  outC->init = kcg_true;
  outC->Total_Brakingforce = kcg_lit_float32(0.0);
  outC->Total_Tractionforce = kcg_lit_float32(0.0);
  for (idx15 = 0; idx15 < 5; idx15++) {
    outC->LCF_Array[idx15] = kcg_lit_float32(0.0);
  }
  /* _L23=(Math_Operators::Sum_of_Forces#1)/ */
  Sum_of_Forces_init_Math_Operators(&outC->Context_Sum_of_Forces_1);
  for (idx = 0; idx < 5; idx++) {
    /* _L30=(Math_Operators::LCF_Calculation#1)/ */
    LCF_Calculation_init_Math_Operators(&outC->Context_LCF_Calculation_1[idx]);
  }
  /* _L16=(Math_Operators::Shift_Array#1)/ */
  Shift_Array_init_Math_Operators(&outC->Context_Shift_Array_1);
  /* _L17=(Math_Operators::TrainConfiguration0#1)/ */
  TrainConfiguration0_init_Math_Operators(&outC->Context_TrainConfiguration0_1);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void TrainConfiguration_And_LCF_reset(outC_TrainConfiguration_And_LCF *outC)
{
  kcg_size idx;

  outC->init = kcg_true;
  /* _L23=(Math_Operators::Sum_of_Forces#1)/ */
  Sum_of_Forces_reset_Math_Operators(&outC->Context_Sum_of_Forces_1);
  for (idx = 0; idx < 5; idx++) {
    /* _L30=(Math_Operators::LCF_Calculation#1)/ */
    LCF_Calculation_reset_Math_Operators(&outC->Context_LCF_Calculation_1[idx]);
  }
  /* _L16=(Math_Operators::Shift_Array#1)/ */
  Shift_Array_reset_Math_Operators(&outC->Context_Shift_Array_1);
  /* _L17=(Math_Operators::TrainConfiguration0#1)/ */
  TrainConfiguration0_reset_Math_Operators(
    &outC->Context_TrainConfiguration0_1);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** TrainConfiguration_And_LCF.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

