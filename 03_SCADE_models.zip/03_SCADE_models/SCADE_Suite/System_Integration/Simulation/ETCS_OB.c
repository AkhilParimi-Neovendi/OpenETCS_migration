/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ETCS_OB.h"

/* ETCS_OB/ */
void ETCS_OB(
  /* from_ATO_OB/ */
  kcg_bool from_ATO_OB,
  /* from_Train_Driver/ */
  ETCSHMIPacket *from_Train_Driver,
  /* from_EmergencyBrakeIO/ */
  kcg_bool from_EmergencyBrakeIO,
  /* from_OpenIO_interface/ */
  kcg_bool from_OpenIO_interface,
  /* from_Vehicle_Management_System/ */
  kcg_bool from_Vehicle_Management_System,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_RM/ */
  kcg_bool from_RM,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_ETCS_OB *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;
  kcg_bool _2_noname;
  kcg_bool _3_noname;
  kcg_bool _4_noname;
  kcg_bool _5_noname;
  kcg_bool _6_noname;
  /* temp_overrideswitchstate/ */
  kcg_bool last_temp_overrideswitchstate;
  /* ATOmode/ */
  ATO_modes last_ATOmode;
  /* ETCSMode/ */
  ETCS_modes last_ETCSMode;

  last_temp_overrideswitchstate = outC->temp_overrideswitchstate;
  last_ATOmode = outC->ATOmode;
  last_ETCSMode = outC->ETCSMode;
  outC->_L53 = kcg_lit_int8(1);
  outC->_L52 = last_ETCSMode;
  outC->_L51 = outC->_L52 == outC->_L53;
  kcg_copy_ETCSATOPacket(&outC->_L50, (ETCSATOPacket *) &ETCSATOPacketinit);
  outC->_L47 = last_ATOmode;
  kcg_copy_ETCSHMIPacket(&outC->_L12, from_Train_Driver);
  /* _L44=(Send_Receive_HMI_Msgs#8)/ */
  Send_Receive_HMI_Msgs(&outC->_L12, &outC->Context_Send_Receive_HMI_Msgs_8);
  kcg_copy_ETCSHMIPacket(
    &outC->_L44,
    &outC->Context_Send_Receive_HMI_Msgs_8.Send_HMI_Packet);
  outC->_L45 = outC->Context_Send_Receive_HMI_Msgs_8.to_ATO_TBD;
  outC->_L48 = last_temp_overrideswitchstate;
  outC->_L46.ATO_selected_mode = outC->_L47;
  outC->_L46.ATO_DataAcknowledged = outC->_L45;
  outC->_L46.temp_Override_SwitchState = outC->_L48;
  /* _L49= */
  if (outC->_L51) {
    kcg_copy_ETCSATOPacket(&outC->_L49, &outC->_L46);
  }
  else {
    kcg_copy_ETCSATOPacket(&outC->_L49, &outC->_L50);
  }
  outC->_L9 = from_FVA;
  outC->temp_overrideswitchstate = outC->_L9;
  kcg_copy_ETCSATOPacket(&outC->to_ATO_OB, &outC->_L49);
  kcg_copy_ETCSHMIPacket(&outC->_L41, from_Train_Driver);
  /* _L42=(SetATOMode#1)/ */ SetATOMode(&outC->_L41, &outC->Context_SetATOMode_1);
  outC->_L42 = outC->Context_SetATOMode_1.ATOMode;
  outC->ATOmode = outC->_L42;
  kcg_copy_ETCSHMIPacket(&outC->_L39, from_Train_Driver);
  /* _L40=(SetETCSMode#1)/ */
  SetETCSMode(&outC->_L39, &outC->Context_SetETCSMode_1);
  outC->_L40 = outC->Context_SetETCSMode_1.ETCSMode;
  outC->ETCSMode = outC->_L40;
  kcg_copy_ETCSHMIPacket(&outC->to_Train_Driver, &outC->_L44);
  outC->_L3 = kcg_false;
  outC->_L10 = from_ATO_OB;
  _6_noname = outC->_L10;
  outC->to_FVA = outC->_L3;
  outC->to_RSC_OB = outC->_L3;
  outC->to_RM = outC->_L3;
  outC->to_Diagnostic_platform = outC->_L3;
  outC->to_Vehicle_Management_System = outC->_L3;
  outC->to_OpenIO_Interface = outC->_L3;
  outC->_L8 = from_RSC_OB;
  _5_noname = outC->_L8;
  outC->_L7 = from_RM;
  _4_noname = outC->_L7;
  outC->_L6 = from_Diagnostic_Platform;
  _3_noname = outC->_L6;
  outC->_L5 = from_Vehicle_Management_System;
  _2_noname = outC->_L5;
  outC->_L4 = from_OpenIO_interface;
  _1_noname = outC->_L4;
  outC->to_EmergencyBrakeIO = outC->_L3;
  outC->_L2 = from_EmergencyBrakeIO;
  noname = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void ETCS_OB_init(outC_ETCS_OB *outC)
{
  outC->_L53 = kcg_lit_int8(0);
  outC->_L52 = kcg_lit_int8(0);
  outC->_L51 = kcg_true;
  outC->_L50.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L50.ATO_DataAcknowledged = kcg_true;
  outC->_L50.temp_Override_SwitchState = kcg_true;
  outC->_L49.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L49.ATO_DataAcknowledged = kcg_true;
  outC->_L49.temp_Override_SwitchState = kcg_true;
  outC->_L48 = kcg_true;
  outC->_L47 = kcg_lit_int8(0);
  outC->_L46.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L46.ATO_DataAcknowledged = kcg_true;
  outC->_L46.temp_Override_SwitchState = kcg_true;
  outC->_L45 = kcg_true;
  outC->_L44.isvalid = kcg_true;
  outC->_L44.Header = kcg_lit_int8(0);
  outC->_L44.Message = kcg_lit_int8(0);
  outC->_L44.currentETCSmode = kcg_lit_int8(0);
  outC->_L44.currentATOmode = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L44.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L44.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L42 = kcg_lit_int8(0);
  outC->_L41.isvalid = kcg_true;
  outC->_L41.Header = kcg_lit_int8(0);
  outC->_L41.Message = kcg_lit_int8(0);
  outC->_L41.currentETCSmode = kcg_lit_int8(0);
  outC->_L41.currentATOmode = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L41.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L41.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L40 = kcg_lit_int8(0);
  outC->_L39.isvalid = kcg_true;
  outC->_L39.Header = kcg_lit_int8(0);
  outC->_L39.Message = kcg_lit_int8(0);
  outC->_L39.currentETCSmode = kcg_lit_int8(0);
  outC->_L39.currentATOmode = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L39.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L39.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L3 = kcg_true;
  outC->_L12.isvalid = kcg_true;
  outC->_L12.Header = kcg_lit_int8(0);
  outC->_L12.Message = kcg_lit_int8(0);
  outC->_L12.currentETCSmode = kcg_lit_int8(0);
  outC->_L12.currentATOmode = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L12.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L12.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L10 = kcg_true;
  outC->_L9 = kcg_true;
  outC->_L8 = kcg_true;
  outC->_L7 = kcg_true;
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L2 = kcg_true;
  outC->to_FVA = kcg_true;
  outC->to_RSC_OB = kcg_true;
  outC->to_RM = kcg_true;
  outC->to_Diagnostic_platform = kcg_true;
  outC->to_Vehicle_Management_System = kcg_true;
  outC->to_OpenIO_Interface = kcg_true;
  outC->to_EmergencyBrakeIO = kcg_true;
  outC->to_Train_Driver.isvalid = kcg_true;
  outC->to_Train_Driver.Header = kcg_lit_int8(0);
  outC->to_Train_Driver.Message = kcg_lit_int8(0);
  outC->to_Train_Driver.currentETCSmode = kcg_lit_int8(0);
  outC->to_Train_Driver.currentATOmode = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->to_Train_Driver.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->to_ATO_OB.ATO_selected_mode = kcg_lit_int8(0);
  outC->to_ATO_OB.ATO_DataAcknowledged = kcg_true;
  outC->to_ATO_OB.temp_Override_SwitchState = kcg_true;
  /* _L40=(SetETCSMode#1)/ */ SetETCSMode_init(&outC->Context_SetETCSMode_1);
  /* _L42=(SetATOMode#1)/ */ SetATOMode_init(&outC->Context_SetATOMode_1);
  /* _L44=(Send_Receive_HMI_Msgs#8)/ */
  Send_Receive_HMI_Msgs_init(&outC->Context_Send_Receive_HMI_Msgs_8);
  outC->ETCSMode = int8init;
  outC->ATOmode = int8init;
  outC->temp_overrideswitchstate = boolinit;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ETCS_OB_reset(outC_ETCS_OB *outC)
{
  /* _L40=(SetETCSMode#1)/ */ SetETCSMode_reset(&outC->Context_SetETCSMode_1);
  /* _L42=(SetATOMode#1)/ */ SetATOMode_reset(&outC->Context_SetATOMode_1);
  /* _L44=(Send_Receive_HMI_Msgs#8)/ */
  Send_Receive_HMI_Msgs_reset(&outC->Context_Send_Receive_HMI_Msgs_8);
  outC->ETCSMode = int8init;
  outC->ATOmode = int8init;
  outC->temp_overrideswitchstate = boolinit;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ETCS_OB.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

