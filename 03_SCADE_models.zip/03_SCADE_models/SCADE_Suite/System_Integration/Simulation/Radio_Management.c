/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Radio_Management.h"

/* Radio_Management/ */
void Radio_Management(
  /* from_ATO_TS_ss126/ */
  ATO_Packet *from_ATO_TS_ss126,
  /* from_RSC_TS/ */
  kcg_bool from_RSC_TS,
  /* from_ETSC_OB/ */
  kcg_bool from_ETSC_OB,
  /* from_DiagnosticPlatform/ */
  kcg_bool from_DiagnosticPlatform,
  /* from_Diagnostics_TS/ */
  kcg_bool from_Diagnostics_TS,
  /* from_ETCS_TS/ */
  kcg_bool from_ETCS_TS,
  /* from_ATO_OB/ */
  ATO_Packet *from_ATO_OB,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  outC_Radio_Management *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;
  kcg_bool _2_noname;
  kcg_bool _3_noname;
  kcg_bool _4_noname;
  kcg_bool _5_noname;
  /* from_ATO_OB/ */
  ATO_Packet last_from_ATO_OB;
  /* from_ATO_TS_ss126/ */
  ATO_Packet last_from_ATO_TS_ss126;

  kcg_copy_ATO_Packet(&last_from_ATO_TS_ss126, &outC->mem_from_ATO_TS_ss126);
  kcg_copy_ATO_Packet(&outC->mem_from_ATO_TS_ss126, from_ATO_TS_ss126);
  kcg_copy_ATO_Packet(&last_from_ATO_OB, &outC->mem_from_ATO_OB);
  kcg_copy_ATO_Packet(&outC->mem_from_ATO_OB, from_ATO_OB);
  outC->_L8 = kcg_false;
  outC->to_RSC_OB = outC->_L8;
  outC->_L9 = from_RSC_OB;
  _5_noname = outC->_L9;
  outC->to_ETCS_TS = outC->_L8;
  outC->to_Diagnostics_TS = outC->_L8;
  outC->to_DiagnosticPlatform = outC->_L8;
  outC->to_ETCS_OB = outC->_L8;
  outC->to_RSC_TS = outC->_L8;
  kcg_copy_ATO_Packet(&outC->_L7, from_ATO_OB);
  kcg_copy_ATO_Packet(&outC->to_ATO_TS_ss126, &outC->_L7);
  kcg_copy_ATO_Packet(&outC->_L1, from_ATO_TS_ss126);
  kcg_copy_ATO_Packet(&outC->to_ATO_OB, &outC->_L1);
  outC->_L6 = from_ETCS_TS;
  _4_noname = outC->_L6;
  outC->_L5 = from_Diagnostics_TS;
  _3_noname = outC->_L5;
  outC->_L4 = from_DiagnosticPlatform;
  _2_noname = outC->_L4;
  outC->_L3 = from_ETSC_OB;
  _1_noname = outC->_L3;
  outC->_L2 = from_RSC_TS;
  noname = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void Radio_Management_init(outC_Radio_Management *outC)
{
  outC->_L9 = kcg_true;
  outC->_L8 = kcg_true;
  outC->_L7.Header = kcg_lit_int8(0);
  outC->_L7.Value = kcg_true;
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1.Header = kcg_lit_int8(0);
  outC->_L1.Value = kcg_true;
  outC->to_RSC_OB = kcg_true;
  outC->to_ETCS_TS = kcg_true;
  outC->to_Diagnostics_TS = kcg_true;
  outC->to_DiagnosticPlatform = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->to_RSC_TS = kcg_true;
  outC->to_ATO_TS_ss126.Header = kcg_lit_int8(0);
  outC->to_ATO_TS_ss126.Value = kcg_true;
  outC->to_ATO_OB.Header = kcg_lit_int8(0);
  outC->to_ATO_OB.Value = kcg_true;
  kcg_copy_ATO_Packet(&outC->mem_from_ATO_OB, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ATO_Packet(
    &outC->mem_from_ATO_TS_ss126,
    (ATO_Packet *) &ATO_Packetinit);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Radio_Management_reset(outC_Radio_Management *outC)
{
  kcg_copy_ATO_Packet(&outC->mem_from_ATO_OB, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ATO_Packet(
    &outC->mem_from_ATO_TS_ss126,
    (ATO_Packet *) &ATO_Packetinit);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Radio_Management.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

