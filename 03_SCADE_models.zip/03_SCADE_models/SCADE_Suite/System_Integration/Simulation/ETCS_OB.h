/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _ETCS_OB_H_
#define _ETCS_OB_H_

#include "kcg_types.h"
#include "Send_Receive_HMI_Msgs.h"
#include "SetATOMode.h"
#include "SetETCSMode.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ETCSATOPacket /* to_ATO_OB/ */ to_ATO_OB;
  ETCSHMIPacket /* to_Train_Driver/ */ to_Train_Driver;
  kcg_bool /* to_EmergencyBrakeIO/ */ to_EmergencyBrakeIO;
  kcg_bool /* to_OpenIO_Interface/ */ to_OpenIO_Interface;
  kcg_bool /* to_Vehicle_Management_System/ */ to_Vehicle_Management_System;
  kcg_bool /* to_Diagnostic_platform/ */ to_Diagnostic_platform;
  kcg_bool /* to_RM/ */ to_RM;
  kcg_bool /* to_RSC_OB/ */ to_RSC_OB;
  kcg_bool /* to_FVA/ */ to_FVA;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  ETCS_modes /* ETCSMode/ */ ETCSMode;
  ATO_modes /* ATOmode/ */ ATOmode;
  kcg_bool /* temp_overrideswitchstate/ */ temp_overrideswitchstate;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_SetETCSMode /* _L40=(SetETCSMode#1)/ */ Context_SetETCSMode_1;
  outC_SetATOMode /* _L42=(SetATOMode#1)/ */ Context_SetATOMode_1;
  outC_Send_Receive_HMI_Msgs /* _L44=(Send_Receive_HMI_Msgs#8)/ */ Context_Send_Receive_HMI_Msgs_8;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L6/ */ _L6;
  kcg_bool /* _L7/ */ _L7;
  kcg_bool /* _L8/ */ _L8;
  kcg_bool /* _L9/ */ _L9;
  kcg_bool /* _L10/ */ _L10;
  ETCSHMIPacket /* _L12/ */ _L12;
  kcg_bool /* _L3/ */ _L3;
  ETCSHMIPacket /* _L39/ */ _L39;
  ETCS_modes /* _L40/ */ _L40;
  ETCSHMIPacket /* _L41/ */ _L41;
  ATO_modes /* _L42/ */ _L42;
  ETCSHMIPacket /* _L44/ */ _L44;
  kcg_bool /* _L45/ */ _L45;
  ETCSATOPacket /* _L46/ */ _L46;
  ATO_modes /* _L47/ */ _L47;
  kcg_bool /* _L48/ */ _L48;
  ETCSATOPacket /* _L49/ */ _L49;
  ETCSATOPacket /* _L50/ */ _L50;
  kcg_bool /* _L51/ */ _L51;
  ETCS_modes /* _L52/ */ _L52;
  kcg_int8 /* _L53/ */ _L53;
} outC_ETCS_OB;

/* ===========  node initialization and cycle functions  =========== */
/* ETCS_OB/ */
extern void ETCS_OB(
  /* from_ATO_OB/ */
  kcg_bool from_ATO_OB,
  /* from_Train_Driver/ */
  ETCSHMIPacket *from_Train_Driver,
  /* from_EmergencyBrakeIO/ */
  kcg_bool from_EmergencyBrakeIO,
  /* from_OpenIO_interface/ */
  kcg_bool from_OpenIO_interface,
  /* from_Vehicle_Management_System/ */
  kcg_bool from_Vehicle_Management_System,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_RM/ */
  kcg_bool from_RM,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_ETCS_OB *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void ETCS_OB_reset(outC_ETCS_OB *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void ETCS_OB_init(outC_ETCS_OB *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _ETCS_OB_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ETCS_OB.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

