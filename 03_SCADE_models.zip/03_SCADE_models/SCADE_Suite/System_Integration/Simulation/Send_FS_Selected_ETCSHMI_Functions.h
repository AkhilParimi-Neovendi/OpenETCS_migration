/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Send_FS_Selected_ETCSHMI_Functions_H_
#define _Send_FS_Selected_ETCSHMI_Functions_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ETCSHMIPacket /* Out_ETCS_Packet/ */ Out_ETCS_Packet;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  ETCS_HMI_Msgs /* _L1/ */ _L1;
  ETCSHMIPacketDataType /* _L3/ */ _L3;
  ATO_modes /* _L4/ */ _L4;
  ETCS_HMI_MsgHeaders /* _L5/ */ _L5;
  ETCSHMIPacket /* _L6/ */ _L6;
  ETCS_modes /* _L7/ */ _L7;
  kcg_bool /* _L8/ */ _L8;
} outC_Send_FS_Selected_ETCSHMI_Functions;

/* ===========  node initialization and cycle functions  =========== */
/* ETCSHMI_Functions::Send_FS_Selected/ */
extern void Send_FS_Selected_ETCSHMI_Functions(
  /* FS_Mode_button_Pressed/ */
  kcg_bool FS_Mode_button_Pressed,
  outC_Send_FS_Selected_ETCSHMI_Functions *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Send_FS_Selected_reset_ETCSHMI_Functions(
  outC_Send_FS_Selected_ETCSHMI_Functions *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Send_FS_Selected_init_ETCSHMI_Functions(
  outC_Send_FS_Selected_ETCSHMI_Functions *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Send_FS_Selected_ETCSHMI_Functions_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Send_FS_Selected_ETCSHMI_Functions.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

