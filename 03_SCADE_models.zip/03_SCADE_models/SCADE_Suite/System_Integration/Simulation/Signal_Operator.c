/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Signal_Operator.h"

/* Signal_Operator/ */
void Signal_Operator(
  /* from_System/ */
  kcg_bool from_System,
  outC_Signal_Operator *outC)
{
  kcg_bool noname;

  outC->_L2 = kcg_false;
  outC->_L1 = from_System;
  noname = outC->_L1;
  outC->to_System = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void Signal_Operator_init(outC_Signal_Operator *outC)
{
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_System = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Signal_Operator_reset(outC_Signal_Operator *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Signal_Operator.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

