/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Holding_brake_Brakes.h"

/* Brakes::Holding_brake/ */
void Holding_brake_Brakes(
  /* HoldingBrakeStatus/ */
  kcg_bool HoldingBrakeStatus,
  outC_Holding_brake_Brakes *outC)
{
  outC->Input1_NumericToFloat32_2_int32 = M_L * N_L;
  outC->_L1_NumericToFloat32_2_int32 = outC->Input1_NumericToFloat32_2_int32;
  outC->_L2_NumericToFloat32_2_int32 = /* @1/_L2= */(kcg_float32)
      outC->_L1_NumericToFloat32_2_int32;
  outC->Output1_NumericToFloat32_2_int32 = outC->_L2_NumericToFloat32_2_int32;
  outC->_L14 = kcg_lit_float32(5.0) / TCYCLE;
  outC->_L4 = g;
  outC->_L3 = outC->Output1_NumericToFloat32_2_int32;
  outC->_L2 = kcg_lit_float32(0.056);
  outC->_L1 = outC->_L2 * outC->_L3 * outC->_L4;
  outC->Max_HoldingBrakeForce = outC->_L1;
  outC->_L5 = outC->Max_HoldingBrakeForce;
  outC->_L13 = outC->_L5 / outC->_L14;
  outC->_L11 = outC->_L15;
  outC->_L19 = outC->_L11 - outC->_L13;
  outC->_L21 = kcg_lit_float32(0.0);
  outC->_L20 = outC->_L11 <= outC->_L21;
  /* _L22= */
  if (outC->_L20) {
    outC->_L22 = outC->_L21;
  }
  else {
    outC->_L22 = outC->_L19;
  }
  outC->_L17 = outC->_L15;
  outC->_L18 = outC->_L17 >= outC->_L5;
  outC->_L12 = outC->_L13 + outC->_L11;
  /* _L10= */
  if (outC->_L18) {
    outC->_L10 = outC->_L5;
  }
  else {
    outC->_L10 = outC->_L12;
  }
  outC->_L7 = HoldingBrakeStatus;
  /* _L6= */
  if (outC->_L7) {
    outC->_L6 = outC->_L10;
  }
  else {
    outC->_L6 = outC->_L22;
  }
  /* _L15= */
  if (outC->init) {
    outC->_L15 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L15 = outC->_L6;
  }
  outC->AppliedHoldingBrakeForce = outC->_L15;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void Holding_brake_init_Brakes(outC_Holding_brake_Brakes *outC)
{
  outC->_L22 = kcg_lit_float32(0.0);
  outC->_L21 = kcg_lit_float32(0.0);
  outC->_L20 = kcg_true;
  outC->_L19 = kcg_lit_float32(0.0);
  outC->_L18 = kcg_true;
  outC->_L17 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_lit_float32(0.0);
  outC->_L13 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = kcg_lit_float32(0.0);
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_true;
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->Max_HoldingBrakeForce = kcg_lit_float32(0.0);
  outC->_L1_NumericToFloat32_2_int32 = kcg_lit_int32(0);
  outC->_L2_NumericToFloat32_2_int32 = kcg_lit_float32(0.0);
  outC->Input1_NumericToFloat32_2_int32 = kcg_lit_int32(0);
  outC->Output1_NumericToFloat32_2_int32 = kcg_lit_float32(0.0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->init = kcg_true;
  outC->AppliedHoldingBrakeForce = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Holding_brake_reset_Brakes(outC_Holding_brake_Brakes *outC)
{
  outC->init = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: Brakes::Holding_brake/
  @1: (math::NumericToFloat32#2)
*/

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Holding_brake_Brakes.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

