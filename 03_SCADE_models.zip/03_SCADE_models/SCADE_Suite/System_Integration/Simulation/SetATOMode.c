/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "SetATOMode.h"

/* SetATOMode/ */
void SetATOMode(/* Input/ */ ETCSHMIPacket *Input, outC_SetATOMode *outC)
{
  ETCS_HMI_MsgHeaders noname;
  ETCS_HMI_Msgs _1_noname;
  ETCS_modes _2_noname;
  ETCSHMIPacketDataType _3_noname;
  /* temp_ATOMode/ */
  ATO_modes last_temp_ATOMode;

  last_temp_ATOMode = outC->temp_ATOMode;
  outC->_L33 = last_temp_ATOMode;
  kcg_copy_ETCSHMIPacket(&outC->_L27, Input);
  outC->_L31 = outC->_L27.currentATOmode;
  outC->_L38 = outC->_L31 != outC->_L33;
  outC->_L36 = kcg_lit_int8(0);
  outC->_L35 = outC->_L36 != outC->_L31;
  outC->_L37 = outC->_L35 & outC->_L38;
  outC->_L39 = outC->_L27.isvalid;
  outC->_L41 = outC->_L39 & outC->_L37;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L40, &outC->_L27.ETCSHMIPacketData);
  kcg_copy_ETCSHMIPacketDataType(&_3_noname, &outC->_L40);
  /* _L34= */
  if (outC->_L41) {
    outC->_L34 = outC->_L31;
  }
  else {
    outC->_L34 = outC->_L33;
  }
  outC->_L30 = outC->_L27.currentETCSmode;
  _2_noname = outC->_L30;
  outC->temp_ATOMode = outC->_L34;
  outC->_L32 = outC->temp_ATOMode;
  outC->ATOMode = outC->_L32;
  outC->_L29 = outC->_L27.Message;
  _1_noname = outC->_L29;
  outC->_L28 = outC->_L27.Header;
  noname = outC->_L28;
}

#ifndef KCG_USER_DEFINED_INIT
void SetATOMode_init(outC_SetATOMode *outC)
{
  outC->_L41 = kcg_true;
  outC->_L39 = kcg_true;
  outC->_L40.label1 = kcg_lit_int8(0);
  outC->_L40.label2 = kcg_lit_int8(0);
  outC->_L40.label3 = kcg_lit_int8(0);
  outC->_L40.label4 = kcg_lit_int8(0);
  outC->_L40.label5 = kcg_lit_int8(0);
  outC->_L40.label6 = kcg_lit_int8(0);
  outC->_L40.label7 = kcg_lit_int16(0);
  outC->_L40.label8 = kcg_lit_int16(0);
  outC->_L27.isvalid = kcg_true;
  outC->_L27.Header = kcg_lit_int8(0);
  outC->_L27.Message = kcg_lit_int8(0);
  outC->_L27.currentETCSmode = kcg_lit_int8(0);
  outC->_L27.currentATOmode = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L27.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L27.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L31 = kcg_lit_int8(0);
  outC->_L30 = kcg_lit_int8(0);
  outC->_L29 = kcg_lit_int8(0);
  outC->_L28 = kcg_lit_int8(0);
  outC->_L32 = kcg_lit_int8(0);
  outC->_L33 = kcg_lit_int8(0);
  outC->_L34 = kcg_lit_int8(0);
  outC->_L35 = kcg_true;
  outC->_L36 = kcg_lit_int8(0);
  outC->_L37 = kcg_true;
  outC->_L38 = kcg_true;
  outC->ATOMode = kcg_lit_int8(0);
  outC->temp_ATOMode = kcg_lit_int8(0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void SetATOMode_reset(outC_SetATOMode *outC)
{
  outC->temp_ATOMode = kcg_lit_int8(0);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SetATOMode.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

