/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"

/* ETCSHMIpacketdatainit/ */
const ETCSHMIPacketDataType ETCSHMIpacketdatainit = { kcg_lit_int8(0),
  kcg_lit_int8(0), kcg_lit_int8(0), kcg_lit_int8(0), kcg_lit_int8(0),
  kcg_lit_int8(0), kcg_lit_int16(0), kcg_lit_int16(0) };

/* FVA_HMI_packetinit/ */
const FVAHMIPacket FVA_HMI_packetinit = { kcg_false, kcg_lit_int8(0) };

/* SwitchStateinit/ */
const ExternalindicatorStates SwitchStateinit = { kcg_lit_int8(0), kcg_false,
  kcg_false };

/* ETCS_HMI_Packetinit/ */
const ETCSHMIPacket ETCS_HMI_Packetinit = { kcg_false, kcg_lit_int8(0),
  kcg_lit_int8(0), kcg_lit_int8(0), kcg_lit_int8(0), { kcg_lit_int8(0),
    kcg_lit_int8(0), kcg_lit_int8(0), kcg_lit_int8(0), kcg_lit_int8(0),
    kcg_lit_int8(0), kcg_lit_int16(0), kcg_lit_int16(0) } };

/* ATO_Packetinit/ */
const ATO_Packet ATO_Packetinit = { kcg_lit_int8(0), kcg_false };

/* ETCSATOPacketinit/ */
const ETCSATOPacket ETCSATOPacketinit = { kcg_lit_int8(0), kcg_false,
  kcg_false };

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_consts.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

