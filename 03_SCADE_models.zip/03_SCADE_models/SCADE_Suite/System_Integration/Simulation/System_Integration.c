/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "System_Integration.h"

/* System_Integration/ */
void System_Integration(
  inC_System_Integration *inC,
  outC_System_Integration *outC)
{
  /* RSC_OBtoRM/ */
  kcg_bool last_RSC_OBtoRM;
  /* RMtoRSC_OB/ */
  kcg_bool last_RMtoRSC_OB;
  /* VehicleEmergencyBrake_EB_to_Perception_OB/ */
  kcg_bool last_VehicleEmergencyBrake_EB_to_Perception_OB;
  /* Vehicle_EmergencyBrake_EBto_ETCS_OB/ */
  kcg_bool last_Vehicle_EmergencyBrake_EBto_ETCS_OB;
  /* OpenIO_InterfacetoFVA/ */
  kcg_bool last_OpenIO_InterfacetoFVA;
  /* OpenIO_InterfacetoETCS_OB/ */
  kcg_bool last_OpenIO_InterfacetoETCS_OB;
  /* RollingStock_OperatingSystemtoFVA/ */
  kcg_bool last_RollingStock_OperatingSystemtoFVA;
  /* ClassB_Systems_to_VehicleManagement/ */
  kcg_bool last_ClassB_Systems_to_VehicleManagement;
  /* RSC_OperatortoRSC_TS/ */
  kcg_bool last_RSC_OperatortoRSC_TS;
  /* RSC_OperatortoPerception_TS/ */
  kcg_bool last_RSC_OperatortoPerception_TS;
  /* Vehicle_ManagementtoClassB_Systems/ */
  kcg_bool last_Vehicle_ManagementtoClassB_Systems;
  /* Vehicle_ManagementtoETCS_OB/ */
  kcg_bool last_Vehicle_ManagementtoETCS_OB;
  /* Vehicle_Management_toFVA/ */
  kcg_bool last_Vehicle_Management_toFVA;
  /* RSC_TStoRM/ */
  kcg_bool last_RSC_TStoRM;
  /* RSC_TStoRSC_Operator/ */
  kcg_bool last_RSC_TStoRSC_Operator;
  /* RSC_OBtoDiagnostic_Platform/ */
  kcg_bool last_RSC_OBtoDiagnostic_Platform;
  /* RSC_OBtoETCS_OB/ */
  kcg_bool last_RSC_OBtoETCS_OB;
  /* RSC_OBtoFVA_int2/ */
  kcg_bool last_RSC_OBtoFVA_int2;
  /* RSC_OBtoFVA_ss139/ */
  kcg_bool last_RSC_OBtoFVA_ss139;
  /* RMtoETCS_TS/ */
  kcg_bool last_RMtoETCS_TS;
  /* RMtoDiagnostic_TS/ */
  kcg_bool last_RMtoDiagnostic_TS;
  /* RMtoDiagnosticPlatform/ */
  kcg_bool last_RMtoDiagnosticPlatform;
  /* RMtoETCS_OB/ */
  kcg_bool last_RMtoETCS_OB;
  /* RMtoRSC_TS/ */
  kcg_bool last_RMtoRSC_TS;
  /* Perception_TStoPerception_OB/ */
  kcg_bool last_Perception_TStoPerception_OB;
  /* Perception_TStoRSC_Operator/ */
  kcg_bool last_Perception_TStoRSC_Operator;
  /* Perception_OBtoFVA/ */
  kcg_bool last_Perception_OBtoFVA;
  /* Perception_OBtoEmergencyBrake_EB/ */
  kcg_bool last_Perception_OBtoEmergencyBrake_EB;
  /* Perception_OBtoPerception_TS/ */
  kcg_bool last_Perception_OBtoPerception_TS;
  /* FVAtoRSC_OB_ss139/ */
  kcg_bool last_FVAtoRSC_OB_ss139;
  /* FVAtoRSC_OB_int2/ */
  kcg_bool last_FVAtoRSC_OB_int2;
  /* FVAtoRollingStock_OperatingSystem/ */
  kcg_bool last_FVAtoRollingStock_OperatingSystem;
  /* FVAtoDiagnostic_Platform/ */
  kcg_bool last_FVAtoDiagnostic_Platform;
  /* FVAtoVehicleMangement/ */
  kcg_bool last_FVAtoVehicleMangement;
  /* FVAtoOpenIO_Interface/ */
  kcg_bool last_FVAtoOpenIO_Interface;
  /* FVAtoDSE/ */
  kcg_bool last_FVAtoDSE;
  /* FVAtoPerception_OB/ */
  kcg_bool last_FVAtoPerception_OB;
  /* ETCS_TStoRM/ */
  kcg_bool last_ETCS_TStoRM;
  /* ETCS_OBtoFVA/ */
  kcg_bool last_ETCS_OBtoFVA;
  /* ETCS_OBtoRSC_OB/ */
  kcg_bool last_ETCS_OBtoRSC_OB;
  /* ETCS_OBtoRM/ */
  kcg_bool last_ETCS_OBtoRM;
  /* ETCS_OBtoDiagnostic_Platform/ */
  kcg_bool last_ETCS_OBtoDiagnostic_Platform;
  /* ETCS_OBtoVehicle_Management/ */
  kcg_bool last_ETCS_OBtoVehicle_Management;
  /* ETCS_OBtoOpenIO_Interface/ */
  kcg_bool last_ETCS_OBtoOpenIO_Interface;
  /* ETCS_OBtoEmergencyBrake_EB/ */
  kcg_bool last_ETCS_OBtoEmergencyBrake_EB;
  /* DSEtoATO_OB_C15/ */
  kcg_bool last_DSEtoATO_OB_C15;
  /* DSEtoATO_OB_ss139/ */
  kcg_bool last_DSEtoATO_OB_ss139;
  /* DSEtoFVA/ */
  kcg_bool last_DSEtoFVA;
  /* Dianostics_TStoRM/ */
  kcg_bool last_Dianostics_TStoRM;
  /* Diagnostic_PlatformtoETCS_OB/ */
  kcg_bool last_Diagnostic_PlatformtoETCS_OB;
  /* Diagnostic_PlatformtoFVA/ */
  kcg_bool last_Diagnostic_PlatformtoFVA;
  /* Diagnostic_PlatformtoRSC_OB/ */
  kcg_bool last_Diagnostic_PlatformtoRSC_OB;
  /* Diagnostic_PlatformtoATO_OB/ */
  kcg_bool last_Diagnostic_PlatformtoATO_OB;
  /* Diagnostic_PlatformtoRM/ */
  kcg_bool last_Diagnostic_PlatformtoRM;
  /* ATO_OBtoDSE_C15/ */
  kcg_bool last_ATO_OBtoDSE_C15;
  /* ATO_OBtoDiagnosticPlatfom/ */
  kcg_bool last_ATO_OBtoDiagnosticPlatfom;
  /* ATO_OBtoDSE_ss139/ */
  kcg_bool last_ATO_OBtoDSE_ss139;
  /* ATO_OBtoETCS_OB/ */
  kcg_bool last_ATO_OBtoETCS_OB;
  /* RMtoATO_TS/ */
  ATO_Packet last_RMtoATO_TS;
  /* ATO_OBtoRM/ */
  ATO_Packet last_ATO_OBtoRM;
  /* TrainDriver_to_ETCS_OB/ */
  ETCSHMIPacket last_TrainDriver_to_ETCS_OB;
  /* TrainDriver_to_FVA/ */
  FVAHMIPacket last_TrainDriver_to_FVA;
  /* RMtoATO_OB/ */
  ATO_Packet last_RMtoATO_OB;
  /* FVAtoETCSOB/ */
  kcg_bool last_FVAtoETCSOB;
  /* FVAtoTrainDriver/ */
  ExternalindicatorStates last_FVAtoTrainDriver;
  /* ETCS_OBtoTrainDriver/ */
  ETCSHMIPacket last_ETCS_OBtoTrainDriver;
  /* ETCS_OBtoATO_OB/ */
  ETCSATOPacket last_ETCS_OBtoATO_OB;
  /* ATO_TStoRM_ss126/ */
  ATO_Packet last_ATO_TStoRM_ss126;

  last_RSC_OBtoRM = outC->RSC_OBtoRM;
  last_RMtoRSC_OB = outC->RMtoRSC_OB;
  last_VehicleEmergencyBrake_EB_to_Perception_OB =
    outC->VehicleEmergencyBrake_EB_to_Perception_OB;
  last_Vehicle_EmergencyBrake_EBto_ETCS_OB =
    outC->Vehicle_EmergencyBrake_EBto_ETCS_OB;
  last_OpenIO_InterfacetoFVA = outC->OpenIO_InterfacetoFVA;
  last_OpenIO_InterfacetoETCS_OB = outC->OpenIO_InterfacetoETCS_OB;
  last_RollingStock_OperatingSystemtoFVA =
    outC->RollingStock_OperatingSystemtoFVA;
  last_ClassB_Systems_to_VehicleManagement =
    outC->ClassB_Systems_to_VehicleManagement;
  last_RSC_OperatortoRSC_TS = outC->RSC_OperatortoRSC_TS;
  last_RSC_OperatortoPerception_TS = outC->RSC_OperatortoPerception_TS;
  last_Vehicle_ManagementtoClassB_Systems =
    outC->Vehicle_ManagementtoClassB_Systems;
  last_Vehicle_ManagementtoETCS_OB = outC->Vehicle_ManagementtoETCS_OB;
  last_Vehicle_Management_toFVA = outC->Vehicle_Management_toFVA;
  last_RSC_TStoRM = outC->RSC_TStoRM;
  last_RSC_TStoRSC_Operator = outC->RSC_TStoRSC_Operator;
  last_RSC_OBtoDiagnostic_Platform = outC->RSC_OBtoDiagnostic_Platform;
  last_RSC_OBtoETCS_OB = outC->RSC_OBtoETCS_OB;
  last_RSC_OBtoFVA_int2 = outC->RSC_OBtoFVA_int2;
  last_RSC_OBtoFVA_ss139 = outC->RSC_OBtoFVA_ss139;
  last_RMtoETCS_TS = outC->RMtoETCS_TS;
  last_RMtoDiagnostic_TS = outC->RMtoDiagnostic_TS;
  last_RMtoDiagnosticPlatform = outC->RMtoDiagnosticPlatform;
  last_RMtoETCS_OB = outC->RMtoETCS_OB;
  last_RMtoRSC_TS = outC->RMtoRSC_TS;
  last_Perception_TStoPerception_OB = outC->Perception_TStoPerception_OB;
  last_Perception_TStoRSC_Operator = outC->Perception_TStoRSC_Operator;
  last_Perception_OBtoFVA = outC->Perception_OBtoFVA;
  last_Perception_OBtoEmergencyBrake_EB = outC->Perception_OBtoEmergencyBrake_EB;
  last_Perception_OBtoPerception_TS = outC->Perception_OBtoPerception_TS;
  last_FVAtoRSC_OB_ss139 = outC->FVAtoRSC_OB_ss139;
  last_FVAtoRSC_OB_int2 = outC->FVAtoRSC_OB_int2;
  last_FVAtoRollingStock_OperatingSystem =
    outC->FVAtoRollingStock_OperatingSystem;
  last_FVAtoDiagnostic_Platform = outC->FVAtoDiagnostic_Platform;
  last_FVAtoVehicleMangement = outC->FVAtoVehicleMangement;
  last_FVAtoOpenIO_Interface = outC->FVAtoOpenIO_Interface;
  last_FVAtoDSE = outC->FVAtoDSE;
  last_FVAtoPerception_OB = outC->FVAtoPerception_OB;
  last_ETCS_TStoRM = outC->ETCS_TStoRM;
  last_ETCS_OBtoFVA = outC->ETCS_OBtoFVA;
  last_ETCS_OBtoRSC_OB = outC->ETCS_OBtoRSC_OB;
  last_ETCS_OBtoRM = outC->ETCS_OBtoRM;
  last_ETCS_OBtoDiagnostic_Platform = outC->ETCS_OBtoDiagnostic_Platform;
  last_ETCS_OBtoVehicle_Management = outC->ETCS_OBtoVehicle_Management;
  last_ETCS_OBtoOpenIO_Interface = outC->ETCS_OBtoOpenIO_Interface;
  last_ETCS_OBtoEmergencyBrake_EB = outC->ETCS_OBtoEmergencyBrake_EB;
  last_DSEtoATO_OB_C15 = outC->DSEtoATO_OB_C15;
  last_DSEtoATO_OB_ss139 = outC->DSEtoATO_OB_ss139;
  last_DSEtoFVA = outC->DSEtoFVA;
  last_Dianostics_TStoRM = outC->Dianostics_TStoRM;
  last_Diagnostic_PlatformtoETCS_OB = outC->Diagnostic_PlatformtoETCS_OB;
  last_Diagnostic_PlatformtoFVA = outC->Diagnostic_PlatformtoFVA;
  last_Diagnostic_PlatformtoRSC_OB = outC->Diagnostic_PlatformtoRSC_OB;
  last_Diagnostic_PlatformtoATO_OB = outC->Diagnostic_PlatformtoATO_OB;
  last_Diagnostic_PlatformtoRM = outC->Diagnostic_PlatformtoRM;
  last_ATO_OBtoDSE_C15 = outC->ATO_OBtoDSE_C15;
  last_ATO_OBtoDiagnosticPlatfom = outC->ATO_OBtoDiagnosticPlatfom;
  last_ATO_OBtoDSE_ss139 = outC->ATO_OBtoDSE_ss139;
  last_ATO_OBtoETCS_OB = outC->ATO_OBtoETCS_OB;
  kcg_copy_ATO_Packet(&last_RMtoATO_TS, &outC->RMtoATO_TS);
  kcg_copy_ATO_Packet(&last_ATO_OBtoRM, &outC->ATO_OBtoRM);
  kcg_copy_ETCSHMIPacket(
    &last_TrainDriver_to_ETCS_OB,
    &outC->TrainDriver_to_ETCS_OB);
  kcg_copy_FVAHMIPacket(&last_TrainDriver_to_FVA, &outC->TrainDriver_to_FVA);
  kcg_copy_ATO_Packet(&last_RMtoATO_OB, &outC->RMtoATO_OB);
  last_FVAtoETCSOB = outC->FVAtoETCSOB;
  kcg_copy_ExternalindicatorStates(
    &last_FVAtoTrainDriver,
    &outC->FVAtoTrainDriver);
  kcg_copy_ETCSHMIPacket(&last_ETCS_OBtoTrainDriver, &outC->ETCS_OBtoTrainDriver);
  kcg_copy_ETCSATOPacket(&last_ETCS_OBtoATO_OB, &outC->ETCS_OBtoATO_OB);
  kcg_copy_ATO_Packet(&last_ATO_TStoRM_ss126, &outC->ATO_TStoRM_ss126);
  outC->_L185 = inC->OverrideSwitch;
  kcg_copy_ExternalindicatorStates(&outC->_L88, &last_FVAtoTrainDriver);
  kcg_copy_ETCSHMIPacket(&outC->_L89, &last_ETCS_OBtoTrainDriver);
  outC->_L158 = inC->ATORSC_SwitchPosition;
  outC->_L159 = inC->SendMsgto_ETCS_HMI;
  outC->_L169 = inC->GoA4button_ETCs_HMI;
  outC->_L168 = inC->GoA2button_ETCS_HMI;
  outC->_L167 = inC->FSbutton_ETCS_HMI;
  outC->_L180 = inC->T_B_Lever;
  outC->_L182 = inC->ApplyHoldingBrake;
  outC->_L181 = inC->Train_Brake_Lever;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L184, &inC->ETCS_HMI_Data_in);
  /* _L74=(Train_Driver#1)/ */
  Train_Driver(
    &outC->_L88,
    &outC->_L89,
    outC->_L158,
    outC->_L159,
    outC->_L169,
    outC->_L168,
    outC->_L167,
    outC->_L180,
    outC->_L182,
    outC->_L181,
    &outC->_L184,
    outC->_L185,
    &outC->Context_Train_Driver_1);
  kcg_copy_FVAHMIPacket(&outC->_L74, &outC->Context_Train_Driver_1.to_FVA);
  kcg_copy_ETCSHMIPacket(&outC->_L75, &outC->Context_Train_Driver_1.to_ETCS_OB);
  kcg_copy_ExternalindicatorStates(
    &outC->_L157,
    &outC->Context_Train_Driver_1.External_ATORSC_Status);
  kcg_copy_array_char_30(
    &outC->_L177,
    &outC->Context_Train_Driver_1.ETCSHMI_TextBox);
  kcg_copy_Tain_Physics_Outputs(
    &outC->_L179,
    &outC->Context_Train_Driver_1.Train_Physics_Output);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->_L183,
    &outC->Context_Train_Driver_1.ETCSHMI_Data_Out);
  kcg_copy_ETCSHMIPacketDataType(&outC->ETCS_HMI_Data_Out, &outC->_L183);
  kcg_copy_Tain_Physics_Outputs(&outC->Train_PhysicsOutputs, &outC->_L179);
  kcg_copy_array_char_30(&outC->ETCSHMI_TextBox, &outC->_L177);
  outC->_L176 = last_RSC_OBtoRM;
  outC->_L175 = last_RMtoRSC_OB;
  outC->_L117 = last_FVAtoRSC_OB_ss139;
  outC->_L118 = last_FVAtoRSC_OB_int2;
  outC->_L119 = last_ETCS_OBtoRSC_OB;
  outC->_L120 = last_Diagnostic_PlatformtoRSC_OB;
  outC->_L121 = inC->RSC_ONSwitch_GUI;
  /* _L55=(RSC_OB#1)/ */
  RSC_OB(
    outC->_L175,
    outC->_L117,
    outC->_L118,
    outC->_L119,
    outC->_L120,
    outC->_L121,
    &outC->Context_RSC_OB_1);
  outC->_L55 = outC->Context_RSC_OB_1.to_RM;
  outC->_L56 = outC->Context_RSC_OB_1.to_FVA_ss139;
  outC->_L57 = outC->Context_RSC_OB_1.to_FVA_int2;
  outC->_L58 = outC->Context_RSC_OB_1.to_ETCS_OB;
  outC->_L59 = outC->Context_RSC_OB_1.to_Diagnostic_Platform;
  outC->RSC_OBtoRM = outC->_L55;
  kcg_copy_ATO_Packet(&outC->_L123, &last_ATO_TStoRM_ss126);
  outC->_L124 = last_RSC_TStoRM;
  outC->_L125 = last_ETCS_OBtoRM;
  outC->_L126 = last_Diagnostic_PlatformtoRM;
  outC->_L127 = last_Dianostics_TStoRM;
  outC->_L128 = last_ETCS_TStoRM;
  kcg_copy_ATO_Packet(&outC->_L173, &last_ATO_OBtoRM);
  /* _L47=(Radio_Management#1)/ */
  Radio_Management(
    &outC->_L123,
    outC->_L124,
    outC->_L125,
    outC->_L126,
    outC->_L127,
    outC->_L128,
    &outC->_L173,
    outC->_L176,
    &outC->Context_Radio_Management_1);
  kcg_copy_ATO_Packet(&outC->_L47, &outC->Context_Radio_Management_1.to_ATO_OB);
  kcg_copy_ATO_Packet(
    &outC->_L48,
    &outC->Context_Radio_Management_1.to_ATO_TS_ss126);
  outC->_L49 = outC->Context_Radio_Management_1.to_RSC_TS;
  outC->_L50 = outC->Context_Radio_Management_1.to_ETCS_OB;
  outC->_L51 = outC->Context_Radio_Management_1.to_DiagnosticPlatform;
  outC->_L52 = outC->Context_Radio_Management_1.to_Diagnostics_TS;
  outC->_L53 = outC->Context_Radio_Management_1.to_ETCS_TS;
  outC->_L171 = outC->Context_Radio_Management_1.to_RSC_OB;
  outC->RMtoRSC_OB = outC->_L171;
  kcg_copy_ATO_Packet(&outC->_L174, &last_RMtoATO_TS);
  kcg_copy_ATO_Packet(&outC->RMtoATO_TS, &outC->_L48);
  kcg_copy_ATO_Packet(&outC->_L172, &last_RMtoATO_OB);
  outC->_L96 = inC->ATO_ONSwitch_GUI;
  kcg_copy_ETCSATOPacket(&outC->_L97, &last_ETCS_OBtoATO_OB);
  outC->_L98 = last_DSEtoATO_OB_C15;
  outC->_L99 = last_DSEtoATO_OB_ss139;
  outC->_L100 = last_Diagnostic_PlatformtoATO_OB;
  /* _L1=(ATO_OB#1)/ */
  ATO_OB(
    outC->_L96,
    &outC->_L97,
    outC->_L98,
    outC->_L99,
    outC->_L100,
    &outC->_L172,
    &outC->Context_ATO_OB_1);
  outC->_L1 = outC->Context_ATO_OB_1.to_ETCS_OB;
  outC->_L2 = outC->Context_ATO_OB_1.to_Driving_Style_Engine_ss139;
  outC->_L3 = outC->Context_ATO_OB_1.to_Diagnostic_Platform;
  outC->_L4 = outC->Context_ATO_OB_1.to_Driving_Style_Engine_C15;
  kcg_copy_ATO_Packet(&outC->_L170, &outC->Context_ATO_OB_1.to_RM);
  kcg_copy_ATO_Packet(&outC->ATO_OBtoRM, &outC->_L170);
  kcg_copy_ExternalindicatorStates(
    &outC->External_Status_Indication_Status,
    &outC->_L157);
  outC->_L156 = last_ATO_OBtoDSE_C15;
  outC->_L155 = last_ATO_OBtoDSE_ss139;
  outC->_L154 = last_FVAtoDSE;
  outC->_L153 = last_FVAtoETCSOB;
  outC->_L152 = last_RSC_OBtoETCS_OB;
  outC->_L151 = last_RMtoETCS_OB;
  outC->_L150 = last_Diagnostic_PlatformtoETCS_OB;
  outC->_L149 = last_OpenIO_InterfacetoETCS_OB;
  outC->_L148 = last_Vehicle_EmergencyBrake_EBto_ETCS_OB;
  outC->_L147 = last_Vehicle_ManagementtoETCS_OB;
  kcg_copy_ETCSHMIPacket(&outC->_L146, &last_TrainDriver_to_ETCS_OB);
  outC->_L145 = last_ATO_OBtoETCS_OB;
  outC->_L144 = last_RMtoETCS_TS;
  outC->_L143 = last_RSC_OBtoFVA_ss139;
  outC->_L142 = last_RSC_OBtoFVA_int2;
  outC->_L141 = last_RollingStock_OperatingSystemtoFVA;
  outC->_L140 = last_Diagnostic_PlatformtoFVA;
  outC->_L139 = last_Vehicle_Management_toFVA;
  outC->_L138 = last_DSEtoFVA;
  outC->_L137 = last_ETCS_OBtoFVA;
  outC->_L136 = last_OpenIO_InterfacetoFVA;
  kcg_copy_FVAHMIPacket(&outC->_L135, &last_TrainDriver_to_FVA);
  outC->_L134 = last_Perception_OBtoFVA;
  outC->_L133 = last_FVAtoPerception_OB;
  outC->_L132 = last_VehicleEmergencyBrake_EB_to_Perception_OB;
  outC->_L131 = last_Perception_TStoPerception_OB;
  outC->_L130 = last_Perception_OBtoPerception_TS;
  outC->_L129 = last_RSC_OperatortoPerception_TS;
  outC->_L115 = last_RMtoRSC_TS;
  outC->_L113 = last_RSC_OperatortoRSC_TS;
  outC->_L112 = last_ETCS_OBtoDiagnostic_Platform;
  outC->_L111 = last_FVAtoDiagnostic_Platform;
  outC->_L110 = last_RSC_OBtoDiagnostic_Platform;
  outC->_L109 = last_ATO_OBtoDiagnosticPlatfom;
  outC->_L108 = last_RMtoDiagnosticPlatform;
  outC->_L106 = last_RMtoDiagnostic_TS;
  outC->_L103 = last_ClassB_Systems_to_VehicleManagement;
  outC->_L102 = last_ETCS_OBtoVehicle_Management;
  outC->_L101 = last_FVAtoVehicleMangement;
  outC->_L95 = last_Perception_OBtoEmergencyBrake_EB;
  outC->_L94 = last_ETCS_OBtoEmergencyBrake_EB;
  outC->_L93 = last_FVAtoOpenIO_Interface;
  outC->_L92 = last_ETCS_OBtoOpenIO_Interface;
  outC->_L91 = last_FVAtoRollingStock_OperatingSystem;
  outC->_L90 = last_Vehicle_ManagementtoClassB_Systems;
  outC->_L87 = inC->SystemtoSignalOperator;
  outC->_L86 = last_RSC_TStoRSC_Operator;
  outC->_L85 = last_Perception_TStoRSC_Operator;
  /* _L80=(Train::Vehicle_EmergencyBrake_EB#1)/ */
  Vehicle_EmergencyBrake_EB_Train(
    outC->_L94,
    outC->_L95,
    &outC->Context_Vehicle_EmergencyBrake_EB_1);
  outC->_L80 = outC->Context_Vehicle_EmergencyBrake_EB_1.to_ETCS_OB;
  outC->_L81 = outC->Context_Vehicle_EmergencyBrake_EB_1.to_Perception_OB;
  outC->VehicleEmergencyBrake_EB_to_Perception_OB = outC->_L81;
  outC->Vehicle_EmergencyBrake_EBto_ETCS_OB = outC->_L80;
  /* _L78=(Train::OpenIO_Interface#1)/ */
  OpenIO_Interface_Train(
    outC->_L92,
    outC->_L93,
    &outC->Context_OpenIO_Interface_1);
  outC->_L78 = outC->Context_OpenIO_Interface_1.to_ETCS_OB;
  outC->_L79 = outC->Context_OpenIO_Interface_1.to_FVA;
  outC->OpenIO_InterfacetoFVA = outC->_L79;
  outC->OpenIO_InterfacetoETCS_OB = outC->_L78;
  /* _L77=(Train::RollingStock_Operating_System#1)/ */
  RollingStock_Operating_System_Train(
    outC->_L91,
    &outC->Context_RollingStock_Operating_System_1);
  outC->_L77 = outC->Context_RollingStock_Operating_System_1.to_FVA;
  outC->RollingStock_OperatingSystemtoFVA = outC->_L77;
  /* _L76=(Train::ClassB_Systems#1)/ */
  ClassB_Systems_Train(outC->_L90, &outC->Context_ClassB_Systems_1);
  outC->_L76 = outC->Context_ClassB_Systems_1.to_Vehicle_Management_Systems;
  outC->ClassB_Systems_to_VehicleManagement = outC->_L76;
  kcg_copy_ETCSHMIPacket(&outC->TrainDriver_to_ETCS_OB, &outC->_L75);
  kcg_copy_FVAHMIPacket(&outC->TrainDriver_to_FVA, &outC->_L74);
  /* _L73=(Signal_Operator#1)/ */
  Signal_Operator(outC->_L87, &outC->Context_Signal_Operator_1);
  outC->_L73 = outC->Context_Signal_Operator_1.to_System;
  outC->Signal_OperatortoSystem = outC->_L73;
  /* _L71=(RSC_Operator#1)/ */
  RSC_Operator(outC->_L85, outC->_L86, &outC->Context_RSC_Operator_1);
  outC->_L71 = outC->Context_RSC_Operator_1.to_Perception_TS;
  outC->_L72 = outC->Context_RSC_Operator_1.to_RSC_TS;
  outC->RSC_OperatortoRSC_TS = outC->_L72;
  outC->RSC_OperatortoPerception_TS = outC->_L71;
  /* _L68=(Vehicle_Management_System#1)/ */
  Vehicle_Management_System(
    outC->_L101,
    outC->_L102,
    outC->_L103,
    &outC->Context_Vehicle_Management_System_1);
  outC->_L68 = outC->Context_Vehicle_Management_System_1.to_FVA;
  outC->_L69 = outC->Context_Vehicle_Management_System_1.to_ETCS_OB;
  outC->_L70 = outC->Context_Vehicle_Management_System_1.to_ClassB_Systems;
  outC->Vehicle_ManagementtoClassB_Systems = outC->_L70;
  outC->Vehicle_ManagementtoETCS_OB = outC->_L69;
  outC->Vehicle_Management_toFVA = outC->_L68;
  /* _L64=(RSC_TS#1)/ */
  RSC_TS(outC->_L113, outC->_L115, &outC->Context_RSC_TS_1);
  outC->_L64 = outC->Context_RSC_TS_1.to_RSC_Operator;
  outC->_L65 = outC->Context_RSC_TS_1.to_RM;
  outC->RSC_TStoRM = outC->_L65;
  outC->RSC_TStoRSC_Operator = outC->_L64;
  outC->RSC_OBtoDiagnostic_Platform = outC->_L59;
  outC->RSC_OBtoETCS_OB = outC->_L58;
  outC->RSC_OBtoFVA_int2 = outC->_L57;
  outC->RSC_OBtoFVA_ss139 = outC->_L56;
  outC->RMtoETCS_TS = outC->_L53;
  outC->RMtoDiagnostic_TS = outC->_L52;
  outC->RMtoDiagnosticPlatform = outC->_L51;
  outC->RMtoETCS_OB = outC->_L50;
  outC->RMtoRSC_TS = outC->_L49;
  kcg_copy_ATO_Packet(&outC->RMtoATO_OB, &outC->_L47);
  /* _L42=(Perception_TS#1)/ */
  Perception_TS(outC->_L129, outC->_L130, &outC->Context_Perception_TS_1);
  outC->_L42 = outC->Context_Perception_TS_1.to_RSC_Operator;
  outC->_L43 = outC->Context_Perception_TS_1.to_Perception_OB;
  outC->Perception_TStoPerception_OB = outC->_L43;
  outC->Perception_TStoRSC_Operator = outC->_L42;
  /* _L37=(Perception_OB#1)/ */
  Perception_OB(
    outC->_L131,
    outC->_L132,
    outC->_L133,
    &outC->Context_Perception_OB_1);
  outC->_L37 = outC->Context_Perception_OB_1.to_Perception_TS;
  outC->_L38 = outC->Context_Perception_OB_1.to_EmergencyBrakeIO;
  outC->_L39 = outC->Context_Perception_OB_1.to_FVA;
  outC->Perception_OBtoPerception_TS = outC->_L37;
  outC->Perception_OBtoFVA = outC->_L39;
  outC->Perception_OBtoEmergencyBrake_EB = outC->_L38;
  /* _L26=(Functional_Vehicle_Adapter#1)/ */
  Functional_Vehicle_Adapter(
    outC->_L134,
    &outC->_L135,
    outC->_L136,
    outC->_L137,
    outC->_L138,
    outC->_L139,
    outC->_L140,
    outC->_L141,
    outC->_L142,
    outC->_L143,
    &outC->Context_Functional_Vehicle_Adapter_1);
  outC->_L26 = outC->Context_Functional_Vehicle_Adapter_1.to_Perception_OB;
  kcg_copy_ExternalindicatorStates(
    &outC->_L27,
    &outC->Context_Functional_Vehicle_Adapter_1.to_Train_Driver);
  outC->_L28 = outC->Context_Functional_Vehicle_Adapter_1.to_ETCS_OB;
  outC->_L29 = outC->Context_Functional_Vehicle_Adapter_1.to_Driving_Style_Engine;
  outC->_L30 = outC->Context_Functional_Vehicle_Adapter_1.to_OpenIO_interface;
  outC->_L31 =
    outC->Context_Functional_Vehicle_Adapter_1.to_Vehicle_Management_System;
  outC->_L32 = outC->Context_Functional_Vehicle_Adapter_1.to_Diagnostic_Platform;
  outC->_L33 = outC->Context_Functional_Vehicle_Adapter_1.to_Open_Vehicle_Bus;
  outC->_L34 = outC->Context_Functional_Vehicle_Adapter_1.to_RSC_OB_int2;
  outC->_L35 = outC->Context_Functional_Vehicle_Adapter_1.to_RSC_OB_ss139;
  outC->FVAtoRSC_OB_ss139 = outC->_L35;
  outC->FVAtoRSC_OB_int2 = outC->_L34;
  outC->FVAtoRollingStock_OperatingSystem = outC->_L33;
  outC->FVAtoDiagnostic_Platform = outC->_L32;
  outC->FVAtoVehicleMangement = outC->_L31;
  outC->FVAtoOpenIO_Interface = outC->_L30;
  outC->FVAtoDSE = outC->_L29;
  outC->FVAtoETCSOB = outC->_L28;
  kcg_copy_ExternalindicatorStates(&outC->FVAtoTrainDriver, &outC->_L27);
  outC->FVAtoPerception_OB = outC->_L26;
  /* _L25=(ETCS_TS#1)/ */ ETCS_TS(outC->_L144, &outC->Context_ETCS_TS_1);
  outC->_L25 = outC->Context_ETCS_TS_1.to_RM;
  outC->ETCS_TStoRM = outC->_L25;
  /* _L16=(ETCS_OB#1)/ */
  ETCS_OB(
    outC->_L145,
    &outC->_L146,
    outC->_L148,
    outC->_L149,
    outC->_L147,
    outC->_L150,
    outC->_L151,
    outC->_L152,
    outC->_L153,
    &outC->Context_ETCS_OB_1);
  kcg_copy_ETCSATOPacket(&outC->_L16, &outC->Context_ETCS_OB_1.to_ATO_OB);
  kcg_copy_ETCSHMIPacket(&outC->_L17, &outC->Context_ETCS_OB_1.to_Train_Driver);
  outC->_L18 = outC->Context_ETCS_OB_1.to_EmergencyBrakeIO;
  outC->_L19 = outC->Context_ETCS_OB_1.to_OpenIO_Interface;
  outC->_L20 = outC->Context_ETCS_OB_1.to_Vehicle_Management_System;
  outC->_L21 = outC->Context_ETCS_OB_1.to_Diagnostic_platform;
  outC->_L22 = outC->Context_ETCS_OB_1.to_RM;
  outC->_L23 = outC->Context_ETCS_OB_1.to_RSC_OB;
  outC->_L24 = outC->Context_ETCS_OB_1.to_FVA;
  outC->ETCS_OBtoFVA = outC->_L24;
  outC->ETCS_OBtoRSC_OB = outC->_L23;
  outC->ETCS_OBtoRM = outC->_L22;
  outC->ETCS_OBtoDiagnostic_Platform = outC->_L21;
  outC->ETCS_OBtoVehicle_Management = outC->_L20;
  outC->ETCS_OBtoOpenIO_Interface = outC->_L19;
  outC->ETCS_OBtoEmergencyBrake_EB = outC->_L18;
  kcg_copy_ETCSHMIPacket(&outC->ETCS_OBtoTrainDriver, &outC->_L17);
  kcg_copy_ETCSATOPacket(&outC->ETCS_OBtoATO_OB, &outC->_L16);
  /* _L13=(Driving_Style_Engine#1)/ */
  Driving_Style_Engine(
    outC->_L154,
    outC->_L155,
    outC->_L156,
    &outC->Context_Driving_Style_Engine_1);
  outC->_L13 = outC->Context_Driving_Style_Engine_1.to_FVA;
  outC->_L14 = outC->Context_Driving_Style_Engine_1.to_ATO_OB_ss139;
  outC->_L15 = outC->Context_Driving_Style_Engine_1.to_ATO_OB_C15;
  outC->DSEtoATO_OB_C15 = outC->_L15;
  outC->DSEtoATO_OB_ss139 = outC->_L14;
  outC->DSEtoFVA = outC->_L13;
  /* _L12=(Diagnostics_TS#1)/ */
  Diagnostics_TS(outC->_L106, &outC->Context_Diagnostics_TS_1);
  outC->_L12 = outC->Context_Diagnostics_TS_1.to_RM;
  outC->Dianostics_TStoRM = outC->_L12;
  /* _L7=(Diagnostic_Platform#1)/ */
  Diagnostic_Platform(
    outC->_L108,
    outC->_L109,
    outC->_L110,
    outC->_L111,
    outC->_L112,
    &outC->Context_Diagnostic_Platform_1);
  outC->_L7 = outC->Context_Diagnostic_Platform_1.to_RM;
  outC->_L8 = outC->Context_Diagnostic_Platform_1.to_ATO_OB;
  outC->_L9 = outC->Context_Diagnostic_Platform_1.to_RSC_OB;
  outC->_L10 = outC->Context_Diagnostic_Platform_1.to_FVA;
  outC->_L11 = outC->Context_Diagnostic_Platform_1.to_ETCS_OB;
  outC->Diagnostic_PlatformtoETCS_OB = outC->_L11;
  outC->Diagnostic_PlatformtoFVA = outC->_L10;
  outC->Diagnostic_PlatformtoRSC_OB = outC->_L9;
  outC->Diagnostic_PlatformtoATO_OB = outC->_L8;
  outC->Diagnostic_PlatformtoRM = outC->_L7;
  /* _L5=(ATO_TS#1)/ */ ATO_TS(&outC->_L174, &outC->Context_ATO_TS_1);
  kcg_copy_ATO_Packet(&outC->_L5, &outC->Context_ATO_TS_1.to_RM_ss126);
  kcg_copy_ATO_Packet(&outC->ATO_TStoRM_ss126, &outC->_L5);
  outC->ATO_OBtoDSE_C15 = outC->_L4;
  outC->ATO_OBtoDiagnosticPlatfom = outC->_L3;
  outC->ATO_OBtoDSE_ss139 = outC->_L2;
  outC->ATO_OBtoETCS_OB = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void System_Integration_init(outC_System_Integration *outC)
{
  kcg_size idx;
  kcg_size idx1;

  outC->_L185 = kcg_true;
  outC->_L184.label1 = kcg_lit_int8(0);
  outC->_L184.label2 = kcg_lit_int8(0);
  outC->_L184.label3 = kcg_lit_int8(0);
  outC->_L184.label4 = kcg_lit_int8(0);
  outC->_L184.label5 = kcg_lit_int8(0);
  outC->_L184.label6 = kcg_lit_int8(0);
  outC->_L184.label7 = kcg_lit_int16(0);
  outC->_L184.label8 = kcg_lit_int16(0);
  outC->_L183.label1 = kcg_lit_int8(0);
  outC->_L183.label2 = kcg_lit_int8(0);
  outC->_L183.label3 = kcg_lit_int8(0);
  outC->_L183.label4 = kcg_lit_int8(0);
  outC->_L183.label5 = kcg_lit_int8(0);
  outC->_L183.label6 = kcg_lit_int8(0);
  outC->_L183.label7 = kcg_lit_int16(0);
  outC->_L183.label8 = kcg_lit_int16(0);
  outC->_L182 = kcg_true;
  outC->_L181 = kcg_lit_int8(0);
  outC->_L180 = kcg_lit_int8(0);
  outC->_L179.Distance_Covered = kcg_lit_int16(0);
  outC->_L179.Train_Speed = kcg_lit_int16(0);
  outC->_L179.Train_Acceleration = kcg_lit_float32(0.0);
  for (idx = 0; idx < 30; idx++) {
    outC->_L177[idx] = ' ';
  }
  outC->_L176 = kcg_true;
  outC->_L175 = kcg_true;
  outC->_L174.Header = kcg_lit_int8(0);
  outC->_L174.Value = kcg_true;
  outC->_L173.Header = kcg_lit_int8(0);
  outC->_L173.Value = kcg_true;
  outC->_L172.Header = kcg_lit_int8(0);
  outC->_L172.Value = kcg_true;
  outC->_L171 = kcg_true;
  outC->_L170.Header = kcg_lit_int8(0);
  outC->_L170.Value = kcg_true;
  outC->_L167 = kcg_true;
  outC->_L169 = kcg_true;
  outC->_L168 = kcg_true;
  outC->_L159 = kcg_true;
  outC->_L158 = kcg_lit_int8(0);
  outC->_L157.IndicatorState = kcg_lit_int8(0);
  outC->_L157.RedLight = kcg_true;
  outC->_L157.GreenLight = kcg_true;
  outC->_L156 = kcg_true;
  outC->_L155 = kcg_true;
  outC->_L154 = kcg_true;
  outC->_L153 = kcg_true;
  outC->_L152 = kcg_true;
  outC->_L151 = kcg_true;
  outC->_L150 = kcg_true;
  outC->_L149 = kcg_true;
  outC->_L148 = kcg_true;
  outC->_L147 = kcg_true;
  outC->_L146.isvalid = kcg_true;
  outC->_L146.Header = kcg_lit_int8(0);
  outC->_L146.Message = kcg_lit_int8(0);
  outC->_L146.currentETCSmode = kcg_lit_int8(0);
  outC->_L146.currentATOmode = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L146.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L146.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L145 = kcg_true;
  outC->_L144 = kcg_true;
  outC->_L143 = kcg_true;
  outC->_L142 = kcg_true;
  outC->_L141 = kcg_true;
  outC->_L140 = kcg_true;
  outC->_L139 = kcg_true;
  outC->_L138 = kcg_true;
  outC->_L137 = kcg_true;
  outC->_L136 = kcg_true;
  outC->_L135.OverrideSwitch = kcg_true;
  outC->_L135.ATORSCSwitch = kcg_lit_int8(0);
  outC->_L134 = kcg_true;
  outC->_L133 = kcg_true;
  outC->_L132 = kcg_true;
  outC->_L131 = kcg_true;
  outC->_L130 = kcg_true;
  outC->_L129 = kcg_true;
  outC->_L128 = kcg_true;
  outC->_L127 = kcg_true;
  outC->_L126 = kcg_true;
  outC->_L125 = kcg_true;
  outC->_L124 = kcg_true;
  outC->_L123.Header = kcg_lit_int8(0);
  outC->_L123.Value = kcg_true;
  outC->_L121 = kcg_true;
  outC->_L120 = kcg_true;
  outC->_L119 = kcg_true;
  outC->_L118 = kcg_true;
  outC->_L117 = kcg_true;
  outC->_L115 = kcg_true;
  outC->_L113 = kcg_true;
  outC->_L112 = kcg_true;
  outC->_L111 = kcg_true;
  outC->_L110 = kcg_true;
  outC->_L109 = kcg_true;
  outC->_L108 = kcg_true;
  outC->_L106 = kcg_true;
  outC->_L103 = kcg_true;
  outC->_L102 = kcg_true;
  outC->_L101 = kcg_true;
  outC->_L100 = kcg_true;
  outC->_L99 = kcg_true;
  outC->_L98 = kcg_true;
  outC->_L97.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L97.ATO_DataAcknowledged = kcg_true;
  outC->_L97.temp_Override_SwitchState = kcg_true;
  outC->_L96 = kcg_true;
  outC->_L95 = kcg_true;
  outC->_L94 = kcg_true;
  outC->_L93 = kcg_true;
  outC->_L92 = kcg_true;
  outC->_L91 = kcg_true;
  outC->_L90 = kcg_true;
  outC->_L89.isvalid = kcg_true;
  outC->_L89.Header = kcg_lit_int8(0);
  outC->_L89.Message = kcg_lit_int8(0);
  outC->_L89.currentETCSmode = kcg_lit_int8(0);
  outC->_L89.currentATOmode = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L89.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L89.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L88.IndicatorState = kcg_lit_int8(0);
  outC->_L88.RedLight = kcg_true;
  outC->_L88.GreenLight = kcg_true;
  outC->_L87 = kcg_true;
  outC->_L86 = kcg_true;
  outC->_L85 = kcg_true;
  outC->_L80 = kcg_true;
  outC->_L81 = kcg_true;
  outC->_L78 = kcg_true;
  outC->_L79 = kcg_true;
  outC->_L77 = kcg_true;
  outC->_L76 = kcg_true;
  outC->_L74.OverrideSwitch = kcg_true;
  outC->_L74.ATORSCSwitch = kcg_lit_int8(0);
  outC->_L75.isvalid = kcg_true;
  outC->_L75.Header = kcg_lit_int8(0);
  outC->_L75.Message = kcg_lit_int8(0);
  outC->_L75.currentETCSmode = kcg_lit_int8(0);
  outC->_L75.currentATOmode = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L75.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L75.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L73 = kcg_true;
  outC->_L71 = kcg_true;
  outC->_L72 = kcg_true;
  outC->_L68 = kcg_true;
  outC->_L69 = kcg_true;
  outC->_L70 = kcg_true;
  outC->_L64 = kcg_true;
  outC->_L65 = kcg_true;
  outC->_L55 = kcg_true;
  outC->_L56 = kcg_true;
  outC->_L57 = kcg_true;
  outC->_L58 = kcg_true;
  outC->_L59 = kcg_true;
  outC->_L47.Header = kcg_lit_int8(0);
  outC->_L47.Value = kcg_true;
  outC->_L48.Header = kcg_lit_int8(0);
  outC->_L48.Value = kcg_true;
  outC->_L49 = kcg_true;
  outC->_L50 = kcg_true;
  outC->_L51 = kcg_true;
  outC->_L52 = kcg_true;
  outC->_L53 = kcg_true;
  outC->_L42 = kcg_true;
  outC->_L43 = kcg_true;
  outC->_L37 = kcg_true;
  outC->_L38 = kcg_true;
  outC->_L39 = kcg_true;
  outC->_L26 = kcg_true;
  outC->_L27.IndicatorState = kcg_lit_int8(0);
  outC->_L27.RedLight = kcg_true;
  outC->_L27.GreenLight = kcg_true;
  outC->_L28 = kcg_true;
  outC->_L29 = kcg_true;
  outC->_L30 = kcg_true;
  outC->_L31 = kcg_true;
  outC->_L32 = kcg_true;
  outC->_L33 = kcg_true;
  outC->_L34 = kcg_true;
  outC->_L35 = kcg_true;
  outC->_L25 = kcg_true;
  outC->_L16.ATO_selected_mode = kcg_lit_int8(0);
  outC->_L16.ATO_DataAcknowledged = kcg_true;
  outC->_L16.temp_Override_SwitchState = kcg_true;
  outC->_L17.isvalid = kcg_true;
  outC->_L17.Header = kcg_lit_int8(0);
  outC->_L17.Message = kcg_lit_int8(0);
  outC->_L17.currentETCSmode = kcg_lit_int8(0);
  outC->_L17.currentATOmode = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L17.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L17.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L18 = kcg_true;
  outC->_L19 = kcg_true;
  outC->_L20 = kcg_true;
  outC->_L21 = kcg_true;
  outC->_L22 = kcg_true;
  outC->_L23 = kcg_true;
  outC->_L24 = kcg_true;
  outC->_L13 = kcg_true;
  outC->_L14 = kcg_true;
  outC->_L15 = kcg_true;
  outC->_L12 = kcg_true;
  outC->_L7 = kcg_true;
  outC->_L8 = kcg_true;
  outC->_L9 = kcg_true;
  outC->_L10 = kcg_true;
  outC->_L11 = kcg_true;
  outC->_L5.Header = kcg_lit_int8(0);
  outC->_L5.Value = kcg_true;
  outC->_L1 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L4 = kcg_true;
  outC->Train_PhysicsOutputs.Distance_Covered = kcg_lit_int16(0);
  outC->Train_PhysicsOutputs.Train_Speed = kcg_lit_int16(0);
  outC->Train_PhysicsOutputs.Train_Acceleration = kcg_lit_float32(0.0);
  outC->Signal_OperatortoSystem = kcg_true;
  outC->RSC_OBtoRM = kcg_true;
  outC->RMtoRSC_OB = kcg_true;
  outC->VehicleEmergencyBrake_EB_to_Perception_OB = kcg_true;
  outC->Vehicle_EmergencyBrake_EBto_ETCS_OB = kcg_true;
  outC->OpenIO_InterfacetoFVA = kcg_true;
  outC->OpenIO_InterfacetoETCS_OB = kcg_true;
  outC->RollingStock_OperatingSystemtoFVA = kcg_true;
  outC->ClassB_Systems_to_VehicleManagement = kcg_true;
  outC->RSC_OperatortoRSC_TS = kcg_true;
  outC->RSC_OperatortoPerception_TS = kcg_true;
  outC->Vehicle_ManagementtoClassB_Systems = kcg_true;
  outC->Vehicle_ManagementtoETCS_OB = kcg_true;
  outC->Vehicle_Management_toFVA = kcg_true;
  outC->RSC_TStoRM = kcg_true;
  outC->RSC_TStoRSC_Operator = kcg_true;
  outC->RSC_OBtoDiagnostic_Platform = kcg_true;
  outC->RSC_OBtoETCS_OB = kcg_true;
  outC->RSC_OBtoFVA_int2 = kcg_true;
  outC->RSC_OBtoFVA_ss139 = kcg_true;
  outC->RMtoETCS_TS = kcg_true;
  outC->RMtoDiagnostic_TS = kcg_true;
  outC->RMtoDiagnosticPlatform = kcg_true;
  outC->RMtoETCS_OB = kcg_true;
  outC->RMtoRSC_TS = kcg_true;
  outC->Perception_TStoPerception_OB = kcg_true;
  outC->Perception_TStoRSC_Operator = kcg_true;
  outC->Perception_OBtoFVA = kcg_true;
  outC->Perception_OBtoEmergencyBrake_EB = kcg_true;
  outC->Perception_OBtoPerception_TS = kcg_true;
  outC->FVAtoRSC_OB_ss139 = kcg_true;
  outC->FVAtoRSC_OB_int2 = kcg_true;
  outC->FVAtoRollingStock_OperatingSystem = kcg_true;
  outC->FVAtoDiagnostic_Platform = kcg_true;
  outC->FVAtoVehicleMangement = kcg_true;
  outC->FVAtoOpenIO_Interface = kcg_true;
  outC->FVAtoDSE = kcg_true;
  outC->FVAtoPerception_OB = kcg_true;
  outC->ETCS_TStoRM = kcg_true;
  outC->ETCS_OBtoFVA = kcg_true;
  outC->ETCS_OBtoRSC_OB = kcg_true;
  outC->ETCS_OBtoRM = kcg_true;
  outC->ETCS_OBtoDiagnostic_Platform = kcg_true;
  outC->ETCS_OBtoVehicle_Management = kcg_true;
  outC->ETCS_OBtoOpenIO_Interface = kcg_true;
  outC->ETCS_OBtoEmergencyBrake_EB = kcg_true;
  outC->DSEtoATO_OB_C15 = kcg_true;
  outC->DSEtoATO_OB_ss139 = kcg_true;
  outC->DSEtoFVA = kcg_true;
  outC->Dianostics_TStoRM = kcg_true;
  outC->Diagnostic_PlatformtoETCS_OB = kcg_true;
  outC->Diagnostic_PlatformtoFVA = kcg_true;
  outC->Diagnostic_PlatformtoRSC_OB = kcg_true;
  outC->Diagnostic_PlatformtoATO_OB = kcg_true;
  outC->Diagnostic_PlatformtoRM = kcg_true;
  outC->ATO_OBtoDSE_C15 = kcg_true;
  outC->ATO_OBtoDiagnosticPlatfom = kcg_true;
  outC->ATO_OBtoDSE_ss139 = kcg_true;
  outC->ATO_OBtoETCS_OB = kcg_true;
  outC->ETCS_HMI_Data_Out.label1 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label2 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label3 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label4 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label5 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label6 = kcg_lit_int8(0);
  outC->ETCS_HMI_Data_Out.label7 = kcg_lit_int16(0);
  outC->ETCS_HMI_Data_Out.label8 = kcg_lit_int16(0);
  for (idx1 = 0; idx1 < 30; idx1++) {
    outC->ETCSHMI_TextBox[idx1] = ' ';
  }
  outC->External_Status_Indication_Status.IndicatorState = kcg_lit_int8(0);
  outC->External_Status_Indication_Status.RedLight = kcg_true;
  outC->External_Status_Indication_Status.GreenLight = kcg_true;
  /* _L5=(ATO_TS#1)/ */ ATO_TS_init(&outC->Context_ATO_TS_1);
  /* _L7=(Diagnostic_Platform#1)/ */
  Diagnostic_Platform_init(&outC->Context_Diagnostic_Platform_1);
  /* _L12=(Diagnostics_TS#1)/ */
  Diagnostics_TS_init(&outC->Context_Diagnostics_TS_1);
  /* _L13=(Driving_Style_Engine#1)/ */
  Driving_Style_Engine_init(&outC->Context_Driving_Style_Engine_1);
  /* _L16=(ETCS_OB#1)/ */ ETCS_OB_init(&outC->Context_ETCS_OB_1);
  /* _L25=(ETCS_TS#1)/ */ ETCS_TS_init(&outC->Context_ETCS_TS_1);
  /* _L26=(Functional_Vehicle_Adapter#1)/ */
  Functional_Vehicle_Adapter_init(&outC->Context_Functional_Vehicle_Adapter_1);
  /* _L37=(Perception_OB#1)/ */
  Perception_OB_init(&outC->Context_Perception_OB_1);
  /* _L42=(Perception_TS#1)/ */
  Perception_TS_init(&outC->Context_Perception_TS_1);
  /* _L64=(RSC_TS#1)/ */ RSC_TS_init(&outC->Context_RSC_TS_1);
  /* _L68=(Vehicle_Management_System#1)/ */
  Vehicle_Management_System_init(&outC->Context_Vehicle_Management_System_1);
  /* _L71=(RSC_Operator#1)/ */ RSC_Operator_init(&outC->Context_RSC_Operator_1);
  /* _L73=(Signal_Operator#1)/ */
  Signal_Operator_init(&outC->Context_Signal_Operator_1);
  /* _L76=(Train::ClassB_Systems#1)/ */
  ClassB_Systems_init_Train(&outC->Context_ClassB_Systems_1);
  /* _L77=(Train::RollingStock_Operating_System#1)/ */
  RollingStock_Operating_System_init_Train(
    &outC->Context_RollingStock_Operating_System_1);
  /* _L78=(Train::OpenIO_Interface#1)/ */
  OpenIO_Interface_init_Train(&outC->Context_OpenIO_Interface_1);
  /* _L80=(Train::Vehicle_EmergencyBrake_EB#1)/ */
  Vehicle_EmergencyBrake_EB_init_Train(
    &outC->Context_Vehicle_EmergencyBrake_EB_1);
  /* _L1=(ATO_OB#1)/ */ ATO_OB_init(&outC->Context_ATO_OB_1);
  /* _L47=(Radio_Management#1)/ */
  Radio_Management_init(&outC->Context_Radio_Management_1);
  /* _L55=(RSC_OB#1)/ */ RSC_OB_init(&outC->Context_RSC_OB_1);
  /* _L74=(Train_Driver#1)/ */ Train_Driver_init(&outC->Context_Train_Driver_1);
  kcg_copy_ATO_Packet(&outC->ATO_TStoRM_ss126, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ETCSATOPacket(
    &outC->ETCS_OBtoATO_OB,
    (ETCSATOPacket *) &ETCSATOPacketinit);
  kcg_copy_ETCSHMIPacket(
    &outC->ETCS_OBtoTrainDriver,
    (ETCSHMIPacket *) &ETCS_HMI_Packetinit);
  kcg_copy_ExternalindicatorStates(
    &outC->FVAtoTrainDriver,
    (ExternalindicatorStates *) &SwitchStateinit);
  outC->FVAtoETCSOB = boolinit;
  kcg_copy_ATO_Packet(&outC->RMtoATO_OB, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_FVAHMIPacket(
    &outC->TrainDriver_to_FVA,
    (FVAHMIPacket *) &FVA_HMI_packetinit);
  kcg_copy_ETCSHMIPacket(
    &outC->TrainDriver_to_ETCS_OB,
    (ETCSHMIPacket *) &ETCS_HMI_Packetinit);
  kcg_copy_ATO_Packet(&outC->ATO_OBtoRM, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ATO_Packet(&outC->RMtoATO_TS, (ATO_Packet *) &ATO_Packetinit);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void System_Integration_reset(outC_System_Integration *outC)
{
  /* _L5=(ATO_TS#1)/ */ ATO_TS_reset(&outC->Context_ATO_TS_1);
  /* _L7=(Diagnostic_Platform#1)/ */
  Diagnostic_Platform_reset(&outC->Context_Diagnostic_Platform_1);
  /* _L12=(Diagnostics_TS#1)/ */
  Diagnostics_TS_reset(&outC->Context_Diagnostics_TS_1);
  /* _L13=(Driving_Style_Engine#1)/ */
  Driving_Style_Engine_reset(&outC->Context_Driving_Style_Engine_1);
  /* _L16=(ETCS_OB#1)/ */ ETCS_OB_reset(&outC->Context_ETCS_OB_1);
  /* _L25=(ETCS_TS#1)/ */ ETCS_TS_reset(&outC->Context_ETCS_TS_1);
  /* _L26=(Functional_Vehicle_Adapter#1)/ */
  Functional_Vehicle_Adapter_reset(&outC->Context_Functional_Vehicle_Adapter_1);
  /* _L37=(Perception_OB#1)/ */
  Perception_OB_reset(&outC->Context_Perception_OB_1);
  /* _L42=(Perception_TS#1)/ */
  Perception_TS_reset(&outC->Context_Perception_TS_1);
  /* _L64=(RSC_TS#1)/ */ RSC_TS_reset(&outC->Context_RSC_TS_1);
  /* _L68=(Vehicle_Management_System#1)/ */
  Vehicle_Management_System_reset(&outC->Context_Vehicle_Management_System_1);
  /* _L71=(RSC_Operator#1)/ */ RSC_Operator_reset(&outC->Context_RSC_Operator_1);
  /* _L73=(Signal_Operator#1)/ */
  Signal_Operator_reset(&outC->Context_Signal_Operator_1);
  /* _L76=(Train::ClassB_Systems#1)/ */
  ClassB_Systems_reset_Train(&outC->Context_ClassB_Systems_1);
  /* _L77=(Train::RollingStock_Operating_System#1)/ */
  RollingStock_Operating_System_reset_Train(
    &outC->Context_RollingStock_Operating_System_1);
  /* _L78=(Train::OpenIO_Interface#1)/ */
  OpenIO_Interface_reset_Train(&outC->Context_OpenIO_Interface_1);
  /* _L80=(Train::Vehicle_EmergencyBrake_EB#1)/ */
  Vehicle_EmergencyBrake_EB_reset_Train(
    &outC->Context_Vehicle_EmergencyBrake_EB_1);
  /* _L1=(ATO_OB#1)/ */ ATO_OB_reset(&outC->Context_ATO_OB_1);
  /* _L47=(Radio_Management#1)/ */
  Radio_Management_reset(&outC->Context_Radio_Management_1);
  /* _L55=(RSC_OB#1)/ */ RSC_OB_reset(&outC->Context_RSC_OB_1);
  /* _L74=(Train_Driver#1)/ */ Train_Driver_reset(&outC->Context_Train_Driver_1);
  kcg_copy_ATO_Packet(&outC->ATO_TStoRM_ss126, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ETCSATOPacket(
    &outC->ETCS_OBtoATO_OB,
    (ETCSATOPacket *) &ETCSATOPacketinit);
  kcg_copy_ETCSHMIPacket(
    &outC->ETCS_OBtoTrainDriver,
    (ETCSHMIPacket *) &ETCS_HMI_Packetinit);
  kcg_copy_ExternalindicatorStates(
    &outC->FVAtoTrainDriver,
    (ExternalindicatorStates *) &SwitchStateinit);
  outC->FVAtoETCSOB = boolinit;
  kcg_copy_ATO_Packet(&outC->RMtoATO_OB, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_FVAHMIPacket(
    &outC->TrainDriver_to_FVA,
    (FVAHMIPacket *) &FVA_HMI_packetinit);
  kcg_copy_ETCSHMIPacket(
    &outC->TrainDriver_to_ETCS_OB,
    (ETCSHMIPacket *) &ETCS_HMI_Packetinit);
  kcg_copy_ATO_Packet(&outC->ATO_OBtoRM, (ATO_Packet *) &ATO_Packetinit);
  kcg_copy_ATO_Packet(&outC->RMtoATO_TS, (ATO_Packet *) &ATO_Packetinit);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** System_Integration.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

