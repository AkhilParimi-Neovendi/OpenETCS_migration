/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Signal_Operator_H_
#define _Signal_Operator_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_System/ */ to_System;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
} outC_Signal_Operator;

/* ===========  node initialization and cycle functions  =========== */
/* Signal_Operator/ */
extern void Signal_Operator(
  /* from_System/ */
  kcg_bool from_System,
  outC_Signal_Operator *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Signal_Operator_reset(outC_Signal_Operator *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Signal_Operator_init(outC_Signal_Operator *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Signal_Operator_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Signal_Operator.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

