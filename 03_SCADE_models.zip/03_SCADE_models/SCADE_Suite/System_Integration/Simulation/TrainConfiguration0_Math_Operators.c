/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "TrainConfiguration0_Math_Operators.h"

/* Math_Operators::TrainConfiguration0/ */
void TrainConfiguration0_Math_Operators(
  /* Scalar_Traction_force/ */
  kcg_float32 Scalar_Traction_force,
  /* Scalar_DynamicBrakingForce/ */
  kcg_float32 Scalar_DynamicBrakingForce,
  /* Scalar_Speed/ */
  kcg_float32 Scalar_Speed,
  /* Scalar_Acceleration/ */
  kcg_float32 Scalar_Acceleration,
  /* Holding_brakestatus/ */
  kcg_bool Holding_brakestatus,
  /* brakelinepressure/ */
  kcg_float32 brakelinepressure,
  outC_TrainConfiguration0_Math_Operators *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;
  kcg_size idx3;
  kcg_size idx4;
  kcg_size idx5;
  kcg_size idx6;
  kcg_size idx7;
  kcg_size idx8;
  kcg_size idx9;
  kcg_size idx10;
  kcg_size idx11;

  outC->_L37 = brakelinepressure;
  /* _L40/ */
  for (idx = 0; idx < 1; idx++) {
    outC->_L40[idx] = outC->_L37;
  }
  /* _L41/ */
  for (idx1 = 0; idx1 < 4; idx1++) {
    outC->_L41[idx1] = outC->_L37;
  }
  outC->_L35 = kcg_false;
  /* _L31/ */
  for (idx2 = 0; idx2 < 4; idx2++) {
    outC->_L31[idx2] = outC->_L35;
  }
  outC->_L28 = Holding_brakestatus;
  /* _L33/ */
  for (idx3 = 0; idx3 < 1; idx3++) {
    outC->_L33[idx3] = outC->_L28;
  }
  outC->_L32[0] = outC->_L33[0];
  kcg_copy_array_bool_4(&outC->_L32[1], &outC->_L31);
  kcg_copy_array_bool_5(&outC->holdingbrakestatus, &outC->_L32);
  outC->_L44[0] = outC->_L40[0];
  kcg_copy_array_float32_4(&outC->_L44[1], &outC->_L41);
  kcg_copy_array_float32_5(&outC->brakelinepressurearray, &outC->_L44);
  outC->_L20 = M_C;
  /* _L19/ */
  for (idx4 = 0; idx4 < 4; idx4++) {
    outC->_L19[idx4] = outC->_L20;
  }
  outC->_L17 = M_L;
  /* _L13/ */
  for (idx5 = 0; idx5 < 1; idx5++) {
    outC->_L13[idx5] = outC->_L17;
  }
  outC->_L18[0] = outC->_L13[0];
  kcg_copy_array_int32_4(&outC->_L18[1], &outC->_L19);
  kcg_copy_array_int32_5(&outC->Mass_Array, &outC->_L18);
  outC->_L15 = Scalar_Acceleration;
  /* _L12/ */
  for (idx6 = 0; idx6 < 5; idx6++) {
    outC->_L12[idx6] = outC->_L15;
  }
  kcg_copy_array_float32_5(&outC->Accelartion_Array, &outC->_L12);
  outC->_L14 = Scalar_Speed;
  /* _L11/ */
  for (idx7 = 0; idx7 < 5; idx7++) {
    outC->_L11[idx7] = outC->_L14;
  }
  kcg_copy_array_float32_5(&outC->Speed_Array, &outC->_L11);
  outC->_L10 = kcg_lit_float32(0.0);
  /* _L6/ */
  for (idx8 = 0; idx8 < 4; idx8++) {
    outC->_L6[idx8] = outC->_L10;
  }
  outC->_L2 = Scalar_DynamicBrakingForce;
  /* _L7/ */
  for (idx9 = 0; idx9 < 1; idx9++) {
    outC->_L7[idx9] = outC->_L2;
  }
  outC->_L8[0] = outC->_L7[0];
  kcg_copy_array_float32_4(&outC->_L8[1], &outC->_L6);
  kcg_copy_array_float32_5(&outC->Braking_force_Array, &outC->_L8);
  outC->_L9 = kcg_lit_float32(0.0);
  /* _L3/ */
  for (idx10 = 0; idx10 < 4; idx10++) {
    outC->_L3[idx10] = outC->_L9;
  }
  outC->_L1 = Scalar_Traction_force;
  /* _L4/ */
  for (idx11 = 0; idx11 < 1; idx11++) {
    outC->_L4[idx11] = outC->_L1;
  }
  outC->_L5[0] = outC->_L4[0];
  kcg_copy_array_float32_4(&outC->_L5[1], &outC->_L3);
  kcg_copy_array_float32_5(&outC->Traction_force_Array, &outC->_L5);
}

#ifndef KCG_USER_DEFINED_INIT
void TrainConfiguration0_init_Math_Operators(
  outC_TrainConfiguration0_Math_Operators *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;
  kcg_size idx3;
  kcg_size idx4;
  kcg_size idx5;
  kcg_size idx6;
  kcg_size idx7;
  kcg_size idx8;
  kcg_size idx9;
  kcg_size idx10;
  kcg_size idx11;
  kcg_size idx12;
  kcg_size idx13;
  kcg_size idx14;
  kcg_size idx15;
  kcg_size idx16;
  kcg_size idx17;
  kcg_size idx18;
  kcg_size idx19;
  kcg_size idx20;
  kcg_size idx21;
  kcg_size idx22;
  kcg_size idx23;

  for (idx = 0; idx < 1; idx++) {
    outC->_L40[idx] = kcg_lit_float32(0.0);
  }
  for (idx1 = 0; idx1 < 4; idx1++) {
    outC->_L41[idx1] = kcg_lit_float32(0.0);
  }
  for (idx2 = 0; idx2 < 5; idx2++) {
    outC->_L44[idx2] = kcg_lit_float32(0.0);
  }
  outC->_L37 = kcg_lit_float32(0.0);
  outC->_L35 = kcg_true;
  for (idx3 = 0; idx3 < 4; idx3++) {
    outC->_L31[idx3] = kcg_true;
  }
  for (idx4 = 0; idx4 < 5; idx4++) {
    outC->_L32[idx4] = kcg_true;
  }
  for (idx5 = 0; idx5 < 1; idx5++) {
    outC->_L33[idx5] = kcg_true;
  }
  outC->_L28 = kcg_true;
  outC->_L20 = kcg_lit_int32(0);
  for (idx6 = 0; idx6 < 4; idx6++) {
    outC->_L19[idx6] = kcg_lit_int32(0);
  }
  for (idx7 = 0; idx7 < 5; idx7++) {
    outC->_L18[idx7] = kcg_lit_int32(0);
  }
  outC->_L17 = kcg_lit_int32(0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L14 = kcg_lit_float32(0.0);
  for (idx8 = 0; idx8 < 5; idx8++) {
    outC->_L11[idx8] = kcg_lit_float32(0.0);
  }
  for (idx9 = 0; idx9 < 5; idx9++) {
    outC->_L12[idx9] = kcg_lit_float32(0.0);
  }
  for (idx10 = 0; idx10 < 1; idx10++) {
    outC->_L13[idx10] = kcg_lit_int32(0);
  }
  outC->_L10 = kcg_lit_float32(0.0);
  outC->_L9 = kcg_lit_float32(0.0);
  for (idx11 = 0; idx11 < 4; idx11++) {
    outC->_L6[idx11] = kcg_lit_float32(0.0);
  }
  for (idx12 = 0; idx12 < 1; idx12++) {
    outC->_L7[idx12] = kcg_lit_float32(0.0);
  }
  for (idx13 = 0; idx13 < 5; idx13++) {
    outC->_L8[idx13] = kcg_lit_float32(0.0);
  }
  for (idx14 = 0; idx14 < 4; idx14++) {
    outC->_L3[idx14] = kcg_lit_float32(0.0);
  }
  for (idx15 = 0; idx15 < 1; idx15++) {
    outC->_L4[idx15] = kcg_lit_float32(0.0);
  }
  for (idx16 = 0; idx16 < 5; idx16++) {
    outC->_L5[idx16] = kcg_lit_float32(0.0);
  }
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  for (idx17 = 0; idx17 < 5; idx17++) {
    outC->holdingbrakestatus[idx17] = kcg_true;
  }
  for (idx18 = 0; idx18 < 5; idx18++) {
    outC->brakelinepressurearray[idx18] = kcg_lit_float32(0.0);
  }
  for (idx19 = 0; idx19 < 5; idx19++) {
    outC->Mass_Array[idx19] = kcg_lit_int32(0);
  }
  for (idx20 = 0; idx20 < 5; idx20++) {
    outC->Accelartion_Array[idx20] = kcg_lit_float32(0.0);
  }
  for (idx21 = 0; idx21 < 5; idx21++) {
    outC->Speed_Array[idx21] = kcg_lit_float32(0.0);
  }
  for (idx22 = 0; idx22 < 5; idx22++) {
    outC->Braking_force_Array[idx22] = kcg_lit_float32(0.0);
  }
  for (idx23 = 0; idx23 < 5; idx23++) {
    outC->Traction_force_Array[idx23] = kcg_lit_float32(0.0);
  }
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void TrainConfiguration0_reset_Math_Operators(
  outC_TrainConfiguration0_Math_Operators *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** TrainConfiguration0_Math_Operators.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

