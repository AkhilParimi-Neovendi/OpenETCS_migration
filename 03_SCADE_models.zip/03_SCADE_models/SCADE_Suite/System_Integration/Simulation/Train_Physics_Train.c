/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train_Physics_Train.h"

/* Train::Train_Physics/ */
void Train_Physics_Train(
  /* T_B_Lever/ */
  kcg_int8 T_B_Lever,
  /* HoldingBrakeSwitch/ */
  kcg_bool HoldingBrakeSwitch,
  /* TrainBrakeLever/ */
  kcg_int8 TrainBrakeLever,
  outC_Train_Physics_Train *outC)
{
  outC->_L32 = TrainBrakeLever;
  outC->_L31 = HoldingBrakeSwitch;
  outC->_L30 = T_B_Lever;
  /* _L23=(Train_with_TandB_Lever#4)/ */
  Train_with_TandB_Lever(
    outC->_L30,
    outC->_L31,
    outC->_L32,
    &outC->Context_Train_with_TandB_Lever_4);
  outC->_L23 = outC->Context_Train_with_TandB_Lever_4.Distance_Covered;
  outC->_L24 = outC->Context_Train_with_TandB_Lever_4.Current_TrainSpeed;
  outC->_L25 = outC->Context_Train_with_TandB_Lever_4.CurrentTrainAcceleration;
  outC->_L29.Distance_Covered = outC->_L23;
  outC->_L29.Train_Speed = outC->_L24;
  outC->_L29.Train_Acceleration = outC->_L25;
  kcg_copy_Tain_Physics_Outputs(&outC->Train_Outputs, &outC->_L29);
}

#ifndef KCG_USER_DEFINED_INIT
void Train_Physics_init_Train(outC_Train_Physics_Train *outC)
{
  outC->_L32 = kcg_lit_int8(0);
  outC->_L31 = kcg_true;
  outC->_L30 = kcg_lit_int8(0);
  outC->_L23 = kcg_lit_int16(0);
  outC->_L24 = kcg_lit_int16(0);
  outC->_L25 = kcg_lit_float32(0.0);
  outC->_L29.Distance_Covered = kcg_lit_int16(0);
  outC->_L29.Train_Speed = kcg_lit_int16(0);
  outC->_L29.Train_Acceleration = kcg_lit_float32(0.0);
  outC->Train_Outputs.Distance_Covered = kcg_lit_int16(0);
  outC->Train_Outputs.Train_Speed = kcg_lit_int16(0);
  outC->Train_Outputs.Train_Acceleration = kcg_lit_float32(0.0);
  /* _L23=(Train_with_TandB_Lever#4)/ */
  Train_with_TandB_Lever_init(&outC->Context_Train_with_TandB_Lever_4);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_Physics_reset_Train(outC_Train_Physics_Train *outC)
{
  /* _L23=(Train_with_TandB_Lever#4)/ */
  Train_with_TandB_Lever_reset(&outC->Context_Train_with_TandB_Lever_4);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train_Physics_Train.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

