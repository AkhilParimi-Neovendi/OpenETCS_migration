/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ETCS_TS.h"

/* ETCS_TS/ */
void ETCS_TS(/* from_RM/ */ kcg_bool from_RM, outC_ETCS_TS *outC)
{
  kcg_bool noname;

  outC->_L2 = kcg_false;
  outC->to_RM = outC->_L2;
  outC->_L1 = from_RM;
  noname = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void ETCS_TS_init(outC_ETCS_TS *outC)
{
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_RM = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ETCS_TS_reset(outC_ETCS_TS *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ETCS_TS.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

