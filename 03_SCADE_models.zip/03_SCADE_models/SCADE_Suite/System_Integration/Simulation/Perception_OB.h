/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Perception_OB_H_
#define _Perception_OB_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_Perception_TS/ */ to_Perception_TS;
  kcg_bool /* to_EmergencyBrakeIO/ */ to_EmergencyBrakeIO;
  kcg_bool /* to_FVA/ */ to_FVA;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L3/ */ _L3;
  kcg_bool /* _L4/ */ _L4;
} outC_Perception_OB;

/* ===========  node initialization and cycle functions  =========== */
/* Perception_OB/ */
extern void Perception_OB(
  /* from_Perception_TS/ */
  kcg_bool from_Perception_TS,
  /* from_EmergencyBrakeIO/ */
  kcg_bool from_EmergencyBrakeIO,
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_Perception_OB *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Perception_OB_reset(outC_Perception_OB *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Perception_OB_init(outC_Perception_OB *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Perception_OB_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Perception_OB.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

