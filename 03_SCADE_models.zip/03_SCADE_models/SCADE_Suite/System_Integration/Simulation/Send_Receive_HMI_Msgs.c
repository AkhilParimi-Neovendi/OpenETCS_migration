/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Send_Receive_HMI_Msgs.h"

/* Send_Receive_HMI_Msgs/ */
void Send_Receive_HMI_Msgs(
  /* Receive_HMI_Packet/ */
  ETCSHMIPacket *Receive_HMI_Packet,
  outC_Send_Receive_HMI_Msgs *outC)
{
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType to_HMI_Data_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool ATO_Data_Acknowledged_partial;
  /* ETCS_Data_Acknowledged/ */
  kcg_bool ETCS_Data_Acknowledged_partial;
  /* TrainDataAvailable/ */
  kcg_bool TrainDataAvailable_partial;
  /* MessageCondition/ */
  kcg_bool MessageCondition_partial;
  /* Msg/ */
  kcg_int8 Msg_partial;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType _1_to_HMI_Data_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool _2_ATO_Data_Acknowledged_partial;
  /* ETCS_Data_Acknowledged/ */
  kcg_bool _3_ETCS_Data_Acknowledged_partial;
  /* TrainDataAvailable/ */
  kcg_bool _4_TrainDataAvailable_partial;
  /* MessageCondition/ */
  kcg_bool _5_MessageCondition_partial;
  /* Msg/ */
  kcg_int8 _6_Msg_partial;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType _7_to_HMI_Data_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool _8_ATO_Data_Acknowledged_partial;
  /* MessageCondition/ */
  kcg_bool _9_MessageCondition_partial;
  /* Msg/ */
  kcg_int8 _10_Msg_partial;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType _11_to_HMI_Data_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool _12_ATO_Data_Acknowledged_partial;
  /* MessageCondition/ */
  kcg_bool _13_MessageCondition_partial;
  /* Msg/ */
  kcg_int8 _14_Msg_partial;
  /* Msg/ */
  kcg_int8 _15_Msg_partial;
  /* MessageCondition/ */
  kcg_bool _16_MessageCondition_partial;
  /* ETCS_Data_Acknowledged/ */
  kcg_bool _17_ETCS_Data_Acknowledged_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool _18_ATO_Data_Acknowledged_partial;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType _19_to_HMI_Data_partial;
  /* Msg/ */
  kcg_int8 _20_Msg_partial;
  /* MessageCondition/ */
  kcg_bool _21_MessageCondition_partial;
  /* ETCS_Data_Acknowledged/ */
  kcg_bool _22_ETCS_Data_Acknowledged_partial;
  /* ATO_Data_Acknowledged/ */
  kcg_bool _23_ATO_Data_Acknowledged_partial;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType _24_to_HMI_Data_partial;
  ETCS_modes noname;
  ATO_modes _25_noname;
  ETCSHMIPacketDataType _26_noname;
  ETCS_modes _27_noname;
  ATO_modes _28_noname;
  /* MessageCondition/ */
  kcg_bool last_MessageCondition;
  /* TrainDataAvailable/ */
  kcg_bool last_TrainDataAvailable;
  /* ETCS_Data_Acknowledged/ */
  kcg_bool last_ETCS_Data_Acknowledged;
  /* ATO_Data_Acknowledged/ */
  kcg_bool last_ATO_Data_Acknowledged;
  /* TrainData_from_HMI/ */
  ETCSHMIPacketDataType last_TrainData_from_HMI;
  /* to_HMI_Data/ */
  ETCSHMIPacketDataType last_to_HMI_Data;

  last_MessageCondition = outC->MessageCondition;
  last_TrainDataAvailable = outC->TrainDataAvailable;
  last_ETCS_Data_Acknowledged = outC->ETCS_Data_Acknowledged;
  last_ATO_Data_Acknowledged = outC->ATO_Data_Acknowledged;
  kcg_copy_ETCSHMIPacketDataType(
    &last_TrainData_from_HMI,
    &outC->TrainData_from_HMI);
  kcg_copy_ETCSHMIPacketDataType(&last_to_HMI_Data, &outC->to_HMI_Data);
  outC->IfBlock1_clock = !last_TrainDataAvailable;
  if (outC->IfBlock1_clock) {
  }
  else {
    outC->else_clock_IfBlock1 = !last_ETCS_Data_Acknowledged;
    if (outC->else_clock_IfBlock1) {
    }
    else {
      outC->else_clock_else_IfBlock1 = !last_ATO_Data_Acknowledged;
      if (outC->else_clock_else_IfBlock1) {
      }
      else {
        _12_ATO_Data_Acknowledged_partial = last_ATO_Data_Acknowledged;
      }
    }
  }
  outC->_L20 = kcg_lit_int8(2);
  outC->_L21 = kcg_lit_int8(4);
  outC->_L22 = kcg_lit_int8(6);
  outC->_L18 = kcg_lit_int8(0);
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    outC->_L4_then_IfBlock1 = kcg_lit_int8(1);
    Msg_partial = outC->_L4_then_IfBlock1;
    outC->Msg = Msg_partial;
  }
  else {
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      outC->_L3_then_else_IfBlock1 = kcg_lit_int8(3);
      _20_Msg_partial = outC->_L3_then_else_IfBlock1;
      _6_Msg_partial = _20_Msg_partial;
    }
    else {
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L4_then_else_else_IfBlock1 = kcg_lit_int8(5);
        _10_Msg_partial = outC->_L4_then_else_else_IfBlock1;
        _15_Msg_partial = _10_Msg_partial;
      }
      else {
        outC->_L19_else_else_else_IfBlock1 = kcg_lit_int8(0);
        _14_Msg_partial = outC->_L19_else_else_else_IfBlock1;
        _15_Msg_partial = _14_Msg_partial;
      }
      _6_Msg_partial = _15_Msg_partial;
    }
    outC->Msg = _6_Msg_partial;
  }
  outC->_L62 = outC->Msg;
  /* _L17= */
  switch (outC->_L62) {
    case kcg_lit_int8(1) :
      outC->_L17 = outC->_L20;
      break;
    case kcg_lit_int8(3) :
      outC->_L17 = outC->_L21;
      break;
    case kcg_lit_int8(5) :
      outC->_L17 = outC->_L22;
      break;
    default :
      outC->_L17 = outC->_L18;
      break;
  }
  outC->_L12 = kcg_lit_int8(0);
  kcg_copy_ETCSHMIPacket(&outC->_L25, Receive_HMI_Packet);
  outC->_L9 = outC->_L25.Message;
  outC->_L8 = outC->_L25.Header;
  outC->_L14 = kcg_lit_int8(2);
  outC->_L11 = outC->_L14 == outC->_L8;
  outC->_L31 = outC->_L25.isvalid;
  outC->_L33 = outC->_L31 & outC->_L11;
  /* _L10= */
  if (outC->_L33) {
    outC->_L10 = outC->_L9;
  }
  else {
    outC->_L10 = outC->_L12;
  }
  outC->_L15 = outC->_L10 == outC->_L17;
  outC->_L64 = last_MessageCondition;
  outC->_L16 = outC->_L64 | outC->_L15;
  outC->UpdatedMsgCondition = outC->_L16;
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    ATO_Data_Acknowledged_partial = last_ATO_Data_Acknowledged;
    outC->ATO_Data_Acknowledged = ATO_Data_Acknowledged_partial;
  }
  else {
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      _23_ATO_Data_Acknowledged_partial = last_ATO_Data_Acknowledged;
      _2_ATO_Data_Acknowledged_partial = _23_ATO_Data_Acknowledged_partial;
    }
    else {
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L6_then_else_else_IfBlock1 = outC->UpdatedMsgCondition;
        _8_ATO_Data_Acknowledged_partial = outC->_L6_then_else_else_IfBlock1;
        _18_ATO_Data_Acknowledged_partial = _8_ATO_Data_Acknowledged_partial;
      }
      else {
        _18_ATO_Data_Acknowledged_partial = _12_ATO_Data_Acknowledged_partial;
      }
      _2_ATO_Data_Acknowledged_partial = _18_ATO_Data_Acknowledged_partial;
    }
    outC->ATO_Data_Acknowledged = _2_ATO_Data_Acknowledged_partial;
  }
  outC->_L77 = outC->ATO_Data_Acknowledged;
  outC->to_ATO_TBD = outC->_L77;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L71, &last_to_HMI_Data);
  kcg_copy_ETCSHMIPacketDataType(&outC->_L76, &last_TrainData_from_HMI);
  kcg_copy_ETCSHMIPacket(&outC->_L34, Receive_HMI_Packet);
  kcg_copy_ETCSHMIPacketDataType(&outC->_L35, &outC->_L34.ETCSHMIPacketData);
  outC->_L45 = kcg_lit_int8(2);
  outC->_L38 = outC->_L34.Message;
  outC->_L44 = outC->_L38 == outC->_L45;
  outC->_L42 = kcg_lit_int8(2);
  outC->_L39 = outC->_L34.Header;
  outC->_L41 = outC->_L39 == outC->_L42;
  outC->_L40 = outC->_L34.isvalid;
  outC->_L43 = outC->_L40 & outC->_L41 & outC->_L44;
  /* _L46= */
  if (outC->_L43) {
    kcg_copy_ETCSHMIPacketDataType(&outC->_L46, &outC->_L35);
  }
  else {
    kcg_copy_ETCSHMIPacketDataType(&outC->_L46, &outC->_L76);
  }
  kcg_copy_ETCSHMIPacketDataType(&outC->TrainData_from_HMI, &outC->_L46);
  outC->_L73 = outC->Msg;
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    outC->_L2_then_IfBlock1 = last_TrainDataAvailable;
    MessageCondition_partial = outC->_L2_then_IfBlock1;
    outC->MessageCondition = MessageCondition_partial;
  }
  else {
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      outC->_L1_then_else_IfBlock1 = last_ETCS_Data_Acknowledged;
      _21_MessageCondition_partial = outC->_L1_then_else_IfBlock1;
      _5_MessageCondition_partial = _21_MessageCondition_partial;
    }
    else {
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L1_then_else_else_IfBlock1 = last_ATO_Data_Acknowledged;
        _9_MessageCondition_partial = outC->_L1_then_else_else_IfBlock1;
        _16_MessageCondition_partial = _9_MessageCondition_partial;
      }
      else {
        outC->_L16_else_else_else_IfBlock1 = kcg_true;
        _13_MessageCondition_partial = outC->_L16_else_else_else_IfBlock1;
        _16_MessageCondition_partial = _13_MessageCondition_partial;
      }
      _5_MessageCondition_partial = _16_MessageCondition_partial;
    }
    outC->MessageCondition = _5_MessageCondition_partial;
  }
  outC->_L72 = outC->MessageCondition;
  outC->_L70 = kcg_true;
  outC->_L69 = kcg_lit_int8(0);
  outC->_L68 = kcg_lit_int8(0);
  outC->_L67 = kcg_lit_int8(1);
  /* _L65= */
  if (outC->_L72) {
    outC->_L65 = outC->_L68;
  }
  else {
    outC->_L65 = outC->_L73;
  }
  outC->_L66.isvalid = outC->_L70;
  outC->_L66.Header = outC->_L67;
  outC->_L66.Message = outC->_L65;
  outC->_L66.currentETCSmode = outC->_L69;
  outC->_L66.currentATOmode = outC->_L69;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L66.ETCSHMIPacketData, &outC->_L71);
  kcg_copy_ETCSHMIPacket(&outC->Send_HMI_Packet, &outC->_L66);
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    ETCS_Data_Acknowledged_partial = last_ETCS_Data_Acknowledged;
    kcg_copy_ETCSHMIPacketDataType(&to_HMI_Data_partial, &last_to_HMI_Data);
    outC->_L7_then_IfBlock1 = outC->UpdatedMsgCondition;
    TrainDataAvailable_partial = outC->_L7_then_IfBlock1;
    kcg_copy_ETCSHMIPacketDataType(&outC->to_HMI_Data, &to_HMI_Data_partial);
    outC->ETCS_Data_Acknowledged = ETCS_Data_Acknowledged_partial;
    outC->TrainDataAvailable = TrainDataAvailable_partial;
  }
  else {
    _4_TrainDataAvailable_partial = last_TrainDataAvailable;
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      kcg_copy_ETCSHMIPacketDataType(
        &outC->_L7_then_else_IfBlock1,
        &last_TrainData_from_HMI);
      kcg_copy_ETCSHMIPacketDataType(
        &_24_to_HMI_Data_partial,
        &outC->_L7_then_else_IfBlock1);
      outC->_L6_then_else_IfBlock1 = outC->UpdatedMsgCondition;
      _22_ETCS_Data_Acknowledged_partial = outC->_L6_then_else_IfBlock1;
      kcg_copy_ETCSHMIPacketDataType(
        &_1_to_HMI_Data_partial,
        &_24_to_HMI_Data_partial);
      _3_ETCS_Data_Acknowledged_partial = _22_ETCS_Data_Acknowledged_partial;
    }
    else {
      _17_ETCS_Data_Acknowledged_partial = last_ETCS_Data_Acknowledged;
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        kcg_copy_ETCSHMIPacketDataType(
          &outC->_L7_then_else_else_IfBlock1,
          &outC->TrainData_from_HMI);
        kcg_copy_ETCSHMIPacketDataType(
          &_7_to_HMI_Data_partial,
          &outC->_L7_then_else_else_IfBlock1);
        kcg_copy_ETCSHMIPacketDataType(
          &_19_to_HMI_Data_partial,
          &_7_to_HMI_Data_partial);
      }
      else {
        kcg_copy_ETCSHMIPacketDataType(&_11_to_HMI_Data_partial, &last_to_HMI_Data);
        kcg_copy_ETCSHMIPacketDataType(
          &_19_to_HMI_Data_partial,
          &_11_to_HMI_Data_partial);
      }
      kcg_copy_ETCSHMIPacketDataType(
        &_1_to_HMI_Data_partial,
        &_19_to_HMI_Data_partial);
      _3_ETCS_Data_Acknowledged_partial = _17_ETCS_Data_Acknowledged_partial;
    }
    kcg_copy_ETCSHMIPacketDataType(&outC->to_HMI_Data, &_1_to_HMI_Data_partial);
    outC->ETCS_Data_Acknowledged = _3_ETCS_Data_Acknowledged_partial;
    outC->TrainDataAvailable = _4_TrainDataAvailable_partial;
  }
  outC->_L36 = outC->_L34.currentATOmode;
  _28_noname = outC->_L36;
  outC->_L37 = outC->_L34.currentETCSmode;
  _27_noname = outC->_L37;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L32, &outC->_L25.ETCSHMIPacketData);
  kcg_copy_ETCSHMIPacketDataType(&_26_noname, &outC->_L32);
  outC->_L27 = outC->_L25.currentATOmode;
  _25_noname = outC->_L27;
  outC->_L26 = outC->_L25.currentETCSmode;
  noname = outC->_L26;
}

#ifndef KCG_USER_DEFINED_INIT
void Send_Receive_HMI_Msgs_init(outC_Send_Receive_HMI_Msgs *outC)
{
  outC->_L77 = kcg_true;
  outC->_L71.label1 = kcg_lit_int8(0);
  outC->_L71.label2 = kcg_lit_int8(0);
  outC->_L71.label3 = kcg_lit_int8(0);
  outC->_L71.label4 = kcg_lit_int8(0);
  outC->_L71.label5 = kcg_lit_int8(0);
  outC->_L71.label6 = kcg_lit_int8(0);
  outC->_L71.label7 = kcg_lit_int16(0);
  outC->_L71.label8 = kcg_lit_int16(0);
  outC->_L76.label1 = kcg_lit_int8(0);
  outC->_L76.label2 = kcg_lit_int8(0);
  outC->_L76.label3 = kcg_lit_int8(0);
  outC->_L76.label4 = kcg_lit_int8(0);
  outC->_L76.label5 = kcg_lit_int8(0);
  outC->_L76.label6 = kcg_lit_int8(0);
  outC->_L76.label7 = kcg_lit_int16(0);
  outC->_L76.label8 = kcg_lit_int16(0);
  outC->_L65 = kcg_lit_int8(0);
  outC->_L66.isvalid = kcg_true;
  outC->_L66.Header = kcg_lit_int8(0);
  outC->_L66.Message = kcg_lit_int8(0);
  outC->_L66.currentETCSmode = kcg_lit_int8(0);
  outC->_L66.currentATOmode = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L66.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L66.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L67 = kcg_lit_int8(0);
  outC->_L68 = kcg_lit_int8(0);
  outC->_L69 = kcg_lit_int8(0);
  outC->_L70 = kcg_true;
  outC->_L72 = kcg_true;
  outC->_L73 = kcg_lit_int8(0);
  outC->_L64 = kcg_true;
  outC->_L62 = kcg_lit_int8(0);
  outC->_L46.label1 = kcg_lit_int8(0);
  outC->_L46.label2 = kcg_lit_int8(0);
  outC->_L46.label3 = kcg_lit_int8(0);
  outC->_L46.label4 = kcg_lit_int8(0);
  outC->_L46.label5 = kcg_lit_int8(0);
  outC->_L46.label6 = kcg_lit_int8(0);
  outC->_L46.label7 = kcg_lit_int16(0);
  outC->_L46.label8 = kcg_lit_int16(0);
  outC->_L45 = kcg_lit_int8(0);
  outC->_L44 = kcg_true;
  outC->_L43 = kcg_true;
  outC->_L42 = kcg_lit_int8(0);
  outC->_L41 = kcg_true;
  outC->_L35.label1 = kcg_lit_int8(0);
  outC->_L35.label2 = kcg_lit_int8(0);
  outC->_L35.label3 = kcg_lit_int8(0);
  outC->_L35.label4 = kcg_lit_int8(0);
  outC->_L35.label5 = kcg_lit_int8(0);
  outC->_L35.label6 = kcg_lit_int8(0);
  outC->_L35.label7 = kcg_lit_int16(0);
  outC->_L35.label8 = kcg_lit_int16(0);
  outC->_L36 = kcg_lit_int8(0);
  outC->_L37 = kcg_lit_int8(0);
  outC->_L38 = kcg_lit_int8(0);
  outC->_L39 = kcg_lit_int8(0);
  outC->_L40 = kcg_true;
  outC->_L34.isvalid = kcg_true;
  outC->_L34.Header = kcg_lit_int8(0);
  outC->_L34.Message = kcg_lit_int8(0);
  outC->_L34.currentETCSmode = kcg_lit_int8(0);
  outC->_L34.currentATOmode = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L34.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L34.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L33 = kcg_true;
  outC->_L31 = kcg_true;
  outC->_L32.label1 = kcg_lit_int8(0);
  outC->_L32.label2 = kcg_lit_int8(0);
  outC->_L32.label3 = kcg_lit_int8(0);
  outC->_L32.label4 = kcg_lit_int8(0);
  outC->_L32.label5 = kcg_lit_int8(0);
  outC->_L32.label6 = kcg_lit_int8(0);
  outC->_L32.label7 = kcg_lit_int16(0);
  outC->_L32.label8 = kcg_lit_int16(0);
  outC->_L26 = kcg_lit_int8(0);
  outC->_L27 = kcg_lit_int8(0);
  outC->_L25.isvalid = kcg_true;
  outC->_L25.Header = kcg_lit_int8(0);
  outC->_L25.Message = kcg_lit_int8(0);
  outC->_L25.currentETCSmode = kcg_lit_int8(0);
  outC->_L25.currentATOmode = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L25.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L25.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L22 = kcg_lit_int8(0);
  outC->_L21 = kcg_lit_int8(0);
  outC->_L20 = kcg_lit_int8(0);
  outC->_L18 = kcg_lit_int8(0);
  outC->_L17 = kcg_lit_int8(0);
  outC->_L9 = kcg_lit_int8(0);
  outC->_L8 = kcg_lit_int8(0);
  outC->_L10 = kcg_lit_int8(0);
  outC->_L11 = kcg_true;
  outC->_L12 = kcg_lit_int8(0);
  outC->_L14 = kcg_lit_int8(0);
  outC->_L15 = kcg_true;
  outC->_L16 = kcg_true;
  outC->Msg = kcg_lit_int8(0);
  outC->UpdatedMsgCondition = kcg_true;
  outC->IfBlock1_clock = kcg_true;
  outC->_L7_then_else_IfBlock1.label1 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label2 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label3 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label4 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label5 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label6 = kcg_lit_int8(0);
  outC->_L7_then_else_IfBlock1.label7 = kcg_lit_int16(0);
  outC->_L7_then_else_IfBlock1.label8 = kcg_lit_int16(0);
  outC->_L6_then_else_IfBlock1 = kcg_true;
  outC->_L1_then_else_IfBlock1 = kcg_true;
  outC->_L3_then_else_IfBlock1 = kcg_lit_int8(0);
  outC->else_clock_else_IfBlock1 = kcg_true;
  outC->_L16_else_else_else_IfBlock1 = kcg_true;
  outC->_L19_else_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L4_then_else_else_IfBlock1 = kcg_lit_int8(0);
  outC->_L1_then_else_else_IfBlock1 = kcg_true;
  outC->_L6_then_else_else_IfBlock1 = kcg_true;
  outC->_L7_then_else_else_IfBlock1.label1 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label2 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label3 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label4 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label5 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label6 = kcg_lit_int8(0);
  outC->_L7_then_else_else_IfBlock1.label7 = kcg_lit_int16(0);
  outC->_L7_then_else_else_IfBlock1.label8 = kcg_lit_int16(0);
  outC->else_clock_IfBlock1 = kcg_true;
  outC->_L4_then_IfBlock1 = kcg_lit_int8(0);
  outC->_L2_then_IfBlock1 = kcg_true;
  outC->_L7_then_IfBlock1 = kcg_true;
  outC->to_ATO_TBD = kcg_true;
  outC->Send_HMI_Packet.isvalid = kcg_true;
  outC->Send_HMI_Packet.Header = kcg_lit_int8(0);
  outC->Send_HMI_Packet.Message = kcg_lit_int8(0);
  outC->Send_HMI_Packet.currentETCSmode = kcg_lit_int8(0);
  outC->Send_HMI_Packet.currentATOmode = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->Send_HMI_Packet.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->to_HMI_Data,
    (ETCSHMIPacketDataType *) &ETCSHMIpacketdatainit);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->TrainData_from_HMI,
    (ETCSHMIPacketDataType *) &ETCSHMIpacketdatainit);
  outC->ATO_Data_Acknowledged = boolinit;
  outC->ETCS_Data_Acknowledged = boolinit;
  outC->TrainDataAvailable = boolinit;
  outC->MessageCondition = boolinit;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Send_Receive_HMI_Msgs_reset(outC_Send_Receive_HMI_Msgs *outC)
{
  kcg_copy_ETCSHMIPacketDataType(
    &outC->to_HMI_Data,
    (ETCSHMIPacketDataType *) &ETCSHMIpacketdatainit);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->TrainData_from_HMI,
    (ETCSHMIPacketDataType *) &ETCSHMIpacketdatainit);
  outC->ATO_Data_Acknowledged = boolinit;
  outC->ETCS_Data_Acknowledged = boolinit;
  outC->TrainDataAvailable = boolinit;
  outC->MessageCondition = boolinit;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Send_Receive_HMI_Msgs.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

