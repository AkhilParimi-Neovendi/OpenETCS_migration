/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Functional_Vehicle_Adapter_H_
#define _Functional_Vehicle_Adapter_H_

#include "kcg_types.h"
#include "ExternalStatusIndicator_Internal_functions.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_Perception_OB/ */ to_Perception_OB;
  ExternalindicatorStates /* to_Train_Driver/ */ to_Train_Driver;
  kcg_bool /* to_ETCS_OB/ */ to_ETCS_OB;
  kcg_bool /* to_Driving_Style_Engine/ */ to_Driving_Style_Engine;
  kcg_bool /* to_OpenIO_interface/ */ to_OpenIO_interface;
  kcg_bool /* to_Vehicle_Management_System/ */ to_Vehicle_Management_System;
  kcg_bool /* to_Diagnostic_Platform/ */ to_Diagnostic_Platform;
  kcg_bool /* to_Open_Vehicle_Bus/ */ to_Open_Vehicle_Bus;
  kcg_bool /* to_RSC_OB_int2/ */ to_RSC_OB_int2;
  kcg_bool /* to_RSC_OB_ss139/ */ to_RSC_OB_ss139;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  SSM_ST_OverrideSwitch_SM /* OverrideSwitch_SM: */ OverrideSwitch_SM_state_nxt;
  kcg_bool /* OverrideSwitch_SM: */ OverrideSwitch_SM_reset_act;
  kcg_bool /* OverrideSwitch_SM: */ OverrideSwitch_SM_reset_nxt;
  kcg_int8 /* ExternalIndicatorState/ */ ExternalIndicatorState;
  kcg_bool /* OverrideSwitchState/ */ OverrideSwitchState;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_ExternalStatusIndicator_Internal_functions /* _L19=(Internal_functions::ExternalStatusIndicator#1)/ */ Context_ExternalStatusIndicator_1;
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* OverrideSwitch_SM:Manual_Mode:<1> */ tr_1_clock_Manual_Mode_OverrideSwitch_SM;
  kcg_bool /* OverrideSwitch_SM:Manual_Mode:<2> */ tr_2_clock_Manual_Mode_OverrideSwitch_SM;
  kcg_bool /* OverrideSwitch_SM:ATO_Mode:<1> */ tr_1_clock_ATO_Mode_OverrideSwitch_SM;
  kcg_bool /* OverrideSwitch_SM:ATO_Mode:<2> */ tr_2_clock_ATO_Mode_OverrideSwitch_SM;
  kcg_bool /* OverrideSwitch_SM:RSC_Mode:<1> */ tr_1_clock_RSC_Mode_OverrideSwitch_SM;
  kcg_bool /* OverrideSwitch_SM:RSC_Mode:<2> */ tr_2_clock_RSC_Mode_OverrideSwitch_SM;
  SSM_ST_OverrideSwitch_SM /* OverrideSwitch_SM: */ OverrideSwitch_SM_state_sel;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  SSM_ST_OverrideSwitch_SM /* OverrideSwitch_SM: */ OverrideSwitch_SM_state_act;
  SSM_TR_OverrideSwitch_SM /* OverrideSwitch_SM: */ OverrideSwitch_SM_fired_strong;
  SSM_TR_OverrideSwitch_SM /* OverrideSwitch_SM: */ OverrideSwitch_SM_fired;
  kcg_int8 /* ATORSCSwitchState/ */ ATORSCSwitchState;
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L6/ */ _L6;
  kcg_bool /* _L7/ */ _L7;
  kcg_bool /* _L8/ */ _L8;
  kcg_bool /* _L9/ */ _L9;
  kcg_bool /* _L10/ */ _L10;
  kcg_bool /* _L11/ */ _L11;
  FVAHMIPacket /* _L12/ */ _L12;
  ExternalindicatorStates /* _L19/ */ _L19;
  kcg_int8 /* _L21/ */ _L21;
  Override_Switch_State /* _L23/ */ _L23;
  ATORSCSwitchPosition /* _L22/ */ _L22;
  kcg_bool /* _L26/ */ _L26;
  kcg_bool /* _L27/ */ _L27;
} outC_Functional_Vehicle_Adapter;

/* ===========  node initialization and cycle functions  =========== */
/* Functional_Vehicle_Adapter/ */
extern void Functional_Vehicle_Adapter(
  /* from_Perception_OB/ */
  kcg_bool from_Perception_OB,
  /* from_Train_Driver/ */
  FVAHMIPacket *from_Train_Driver,
  /* from_OpenIO_interface/ */
  kcg_bool from_OpenIO_interface,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_Driving_Style_Engine/ */
  kcg_bool from_Driving_Style_Engine,
  /* from_Vehicle_Management_System/ */
  kcg_bool from_Vehicle_Management_System,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_Open_Vehicle_Bus/ */
  kcg_bool from_Open_Vehicle_Bus,
  /* from_RSC_OB_int2/ */
  kcg_bool from_RSC_OB_int2,
  /* from_RSC_OB_ss139/ */
  kcg_bool from_RSC_OB_ss139,
  outC_Functional_Vehicle_Adapter *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Functional_Vehicle_Adapter_reset(
  outC_Functional_Vehicle_Adapter *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Functional_Vehicle_Adapter_init(
  outC_Functional_Vehicle_Adapter *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Functional_Vehicle_Adapter_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Functional_Vehicle_Adapter.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

