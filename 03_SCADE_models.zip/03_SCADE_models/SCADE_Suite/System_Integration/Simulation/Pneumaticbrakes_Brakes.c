/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Pneumaticbrakes_Brakes.h"

/* Brakes::Pneumaticbrakes/ */
void Pneumaticbrakes_Brakes(
  /* BrakePipePressure/ */
  kcg_float32 BrakePipePressure,
  /* Mass/ */
  kcg_int32 Mass,
  outC_Pneumaticbrakes_Brakes *outC)
{
  outC->_L17 = Mass;
  outC->Input1_NumericToFloat32_2_int32 = outC->_L17;
  outC->_L1_NumericToFloat32_2_int32 = outC->Input1_NumericToFloat32_2_int32;
  outC->_L2_NumericToFloat32_2_int32 = /* @1/_L2= */(kcg_float32)
      outC->_L1_NumericToFloat32_2_int32;
  outC->Output1_NumericToFloat32_2_int32 = outC->_L2_NumericToFloat32_2_int32;
  outC->_L1 = BrakePipePressure;
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = outC->_L1 <= outC->_L3;
  /* _L4= */
  if (outC->_L2) {
    outC->_L4 = outC->_L3;
  }
  else {
    outC->_L4 = outC->_L1;
  }
  outC->_L6 = kcg_lit_float32(5.0);
  outC->_L5 = outC->_L1 >= outC->_L6;
  /* _L7= */
  if (outC->_L5) {
    outC->_L7 = outC->_L6;
  }
  else {
    outC->_L7 = outC->_L4;
  }
  outC->Brakepressure = outC->_L7;
  outC->_L19 = outC->Brakepressure;
  outC->_L18 = outC->Output1_NumericToFloat32_2_int32;
  outC->_L16 = kcg_lit_float32(1.0) - BWP;
  outC->_L15 = Mue_S * g;
  outC->_L12 = kcg_lit_float32(0.667);
  outC->_L9 = kcg_lit_float32(5.0);
  outC->_L8 = outC->_L9 - outC->_L19;
  outC->_L11 = outC->_L8 * outC->_L12 * outC->_L18 * outC->_L15 * outC->_L16;
  outC->AppliedPneumaticBrakingforce = outC->_L11;
}

#ifndef KCG_USER_DEFINED_INIT
void Pneumaticbrakes_init_Brakes(outC_Pneumaticbrakes_Brakes *outC)
{
  outC->_L19 = kcg_lit_float32(0.0);
  outC->_L18 = kcg_lit_float32(0.0);
  outC->_L17 = kcg_lit_int32(0);
  outC->_L16 = kcg_lit_float32(0.0);
  outC->_L15 = kcg_lit_float32(0.0);
  outC->_L12 = kcg_lit_float32(0.0);
  outC->_L11 = kcg_lit_float32(0.0);
  outC->_L9 = kcg_lit_float32(0.0);
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L6 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_lit_float32(0.0);
  outC->Brakepressure = kcg_lit_float32(0.0);
  outC->_L1_NumericToFloat32_2_int32 = kcg_lit_int32(0);
  outC->_L2_NumericToFloat32_2_int32 = kcg_lit_float32(0.0);
  outC->Input1_NumericToFloat32_2_int32 = kcg_lit_int32(0);
  outC->Output1_NumericToFloat32_2_int32 = kcg_lit_float32(0.0);
  outC->AppliedPneumaticBrakingforce = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Pneumaticbrakes_reset_Brakes(outC_Pneumaticbrakes_Brakes *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: Brakes::Pneumaticbrakes/
  @1: (math::NumericToFloat32#2)
*/

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Pneumaticbrakes_Brakes.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

