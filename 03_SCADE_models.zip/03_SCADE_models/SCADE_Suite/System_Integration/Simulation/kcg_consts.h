/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _KCG_CONSTS_H_
#define _KCG_CONSTS_H_

#include "kcg_types.h"

/* Max_Traction_and_Braking/ */
#define Max_Traction_and_Braking (kcg_lit_float32(1000000.))

/* force_gradient/ */
#define force_gradient (kcg_lit_float32(50000.))

/* BWP/ */
#define BWP (kcg_lit_float32(0.0))

/* Mue_S/ */
#define Mue_S (kcg_lit_float32(0.3))

/* Mue_k/ */
#define Mue_k (kcg_lit_float32(0.0))

/* Theta/ */
#define Theta (kcg_lit_float32(0.0))

/* g/ */
#define g (kcg_lit_float32(9.81))

/* A/ */
#define A (kcg_lit_float32(0.0))

/* rho/ */
#define rho (kcg_lit_float32(0.0))

/* C_d/ */
#define C_d (kcg_lit_float32(0.0))

/* kmph2mps/ */
#define kmph2mps (kcg_lit_float32(5.) / kcg_lit_float32(18.))

/* MASS/ */
#define MASS                                                                  \
  (kcg_lit_int32(50000) * kcg_lit_int32(4) + kcg_lit_int32(80000) *           \
    kcg_lit_int32(1))

/* M_L/ */
#define M_L (kcg_lit_int32(80000))

/* M_C/ */
#define M_C (kcg_lit_int32(50000))

/* mps2kmph/ */
#define mps2kmph (kcg_lit_float32(18.) / kcg_lit_float32(5.))

/* TCYCLE/ */
#define TCYCLE (kcg_lit_float32(0.1))

/* N_L/ */
#define N_L (kcg_lit_int32(1))

/* N_C/ */
#define N_C (kcg_lit_int32(4))

/* Default_trainbrake/ */
#define Default_trainbrake (kcg_lit_float32(5.0))

/* ETCS_HMI_Msg_init/ */
#define ETCS_HMI_Msg_init (kcg_lit_int8(0))

/* ETCSHMIpacketdatainit/ */
extern const ETCSHMIPacketDataType ETCSHMIpacketdatainit;

/* int8init/ */
#define int8init (kcg_lit_int8(0))

/* FVA_HMI_packetinit/ */
extern const FVAHMIPacket FVA_HMI_packetinit;

/* SwitchStateinit/ */
extern const ExternalindicatorStates SwitchStateinit;

/* ETCS_HMI_Packetinit/ */
extern const ETCSHMIPacket ETCS_HMI_Packetinit;

/* ATO_Packetinit/ */
extern const ATO_Packet ATO_Packetinit;

/* ETCSATOPacketinit/ */
extern const ETCSATOPacket ETCSATOPacketinit;

/* boolinit/ */
#define boolinit kcg_false

#endif /* _KCG_CONSTS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_consts.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

