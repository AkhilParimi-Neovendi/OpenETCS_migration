const char*  pszDllPathname = "System_Integration.dll";
const char*  pszLauncherPathname = "C:/Program Files/ANSYS Inc/v222/SCADE/SCADE/bin/SCSSMLNC.exe";
