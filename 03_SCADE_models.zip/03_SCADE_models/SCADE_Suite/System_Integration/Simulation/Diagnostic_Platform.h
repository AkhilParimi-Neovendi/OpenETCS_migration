/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Diagnostic_Platform_H_
#define _Diagnostic_Platform_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_RM/ */ to_RM;
  kcg_bool /* to_ATO_OB/ */ to_ATO_OB;
  kcg_bool /* to_RSC_OB/ */ to_RSC_OB;
  kcg_bool /* to_FVA/ */ to_FVA;
  kcg_bool /* to_ETCS_OB/ */ to_ETCS_OB;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L6/ */ _L6;
  kcg_bool /* _L7/ */ _L7;
} outC_Diagnostic_Platform;

/* ===========  node initialization and cycle functions  =========== */
/* Diagnostic_Platform/ */
extern void Diagnostic_Platform(
  /* from_RM/ */
  kcg_bool from_RM,
  /* from_ATO_OB/ */
  kcg_bool from_ATO_OB,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  /* from_FVA/ */
  kcg_bool from_FVA,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  outC_Diagnostic_Platform *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Diagnostic_Platform_reset(outC_Diagnostic_Platform *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Diagnostic_Platform_init(outC_Diagnostic_Platform *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Diagnostic_Platform_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Diagnostic_Platform.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

