/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Send_GoA4_Selected_ETCSHMI_Functions.h"

/* ETCSHMI_Functions::Send_GoA4_Selected/ */
void Send_GoA4_Selected_ETCSHMI_Functions(
  /* GoA4_Mode_button_Pressed/ */
  kcg_bool GoA4_Mode_button_Pressed,
  outC_Send_GoA4_Selected_ETCSHMI_Functions *outC)
{
  outC->_L8 = GoA4_Mode_button_Pressed;
  outC->_L7 = kcg_lit_int8(0);
  outC->_L5 = kcg_lit_int8(0);
  outC->_L1 = ETCS_HMI_Msg_init;
  outC->_L4 = kcg_lit_int8(2);
  kcg_copy_ETCSHMIPacketDataType(
    &outC->_L3,
    (ETCSHMIPacketDataType *) &ETCSHMIpacketdatainit);
  outC->_L6.isvalid = outC->_L8;
  outC->_L6.Header = outC->_L5;
  outC->_L6.Message = outC->_L1;
  outC->_L6.currentETCSmode = outC->_L7;
  outC->_L6.currentATOmode = outC->_L4;
  kcg_copy_ETCSHMIPacketDataType(&outC->_L6.ETCSHMIPacketData, &outC->_L3);
  kcg_copy_ETCSHMIPacket(&outC->Out_ETCS_Packet, &outC->_L6);
}

#ifndef KCG_USER_DEFINED_INIT
void Send_GoA4_Selected_init_ETCSHMI_Functions(
  outC_Send_GoA4_Selected_ETCSHMI_Functions *outC)
{
  outC->_L8 = kcg_true;
  outC->_L7 = kcg_lit_int8(0);
  outC->_L6.isvalid = kcg_true;
  outC->_L6.Header = kcg_lit_int8(0);
  outC->_L6.Message = kcg_lit_int8(0);
  outC->_L6.currentETCSmode = kcg_lit_int8(0);
  outC->_L6.currentATOmode = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L6.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L6.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->_L5 = kcg_lit_int8(0);
  outC->_L4 = kcg_lit_int8(0);
  outC->_L3.label1 = kcg_lit_int8(0);
  outC->_L3.label2 = kcg_lit_int8(0);
  outC->_L3.label3 = kcg_lit_int8(0);
  outC->_L3.label4 = kcg_lit_int8(0);
  outC->_L3.label5 = kcg_lit_int8(0);
  outC->_L3.label6 = kcg_lit_int8(0);
  outC->_L3.label7 = kcg_lit_int16(0);
  outC->_L3.label8 = kcg_lit_int16(0);
  outC->_L1 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.isvalid = kcg_true;
  outC->Out_ETCS_Packet.Header = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.Message = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.currentETCSmode = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.currentATOmode = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->Out_ETCS_Packet.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Send_GoA4_Selected_reset_ETCSHMI_Functions(
  outC_Send_GoA4_Selected_ETCSHMI_Functions *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Send_GoA4_Selected_ETCSHMI_Functions.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

