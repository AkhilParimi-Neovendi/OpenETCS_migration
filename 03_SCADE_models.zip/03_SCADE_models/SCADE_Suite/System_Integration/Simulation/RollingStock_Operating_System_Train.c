/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "RollingStock_Operating_System_Train.h"

/* Train::RollingStock_Operating_System/ */
void RollingStock_Operating_System_Train(
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_RollingStock_Operating_System_Train *outC)
{
  kcg_bool noname;

  outC->_L1 = from_FVA;
  noname = outC->_L1;
  outC->_L2 = kcg_false;
  outC->to_FVA = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void RollingStock_Operating_System_init_Train(
  outC_RollingStock_Operating_System_Train *outC)
{
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_FVA = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void RollingStock_Operating_System_reset_Train(
  outC_RollingStock_Operating_System_Train *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RollingStock_Operating_System_Train.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

