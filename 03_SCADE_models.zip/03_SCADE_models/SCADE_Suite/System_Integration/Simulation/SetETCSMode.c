/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "SetETCSMode.h"

/* SetETCSMode/ */
void SetETCSMode(/* Input/ */ ETCSHMIPacket *Input, outC_SetETCSMode *outC)
{
  ETCS_HMI_MsgHeaders noname;
  ETCS_HMI_Msgs _1_noname;
  ATO_modes _2_noname;
  ETCSHMIPacketDataType _3_noname;
  /* temp_ETCSMode/ */
  ETCS_modes last_temp_ETCSMode;

  last_temp_ETCSMode = outC->temp_ETCSMode;
  kcg_copy_ETCSHMIPacket(&outC->_L1, Input);
  kcg_copy_ETCSHMIPacketDataType(&outC->_L18, &outC->_L1.ETCSHMIPacketData);
  kcg_copy_ETCSHMIPacketDataType(&_3_noname, &outC->_L18);
  outC->_L6 = last_temp_ETCSMode;
  outC->_L3 = outC->_L1.currentETCSmode;
  outC->_L15 = outC->_L3 != outC->_L6;
  outC->_L7 = kcg_lit_int8(0);
  outC->_L14 = outC->_L7 != outC->_L3;
  outC->_L16 = outC->_L14 & outC->_L15;
  outC->_L17 = outC->_L1.isvalid;
  outC->_L20 = outC->_L17 & outC->_L16;
  /* _L13= */
  if (outC->_L20) {
    outC->_L13 = outC->_L3;
  }
  else {
    outC->_L13 = outC->_L6;
  }
  outC->temp_ETCSMode = outC->_L13;
  outC->_L12 = outC->temp_ETCSMode;
  outC->ETCSMode = outC->_L12;
  outC->_L2 = outC->_L1.currentATOmode;
  _2_noname = outC->_L2;
  outC->_L4 = outC->_L1.Message;
  _1_noname = outC->_L4;
  outC->_L5 = outC->_L1.Header;
  noname = outC->_L5;
}

#ifndef KCG_USER_DEFINED_INIT
void SetETCSMode_init(outC_SetETCSMode *outC)
{
  outC->_L20 = kcg_true;
  outC->_L17 = kcg_true;
  outC->_L18.label1 = kcg_lit_int8(0);
  outC->_L18.label2 = kcg_lit_int8(0);
  outC->_L18.label3 = kcg_lit_int8(0);
  outC->_L18.label4 = kcg_lit_int8(0);
  outC->_L18.label5 = kcg_lit_int8(0);
  outC->_L18.label6 = kcg_lit_int8(0);
  outC->_L18.label7 = kcg_lit_int16(0);
  outC->_L18.label8 = kcg_lit_int16(0);
  outC->_L14 = kcg_true;
  outC->_L15 = kcg_true;
  outC->_L16 = kcg_true;
  outC->_L13 = kcg_lit_int8(0);
  outC->_L12 = kcg_lit_int8(0);
  outC->_L7 = kcg_lit_int8(0);
  outC->_L6 = kcg_lit_int8(0);
  outC->_L2 = kcg_lit_int8(0);
  outC->_L3 = kcg_lit_int8(0);
  outC->_L4 = kcg_lit_int8(0);
  outC->_L5 = kcg_lit_int8(0);
  outC->_L1.isvalid = kcg_true;
  outC->_L1.Header = kcg_lit_int8(0);
  outC->_L1.Message = kcg_lit_int8(0);
  outC->_L1.currentETCSmode = kcg_lit_int8(0);
  outC->_L1.currentATOmode = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label1 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label2 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label3 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label4 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label5 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label6 = kcg_lit_int8(0);
  outC->_L1.ETCSHMIPacketData.label7 = kcg_lit_int16(0);
  outC->_L1.ETCSHMIPacketData.label8 = kcg_lit_int16(0);
  outC->ETCSMode = kcg_lit_int8(0);
  outC->temp_ETCSMode = kcg_lit_int8(0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void SetETCSMode_reset(outC_SetETCSMode *outC)
{
  outC->temp_ETCSMode = kcg_lit_int8(0);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SetETCSMode.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

