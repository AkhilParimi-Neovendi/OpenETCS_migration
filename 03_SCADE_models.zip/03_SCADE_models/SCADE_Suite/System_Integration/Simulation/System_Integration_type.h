#ifndef SYSTEM_INTEGRATION_TYPES_CONVERSION
#define SYSTEM_INTEGRATION_TYPES_CONVERSION

#include "SmuTypes.h"

/****************************************************************
 ** _2_SSM_ST_SM1 
 ****************************************************************/
extern int _2_SSM_ST_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check__2_SSM_ST_SM1_string(const char *str, char **endptr);
extern int string_to__2_SSM_ST_SM1(const char *str, void *pValue, char **endptr);
extern int is__2_SSM_ST_SM1_double_conversion_allowed();
extern int _2_SSM_ST_SM1_to_double(const void *pValue, double *nValue);
extern int is__2_SSM_ST_SM1_long_conversion_allowed();
extern int _2_SSM_ST_SM1_to_long(const void *pValue, long *nValue);
extern void compare__2_SSM_ST_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get__2_SSM_ST_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init__2_SSM_ST_SM1(void *pValue);
extern int release__2_SSM_ST_SM1(void *pValue);
extern int copy__2_SSM_ST_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type__2_SSM_ST_SM1_Utils;

/****************************************************************
 ** _3_SSM_TR_SM1 
 ****************************************************************/
extern int _3_SSM_TR_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check__3_SSM_TR_SM1_string(const char *str, char **endptr);
extern int string_to__3_SSM_TR_SM1(const char *str, void *pValue, char **endptr);
extern int is__3_SSM_TR_SM1_double_conversion_allowed();
extern int _3_SSM_TR_SM1_to_double(const void *pValue, double *nValue);
extern int is__3_SSM_TR_SM1_long_conversion_allowed();
extern int _3_SSM_TR_SM1_to_long(const void *pValue, long *nValue);
extern void compare__3_SSM_TR_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get__3_SSM_TR_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init__3_SSM_TR_SM1(void *pValue);
extern int release__3_SSM_TR_SM1(void *pValue);
extern int copy__3_SSM_TR_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type__3_SSM_TR_SM1_Utils;

/****************************************************************
 ** array_bool_1 
 ****************************************************************/
extern int array_bool_1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_bool_1_string(const char *str, char **endptr);
extern int string_to_array_bool_1(const char *str, void *pValue, char **endptr);
extern int is_array_bool_1_double_conversion_allowed();
extern int array_bool_1_to_double(const void *pValue, double *nValue);
extern int is_array_bool_1_long_conversion_allowed();
extern int array_bool_1_to_long(const void *pValue, long *nValue);
extern void compare_array_bool_1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_bool_1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_bool_1(void *pValue);
extern int release_array_bool_1(void *pValue);
extern int copy_array_bool_1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_bool_1_Utils;

/****************************************************************
 ** array_bool_3 
 ****************************************************************/
extern int array_bool_3_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_bool_3_string(const char *str, char **endptr);
extern int string_to_array_bool_3(const char *str, void *pValue, char **endptr);
extern int is_array_bool_3_double_conversion_allowed();
extern int array_bool_3_to_double(const void *pValue, double *nValue);
extern int is_array_bool_3_long_conversion_allowed();
extern int array_bool_3_to_long(const void *pValue, long *nValue);
extern void compare_array_bool_3(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_bool_3_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_bool_3(void *pValue);
extern int release_array_bool_3(void *pValue);
extern int copy_array_bool_3(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_bool_3_Utils;

/****************************************************************
 ** array_bool_4 
 ****************************************************************/
extern int array_bool_4_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_bool_4_string(const char *str, char **endptr);
extern int string_to_array_bool_4(const char *str, void *pValue, char **endptr);
extern int is_array_bool_4_double_conversion_allowed();
extern int array_bool_4_to_double(const void *pValue, double *nValue);
extern int is_array_bool_4_long_conversion_allowed();
extern int array_bool_4_to_long(const void *pValue, long *nValue);
extern void compare_array_bool_4(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_bool_4_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_bool_4(void *pValue);
extern int release_array_bool_4(void *pValue);
extern int copy_array_bool_4(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_bool_4_Utils;

/****************************************************************
 ** array_bool_5 
 ****************************************************************/
extern int array_bool_5_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_bool_5_string(const char *str, char **endptr);
extern int string_to_array_bool_5(const char *str, void *pValue, char **endptr);
extern int is_array_bool_5_double_conversion_allowed();
extern int array_bool_5_to_double(const void *pValue, double *nValue);
extern int is_array_bool_5_long_conversion_allowed();
extern int array_bool_5_to_long(const void *pValue, long *nValue);
extern void compare_array_bool_5(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_bool_5_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_bool_5(void *pValue);
extern int release_array_bool_5(void *pValue);
extern int copy_array_bool_5(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_bool_5_Utils;

/****************************************************************
 ** array_bool_6 
 ****************************************************************/
extern int array_bool_6_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_bool_6_string(const char *str, char **endptr);
extern int string_to_array_bool_6(const char *str, void *pValue, char **endptr);
extern int is_array_bool_6_double_conversion_allowed();
extern int array_bool_6_to_double(const void *pValue, double *nValue);
extern int is_array_bool_6_long_conversion_allowed();
extern int array_bool_6_to_long(const void *pValue, long *nValue);
extern void compare_array_bool_6(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_bool_6_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_bool_6(void *pValue);
extern int release_array_bool_6(void *pValue);
extern int copy_array_bool_6(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_bool_6_Utils;

/****************************************************************
 ** array_char_30 
 ****************************************************************/
extern int array_char_30_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_char_30_string(const char *str, char **endptr);
extern int string_to_array_char_30(const char *str, void *pValue, char **endptr);
extern int is_array_char_30_double_conversion_allowed();
extern int array_char_30_to_double(const void *pValue, double *nValue);
extern int is_array_char_30_long_conversion_allowed();
extern int array_char_30_to_long(const void *pValue, long *nValue);
extern void compare_array_char_30(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_char_30_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_char_30(void *pValue);
extern int release_array_char_30(void *pValue);
extern int copy_array_char_30(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_char_30_Utils;

/****************************************************************
 ** array_float32_1 
 ****************************************************************/
extern int array_float32_1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_float32_1_string(const char *str, char **endptr);
extern int string_to_array_float32_1(const char *str, void *pValue, char **endptr);
extern int is_array_float32_1_double_conversion_allowed();
extern int array_float32_1_to_double(const void *pValue, double *nValue);
extern int is_array_float32_1_long_conversion_allowed();
extern int array_float32_1_to_long(const void *pValue, long *nValue);
extern void compare_array_float32_1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_float32_1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_float32_1(void *pValue);
extern int release_array_float32_1(void *pValue);
extern int copy_array_float32_1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_float32_1_Utils;

/****************************************************************
 ** array_float32_4 
 ****************************************************************/
extern int array_float32_4_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_float32_4_string(const char *str, char **endptr);
extern int string_to_array_float32_4(const char *str, void *pValue, char **endptr);
extern int is_array_float32_4_double_conversion_allowed();
extern int array_float32_4_to_double(const void *pValue, double *nValue);
extern int is_array_float32_4_long_conversion_allowed();
extern int array_float32_4_to_long(const void *pValue, long *nValue);
extern void compare_array_float32_4(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_float32_4_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_float32_4(void *pValue);
extern int release_array_float32_4(void *pValue);
extern int copy_array_float32_4(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_float32_4_Utils;

/****************************************************************
 ** array_float32_5 
 ****************************************************************/
extern int array_float32_5_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_float32_5_string(const char *str, char **endptr);
extern int string_to_array_float32_5(const char *str, void *pValue, char **endptr);
extern int is_array_float32_5_double_conversion_allowed();
extern int array_float32_5_to_double(const void *pValue, double *nValue);
extern int is_array_float32_5_long_conversion_allowed();
extern int array_float32_5_to_long(const void *pValue, long *nValue);
extern void compare_array_float32_5(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_float32_5_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_float32_5(void *pValue);
extern int release_array_float32_5(void *pValue);
extern int copy_array_float32_5(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_float32_5_Utils;

/****************************************************************
 ** array_int32_1 
 ****************************************************************/
extern int array_int32_1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_int32_1_string(const char *str, char **endptr);
extern int string_to_array_int32_1(const char *str, void *pValue, char **endptr);
extern int is_array_int32_1_double_conversion_allowed();
extern int array_int32_1_to_double(const void *pValue, double *nValue);
extern int is_array_int32_1_long_conversion_allowed();
extern int array_int32_1_to_long(const void *pValue, long *nValue);
extern void compare_array_int32_1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_int32_1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_int32_1(void *pValue);
extern int release_array_int32_1(void *pValue);
extern int copy_array_int32_1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_int32_1_Utils;

/****************************************************************
 ** array_int32_4 
 ****************************************************************/
extern int array_int32_4_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_int32_4_string(const char *str, char **endptr);
extern int string_to_array_int32_4(const char *str, void *pValue, char **endptr);
extern int is_array_int32_4_double_conversion_allowed();
extern int array_int32_4_to_double(const void *pValue, double *nValue);
extern int is_array_int32_4_long_conversion_allowed();
extern int array_int32_4_to_long(const void *pValue, long *nValue);
extern void compare_array_int32_4(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_int32_4_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_int32_4(void *pValue);
extern int release_array_int32_4(void *pValue);
extern int copy_array_int32_4(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_int32_4_Utils;

/****************************************************************
 ** array_int32_5 
 ****************************************************************/
extern int array_int32_5_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_array_int32_5_string(const char *str, char **endptr);
extern int string_to_array_int32_5(const char *str, void *pValue, char **endptr);
extern int is_array_int32_5_double_conversion_allowed();
extern int array_int32_5_to_double(const void *pValue, double *nValue);
extern int is_array_int32_5_long_conversion_allowed();
extern int array_int32_5_to_long(const void *pValue, long *nValue);
extern void compare_array_int32_5(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_array_int32_5_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_array_int32_5(void *pValue);
extern int release_array_int32_5(void *pValue);
extern int copy_array_int32_5(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_array_int32_5_Utils;

/****************************************************************
 ** ATO_modes 
 ****************************************************************/
extern int ATO_modes_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ATO_modes_string(const char *str, char **endptr);
extern int string_to_ATO_modes(const char *str, void *pValue, char **endptr);
extern int is_ATO_modes_double_conversion_allowed();
extern int ATO_modes_to_double(const void *pValue, double *nValue);
extern int is_ATO_modes_long_conversion_allowed();
extern int ATO_modes_to_long(const void *pValue, long *nValue);
extern void compare_ATO_modes(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ATO_modes_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ATO_modes(void *pValue);
extern int release_ATO_modes(void *pValue);
extern int copy_ATO_modes(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ATO_modes_Utils;

/****************************************************************
 ** ATO_Packet 
 ****************************************************************/
extern int ATO_Packet_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ATO_Packet_string(const char *str, char **endptr);
extern int string_to_ATO_Packet(const char *str, void *pValue, char **endptr);
extern int is_ATO_Packet_double_conversion_allowed();
extern int ATO_Packet_to_double(const void *pValue, double *nValue);
extern int is_ATO_Packet_long_conversion_allowed();
extern int ATO_Packet_to_long(const void *pValue, long *nValue);
extern void compare_ATO_Packet(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ATO_Packet_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ATO_Packet(void *pValue);
extern int release_ATO_Packet(void *pValue);
extern int copy_ATO_Packet(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ATO_Packet_Utils;

/****************************************************************
 ** ATORSCSwitchPosition 
 ****************************************************************/
extern int ATORSCSwitchPosition_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ATORSCSwitchPosition_string(const char *str, char **endptr);
extern int string_to_ATORSCSwitchPosition(const char *str, void *pValue, char **endptr);
extern int is_ATORSCSwitchPosition_double_conversion_allowed();
extern int ATORSCSwitchPosition_to_double(const void *pValue, double *nValue);
extern int is_ATORSCSwitchPosition_long_conversion_allowed();
extern int ATORSCSwitchPosition_to_long(const void *pValue, long *nValue);
extern void compare_ATORSCSwitchPosition(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ATORSCSwitchPosition_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ATORSCSwitchPosition(void *pValue);
extern int release_ATORSCSwitchPosition(void *pValue);
extern int copy_ATORSCSwitchPosition(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ATORSCSwitchPosition_Utils;

/****************************************************************
 ** ETCS_HMI_MsgHeaders 
 ****************************************************************/
extern int ETCS_HMI_MsgHeaders_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCS_HMI_MsgHeaders_string(const char *str, char **endptr);
extern int string_to_ETCS_HMI_MsgHeaders(const char *str, void *pValue, char **endptr);
extern int is_ETCS_HMI_MsgHeaders_double_conversion_allowed();
extern int ETCS_HMI_MsgHeaders_to_double(const void *pValue, double *nValue);
extern int is_ETCS_HMI_MsgHeaders_long_conversion_allowed();
extern int ETCS_HMI_MsgHeaders_to_long(const void *pValue, long *nValue);
extern void compare_ETCS_HMI_MsgHeaders(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCS_HMI_MsgHeaders_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCS_HMI_MsgHeaders(void *pValue);
extern int release_ETCS_HMI_MsgHeaders(void *pValue);
extern int copy_ETCS_HMI_MsgHeaders(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCS_HMI_MsgHeaders_Utils;

/****************************************************************
 ** ETCS_HMI_Msgs 
 ****************************************************************/
extern int ETCS_HMI_Msgs_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCS_HMI_Msgs_string(const char *str, char **endptr);
extern int string_to_ETCS_HMI_Msgs(const char *str, void *pValue, char **endptr);
extern int is_ETCS_HMI_Msgs_double_conversion_allowed();
extern int ETCS_HMI_Msgs_to_double(const void *pValue, double *nValue);
extern int is_ETCS_HMI_Msgs_long_conversion_allowed();
extern int ETCS_HMI_Msgs_to_long(const void *pValue, long *nValue);
extern void compare_ETCS_HMI_Msgs(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCS_HMI_Msgs_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCS_HMI_Msgs(void *pValue);
extern int release_ETCS_HMI_Msgs(void *pValue);
extern int copy_ETCS_HMI_Msgs(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCS_HMI_Msgs_Utils;

/****************************************************************
 ** ETCS_modes 
 ****************************************************************/
extern int ETCS_modes_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCS_modes_string(const char *str, char **endptr);
extern int string_to_ETCS_modes(const char *str, void *pValue, char **endptr);
extern int is_ETCS_modes_double_conversion_allowed();
extern int ETCS_modes_to_double(const void *pValue, double *nValue);
extern int is_ETCS_modes_long_conversion_allowed();
extern int ETCS_modes_to_long(const void *pValue, long *nValue);
extern void compare_ETCS_modes(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCS_modes_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCS_modes(void *pValue);
extern int release_ETCS_modes(void *pValue);
extern int copy_ETCS_modes(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCS_modes_Utils;

/****************************************************************
 ** ETCSATOPacket 
 ****************************************************************/
extern int ETCSATOPacket_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCSATOPacket_string(const char *str, char **endptr);
extern int string_to_ETCSATOPacket(const char *str, void *pValue, char **endptr);
extern int is_ETCSATOPacket_double_conversion_allowed();
extern int ETCSATOPacket_to_double(const void *pValue, double *nValue);
extern int is_ETCSATOPacket_long_conversion_allowed();
extern int ETCSATOPacket_to_long(const void *pValue, long *nValue);
extern void compare_ETCSATOPacket(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCSATOPacket_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCSATOPacket(void *pValue);
extern int release_ETCSATOPacket(void *pValue);
extern int copy_ETCSATOPacket(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCSATOPacket_Utils;

/****************************************************************
 ** ETCSHMIPacket 
 ****************************************************************/
extern int ETCSHMIPacket_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCSHMIPacket_string(const char *str, char **endptr);
extern int string_to_ETCSHMIPacket(const char *str, void *pValue, char **endptr);
extern int is_ETCSHMIPacket_double_conversion_allowed();
extern int ETCSHMIPacket_to_double(const void *pValue, double *nValue);
extern int is_ETCSHMIPacket_long_conversion_allowed();
extern int ETCSHMIPacket_to_long(const void *pValue, long *nValue);
extern void compare_ETCSHMIPacket(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCSHMIPacket_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCSHMIPacket(void *pValue);
extern int release_ETCSHMIPacket(void *pValue);
extern int copy_ETCSHMIPacket(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCSHMIPacket_Utils;

/****************************************************************
 ** ETCSHMIPacketDataType 
 ****************************************************************/
extern int ETCSHMIPacketDataType_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ETCSHMIPacketDataType_string(const char *str, char **endptr);
extern int string_to_ETCSHMIPacketDataType(const char *str, void *pValue, char **endptr);
extern int is_ETCSHMIPacketDataType_double_conversion_allowed();
extern int ETCSHMIPacketDataType_to_double(const void *pValue, double *nValue);
extern int is_ETCSHMIPacketDataType_long_conversion_allowed();
extern int ETCSHMIPacketDataType_to_long(const void *pValue, long *nValue);
extern void compare_ETCSHMIPacketDataType(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ETCSHMIPacketDataType_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ETCSHMIPacketDataType(void *pValue);
extern int release_ETCSHMIPacketDataType(void *pValue);
extern int copy_ETCSHMIPacketDataType(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ETCSHMIPacketDataType_Utils;

/****************************************************************
 ** ExternalindicatorStates 
 ****************************************************************/
extern int ExternalindicatorStates_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_ExternalindicatorStates_string(const char *str, char **endptr);
extern int string_to_ExternalindicatorStates(const char *str, void *pValue, char **endptr);
extern int is_ExternalindicatorStates_double_conversion_allowed();
extern int ExternalindicatorStates_to_double(const void *pValue, double *nValue);
extern int is_ExternalindicatorStates_long_conversion_allowed();
extern int ExternalindicatorStates_to_long(const void *pValue, long *nValue);
extern void compare_ExternalindicatorStates(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_ExternalindicatorStates_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_ExternalindicatorStates(void *pValue);
extern int release_ExternalindicatorStates(void *pValue);
extern int copy_ExternalindicatorStates(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_ExternalindicatorStates_Utils;

/****************************************************************
 ** FVAHMIPacket 
 ****************************************************************/
extern int FVAHMIPacket_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_FVAHMIPacket_string(const char *str, char **endptr);
extern int string_to_FVAHMIPacket(const char *str, void *pValue, char **endptr);
extern int is_FVAHMIPacket_double_conversion_allowed();
extern int FVAHMIPacket_to_double(const void *pValue, double *nValue);
extern int is_FVAHMIPacket_long_conversion_allowed();
extern int FVAHMIPacket_to_long(const void *pValue, long *nValue);
extern void compare_FVAHMIPacket(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_FVAHMIPacket_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_FVAHMIPacket(void *pValue);
extern int release_FVAHMIPacket(void *pValue);
extern int copy_FVAHMIPacket(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_FVAHMIPacket_Utils;

/****************************************************************
 ** kcg_bool 
 ****************************************************************/
extern int kcg_bool_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_bool_string(const char *str, char **endptr);
extern int string_to_kcg_bool(const char *str, void *pValue, char **endptr);
extern int is_kcg_bool_double_conversion_allowed();
extern int kcg_bool_to_double(const void *pValue, double *nValue);
extern int is_kcg_bool_long_conversion_allowed();
extern int kcg_bool_to_long(const void *pValue, long *nValue);
extern void compare_kcg_bool(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_bool_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_bool(void *pValue);
extern int release_kcg_bool(void *pValue);
extern int copy_kcg_bool(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_bool_Utils;

/****************************************************************
 ** kcg_char 
 ****************************************************************/
extern int kcg_char_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_char_string(const char *str, char **endptr);
extern int string_to_kcg_char(const char *str, void *pValue, char **endptr);
extern int is_kcg_char_double_conversion_allowed();
extern int kcg_char_to_double(const void *pValue, double *nValue);
extern int is_kcg_char_long_conversion_allowed();
extern int kcg_char_to_long(const void *pValue, long *nValue);
extern void compare_kcg_char(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_char_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_char(void *pValue);
extern int release_kcg_char(void *pValue);
extern int copy_kcg_char(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_char_Utils;

/****************************************************************
 ** kcg_float32 
 ****************************************************************/
extern int kcg_float32_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_float32_string(const char *str, char **endptr);
extern int string_to_kcg_float32(const char *str, void *pValue, char **endptr);
extern int is_kcg_float32_double_conversion_allowed();
extern int kcg_float32_to_double(const void *pValue, double *nValue);
extern int is_kcg_float32_long_conversion_allowed();
extern int kcg_float32_to_long(const void *pValue, long *nValue);
extern void compare_kcg_float32(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_float32_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_float32(void *pValue);
extern int release_kcg_float32(void *pValue);
extern int copy_kcg_float32(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_float32_Utils;

/****************************************************************
 ** kcg_float64 
 ****************************************************************/
extern int kcg_float64_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_float64_string(const char *str, char **endptr);
extern int string_to_kcg_float64(const char *str, void *pValue, char **endptr);
extern int is_kcg_float64_double_conversion_allowed();
extern int kcg_float64_to_double(const void *pValue, double *nValue);
extern int is_kcg_float64_long_conversion_allowed();
extern int kcg_float64_to_long(const void *pValue, long *nValue);
extern void compare_kcg_float64(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_float64_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_float64(void *pValue);
extern int release_kcg_float64(void *pValue);
extern int copy_kcg_float64(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_float64_Utils;

/****************************************************************
 ** kcg_int16 
 ****************************************************************/
extern int kcg_int16_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_int16_string(const char *str, char **endptr);
extern int string_to_kcg_int16(const char *str, void *pValue, char **endptr);
extern int is_kcg_int16_double_conversion_allowed();
extern int kcg_int16_to_double(const void *pValue, double *nValue);
extern int is_kcg_int16_long_conversion_allowed();
extern int kcg_int16_to_long(const void *pValue, long *nValue);
extern void compare_kcg_int16(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_int16_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_int16(void *pValue);
extern int release_kcg_int16(void *pValue);
extern int copy_kcg_int16(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_int16_Utils;

/****************************************************************
 ** kcg_int32 
 ****************************************************************/
extern int kcg_int32_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_int32_string(const char *str, char **endptr);
extern int string_to_kcg_int32(const char *str, void *pValue, char **endptr);
extern int is_kcg_int32_double_conversion_allowed();
extern int kcg_int32_to_double(const void *pValue, double *nValue);
extern int is_kcg_int32_long_conversion_allowed();
extern int kcg_int32_to_long(const void *pValue, long *nValue);
extern void compare_kcg_int32(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_int32_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_int32(void *pValue);
extern int release_kcg_int32(void *pValue);
extern int copy_kcg_int32(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_int32_Utils;

/****************************************************************
 ** kcg_int64 
 ****************************************************************/
extern int kcg_int64_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_int64_string(const char *str, char **endptr);
extern int string_to_kcg_int64(const char *str, void *pValue, char **endptr);
extern int is_kcg_int64_double_conversion_allowed();
extern int kcg_int64_to_double(const void *pValue, double *nValue);
extern int is_kcg_int64_long_conversion_allowed();
extern int kcg_int64_to_long(const void *pValue, long *nValue);
extern void compare_kcg_int64(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_int64_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_int64(void *pValue);
extern int release_kcg_int64(void *pValue);
extern int copy_kcg_int64(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_int64_Utils;

/****************************************************************
 ** kcg_int8 
 ****************************************************************/
extern int kcg_int8_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_int8_string(const char *str, char **endptr);
extern int string_to_kcg_int8(const char *str, void *pValue, char **endptr);
extern int is_kcg_int8_double_conversion_allowed();
extern int kcg_int8_to_double(const void *pValue, double *nValue);
extern int is_kcg_int8_long_conversion_allowed();
extern int kcg_int8_to_long(const void *pValue, long *nValue);
extern void compare_kcg_int8(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_int8_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_int8(void *pValue);
extern int release_kcg_int8(void *pValue);
extern int copy_kcg_int8(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_int8_Utils;

/****************************************************************
 ** kcg_size 
 ****************************************************************/
extern int kcg_size_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_size_string(const char *str, char **endptr);
extern int string_to_kcg_size(const char *str, void *pValue, char **endptr);
extern int is_kcg_size_double_conversion_allowed();
extern int kcg_size_to_double(const void *pValue, double *nValue);
extern int is_kcg_size_long_conversion_allowed();
extern int kcg_size_to_long(const void *pValue, long *nValue);
extern void compare_kcg_size(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_size_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_size(void *pValue);
extern int release_kcg_size(void *pValue);
extern int copy_kcg_size(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_size_Utils;

/****************************************************************
 ** kcg_uint16 
 ****************************************************************/
extern int kcg_uint16_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_uint16_string(const char *str, char **endptr);
extern int string_to_kcg_uint16(const char *str, void *pValue, char **endptr);
extern int is_kcg_uint16_double_conversion_allowed();
extern int kcg_uint16_to_double(const void *pValue, double *nValue);
extern int is_kcg_uint16_long_conversion_allowed();
extern int kcg_uint16_to_long(const void *pValue, long *nValue);
extern void compare_kcg_uint16(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_uint16_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_uint16(void *pValue);
extern int release_kcg_uint16(void *pValue);
extern int copy_kcg_uint16(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_uint16_Utils;

/****************************************************************
 ** kcg_uint32 
 ****************************************************************/
extern int kcg_uint32_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_uint32_string(const char *str, char **endptr);
extern int string_to_kcg_uint32(const char *str, void *pValue, char **endptr);
extern int is_kcg_uint32_double_conversion_allowed();
extern int kcg_uint32_to_double(const void *pValue, double *nValue);
extern int is_kcg_uint32_long_conversion_allowed();
extern int kcg_uint32_to_long(const void *pValue, long *nValue);
extern void compare_kcg_uint32(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_uint32_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_uint32(void *pValue);
extern int release_kcg_uint32(void *pValue);
extern int copy_kcg_uint32(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_uint32_Utils;

/****************************************************************
 ** kcg_uint64 
 ****************************************************************/
extern int kcg_uint64_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_uint64_string(const char *str, char **endptr);
extern int string_to_kcg_uint64(const char *str, void *pValue, char **endptr);
extern int is_kcg_uint64_double_conversion_allowed();
extern int kcg_uint64_to_double(const void *pValue, double *nValue);
extern int is_kcg_uint64_long_conversion_allowed();
extern int kcg_uint64_to_long(const void *pValue, long *nValue);
extern void compare_kcg_uint64(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_uint64_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_uint64(void *pValue);
extern int release_kcg_uint64(void *pValue);
extern int copy_kcg_uint64(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_uint64_Utils;

/****************************************************************
 ** kcg_uint8 
 ****************************************************************/
extern int kcg_uint8_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_kcg_uint8_string(const char *str, char **endptr);
extern int string_to_kcg_uint8(const char *str, void *pValue, char **endptr);
extern int is_kcg_uint8_double_conversion_allowed();
extern int kcg_uint8_to_double(const void *pValue, double *nValue);
extern int is_kcg_uint8_long_conversion_allowed();
extern int kcg_uint8_to_long(const void *pValue, long *nValue);
extern void compare_kcg_uint8(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_kcg_uint8_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_kcg_uint8(void *pValue);
extern int release_kcg_uint8(void *pValue);
extern int copy_kcg_uint8(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_kcg_uint8_Utils;

/****************************************************************
 ** LCF_Data 
 ****************************************************************/
extern int LCF_Data_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_LCF_Data_string(const char *str, char **endptr);
extern int string_to_LCF_Data(const char *str, void *pValue, char **endptr);
extern int is_LCF_Data_double_conversion_allowed();
extern int LCF_Data_to_double(const void *pValue, double *nValue);
extern int is_LCF_Data_long_conversion_allowed();
extern int LCF_Data_to_long(const void *pValue, long *nValue);
extern void compare_LCF_Data(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_LCF_Data_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_LCF_Data(void *pValue);
extern int release_LCF_Data(void *pValue);
extern int copy_LCF_Data(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_LCF_Data_Utils;

/****************************************************************
 ** Override_Switch_State 
 ****************************************************************/
extern int Override_Switch_State_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_Override_Switch_State_string(const char *str, char **endptr);
extern int string_to_Override_Switch_State(const char *str, void *pValue, char **endptr);
extern int is_Override_Switch_State_double_conversion_allowed();
extern int Override_Switch_State_to_double(const void *pValue, double *nValue);
extern int is_Override_Switch_State_long_conversion_allowed();
extern int Override_Switch_State_to_long(const void *pValue, long *nValue);
extern void compare_Override_Switch_State(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_Override_Switch_State_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_Override_Switch_State(void *pValue);
extern int release_Override_Switch_State(void *pValue);
extern int copy_Override_Switch_State(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_Override_Switch_State_Utils;

/****************************************************************
 ** SSM_ST_OverrideSwitch_SM 
 ****************************************************************/
extern int SSM_ST_OverrideSwitch_SM_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_ST_OverrideSwitch_SM_string(const char *str, char **endptr);
extern int string_to_SSM_ST_OverrideSwitch_SM(const char *str, void *pValue, char **endptr);
extern int is_SSM_ST_OverrideSwitch_SM_double_conversion_allowed();
extern int SSM_ST_OverrideSwitch_SM_to_double(const void *pValue, double *nValue);
extern int is_SSM_ST_OverrideSwitch_SM_long_conversion_allowed();
extern int SSM_ST_OverrideSwitch_SM_to_long(const void *pValue, long *nValue);
extern void compare_SSM_ST_OverrideSwitch_SM(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_ST_OverrideSwitch_SM_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_ST_OverrideSwitch_SM(void *pValue);
extern int release_SSM_ST_OverrideSwitch_SM(void *pValue);
extern int copy_SSM_ST_OverrideSwitch_SM(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_ST_OverrideSwitch_SM_Utils;

/****************************************************************
 ** SSM_ST_SM1 
 ****************************************************************/
extern int SSM_ST_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_ST_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_ST_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_ST_SM1_double_conversion_allowed();
extern int SSM_ST_SM1_to_double(const void *pValue, double *nValue);
extern int is_SSM_ST_SM1_long_conversion_allowed();
extern int SSM_ST_SM1_to_long(const void *pValue, long *nValue);
extern void compare_SSM_ST_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_ST_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_ST_SM1(void *pValue);
extern int release_SSM_ST_SM1(void *pValue);
extern int copy_SSM_ST_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_ST_SM1_Utils;

/****************************************************************
 ** SSM_ST_SM2_Power_On_SM1 
 ****************************************************************/
extern int SSM_ST_SM2_Power_On_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_ST_SM2_Power_On_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_ST_SM2_Power_On_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_ST_SM2_Power_On_SM1_double_conversion_allowed();
extern int SSM_ST_SM2_Power_On_SM1_to_double(const void *pValue, double *nValue);
extern int is_SSM_ST_SM2_Power_On_SM1_long_conversion_allowed();
extern int SSM_ST_SM2_Power_On_SM1_to_long(const void *pValue, long *nValue);
extern void compare_SSM_ST_SM2_Power_On_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_ST_SM2_Power_On_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_ST_SM2_Power_On_SM1(void *pValue);
extern int release_SSM_ST_SM2_Power_On_SM1(void *pValue);
extern int copy_SSM_ST_SM2_Power_On_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_ST_SM2_Power_On_SM1_Utils;

/****************************************************************
 ** SSM_TR_OverrideSwitch_SM 
 ****************************************************************/
extern int SSM_TR_OverrideSwitch_SM_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_TR_OverrideSwitch_SM_string(const char *str, char **endptr);
extern int string_to_SSM_TR_OverrideSwitch_SM(const char *str, void *pValue, char **endptr);
extern int is_SSM_TR_OverrideSwitch_SM_double_conversion_allowed();
extern int SSM_TR_OverrideSwitch_SM_to_double(const void *pValue, double *nValue);
extern int is_SSM_TR_OverrideSwitch_SM_long_conversion_allowed();
extern int SSM_TR_OverrideSwitch_SM_to_long(const void *pValue, long *nValue);
extern void compare_SSM_TR_OverrideSwitch_SM(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_TR_OverrideSwitch_SM_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_TR_OverrideSwitch_SM(void *pValue);
extern int release_SSM_TR_OverrideSwitch_SM(void *pValue);
extern int copy_SSM_TR_OverrideSwitch_SM(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_TR_OverrideSwitch_SM_Utils;

/****************************************************************
 ** SSM_TR_SM1 
 ****************************************************************/
extern int SSM_TR_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_TR_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_TR_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_TR_SM1_double_conversion_allowed();
extern int SSM_TR_SM1_to_double(const void *pValue, double *nValue);
extern int is_SSM_TR_SM1_long_conversion_allowed();
extern int SSM_TR_SM1_to_long(const void *pValue, long *nValue);
extern void compare_SSM_TR_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_TR_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_TR_SM1(void *pValue);
extern int release_SSM_TR_SM1(void *pValue);
extern int copy_SSM_TR_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_TR_SM1_Utils;

/****************************************************************
 ** SSM_TR_SM2_Power_On_SM1 
 ****************************************************************/
extern int SSM_TR_SM2_Power_On_SM1_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_SSM_TR_SM2_Power_On_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_TR_SM2_Power_On_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_TR_SM2_Power_On_SM1_double_conversion_allowed();
extern int SSM_TR_SM2_Power_On_SM1_to_double(const void *pValue, double *nValue);
extern int is_SSM_TR_SM2_Power_On_SM1_long_conversion_allowed();
extern int SSM_TR_SM2_Power_On_SM1_to_long(const void *pValue, long *nValue);
extern void compare_SSM_TR_SM2_Power_On_SM1(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_SSM_TR_SM2_Power_On_SM1_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_SSM_TR_SM2_Power_On_SM1(void *pValue);
extern int release_SSM_TR_SM2_Power_On_SM1(void *pValue);
extern int copy_SSM_TR_SM2_Power_On_SM1(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_SSM_TR_SM2_Power_On_SM1_Utils;

/****************************************************************
 ** struct_11492 
 ****************************************************************/
extern int struct_11492_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_struct_11492_string(const char *str, char **endptr);
extern int string_to_struct_11492(const char *str, void *pValue, char **endptr);
extern int is_struct_11492_double_conversion_allowed();
extern int struct_11492_to_double(const void *pValue, double *nValue);
extern int is_struct_11492_long_conversion_allowed();
extern int struct_11492_to_long(const void *pValue, long *nValue);
extern void compare_struct_11492(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_struct_11492_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_struct_11492(void *pValue);
extern int release_struct_11492(void *pValue);
extern int copy_struct_11492(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_struct_11492_Utils;

/****************************************************************
 ** struct_11590 
 ****************************************************************/
extern int struct_11590_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_struct_11590_string(const char *str, char **endptr);
extern int string_to_struct_11590(const char *str, void *pValue, char **endptr);
extern int is_struct_11590_double_conversion_allowed();
extern int struct_11590_to_double(const void *pValue, double *nValue);
extern int is_struct_11590_long_conversion_allowed();
extern int struct_11590_to_long(const void *pValue, long *nValue);
extern void compare_struct_11590(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_struct_11590_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_struct_11590(void *pValue);
extern int release_struct_11590(void *pValue);
extern int copy_struct_11590(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_struct_11590_Utils;

/****************************************************************
 ** Tain_Physics_Outputs 
 ****************************************************************/
extern int Tain_Physics_Outputs_to_string(const void *pValue, PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int check_Tain_Physics_Outputs_string(const char *str, char **endptr);
extern int string_to_Tain_Physics_Outputs(const char *str, void *pValue, char **endptr);
extern int is_Tain_Physics_Outputs_double_conversion_allowed();
extern int Tain_Physics_Outputs_to_double(const void *pValue, double *nValue);
extern int is_Tain_Physics_Outputs_long_conversion_allowed();
extern int Tain_Physics_Outputs_to_long(const void *pValue, long *nValue);
extern void compare_Tain_Physics_Outputs(int *nStatus, const void *pValue1, const void *pValue2, SimTolerance *pTol, const char *pszPath, PFN_STR_LIST_APPEND pfnStrListAppend, void *pListErrPaths);
extern int get_Tain_Physics_Outputs_signature(PFN_STR_APPEND pfnStrAppend, void *pStrObj);
extern int init_Tain_Physics_Outputs(void *pValue);
extern int release_Tain_Physics_Outputs(void *pValue);
extern int copy_Tain_Physics_Outputs(void *pToValue, const void *pFromValue);
extern SimTypeUtils _Type_Tain_Physics_Outputs_Utils;


#endif /*SYSTEM_INTEGRATION_TYPES_CONVERSION */
