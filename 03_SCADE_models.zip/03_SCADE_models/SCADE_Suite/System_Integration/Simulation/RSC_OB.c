/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "RSC_OB.h"

/* RSC_OB/ */
void RSC_OB(
  /* from_RM/ */
  kcg_bool from_RM,
  /* from_FVA_ss139/ */
  kcg_bool from_FVA_ss139,
  /* from_FVA_int2/ */
  kcg_bool from_FVA_int2,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* ONSwitchGui/ */
  kcg_bool ONSwitchGui,
  outC_RSC_OB *outC)
{
  /* SM1: */
  SSM_ST_SM1 SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _1_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _2_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _3_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _4_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _5_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _6_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _7_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _8_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _9_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _10_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _11_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _12_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _13_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _14_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _15_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 _16_SM1_state_nxt_partial;
  /* SM1: */
  kcg_bool _17_SM1_reset_nxt_partial;
  /* SM1: */
  SSM_TR_SM1 _18_SM1_fired_partial;
  /* SM1: */
  SSM_ST_SM1 SM1_state_act_partial;
  /* SM1: */
  kcg_bool SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 SM1_fired_strong_partial;
  /* SM1:Connecting:<1> */
  kcg_bool tr_1_guard_Connecting_SM1;
  /* SM1: */
  SSM_ST_SM1 _19_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _20_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _21_SM1_fired_strong_partial;
  /* SM1:Available:<1> */
  kcg_bool tr_1_guard_Available_SM1;
  /* SM1: */
  SSM_ST_SM1 _22_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _23_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _24_SM1_fired_strong_partial;
  /* SM1:Remote_Supervision:<3> */
  kcg_bool tr_3_guard_Remote_Supervision_SM1;
  /* SM1:Remote_Supervision:<2> */
  kcg_bool tr_2_guard_Remote_Supervision_SM1;
  /* SM1:Remote_Supervision:<1> */
  kcg_bool tr_1_guard_Remote_Supervision_SM1;
  /* SM1: */
  SSM_ST_SM1 _25_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _26_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _27_SM1_fired_strong_partial;
  /* SM1:Remote_Control:<3> */
  kcg_bool tr_3_guard_Remote_Control_SM1;
  /* SM1:Remote_Control:<2> */
  kcg_bool tr_2_guard_Remote_Control_SM1;
  /* SM1:Remote_Control:<1> */
  kcg_bool tr_1_guard_Remote_Control_SM1;
  /* SM1: */
  SSM_ST_SM1 _28_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _29_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _30_SM1_fired_strong_partial;
  /* SM1:InterruptedRemoteSupervision:<2> */
  kcg_bool tr_2_guard_InterruptedRemoteSupervision_SM1;
  /* SM1:InterruptedRemoteSupervision:<1> */
  kcg_bool tr_1_guard_InterruptedRemoteSupervision_SM1;
  /* SM1: */
  SSM_ST_SM1 _31_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _32_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _33_SM1_fired_strong_partial;
  /* SM1:InterruptedRemoteControl:<3> */
  kcg_bool tr_3_guard_InterruptedRemoteControl_SM1;
  /* SM1:InterruptedRemoteControl:<2> */
  kcg_bool tr_2_guard_InterruptedRemoteControl_SM1;
  /* SM1:InterruptedRemoteControl:<1> */
  kcg_bool tr_1_guard_InterruptedRemoteControl_SM1;
  /* SM1: */
  SSM_ST_SM1 _34_SM1_state_act_partial;
  /* SM1: */
  kcg_bool _35_SM1_reset_act_partial;
  /* SM1: */
  SSM_TR_SM1 _36_SM1_fired_strong_partial;
  /* SM1:Intitial:<1> */
  kcg_bool tr_1_guard_Intitial_SM1;
  kcg_bool noname;
  kcg_bool _37_noname;
  kcg_bool _38_noname;
  kcg_bool _39_noname;
  kcg_bool _40_noname;
  /* SM1: */
  kcg_bool SM1_reset_sel;
  /* SM1: */
  kcg_bool SM1_reset_prv;

  outC->_L7 = ONSwitchGui;
  outC->RSC_PowerOn = outC->_L7;
  outC->SM1_state_sel = outC->SM1_state_nxt;
  /* SM1: */
  switch (outC->SM1_state_sel) {
    case SSM_st_Intitial_SM1 :
      tr_1_guard_Intitial_SM1 = kcg_true;
      if (tr_1_guard_Intitial_SM1) {
        _34_SM1_state_act_partial = SSM_st_Connecting_SM1;
      }
      else {
        _34_SM1_state_act_partial = SSM_st_Intitial_SM1;
      }
      outC->SM1_state_act = _34_SM1_state_act_partial;
      if (tr_1_guard_Intitial_SM1) {
        _36_SM1_fired_strong_partial = SSM_TR_Intitial_Connecting_1_Intitial_SM1;
      }
      else {
        _36_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _36_SM1_fired_strong_partial;
      break;
    case SSM_st_InterruptedRemoteControl_SM1 :
      tr_3_guard_InterruptedRemoteControl_SM1 = !outC->RSC_PowerOn;
      tr_2_guard_InterruptedRemoteControl_SM1 = kcg_false;
      tr_1_guard_InterruptedRemoteControl_SM1 = kcg_false;
      if (tr_1_guard_InterruptedRemoteControl_SM1) {
        _31_SM1_state_act_partial = SSM_st_Remote_Control_SM1;
      }
      else if (tr_2_guard_InterruptedRemoteControl_SM1) {
        _31_SM1_state_act_partial = SSM_st_Remote_Supervision_SM1;
      }
      else if (tr_3_guard_InterruptedRemoteControl_SM1) {
        _31_SM1_state_act_partial = SSM_st_Connecting_SM1;
      }
      else {
        _31_SM1_state_act_partial = SSM_st_InterruptedRemoteControl_SM1;
      }
      outC->SM1_state_act = _31_SM1_state_act_partial;
      if (tr_1_guard_InterruptedRemoteControl_SM1) {
        _33_SM1_fired_strong_partial =
          SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1;
      }
      else if (tr_2_guard_InterruptedRemoteControl_SM1) {
        _33_SM1_fired_strong_partial =
          _5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1;
      }
      else if (tr_3_guard_InterruptedRemoteControl_SM1) {
        _33_SM1_fired_strong_partial =
          _6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1;
      }
      else {
        _33_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _33_SM1_fired_strong_partial;
      break;
    case SSM_st_InterruptedRemoteSupervision_SM1 :
      tr_2_guard_InterruptedRemoteSupervision_SM1 = !outC->RSC_PowerOn;
      tr_1_guard_InterruptedRemoteSupervision_SM1 = kcg_false;
      if (tr_1_guard_InterruptedRemoteSupervision_SM1) {
        _28_SM1_state_act_partial = SSM_st_Remote_Supervision_SM1;
      }
      else if (tr_2_guard_InterruptedRemoteSupervision_SM1) {
        _28_SM1_state_act_partial = SSM_st_Connecting_SM1;
      }
      else {
        _28_SM1_state_act_partial = SSM_st_InterruptedRemoteSupervision_SM1;
      }
      outC->SM1_state_act = _28_SM1_state_act_partial;
      if (tr_1_guard_InterruptedRemoteSupervision_SM1) {
        _30_SM1_fired_strong_partial =
          SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1;
      }
      else if (tr_2_guard_InterruptedRemoteSupervision_SM1) {
        _30_SM1_fired_strong_partial =
          _7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1;
      }
      else {
        _30_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _30_SM1_fired_strong_partial;
      break;
    case SSM_st_Remote_Control_SM1 :
      tr_3_guard_Remote_Control_SM1 = kcg_false;
      tr_2_guard_Remote_Control_SM1 = kcg_false;
      tr_1_guard_Remote_Control_SM1 = kcg_false;
      if (tr_1_guard_Remote_Control_SM1) {
        _25_SM1_state_act_partial = SSM_st_Available_SM1;
      }
      else if (tr_2_guard_Remote_Control_SM1) {
        _25_SM1_state_act_partial = SSM_st_Remote_Supervision_SM1;
      }
      else if (tr_3_guard_Remote_Control_SM1) {
        _25_SM1_state_act_partial = SSM_st_InterruptedRemoteControl_SM1;
      }
      else {
        _25_SM1_state_act_partial = SSM_st_Remote_Control_SM1;
      }
      outC->SM1_state_act = _25_SM1_state_act_partial;
      if (tr_1_guard_Remote_Control_SM1) {
        _27_SM1_fired_strong_partial =
          SSM_TR_Remote_Control_Available_1_Remote_Control_SM1;
      }
      else if (tr_2_guard_Remote_Control_SM1) {
        _27_SM1_fired_strong_partial =
          SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1;
      }
      else if (tr_3_guard_Remote_Control_SM1) {
        _27_SM1_fired_strong_partial =
          SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1;
      }
      else {
        _27_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _27_SM1_fired_strong_partial;
      break;
    case SSM_st_Remote_Supervision_SM1 :
      tr_3_guard_Remote_Supervision_SM1 = !outC->RSC_PowerOn;
      tr_2_guard_Remote_Supervision_SM1 = kcg_false;
      tr_1_guard_Remote_Supervision_SM1 = kcg_false;
      if (tr_1_guard_Remote_Supervision_SM1) {
        _22_SM1_state_act_partial = SSM_st_Available_SM1;
      }
      else if (tr_2_guard_Remote_Supervision_SM1) {
        _22_SM1_state_act_partial = SSM_st_Remote_Control_SM1;
      }
      else if (tr_3_guard_Remote_Supervision_SM1) {
        _22_SM1_state_act_partial = SSM_st_InterruptedRemoteSupervision_SM1;
      }
      else {
        _22_SM1_state_act_partial = SSM_st_Remote_Supervision_SM1;
      }
      outC->SM1_state_act = _22_SM1_state_act_partial;
      if (tr_1_guard_Remote_Supervision_SM1) {
        _24_SM1_fired_strong_partial =
          SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1;
      }
      else if (tr_2_guard_Remote_Supervision_SM1) {
        _24_SM1_fired_strong_partial =
          SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1;
      }
      else if (tr_3_guard_Remote_Supervision_SM1) {
        _24_SM1_fired_strong_partial =
          SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1;
      }
      else {
        _24_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _24_SM1_fired_strong_partial;
      break;
    case SSM_st_Available_SM1 :
      tr_1_guard_Available_SM1 = kcg_true;
      if (tr_1_guard_Available_SM1) {
        _19_SM1_state_act_partial = SSM_st_Remote_Supervision_SM1;
      }
      else {
        _19_SM1_state_act_partial = SSM_st_Available_SM1;
      }
      outC->SM1_state_act = _19_SM1_state_act_partial;
      if (tr_1_guard_Available_SM1) {
        _21_SM1_fired_strong_partial =
          SSM_TR_Available_Remote_Supervision_1_Available_SM1;
      }
      else {
        _21_SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _21_SM1_fired_strong_partial;
      break;
    case SSM_st_Connecting_SM1 :
      tr_1_guard_Connecting_SM1 = outC->RSC_PowerOn;
      if (tr_1_guard_Connecting_SM1) {
        SM1_state_act_partial = SSM_st_Available_SM1;
      }
      else {
        SM1_state_act_partial = SSM_st_Connecting_SM1;
      }
      outC->SM1_state_act = SM1_state_act_partial;
      if (tr_1_guard_Connecting_SM1) {
        SM1_fired_strong_partial = SSM_TR_Connecting_Available_1_Connecting_SM1;
      }
      else {
        SM1_fired_strong_partial = _4_SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = SM1_fired_strong_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  /* SM1: */
  switch (outC->SM1_state_act) {
    case SSM_st_Intitial_SM1 :
      _18_SM1_fired_partial = outC->SM1_fired_strong;
      _17_SM1_reset_nxt_partial = kcg_false;
      _16_SM1_state_nxt_partial = SSM_st_Intitial_SM1;
      outC->SM1_state_nxt = _16_SM1_state_nxt_partial;
      break;
    case SSM_st_InterruptedRemoteControl_SM1 :
      _15_SM1_fired_partial = outC->SM1_fired_strong;
      _14_SM1_reset_nxt_partial = kcg_false;
      _13_SM1_state_nxt_partial = SSM_st_InterruptedRemoteControl_SM1;
      outC->SM1_state_nxt = _13_SM1_state_nxt_partial;
      break;
    case SSM_st_InterruptedRemoteSupervision_SM1 :
      _12_SM1_fired_partial = outC->SM1_fired_strong;
      _11_SM1_reset_nxt_partial = kcg_false;
      _10_SM1_state_nxt_partial = SSM_st_InterruptedRemoteSupervision_SM1;
      outC->SM1_state_nxt = _10_SM1_state_nxt_partial;
      break;
    case SSM_st_Remote_Control_SM1 :
      _9_SM1_fired_partial = outC->SM1_fired_strong;
      _8_SM1_reset_nxt_partial = kcg_false;
      _7_SM1_state_nxt_partial = SSM_st_Remote_Control_SM1;
      outC->SM1_state_nxt = _7_SM1_state_nxt_partial;
      break;
    case SSM_st_Remote_Supervision_SM1 :
      _6_SM1_fired_partial = outC->SM1_fired_strong;
      _5_SM1_reset_nxt_partial = kcg_false;
      _4_SM1_state_nxt_partial = SSM_st_Remote_Supervision_SM1;
      outC->SM1_state_nxt = _4_SM1_state_nxt_partial;
      break;
    case SSM_st_Available_SM1 :
      _3_SM1_fired_partial = outC->SM1_fired_strong;
      _2_SM1_reset_nxt_partial = kcg_false;
      _1_SM1_state_nxt_partial = SSM_st_Available_SM1;
      outC->SM1_state_nxt = _1_SM1_state_nxt_partial;
      break;
    case SSM_st_Connecting_SM1 :
      SM1_fired_partial = outC->SM1_fired_strong;
      SM1_reset_nxt_partial = kcg_false;
      SM1_state_nxt_partial = SSM_st_Connecting_SM1;
      outC->SM1_state_nxt = SM1_state_nxt_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  SM1_reset_sel = outC->SM1_reset_nxt;
  /* SM1: */
  switch (outC->SM1_state_act) {
    case SSM_st_Intitial_SM1 :
      outC->SM1_reset_nxt = _17_SM1_reset_nxt_partial;
      outC->SM1_fired = _18_SM1_fired_partial;
      break;
    case SSM_st_InterruptedRemoteControl_SM1 :
      outC->SM1_reset_nxt = _14_SM1_reset_nxt_partial;
      outC->SM1_fired = _15_SM1_fired_partial;
      break;
    case SSM_st_InterruptedRemoteSupervision_SM1 :
      outC->SM1_reset_nxt = _11_SM1_reset_nxt_partial;
      outC->SM1_fired = _12_SM1_fired_partial;
      break;
    case SSM_st_Remote_Control_SM1 :
      outC->SM1_reset_nxt = _8_SM1_reset_nxt_partial;
      outC->SM1_fired = _9_SM1_fired_partial;
      break;
    case SSM_st_Remote_Supervision_SM1 :
      outC->SM1_reset_nxt = _5_SM1_reset_nxt_partial;
      outC->SM1_fired = _6_SM1_fired_partial;
      break;
    case SSM_st_Available_SM1 :
      outC->SM1_reset_nxt = _2_SM1_reset_nxt_partial;
      outC->SM1_fired = _3_SM1_fired_partial;
      break;
    case SSM_st_Connecting_SM1 :
      outC->SM1_reset_nxt = SM1_reset_nxt_partial;
      outC->SM1_fired = SM1_fired_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  switch (outC->SM1_state_sel) {
    case SSM_st_Intitial_SM1 :
      _35_SM1_reset_act_partial = tr_1_guard_Intitial_SM1;
      break;
    case SSM_st_InterruptedRemoteControl_SM1 :
      if (tr_1_guard_InterruptedRemoteControl_SM1) {
        _32_SM1_reset_act_partial = kcg_true;
      }
      else if (tr_2_guard_InterruptedRemoteControl_SM1) {
        _32_SM1_reset_act_partial = kcg_true;
      }
      else {
        _32_SM1_reset_act_partial = tr_3_guard_InterruptedRemoteControl_SM1;
      }
      break;
    case SSM_st_InterruptedRemoteSupervision_SM1 :
      if (tr_1_guard_InterruptedRemoteSupervision_SM1) {
        _29_SM1_reset_act_partial = kcg_true;
      }
      else {
        _29_SM1_reset_act_partial = tr_2_guard_InterruptedRemoteSupervision_SM1;
      }
      break;
    case SSM_st_Remote_Control_SM1 :
      if (tr_1_guard_Remote_Control_SM1) {
        _26_SM1_reset_act_partial = kcg_true;
      }
      else if (tr_2_guard_Remote_Control_SM1) {
        _26_SM1_reset_act_partial = kcg_true;
      }
      else {
        _26_SM1_reset_act_partial = tr_3_guard_Remote_Control_SM1;
      }
      break;
    case SSM_st_Remote_Supervision_SM1 :
      if (tr_1_guard_Remote_Supervision_SM1) {
        _23_SM1_reset_act_partial = kcg_true;
      }
      else if (tr_2_guard_Remote_Supervision_SM1) {
        _23_SM1_reset_act_partial = kcg_true;
      }
      else {
        _23_SM1_reset_act_partial = tr_3_guard_Remote_Supervision_SM1;
      }
      break;
    case SSM_st_Available_SM1 :
      _20_SM1_reset_act_partial = tr_1_guard_Available_SM1;
      break;
    case SSM_st_Connecting_SM1 :
      SM1_reset_act_partial = tr_1_guard_Connecting_SM1;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  SM1_reset_prv = outC->SM1_reset_act;
  /* SM1: */
  switch (outC->SM1_state_sel) {
    case SSM_st_Intitial_SM1 :
      outC->SM1_reset_act = _35_SM1_reset_act_partial;
      break;
    case SSM_st_InterruptedRemoteControl_SM1 :
      outC->SM1_reset_act = _32_SM1_reset_act_partial;
      break;
    case SSM_st_InterruptedRemoteSupervision_SM1 :
      outC->SM1_reset_act = _29_SM1_reset_act_partial;
      break;
    case SSM_st_Remote_Control_SM1 :
      outC->SM1_reset_act = _26_SM1_reset_act_partial;
      break;
    case SSM_st_Remote_Supervision_SM1 :
      outC->SM1_reset_act = _23_SM1_reset_act_partial;
      break;
    case SSM_st_Available_SM1 :
      outC->SM1_reset_act = _20_SM1_reset_act_partial;
      break;
    case SSM_st_Connecting_SM1 :
      outC->SM1_reset_act = SM1_reset_act_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  outC->_L6 = kcg_false;
  outC->to_Diagnostic_Platform = outC->_L6;
  outC->to_ETCS_OB = outC->_L6;
  outC->to_FVA_int2 = outC->_L6;
  outC->to_FVA_ss139 = outC->_L6;
  outC->to_RM = outC->_L6;
  outC->_L5 = from_Diagnostic_Platform;
  _40_noname = outC->_L5;
  outC->_L4 = from_ETCS_OB;
  _39_noname = outC->_L4;
  outC->_L3 = from_FVA_int2;
  _38_noname = outC->_L3;
  outC->_L2 = from_FVA_ss139;
  _37_noname = outC->_L2;
  outC->_L1 = from_RM;
  noname = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void RSC_OB_init(outC_RSC_OB *outC)
{
  outC->_L7 = kcg_true;
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->RSC_PowerOn = kcg_true;
  outC->SM1_fired = _4_SSM_TR_no_trans_SM1;
  outC->SM1_fired_strong = _4_SSM_TR_no_trans_SM1;
  outC->SM1_state_act = SSM_st_Connecting_SM1;
  outC->SM1_state_sel = SSM_st_Connecting_SM1;
  outC->to_Diagnostic_Platform = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->to_FVA_int2 = kcg_true;
  outC->to_FVA_ss139 = kcg_true;
  outC->to_RM = kcg_true;
  outC->SM1_reset_act = kcg_false;
  outC->SM1_reset_nxt = kcg_false;
  outC->SM1_state_nxt = SSM_st_Intitial_SM1;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void RSC_OB_reset(outC_RSC_OB *outC)
{
  outC->SM1_reset_act = kcg_false;
  outC->SM1_reset_nxt = kcg_false;
  outC->SM1_state_nxt = SSM_st_Intitial_SM1;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RSC_OB.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

