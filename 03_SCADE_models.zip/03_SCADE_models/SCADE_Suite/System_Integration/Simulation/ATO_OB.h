/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _ATO_OB_H_
#define _ATO_OB_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_ETCS_OB/ */ to_ETCS_OB;
  kcg_bool /* to_Driving_Style_Engine_ss139/ */ to_Driving_Style_Engine_ss139;
  kcg_bool /* to_Diagnostic_Platform/ */ to_Diagnostic_Platform;
  kcg_bool /* to_Driving_Style_Engine_C15/ */ to_Driving_Style_Engine_C15;
  ATO_Packet /* to_RM/ */ to_RM;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_bool /* SM1:Power_On:SM2: */ SM2_reset_nxt_Power_On_SM1;
  kcg_bool /* SM1:Power_On:SM2: */ SM2_reset_act_Power_On_SM1;
  SSM_ST_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_state_nxt_Power_On_SM1;
  _2_SSM_ST_SM1 /* SM1: */ SM1_state_nxt;
  kcg_bool /* SM1: */ SM1_reset_act;
  kcg_bool /* SM1: */ SM1_reset_nxt;
  kcg_int8 /* ATO_State/ */ ATO_State;
  kcg_bool /* ATO_Data_Received/ */ ATO_Data_Received;
  kcg_bool /* Override_Switch_State/ */ Override_Switch_State;
  kcg_bool /* Journey_Profile_Received/ */ Journey_Profile_Received;
  kcg_int8 /* ATO_Mode_Selected/ */ ATO_Mode_Selected;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ------------------ clocks of observable data -------------------- */
  SSM_ST_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_clock_Power_On_SM1;
  SSM_ST_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ _1_SM2_clock_Power_On_SM1;
  kcg_bool /* SM1:Power_On:SM2:ATO_Available: */ ATO_Available_weakb_clock_SM2_Power_On_SM1;
  kcg_bool /* SM1:Power_On:SM2:ATO_Not_Available: */ ATO_Not_Available_weakb_clock_SM2_Power_On_SM1;
  _2_SSM_ST_SM1 /* SM1: */ SM1_state_act;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_int8 /* SM1:No_Power:_L2/ */ _L2_No_Power_SM1;
  SSM_TR_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_fired_Power_On_SM1;
  SSM_TR_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_fired_strong_Power_On_SM1;
  SSM_ST_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_state_act_Power_On_SM1;
  SSM_ST_SM2_Power_On_SM1 /* SM1:Power_On:SM2: */ SM2_state_sel_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Disengaging:_L2/ */ _L2_ATO_Disengaging_SM2_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Engaged:_L2/ */ _L2_ATO_Engaged_SM2_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Ready:_L3/ */ _L3_ATO_Ready_SM2_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Available:_L4/ */ _L4_ATO_Available_SM2_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Not_Available:_L2/ */ _L2_ATO_Not_Available_SM2_Power_On_SM1;
  kcg_int8 /* SM1:Power_On:SM2:ATO_Configuration:_L3/ */ _L3_ATO_Configuration_SM2_Power_On_SM1;
  kcg_int8 /* SM1:ATO_Failure:_L2/ */ _L2_ATO_Failure_SM1;
  _2_SSM_ST_SM1 /* SM1: */ SM1_state_sel;
  _3_SSM_TR_SM1 /* SM1: */ SM1_fired_strong;
  _3_SSM_TR_SM1 /* SM1: */ SM1_fired;
  kcg_bool /* ATO_Power_On/ */ ATO_Power_On;
  kcg_bool /* ATO_Active_VM/ */ ATO_Active_VM;
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  ETCSATOPacket /* _L3/ */ _L3;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  ATO_Packet /* _L14/ */ _L14;
  kcg_bool /* _L32/ */ _L32;
  kcg_bool /* _L31/ */ _L31;
  kcg_int8 /* _L30/ */ _L30;
  kcg_int8 /* _L29/ */ _L29;
  kcg_bool /* _L28/ */ _L28;
  kcg_bool /* _L27/ */ _L27;
  ATO_Packet /* _L33/ */ _L33;
  kcg_int8 /* _L34/ */ _L34;
  kcg_int8 /* _L36/ */ _L36;
  kcg_bool /* _L35/ */ _L35;
  kcg_bool /* _L37/ */ _L37;
  kcg_int8 /* _L38/ */ _L38;
  kcg_bool /* _L39/ */ _L39;
  kcg_bool /* _L40/ */ _L40;
  kcg_bool /* _L41/ */ _L41;
  kcg_bool /* _L43/ */ _L43;
  ATO_modes /* _L46/ */ _L46;
  kcg_bool /* _L45/ */ _L45;
  kcg_bool /* _L47/ */ _L47;
} outC_ATO_OB;

/* ===========  node initialization and cycle functions  =========== */
/* ATO_OB/ */
extern void ATO_OB(
  /* OnSwitch_GUI/ */
  kcg_bool OnSwitch_GUI,
  /* from_ETCS_OB/ */
  ETCSATOPacket *from_ETCS_OB,
  /* from_Driving_Style_Engine_C15/ */
  kcg_bool from_Driving_Style_Engine_C15,
  /* from_Driving_Style_Engine_ss139/ */
  kcg_bool from_Driving_Style_Engine_ss139,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_RM/ */
  ATO_Packet *from_RM,
  outC_ATO_OB *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void ATO_OB_reset(outC_ATO_OB *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void ATO_OB_init(outC_ATO_OB *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _ATO_OB_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ATO_OB.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

