/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Radio_Management_H_
#define _Radio_Management_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ATO_Packet /* to_ATO_OB/ */ to_ATO_OB;
  ATO_Packet /* to_ATO_TS_ss126/ */ to_ATO_TS_ss126;
  kcg_bool /* to_RSC_TS/ */ to_RSC_TS;
  kcg_bool /* to_ETCS_OB/ */ to_ETCS_OB;
  kcg_bool /* to_DiagnosticPlatform/ */ to_DiagnosticPlatform;
  kcg_bool /* to_Diagnostics_TS/ */ to_Diagnostics_TS;
  kcg_bool /* to_ETCS_TS/ */ to_ETCS_TS;
  kcg_bool /* to_RSC_OB/ */ to_RSC_OB;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  ATO_Packet /* from_ATO_TS_ss126/ */ mem_from_ATO_TS_ss126;
  ATO_Packet /* from_ATO_OB/ */ mem_from_ATO_OB;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  ATO_Packet /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
  kcg_bool /* _L3/ */ _L3;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L6/ */ _L6;
  ATO_Packet /* _L7/ */ _L7;
  kcg_bool /* _L8/ */ _L8;
  kcg_bool /* _L9/ */ _L9;
} outC_Radio_Management;

/* ===========  node initialization and cycle functions  =========== */
/* Radio_Management/ */
extern void Radio_Management(
  /* from_ATO_TS_ss126/ */
  ATO_Packet *from_ATO_TS_ss126,
  /* from_RSC_TS/ */
  kcg_bool from_RSC_TS,
  /* from_ETSC_OB/ */
  kcg_bool from_ETSC_OB,
  /* from_DiagnosticPlatform/ */
  kcg_bool from_DiagnosticPlatform,
  /* from_Diagnostics_TS/ */
  kcg_bool from_Diagnostics_TS,
  /* from_ETCS_TS/ */
  kcg_bool from_ETCS_TS,
  /* from_ATO_OB/ */
  ATO_Packet *from_ATO_OB,
  /* from_RSC_OB/ */
  kcg_bool from_RSC_OB,
  outC_Radio_Management *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Radio_Management_reset(outC_Radio_Management *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Radio_Management_init(outC_Radio_Management *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Radio_Management_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Radio_Management.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

