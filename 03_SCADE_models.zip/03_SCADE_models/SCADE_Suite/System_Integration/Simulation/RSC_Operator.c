/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "RSC_Operator.h"

/* RSC_Operator/ */
void RSC_Operator(
  /* from_Perception_TS/ */
  kcg_bool from_Perception_TS,
  /* from_RSC_TS/ */
  kcg_bool from_RSC_TS,
  outC_RSC_Operator *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;

  outC->_L3 = from_RSC_TS;
  _1_noname = outC->_L3;
  outC->_L2 = kcg_false;
  outC->to_RSC_TS = outC->_L2;
  outC->_L1 = from_Perception_TS;
  noname = outC->_L1;
  outC->to_Perception_TS = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void RSC_Operator_init(outC_RSC_Operator *outC)
{
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_RSC_TS = kcg_true;
  outC->to_Perception_TS = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void RSC_Operator_reset(outC_RSC_Operator *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RSC_Operator.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

