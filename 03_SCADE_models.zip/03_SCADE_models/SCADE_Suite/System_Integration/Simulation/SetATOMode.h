/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _SetATOMode_H_
#define _SetATOMode_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ATO_modes /* ATOMode/ */ ATOMode;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  ATO_modes /* temp_ATOMode/ */ temp_ATOMode;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L38/ */ _L38;
  kcg_bool /* _L37/ */ _L37;
  ATO_modes /* _L36/ */ _L36;
  kcg_bool /* _L35/ */ _L35;
  ATO_modes /* _L34/ */ _L34;
  ATO_modes /* _L33/ */ _L33;
  ATO_modes /* _L32/ */ _L32;
  ETCS_HMI_MsgHeaders /* _L28/ */ _L28;
  ETCS_HMI_Msgs /* _L29/ */ _L29;
  ETCS_modes /* _L30/ */ _L30;
  ATO_modes /* _L31/ */ _L31;
  ETCSHMIPacket /* _L27/ */ _L27;
  ETCSHMIPacketDataType /* _L40/ */ _L40;
  kcg_bool /* _L39/ */ _L39;
  kcg_bool /* _L41/ */ _L41;
} outC_SetATOMode;

/* ===========  node initialization and cycle functions  =========== */
/* SetATOMode/ */
extern void SetATOMode(
  /* Input/ */
  ETCSHMIPacket *Input,
  outC_SetATOMode *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void SetATOMode_reset(outC_SetATOMode *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void SetATOMode_init(outC_SetATOMode *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _SetATOMode_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SetATOMode.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

