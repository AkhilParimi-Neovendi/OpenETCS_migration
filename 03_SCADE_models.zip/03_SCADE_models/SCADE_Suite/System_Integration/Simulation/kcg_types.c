/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_types.h"

#ifdef kcg_use_array_int32_4
kcg_bool kcg_comp_array_int32_4(array_int32_4 *kcg_c1, array_int32_4 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_int32_4 */

#ifdef kcg_use_array_bool_6
kcg_bool kcg_comp_array_bool_6(array_bool_6 *kcg_c1, array_bool_6 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 6; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_6 */

#ifdef kcg_use_array_float32_4
kcg_bool kcg_comp_array_float32_4(
  array_float32_4 *kcg_c1,
  array_float32_4 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_float32_4 */

#ifdef kcg_use_array_int32_1
kcg_bool kcg_comp_array_int32_1(array_int32_1 *kcg_c1, array_int32_1 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 1; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_int32_1 */

#ifdef kcg_use_array_bool_1
kcg_bool kcg_comp_array_bool_1(array_bool_1 *kcg_c1, array_bool_1 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 1; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_1 */

#ifdef kcg_use_array_float32_1
kcg_bool kcg_comp_array_float32_1(
  array_float32_1 *kcg_c1,
  array_float32_1 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 1; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_float32_1 */

#ifdef kcg_use_array_bool_5
kcg_bool kcg_comp_array_bool_5(array_bool_5 *kcg_c1, array_bool_5 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 5; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_5 */

#ifdef kcg_use_array_char_30
kcg_bool kcg_comp_array_char_30(array_char_30 *kcg_c1, array_char_30 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 30; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_char_30 */

#ifdef kcg_use_array_bool_4
kcg_bool kcg_comp_array_bool_4(array_bool_4 *kcg_c1, array_bool_4 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_4 */

#ifdef kcg_use_array_int32_5
kcg_bool kcg_comp_array_int32_5(array_int32_5 *kcg_c1, array_int32_5 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 5; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_int32_5 */

#ifdef kcg_use_array_float32_5
kcg_bool kcg_comp_array_float32_5(
  array_float32_5 *kcg_c1,
  array_float32_5 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 5; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_float32_5 */

#ifdef kcg_use_array_bool_3
kcg_bool kcg_comp_array_bool_3(array_bool_3 *kcg_c1, array_bool_3 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 3; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_3 */

#ifdef kcg_use_struct_11492
kcg_bool kcg_comp_struct_11492(struct_11492 *kcg_c1, struct_11492 *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array_bool_3(&kcg_c1->items, &kcg_c2->items);
  kcg_equ = kcg_equ & (kcg_c1->idx == kcg_c2->idx);
  return kcg_equ;
}
#endif /* kcg_use_struct_11492 */

#ifdef kcg_use_ATO_Packet
kcg_bool kcg_comp_ATO_Packet(ATO_Packet *kcg_c1, ATO_Packet *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Value == kcg_c2->Value);
  kcg_equ = kcg_equ & (kcg_c1->Header == kcg_c2->Header);
  return kcg_equ;
}
#endif /* kcg_use_ATO_Packet */

#ifdef kcg_use_ETCSATOPacket
kcg_bool kcg_comp_ETCSATOPacket(ETCSATOPacket *kcg_c1, ETCSATOPacket *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->temp_Override_SwitchState ==
      kcg_c2->temp_Override_SwitchState);
  kcg_equ = kcg_equ & (kcg_c1->ATO_DataAcknowledged ==
      kcg_c2->ATO_DataAcknowledged);
  kcg_equ = kcg_equ & (kcg_c1->ATO_selected_mode == kcg_c2->ATO_selected_mode);
  return kcg_equ;
}
#endif /* kcg_use_ETCSATOPacket */

#ifdef kcg_use_Tain_Physics_Outputs
kcg_bool kcg_comp_Tain_Physics_Outputs(
  Tain_Physics_Outputs *kcg_c1,
  Tain_Physics_Outputs *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Train_Acceleration == kcg_c2->Train_Acceleration);
  kcg_equ = kcg_equ & (kcg_c1->Train_Speed == kcg_c2->Train_Speed);
  kcg_equ = kcg_equ & (kcg_c1->Distance_Covered == kcg_c2->Distance_Covered);
  return kcg_equ;
}
#endif /* kcg_use_Tain_Physics_Outputs */

#ifdef kcg_use_struct_11590
kcg_bool kcg_comp_struct_11590(struct_11590 *kcg_c1, struct_11590 *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array_bool_6(&kcg_c1->items, &kcg_c2->items);
  kcg_equ = kcg_equ & (kcg_c1->idx == kcg_c2->idx);
  return kcg_equ;
}
#endif /* kcg_use_struct_11590 */

#ifdef kcg_use_FVAHMIPacket
kcg_bool kcg_comp_FVAHMIPacket(FVAHMIPacket *kcg_c1, FVAHMIPacket *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->ATORSCSwitch == kcg_c2->ATORSCSwitch);
  kcg_equ = kcg_equ & (kcg_c1->OverrideSwitch == kcg_c2->OverrideSwitch);
  return kcg_equ;
}
#endif /* kcg_use_FVAHMIPacket */

#ifdef kcg_use_ETCSHMIPacket
kcg_bool kcg_comp_ETCSHMIPacket(ETCSHMIPacket *kcg_c1, ETCSHMIPacket *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_ETCSHMIPacketDataType(
      &kcg_c1->ETCSHMIPacketData,
      &kcg_c2->ETCSHMIPacketData);
  kcg_equ = kcg_equ & (kcg_c1->currentATOmode == kcg_c2->currentATOmode);
  kcg_equ = kcg_equ & (kcg_c1->currentETCSmode == kcg_c2->currentETCSmode);
  kcg_equ = kcg_equ & (kcg_c1->Message == kcg_c2->Message);
  kcg_equ = kcg_equ & (kcg_c1->Header == kcg_c2->Header);
  kcg_equ = kcg_equ & (kcg_c1->isvalid == kcg_c2->isvalid);
  return kcg_equ;
}
#endif /* kcg_use_ETCSHMIPacket */

#ifdef kcg_use_LCF_Data
kcg_bool kcg_comp_LCF_Data(LCF_Data *kcg_c1, LCF_Data *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array_float32_5(
      &kcg_c1->LCF_Values,
      &kcg_c2->LCF_Values);
  return kcg_equ;
}
#endif /* kcg_use_LCF_Data */

#ifdef kcg_use_ExternalindicatorStates
kcg_bool kcg_comp_ExternalindicatorStates(
  ExternalindicatorStates *kcg_c1,
  ExternalindicatorStates *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->GreenLight == kcg_c2->GreenLight);
  kcg_equ = kcg_equ & (kcg_c1->RedLight == kcg_c2->RedLight);
  kcg_equ = kcg_equ & (kcg_c1->IndicatorState == kcg_c2->IndicatorState);
  return kcg_equ;
}
#endif /* kcg_use_ExternalindicatorStates */

#ifdef kcg_use_ETCSHMIPacketDataType
kcg_bool kcg_comp_ETCSHMIPacketDataType(
  ETCSHMIPacketDataType *kcg_c1,
  ETCSHMIPacketDataType *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->label8 == kcg_c2->label8);
  kcg_equ = kcg_equ & (kcg_c1->label7 == kcg_c2->label7);
  kcg_equ = kcg_equ & (kcg_c1->label6 == kcg_c2->label6);
  kcg_equ = kcg_equ & (kcg_c1->label5 == kcg_c2->label5);
  kcg_equ = kcg_equ & (kcg_c1->label4 == kcg_c2->label4);
  kcg_equ = kcg_equ & (kcg_c1->label3 == kcg_c2->label3);
  kcg_equ = kcg_equ & (kcg_c1->label2 == kcg_c2->label2);
  kcg_equ = kcg_equ & (kcg_c1->label1 == kcg_c2->label1);
  return kcg_equ;
}
#endif /* kcg_use_ETCSHMIPacketDataType */

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

