/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Driving_Style_Engine.h"

/* Driving_Style_Engine/ */
void Driving_Style_Engine(
  /* from_FVA/ */
  kcg_bool from_FVA,
  /* from_ATO_OB_ss139/ */
  kcg_bool from_ATO_OB_ss139,
  /* from_ATO_OB_C15/ */
  kcg_bool from_ATO_OB_C15,
  outC_Driving_Style_Engine *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;
  kcg_bool _2_noname;

  outC->_L5 = kcg_false;
  outC->to_ATO_OB_ss139 = outC->_L5;
  outC->to_ATO_OB_C15 = outC->_L5;
  outC->to_FVA = outC->_L5;
  outC->_L3 = from_ATO_OB_C15;
  _2_noname = outC->_L3;
  outC->_L2 = from_ATO_OB_ss139;
  _1_noname = outC->_L2;
  outC->_L1 = from_FVA;
  noname = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void Driving_Style_Engine_init(outC_Driving_Style_Engine *outC)
{
  outC->_L5 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_ATO_OB_C15 = kcg_true;
  outC->to_ATO_OB_ss139 = kcg_true;
  outC->to_FVA = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Driving_Style_Engine_reset(outC_Driving_Style_Engine *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Driving_Style_Engine.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

