/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _ExternalStatusIndicator_Internal_functions_H_
#define _ExternalStatusIndicator_Internal_functions_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ExternalindicatorStates /* ExternalIndicationOut/ */ ExternalIndicationOut;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  struct_11492 /* IfBlock1:else:else:else:then:_L6= */ fby_3;
  struct_11590 /* IfBlock1:else:else:then:_L5= */ fby_1;
  kcg_bool init;
  kcg_bool init1;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* IfBlock1:else: */ else_clock_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else: */ else_clock_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else: */ else_clock_else_IfBlock1;
  kcg_bool /* IfBlock1: */ IfBlock1_clock;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* IfBlock1:then:_L1/ */ _L1_then_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L6/ */ _L6_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L2/ */ _L2_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L3/ */ _L3_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L4/ */ _L4_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L5/ */ _L5_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:then:_L1/ */ _L1_then_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:else:_L2/ */ _L2_else_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L1/ */ _L1_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L8/ */ _L8_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L7/ */ _L7_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L6/ */ _L6_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L5/ */ _L5_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:else:else:then:_L9/ */ _L9_then_else_else_else_IfBlock1;
  kcg_bool /* IfBlock1:else:then:_L1/ */ _L1_then_else_IfBlock1;
  kcg_bool /* IfBlock1:else:then:_L2/ */ _L2_then_else_IfBlock1;
  kcg_int8 /* Mem_State/ */ Mem_State;
  kcg_bool /* Red_light/ */ Red_light;
  kcg_bool /* Green_light/ */ Green_light;
  Override_Switch_State /* local_OverrideState/ */ local_OverrideState;
  kcg_int8 /* _L1/ */ _L1;
  kcg_int8 /* _L2/ */ _L2;
  kcg_bool /* _L3/ */ _L3;
  kcg_bool /* _L4/ */ _L4;
  ExternalindicatorStates /* _L5/ */ _L5;
  Override_Switch_State /* _L6/ */ _L6;
} outC_ExternalStatusIndicator_Internal_functions;

/* ===========  node initialization and cycle functions  =========== */
/* Internal_functions::ExternalStatusIndicator/ */
extern void ExternalStatusIndicator_Internal_functions(
  /* IndicationState_in/ */
  kcg_int8 IndicationState_in,
  /* Overrideswitchstate/ */
  Override_Switch_State Overrideswitchstate,
  outC_ExternalStatusIndicator_Internal_functions *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void ExternalStatusIndicator_reset_Internal_functions(
  outC_ExternalStatusIndicator_Internal_functions *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void ExternalStatusIndicator_init_Internal_functions(
  outC_ExternalStatusIndicator_Internal_functions *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _ExternalStatusIndicator_Internal_functions_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ExternalStatusIndicator_Internal_functions.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

