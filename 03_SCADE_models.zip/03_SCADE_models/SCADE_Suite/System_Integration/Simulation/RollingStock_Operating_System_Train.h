/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _RollingStock_Operating_System_Train_H_
#define _RollingStock_Operating_System_Train_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_FVA/ */ to_FVA;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
} outC_RollingStock_Operating_System_Train;

/* ===========  node initialization and cycle functions  =========== */
/* Train::RollingStock_Operating_System/ */
extern void RollingStock_Operating_System_Train(
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_RollingStock_Operating_System_Train *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void RollingStock_Operating_System_reset_Train(
  outC_RollingStock_Operating_System_Train *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void RollingStock_Operating_System_init_Train(
  outC_RollingStock_Operating_System_Train *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _RollingStock_Operating_System_Train_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** RollingStock_Operating_System_Train.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

