/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Functional_Vehicle_Adapter.h"

/* Functional_Vehicle_Adapter/ */
void Functional_Vehicle_Adapter(
  /* from_Perception_OB/ */
  kcg_bool from_Perception_OB,
  /* from_Train_Driver/ */
  FVAHMIPacket *from_Train_Driver,
  /* from_OpenIO_interface/ */
  kcg_bool from_OpenIO_interface,
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_Driving_Style_Engine/ */
  kcg_bool from_Driving_Style_Engine,
  /* from_Vehicle_Management_System/ */
  kcg_bool from_Vehicle_Management_System,
  /* from_Diagnostic_Platform/ */
  kcg_bool from_Diagnostic_Platform,
  /* from_Open_Vehicle_Bus/ */
  kcg_bool from_Open_Vehicle_Bus,
  /* from_RSC_OB_int2/ */
  kcg_bool from_RSC_OB_int2,
  /* from_RSC_OB_ss139/ */
  kcg_bool from_RSC_OB_ss139,
  outC_Functional_Vehicle_Adapter *outC)
{
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM OverrideSwitch_SM_state_nxt_partial;
  /* OverrideSwitch_SM: */
  kcg_bool OverrideSwitch_SM_reset_nxt_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM OverrideSwitch_SM_fired_partial;
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM _1_OverrideSwitch_SM_state_nxt_partial;
  /* OverrideSwitch_SM: */
  kcg_bool _2_OverrideSwitch_SM_reset_nxt_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM _3_OverrideSwitch_SM_fired_partial;
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM _4_OverrideSwitch_SM_state_nxt_partial;
  /* OverrideSwitch_SM: */
  kcg_bool _5_OverrideSwitch_SM_reset_nxt_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM _6_OverrideSwitch_SM_fired_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 ExternalIndicatorState_partial;
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM OverrideSwitch_SM_state_act_partial;
  /* OverrideSwitch_SM: */
  kcg_bool OverrideSwitch_SM_reset_act_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM OverrideSwitch_SM_fired_strong_partial;
  /* OverrideSwitch_SM:Manual_Mode:<2> */
  kcg_bool tr_2_guard_Manual_Mode_OverrideSwitch_SM;
  /* OverrideSwitch_SM:Manual_Mode:<1> */
  kcg_bool tr_1_guard_Manual_Mode_OverrideSwitch_SM;
  /* ExternalIndicatorState/ */
  kcg_int8 _7_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _8_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _9_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _10_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _11_ExternalIndicatorState_partial;
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM _12_OverrideSwitch_SM_state_act_partial;
  /* OverrideSwitch_SM: */
  kcg_bool _13_OverrideSwitch_SM_reset_act_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM _14_OverrideSwitch_SM_fired_strong_partial;
  /* OverrideSwitch_SM:ATO_Mode:<2> */
  kcg_bool tr_2_guard_ATO_Mode_OverrideSwitch_SM;
  /* OverrideSwitch_SM:ATO_Mode:<1> */
  kcg_bool tr_1_guard_ATO_Mode_OverrideSwitch_SM;
  /* ExternalIndicatorState/ */
  kcg_int8 _15_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _16_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _17_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _18_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _19_ExternalIndicatorState_partial;
  /* OverrideSwitch_SM: */
  SSM_ST_OverrideSwitch_SM _20_OverrideSwitch_SM_state_act_partial;
  /* OverrideSwitch_SM: */
  kcg_bool _21_OverrideSwitch_SM_reset_act_partial;
  /* OverrideSwitch_SM: */
  SSM_TR_OverrideSwitch_SM _22_OverrideSwitch_SM_fired_strong_partial;
  /* OverrideSwitch_SM:RSC_Mode:<2> */
  kcg_bool tr_2_guard_RSC_Mode_OverrideSwitch_SM;
  /* OverrideSwitch_SM:RSC_Mode:<1> */
  kcg_bool tr_1_guard_RSC_Mode_OverrideSwitch_SM;
  /* ExternalIndicatorState/ */
  kcg_int8 _23_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _24_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _25_ExternalIndicatorState_partial;
  /* ExternalIndicatorState/ */
  kcg_int8 _26_ExternalIndicatorState_partial;
  kcg_bool noname;
  kcg_bool _27_noname;
  kcg_bool _28_noname;
  kcg_bool _29_noname;
  kcg_bool _30_noname;
  kcg_bool _31_noname;
  kcg_bool _32_noname;
  kcg_bool _33_noname;
  kcg_bool _34_noname;
  /* OverrideSwitchState/ */
  kcg_bool last_OverrideSwitchState;
  /* ExternalIndicatorState/ */
  kcg_int8 last_ExternalIndicatorState;
  /* OverrideSwitch_SM: */
  kcg_bool OverrideSwitch_SM_reset_sel;
  /* OverrideSwitch_SM: */
  kcg_bool OverrideSwitch_SM_reset_prv;

  last_OverrideSwitchState = outC->OverrideSwitchState;
  last_ExternalIndicatorState = outC->ExternalIndicatorState;
  outC->_L27 = last_OverrideSwitchState;
  kcg_copy_FVAHMIPacket(&outC->_L12, from_Train_Driver);
  outC->_L23 = outC->_L12.OverrideSwitch;
  outC->OverrideSwitchState = outC->_L23;
  outC->_L26 = outC->OverrideSwitchState;
  outC->_L22 = outC->_L12.ATORSCSwitch;
  outC->OverrideSwitch_SM_state_sel = outC->OverrideSwitch_SM_state_nxt;
  outC->ATORSCSwitchState = outC->_L22;
  /* OverrideSwitch_SM: */
  switch (outC->OverrideSwitch_SM_state_sel) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      tr_1_guard_RSC_Mode_OverrideSwitch_SM = outC->ATORSCSwitchState ==
        kcg_lit_int8(1);
      outC->tr_1_clock_RSC_Mode_OverrideSwitch_SM =
        tr_1_guard_RSC_Mode_OverrideSwitch_SM;
      tr_2_guard_RSC_Mode_OverrideSwitch_SM = (outC->ATORSCSwitchState ==
          kcg_lit_int8(0)) | outC->OverrideSwitchState;
      /* OverrideSwitch_SM:RSC_Mode:<1> */
      if (outC->tr_1_clock_RSC_Mode_OverrideSwitch_SM) {
        _26_ExternalIndicatorState_partial = kcg_lit_int8(2);
        _19_ExternalIndicatorState_partial = _26_ExternalIndicatorState_partial;
      }
      else {
        outC->tr_2_clock_RSC_Mode_OverrideSwitch_SM =
          tr_2_guard_RSC_Mode_OverrideSwitch_SM;
        /* OverrideSwitch_SM:RSC_Mode:<2> */
        if (outC->tr_2_clock_RSC_Mode_OverrideSwitch_SM) {
          _23_ExternalIndicatorState_partial = kcg_lit_int8(1);
          _25_ExternalIndicatorState_partial = _23_ExternalIndicatorState_partial;
        }
        else {
          _24_ExternalIndicatorState_partial = last_ExternalIndicatorState;
          _25_ExternalIndicatorState_partial = _24_ExternalIndicatorState_partial;
        }
        _19_ExternalIndicatorState_partial = _25_ExternalIndicatorState_partial;
      }
      outC->ExternalIndicatorState = _19_ExternalIndicatorState_partial;
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      tr_1_guard_ATO_Mode_OverrideSwitch_SM = (outC->ATORSCSwitchState ==
          kcg_lit_int8(0)) | outC->OverrideSwitchState;
      outC->tr_1_clock_ATO_Mode_OverrideSwitch_SM =
        tr_1_guard_ATO_Mode_OverrideSwitch_SM;
      tr_2_guard_ATO_Mode_OverrideSwitch_SM = outC->ATORSCSwitchState ==
        kcg_lit_int8(2);
      /* OverrideSwitch_SM:ATO_Mode:<1> */
      if (outC->tr_1_clock_ATO_Mode_OverrideSwitch_SM) {
        _18_ExternalIndicatorState_partial = kcg_lit_int8(2);
        _11_ExternalIndicatorState_partial = _18_ExternalIndicatorState_partial;
      }
      else {
        outC->tr_2_clock_ATO_Mode_OverrideSwitch_SM =
          tr_2_guard_ATO_Mode_OverrideSwitch_SM;
        /* OverrideSwitch_SM:ATO_Mode:<2> */
        if (outC->tr_2_clock_ATO_Mode_OverrideSwitch_SM) {
          _15_ExternalIndicatorState_partial = kcg_lit_int8(2);
          _17_ExternalIndicatorState_partial = _15_ExternalIndicatorState_partial;
        }
        else {
          _16_ExternalIndicatorState_partial = last_ExternalIndicatorState;
          _17_ExternalIndicatorState_partial = _16_ExternalIndicatorState_partial;
        }
        _11_ExternalIndicatorState_partial = _17_ExternalIndicatorState_partial;
      }
      outC->ExternalIndicatorState = _11_ExternalIndicatorState_partial;
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      tr_1_guard_Manual_Mode_OverrideSwitch_SM = (outC->ATORSCSwitchState ==
          kcg_lit_int8(1)) & (!outC->OverrideSwitchState);
      outC->tr_1_clock_Manual_Mode_OverrideSwitch_SM =
        tr_1_guard_Manual_Mode_OverrideSwitch_SM;
      tr_2_guard_Manual_Mode_OverrideSwitch_SM = (outC->ATORSCSwitchState ==
          kcg_lit_int8(2)) & (!outC->OverrideSwitchState);
      /* OverrideSwitch_SM:Manual_Mode:<1> */
      if (outC->tr_1_clock_Manual_Mode_OverrideSwitch_SM) {
        _10_ExternalIndicatorState_partial = kcg_lit_int8(1);
        ExternalIndicatorState_partial = _10_ExternalIndicatorState_partial;
      }
      else {
        outC->tr_2_clock_Manual_Mode_OverrideSwitch_SM =
          tr_2_guard_Manual_Mode_OverrideSwitch_SM;
        /* OverrideSwitch_SM:Manual_Mode:<2> */
        if (outC->tr_2_clock_Manual_Mode_OverrideSwitch_SM) {
          _7_ExternalIndicatorState_partial = kcg_lit_int8(2);
          _9_ExternalIndicatorState_partial = _7_ExternalIndicatorState_partial;
        }
        else {
          _8_ExternalIndicatorState_partial = last_ExternalIndicatorState;
          _9_ExternalIndicatorState_partial = _8_ExternalIndicatorState_partial;
        }
        ExternalIndicatorState_partial = _9_ExternalIndicatorState_partial;
      }
      outC->ExternalIndicatorState = ExternalIndicatorState_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  outC->_L21 = outC->ExternalIndicatorState;
  /* OverrideSwitch_SM: */
  switch (outC->OverrideSwitch_SM_state_sel) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      if (tr_1_guard_RSC_Mode_OverrideSwitch_SM) {
        _20_OverrideSwitch_SM_state_act_partial = SSM_st_ATO_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_RSC_Mode_OverrideSwitch_SM) {
        _20_OverrideSwitch_SM_state_act_partial = SSM_st_Manual_Mode_OverrideSwitch_SM;
      }
      else {
        _20_OverrideSwitch_SM_state_act_partial = SSM_st_RSC_Mode_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_state_act = _20_OverrideSwitch_SM_state_act_partial;
      if (tr_1_guard_RSC_Mode_OverrideSwitch_SM) {
        _22_OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_RSC_Mode_OverrideSwitch_SM) {
        _22_OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM;
      }
      else {
        _22_OverrideSwitch_SM_fired_strong_partial = SSM_TR_no_trans_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_fired_strong =
        _22_OverrideSwitch_SM_fired_strong_partial;
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      if (tr_1_guard_ATO_Mode_OverrideSwitch_SM) {
        _12_OverrideSwitch_SM_state_act_partial = SSM_st_Manual_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_ATO_Mode_OverrideSwitch_SM) {
        _12_OverrideSwitch_SM_state_act_partial = SSM_st_RSC_Mode_OverrideSwitch_SM;
      }
      else {
        _12_OverrideSwitch_SM_state_act_partial = SSM_st_ATO_Mode_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_state_act = _12_OverrideSwitch_SM_state_act_partial;
      if (tr_1_guard_ATO_Mode_OverrideSwitch_SM) {
        _14_OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_ATO_Mode_OverrideSwitch_SM) {
        _14_OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM;
      }
      else {
        _14_OverrideSwitch_SM_fired_strong_partial = SSM_TR_no_trans_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_fired_strong =
        _14_OverrideSwitch_SM_fired_strong_partial;
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      if (tr_1_guard_Manual_Mode_OverrideSwitch_SM) {
        OverrideSwitch_SM_state_act_partial = SSM_st_ATO_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_Manual_Mode_OverrideSwitch_SM) {
        OverrideSwitch_SM_state_act_partial = SSM_st_RSC_Mode_OverrideSwitch_SM;
      }
      else {
        OverrideSwitch_SM_state_act_partial = SSM_st_Manual_Mode_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_state_act = OverrideSwitch_SM_state_act_partial;
      if (tr_1_guard_Manual_Mode_OverrideSwitch_SM) {
        OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM;
      }
      else if (tr_2_guard_Manual_Mode_OverrideSwitch_SM) {
        OverrideSwitch_SM_fired_strong_partial =
          SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM;
      }
      else {
        OverrideSwitch_SM_fired_strong_partial = SSM_TR_no_trans_OverrideSwitch_SM;
      }
      outC->OverrideSwitch_SM_fired_strong = OverrideSwitch_SM_fired_strong_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  /* OverrideSwitch_SM: */
  switch (outC->OverrideSwitch_SM_state_act) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      _6_OverrideSwitch_SM_fired_partial = outC->OverrideSwitch_SM_fired_strong;
      _5_OverrideSwitch_SM_reset_nxt_partial = kcg_false;
      _4_OverrideSwitch_SM_state_nxt_partial = SSM_st_RSC_Mode_OverrideSwitch_SM;
      outC->OverrideSwitch_SM_state_nxt = _4_OverrideSwitch_SM_state_nxt_partial;
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      _3_OverrideSwitch_SM_fired_partial = outC->OverrideSwitch_SM_fired_strong;
      _2_OverrideSwitch_SM_reset_nxt_partial = kcg_false;
      _1_OverrideSwitch_SM_state_nxt_partial = SSM_st_ATO_Mode_OverrideSwitch_SM;
      outC->OverrideSwitch_SM_state_nxt = _1_OverrideSwitch_SM_state_nxt_partial;
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      OverrideSwitch_SM_fired_partial = outC->OverrideSwitch_SM_fired_strong;
      OverrideSwitch_SM_reset_nxt_partial = kcg_false;
      OverrideSwitch_SM_state_nxt_partial = SSM_st_Manual_Mode_OverrideSwitch_SM;
      outC->OverrideSwitch_SM_state_nxt = OverrideSwitch_SM_state_nxt_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  OverrideSwitch_SM_reset_sel = outC->OverrideSwitch_SM_reset_nxt;
  /* OverrideSwitch_SM: */
  switch (outC->OverrideSwitch_SM_state_act) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_nxt = _5_OverrideSwitch_SM_reset_nxt_partial;
      outC->OverrideSwitch_SM_fired = _6_OverrideSwitch_SM_fired_partial;
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_nxt = _2_OverrideSwitch_SM_reset_nxt_partial;
      outC->OverrideSwitch_SM_fired = _3_OverrideSwitch_SM_fired_partial;
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_nxt = OverrideSwitch_SM_reset_nxt_partial;
      outC->OverrideSwitch_SM_fired = OverrideSwitch_SM_fired_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  switch (outC->OverrideSwitch_SM_state_sel) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      if (tr_1_guard_RSC_Mode_OverrideSwitch_SM) {
        _21_OverrideSwitch_SM_reset_act_partial = kcg_true;
      }
      else {
        _21_OverrideSwitch_SM_reset_act_partial = tr_2_guard_RSC_Mode_OverrideSwitch_SM;
      }
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      if (tr_1_guard_ATO_Mode_OverrideSwitch_SM) {
        _13_OverrideSwitch_SM_reset_act_partial = kcg_true;
      }
      else {
        _13_OverrideSwitch_SM_reset_act_partial = tr_2_guard_ATO_Mode_OverrideSwitch_SM;
      }
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      if (tr_1_guard_Manual_Mode_OverrideSwitch_SM) {
        OverrideSwitch_SM_reset_act_partial = kcg_true;
      }
      else {
        OverrideSwitch_SM_reset_act_partial = tr_2_guard_Manual_Mode_OverrideSwitch_SM;
      }
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  OverrideSwitch_SM_reset_prv = outC->OverrideSwitch_SM_reset_act;
  /* OverrideSwitch_SM: */
  switch (outC->OverrideSwitch_SM_state_sel) {
    case SSM_st_RSC_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_act = _21_OverrideSwitch_SM_reset_act_partial;
      break;
    case SSM_st_ATO_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_act = _13_OverrideSwitch_SM_reset_act_partial;
      break;
    case SSM_st_Manual_Mode_OverrideSwitch_SM :
      outC->OverrideSwitch_SM_reset_act = OverrideSwitch_SM_reset_act_partial;
      break;
    default :
      /* this default branch is unreachable */
      break;
  }
  /* _L19=(Internal_functions::ExternalStatusIndicator#1)/ */
  ExternalStatusIndicator_Internal_functions(
    outC->_L21,
    outC->_L26,
    &outC->Context_ExternalStatusIndicator_1);
  kcg_copy_ExternalindicatorStates(
    &outC->_L19,
    &outC->Context_ExternalStatusIndicator_1.ExternalIndicationOut);
  kcg_copy_ExternalindicatorStates(&outC->to_Train_Driver, &outC->_L19);
  outC->_L5 = kcg_false;
  outC->to_RSC_OB_ss139 = outC->_L5;
  outC->to_RSC_OB_int2 = outC->_L5;
  outC->to_Open_Vehicle_Bus = outC->_L5;
  outC->to_Diagnostic_Platform = outC->_L5;
  outC->to_Vehicle_Management_System = outC->_L5;
  outC->to_OpenIO_interface = outC->_L5;
  outC->_L11 = from_RSC_OB_ss139;
  _34_noname = outC->_L11;
  outC->_L10 = from_RSC_OB_int2;
  _33_noname = outC->_L10;
  outC->_L9 = from_Open_Vehicle_Bus;
  _32_noname = outC->_L9;
  outC->_L8 = from_Diagnostic_Platform;
  _31_noname = outC->_L8;
  outC->_L7 = from_Vehicle_Management_System;
  _30_noname = outC->_L7;
  outC->_L6 = from_OpenIO_interface;
  _29_noname = outC->_L6;
  outC->_L4 = from_ETCS_OB;
  _28_noname = outC->_L4;
  outC->_L2 = from_Perception_OB;
  _27_noname = outC->_L2;
  outC->_L1 = from_Driving_Style_Engine;
  noname = outC->_L1;
  outC->to_ETCS_OB = outC->_L27;
  outC->to_Perception_OB = outC->_L5;
  outC->to_Driving_Style_Engine = outC->_L5;
}

#ifndef KCG_USER_DEFINED_INIT
void Functional_Vehicle_Adapter_init(outC_Functional_Vehicle_Adapter *outC)
{
  outC->_L27 = kcg_true;
  outC->_L26 = kcg_true;
  outC->_L22 = kcg_lit_int8(0);
  outC->_L23 = kcg_true;
  outC->_L21 = kcg_lit_int8(0);
  outC->_L19.IndicatorState = kcg_lit_int8(0);
  outC->_L19.RedLight = kcg_true;
  outC->_L19.GreenLight = kcg_true;
  outC->_L12.OverrideSwitch = kcg_true;
  outC->_L12.ATORSCSwitch = kcg_lit_int8(0);
  outC->_L11 = kcg_true;
  outC->_L10 = kcg_true;
  outC->_L9 = kcg_true;
  outC->_L8 = kcg_true;
  outC->_L7 = kcg_true;
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->ATORSCSwitchState = kcg_lit_int8(0);
  outC->OverrideSwitch_SM_fired = SSM_TR_no_trans_OverrideSwitch_SM;
  outC->OverrideSwitch_SM_fired_strong = SSM_TR_no_trans_OverrideSwitch_SM;
  outC->OverrideSwitch_SM_state_act = SSM_st_Manual_Mode_OverrideSwitch_SM;
  outC->OverrideSwitch_SM_state_sel = SSM_st_Manual_Mode_OverrideSwitch_SM;
  outC->tr_2_clock_RSC_Mode_OverrideSwitch_SM = kcg_true;
  outC->tr_1_clock_RSC_Mode_OverrideSwitch_SM = kcg_true;
  outC->tr_2_clock_ATO_Mode_OverrideSwitch_SM = kcg_true;
  outC->tr_1_clock_ATO_Mode_OverrideSwitch_SM = kcg_true;
  outC->tr_2_clock_Manual_Mode_OverrideSwitch_SM = kcg_true;
  outC->tr_1_clock_Manual_Mode_OverrideSwitch_SM = kcg_true;
  outC->to_RSC_OB_ss139 = kcg_true;
  outC->to_RSC_OB_int2 = kcg_true;
  outC->to_Open_Vehicle_Bus = kcg_true;
  outC->to_Diagnostic_Platform = kcg_true;
  outC->to_Vehicle_Management_System = kcg_true;
  outC->to_OpenIO_interface = kcg_true;
  outC->to_Driving_Style_Engine = kcg_true;
  outC->to_ETCS_OB = kcg_true;
  outC->to_Train_Driver.IndicatorState = kcg_lit_int8(0);
  outC->to_Train_Driver.RedLight = kcg_true;
  outC->to_Train_Driver.GreenLight = kcg_true;
  outC->to_Perception_OB = kcg_true;
  /* _L19=(Internal_functions::ExternalStatusIndicator#1)/ */
  ExternalStatusIndicator_init_Internal_functions(
    &outC->Context_ExternalStatusIndicator_1);
  outC->OverrideSwitch_SM_reset_act = kcg_false;
  outC->OverrideSwitch_SM_reset_nxt = kcg_false;
  outC->OverrideSwitch_SM_state_nxt = SSM_st_Manual_Mode_OverrideSwitch_SM;
  outC->ExternalIndicatorState = int8init;
  outC->OverrideSwitchState = boolinit;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Functional_Vehicle_Adapter_reset(outC_Functional_Vehicle_Adapter *outC)
{
  /* _L19=(Internal_functions::ExternalStatusIndicator#1)/ */
  ExternalStatusIndicator_reset_Internal_functions(
    &outC->Context_ExternalStatusIndicator_1);
  outC->OverrideSwitch_SM_reset_act = kcg_false;
  outC->OverrideSwitch_SM_reset_nxt = kcg_false;
  outC->OverrideSwitch_SM_state_nxt = SSM_st_Manual_Mode_OverrideSwitch_SM;
  outC->ExternalIndicatorState = int8init;
  outC->OverrideSwitchState = boolinit;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Functional_Vehicle_Adapter.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

