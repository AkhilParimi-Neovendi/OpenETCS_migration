/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "F_gradient_External_forces.h"

/* External_forces::F_gradient/ */
void F_gradient_External_forces(
  /* Mass/ */
  kcg_float32 Mass,
  outC_F_gradient_External_forces *outC)
{
  outC->_L5 = Theta;
  outC->_L8 = /* _L8=(mathext::SinR#1)/ */ SinR32_mathext_mathextimpl(outC->_L5);
  outC->_L7 = Mass;
  outC->_L3 = g;
  outC->_L2 = outC->_L7 * outC->_L3 * outC->_L8;
  outC->F_Gradient = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void F_gradient_init_External_forces(outC_F_gradient_External_forces *outC)
{
  outC->_L8 = kcg_lit_float32(0.0);
  outC->_L7 = kcg_lit_float32(0.0);
  outC->_L3 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L5 = kcg_lit_float32(0.0);
  outC->F_Gradient = kcg_lit_float32(0.0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void F_gradient_reset_External_forces(outC_F_gradient_External_forces *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** F_gradient_External_forces.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

