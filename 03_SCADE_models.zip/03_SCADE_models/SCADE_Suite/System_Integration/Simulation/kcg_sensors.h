/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_sensors.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

