/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _Diagnostics_TS_H_
#define _Diagnostics_TS_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* to_RM/ */ to_RM;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* _L1/ */ _L1;
  kcg_bool /* _L2/ */ _L2;
} outC_Diagnostics_TS;

/* ===========  node initialization and cycle functions  =========== */
/* Diagnostics_TS/ */
extern void Diagnostics_TS(
  /* from_RM/ */
  kcg_bool from_RM,
  outC_Diagnostics_TS *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void Diagnostics_TS_reset(outC_Diagnostics_TS *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void Diagnostics_TS_init(outC_Diagnostics_TS *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _Diagnostics_TS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Diagnostics_TS.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

