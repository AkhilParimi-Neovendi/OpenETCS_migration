/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "OpenIO_Interface_Train.h"

/* Train::OpenIO_Interface/ */
void OpenIO_Interface_Train(
  /* from_ETCS_OB/ */
  kcg_bool from_ETCS_OB,
  /* from_FVA/ */
  kcg_bool from_FVA,
  outC_OpenIO_Interface_Train *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;

  outC->_L2 = kcg_false;
  outC->to_FVA = outC->_L2;
  outC->_L3 = from_FVA;
  _1_noname = outC->_L3;
  outC->_L1 = from_ETCS_OB;
  noname = outC->_L1;
  outC->to_ETCS_OB = outC->_L2;
}

#ifndef KCG_USER_DEFINED_INIT
void OpenIO_Interface_init_Train(outC_OpenIO_Interface_Train *outC)
{
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_FVA = kcg_true;
  outC->to_ETCS_OB = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void OpenIO_Interface_reset_Train(outC_OpenIO_Interface_Train *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** OpenIO_Interface_Train.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

