/* System_Integration_mapping.c */

#include "System_Integration_type.h"
#include "System_Integration_interface.h"
#include "System_Integration_mapping.h"

#include "SmuTypes.h"
#include "SmuMapping.h"

#include "kcg_sensors.h"

/* mapping declaration */

#define DECL_ITER(name) extern const MappingIterator iter_##name

DECL_ITER(fold_5);
DECL_ITER(array_1);
DECL_ITER(array_4);
DECL_ITER(map_5);
DECL_ITER(array_5);
DECL_ITER(array_30);

#define DECL_SCOPE(name, count) extern const MappingEntry name##_entries[count]; extern const MappingScope name

DECL_SCOPE(scope_151, 5);
DECL_SCOPE(scope_150, 5);
DECL_SCOPE(scope_149, 3);
DECL_SCOPE(scope_148, 3);
DECL_SCOPE(scope_147, 8);
DECL_SCOPE(scope_146, 8);
DECL_SCOPE(scope_145, 8);
DECL_SCOPE(scope_144, 16);
DECL_SCOPE(scope_143, 13);
DECL_SCOPE(scope_142, 8);
DECL_SCOPE(scope_141, 1);
DECL_SCOPE(scope_140, 1);
DECL_SCOPE(scope_139, 1);
DECL_SCOPE(scope_138, 1);
DECL_SCOPE(scope_137, 35);
DECL_SCOPE(scope_136, 1);
DECL_SCOPE(scope_135, 1);
DECL_SCOPE(scope_134, 5);
DECL_SCOPE(scope_133, 3);
DECL_SCOPE(scope_132, 3);
DECL_SCOPE(scope_131, 19);
DECL_SCOPE(scope_130, 3);
DECL_SCOPE(scope_129, 22);
DECL_SCOPE(scope_128, 6);
DECL_SCOPE(scope_127, 29);
DECL_SCOPE(scope_126, 1);
DECL_SCOPE(scope_125, 1);
DECL_SCOPE(scope_124, 30);
DECL_SCOPE(scope_123, 8);
DECL_SCOPE(scope_122, 7);
DECL_SCOPE(scope_121, 6);
DECL_SCOPE(scope_120, 3);
DECL_SCOPE(scope_119, 9);
DECL_SCOPE(scope_118, 10);
DECL_SCOPE(scope_117, 12);
DECL_SCOPE(scope_116, 3);
DECL_SCOPE(scope_115, 24);
DECL_SCOPE(scope_114, 21);
DECL_SCOPE(scope_113, 1);
DECL_SCOPE(scope_112, 1);
DECL_SCOPE(scope_111, 24);
DECL_SCOPE(scope_110, 9);
DECL_SCOPE(scope_109, 3);
DECL_SCOPE(scope_108, 3);
DECL_SCOPE(scope_107, 3);
DECL_SCOPE(scope_106, 49);
DECL_SCOPE(scope_105, 41);
DECL_SCOPE(scope_104, 3);
DECL_SCOPE(scope_103, 5);
DECL_SCOPE(scope_102, 7);
DECL_SCOPE(scope_101, 5);
DECL_SCOPE(scope_100, 1);
DECL_SCOPE(scope_99, 1);
DECL_SCOPE(scope_98, 1);
DECL_SCOPE(scope_97, 1);
DECL_SCOPE(scope_96, 1);
DECL_SCOPE(scope_95, 3);
DECL_SCOPE(scope_94, 1);
DECL_SCOPE(scope_93, 1);
DECL_SCOPE(scope_92, 2);
DECL_SCOPE(scope_91, 1);
DECL_SCOPE(scope_90, 1);
DECL_SCOPE(scope_89, 1);
DECL_SCOPE(scope_88, 3);
DECL_SCOPE(scope_87, 1);
DECL_SCOPE(scope_86, 1);
DECL_SCOPE(scope_85, 1);
DECL_SCOPE(scope_84, 3);
DECL_SCOPE(scope_83, 1);
DECL_SCOPE(scope_82, 1);
DECL_SCOPE(scope_81, 1);
DECL_SCOPE(scope_80, 1);
DECL_SCOPE(scope_79, 14);
DECL_SCOPE(scope_78, 14);
DECL_SCOPE(scope_77, 17);
DECL_SCOPE(scope_76, 5);
DECL_SCOPE(scope_75, 7);
DECL_SCOPE(scope_74, 1);
DECL_SCOPE(scope_73, 1);
DECL_SCOPE(scope_72, 2);
DECL_SCOPE(scope_71, 1);
DECL_SCOPE(scope_70, 1);
DECL_SCOPE(scope_69, 2);
DECL_SCOPE(scope_68, 1);
DECL_SCOPE(scope_67, 1);
DECL_SCOPE(scope_66, 2);
DECL_SCOPE(scope_65, 10);
DECL_SCOPE(scope_64, 1);
DECL_SCOPE(scope_63, 2);
DECL_SCOPE(scope_62, 6);
DECL_SCOPE(scope_61, 6);
DECL_SCOPE(scope_60, 1);
DECL_SCOPE(scope_59, 3);
DECL_SCOPE(scope_58, 3);
DECL_SCOPE(scope_57, 3);
DECL_SCOPE(scope_56, 3);
DECL_SCOPE(scope_55, 12);
DECL_SCOPE(scope_54, 32);
DECL_SCOPE(scope_53, 3);
DECL_SCOPE(scope_52, 3);
DECL_SCOPE(scope_51, 4);
DECL_SCOPE(scope_50, 4);
DECL_SCOPE(scope_49, 2);
DECL_SCOPE(scope_48, 3);
DECL_SCOPE(scope_47, 3);
DECL_SCOPE(scope_46, 3);
DECL_SCOPE(scope_45, 56);
DECL_SCOPE(scope_44, 17);
DECL_SCOPE(scope_43, 17);
DECL_SCOPE(scope_42, 39);
DECL_SCOPE(scope_41, 7);
DECL_SCOPE(scope_40, 3);
DECL_SCOPE(scope_39, 11);
DECL_SCOPE(scope_38, 12);
DECL_SCOPE(scope_37, 1);
DECL_SCOPE(scope_36, 2);
DECL_SCOPE(scope_35, 1);
DECL_SCOPE(scope_34, 1);
DECL_SCOPE(scope_33, 3);
DECL_SCOPE(scope_32, 1);
DECL_SCOPE(scope_31, 1);
DECL_SCOPE(scope_30, 1);
DECL_SCOPE(scope_29, 4);
DECL_SCOPE(scope_28, 1);
DECL_SCOPE(scope_27, 1);
DECL_SCOPE(scope_26, 1);
DECL_SCOPE(scope_25, 4);
DECL_SCOPE(scope_24, 1);
DECL_SCOPE(scope_23, 1);
DECL_SCOPE(scope_22, 3);
DECL_SCOPE(scope_21, 1);
DECL_SCOPE(scope_20, 2);
DECL_SCOPE(scope_19, 1);
DECL_SCOPE(scope_18, 2);
DECL_SCOPE(scope_17, 13);
DECL_SCOPE(scope_16, 1);
DECL_SCOPE(scope_15, 1);
DECL_SCOPE(scope_14, 3);
DECL_SCOPE(scope_13, 1);
DECL_SCOPE(scope_12, 2);
DECL_SCOPE(scope_11, 10);
DECL_SCOPE(scope_10, 40);
DECL_SCOPE(scope_9, 3);
DECL_SCOPE(scope_8, 2);
DECL_SCOPE(scope_7, 6);
DECL_SCOPE(scope_6, 3);
DECL_SCOPE(scope_5, 2);
DECL_SCOPE(scope_4, 8);
DECL_SCOPE(scope_3, 1);
DECL_SCOPE(scope_2, 3);
DECL_SCOPE(scope_1, 261);
DECL_SCOPE(scope_0, 1);

/* clock definition */

static int isActive_SSM_ST_OverrideSwitch_SM_SSM_st_ATO_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_ST_OverrideSwitch_SM*)pHandle == SSM_st_ATO_Mode_OverrideSwitch_SM; }
static int isActive_SSM_ST_OverrideSwitch_SM_SSM_st_Manual_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_ST_OverrideSwitch_SM*)pHandle == SSM_st_Manual_Mode_OverrideSwitch_SM; }
static int isActive_SSM_ST_OverrideSwitch_SM_SSM_st_RSC_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_ST_OverrideSwitch_SM*)pHandle == SSM_st_RSC_Mode_OverrideSwitch_SM; }
static int isActive_SSM_ST_SM1_SSM_st_Available_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_Available_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_Connecting_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_Connecting_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_InterruptedRemoteControl_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_InterruptedRemoteControl_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_InterruptedRemoteSupervision_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_InterruptedRemoteSupervision_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_Intitial_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_Intitial_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_Remote_Control_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_Remote_Control_SM1; }
static int isActive_SSM_ST_SM1_SSM_st_Remote_Supervision_SM1(void* pHandle) { return *(SSM_ST_SM1*)pHandle == SSM_st_Remote_Supervision_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Available_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Available_SM2_Power_On_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Configuration_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Configuration_SM2_Power_On_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Disengaging_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Disengaging_SM2_Power_On_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Engaged_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Engaged_SM2_Power_On_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Not_Available_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Not_Available_SM2_Power_On_SM1; }
static int isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Ready_SM2_Power_On_SM1(void* pHandle) { return *(SSM_ST_SM2_Power_On_SM1*)pHandle == SSM_st_ATO_Ready_SM2_Power_On_SM1; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM(void* pHandle) { return *(SSM_TR_OverrideSwitch_SM*)pHandle == SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM; }
static int isActive_SSM_TR_SM1_SSM_TR_Available_Remote_Supervision_1_Available_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Available_Remote_Supervision_1_Available_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Connecting_Available_1_Connecting_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Connecting_Available_1_Connecting_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Intitial_Connecting_1_Intitial_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Intitial_Connecting_1_Intitial_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Available_1_Remote_Control_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Control_Available_1_Remote_Control_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1; }
static int isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1; }
static int isActive_SSM_TR_SM1__5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == _5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1; }
static int isActive_SSM_TR_SM1__6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == _6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1; }
static int isActive_SSM_TR_SM1__7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1(void* pHandle) { return *(SSM_TR_SM1*)pHandle == _7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1; }
static int isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1(void* pHandle) { return *(SSM_TR_SM2_Power_On_SM1*)pHandle == SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1; }
static int isActive__2_SSM_ST_SM1_SSM_st_ATO_Failure_SM1(void* pHandle) { return *(_2_SSM_ST_SM1*)pHandle == SSM_st_ATO_Failure_SM1; }
static int isActive__2_SSM_ST_SM1_SSM_st_No_Power_SM1(void* pHandle) { return *(_2_SSM_ST_SM1*)pHandle == SSM_st_No_Power_SM1; }
static int isActive__2_SSM_ST_SM1_SSM_st_Power_On_SM1(void* pHandle) { return *(_2_SSM_ST_SM1*)pHandle == SSM_st_Power_On_SM1; }
static int isActive__3_SSM_TR_SM1_SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1(void* pHandle) { return *(_3_SSM_TR_SM1*)pHandle == SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1; }
static int isActive__3_SSM_TR_SM1_SSM_TR_No_Power_Power_On_1_No_Power_SM1(void* pHandle) { return *(_3_SSM_TR_SM1*)pHandle == SSM_TR_No_Power_Power_On_1_No_Power_SM1; }
static int isActive__3_SSM_TR_SM1_SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1(void* pHandle) { return *(_3_SSM_TR_SM1*)pHandle == SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1; }
static int isActive__3_SSM_TR_SM1_SSM_TR_Power_On_No_Power_1_Power_On_SM1(void* pHandle) { return *(_3_SSM_TR_SM1*)pHandle == SSM_TR_Power_On_No_Power_1_Power_On_SM1; }
static int isActive_kcg_bool_kcg_false(void* pHandle) { return *(kcg_bool*)pHandle == kcg_false; }
static int isActive_kcg_bool_kcg_true(void* pHandle) { return *(kcg_bool*)pHandle == kcg_true; }

/* mapping definition */

const MappingIterator iter_fold_5 = { "fold", 5, 5, NULL };
const MappingIterator iter_array_1 = { "array", 1, 1, NULL };
const MappingIterator iter_array_4 = { "array", 4, 4, NULL };
const MappingIterator iter_map_5 = { "map", 5, 5, NULL };
const MappingIterator iter_array_5 = { "array", 5, 5, NULL };
const MappingIterator iter_array_30 = { "array", 30, 30, NULL };

const MappingEntry scope_151_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_EmergencyBrake_EB_Train, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_Perception_OB", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_EmergencyBrake_EB_Train, to_Perception_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_EmergencyBrake_EB_Train, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_EmergencyBrake_EB_Train, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_EmergencyBrake_EB_Train, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 }
};
const MappingScope scope_151 = {
    "Train::Vehicle_EmergencyBrake_EB/ Vehicle_EmergencyBrake_EB_Train",
    scope_151_entries, 5
};

const MappingEntry scope_150_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_OpenIO_Interface_Train, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_OpenIO_Interface_Train, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_OpenIO_Interface_Train, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_OpenIO_Interface_Train, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_OpenIO_Interface_Train, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 }
};
const MappingScope scope_150 = {
    "Train::OpenIO_Interface/ OpenIO_Interface_Train",
    scope_150_entries, 5
};

const MappingEntry scope_149_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_RollingStock_Operating_System_Train, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_RollingStock_Operating_System_Train, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_RollingStock_Operating_System_Train, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_149 = {
    "Train::RollingStock_Operating_System/ RollingStock_Operating_System_Train",
    scope_149_entries, 3
};

const MappingEntry scope_148_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "to_Vehicle_Management_Systems", NULL, sizeof(kcg_bool), offsetof(outC_ClassB_Systems_Train, to_Vehicle_Management_Systems), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ClassB_Systems_Train, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ClassB_Systems_Train, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_148 = {
    "Train::ClassB_Systems/ ClassB_Systems_Train",
    scope_148_entries, 3
};

const MappingEntry scope_147_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Out_ETCS_Packet", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, Out_ETCS_Packet), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L1), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L3), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(ATO_modes), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L4), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L5), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L6), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_modes), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L7), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Send_GoA4_Selected_ETCSHMI_Functions, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_147 = {
    "ETCSHMI_Functions::Send_GoA4_Selected/ Send_GoA4_Selected_ETCSHMI_Functions",
    scope_147_entries, 8
};

const MappingEntry scope_146_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Out_ETCS_Packet", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, Out_ETCS_Packet), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L1), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L3), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(ATO_modes), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L4), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L5), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L6), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_modes), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L7), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Send_GoA2_Selected_ETCSHMI_Functions, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_146 = {
    "ETCSHMI_Functions::Send_GoA2_Selected/ Send_GoA2_Selected_ETCSHMI_Functions",
    scope_146_entries, 8
};

const MappingEntry scope_145_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Out_ETCS_Packet", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, Out_ETCS_Packet), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L1), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L3), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(ATO_modes), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L4), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L5), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L6), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_modes), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L7), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Send_FS_Selected_ETCSHMI_Functions, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_145 = {
    "ETCSHMI_Functions::Send_FS_Selected/ Send_FS_Selected_ETCSHMI_Functions",
    scope_145_entries, 8
};

const MappingEntry scope_144_entries[16] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, Output1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Math_Operators, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_ForceGradient_Math_Operators, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_ForceGradient_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 }
};
const MappingScope scope_144 = {
    "Math_Operators::ForceGradient/ ForceGradient_Math_Operators",
    scope_144_entries, 16
};

const MappingEntry scope_143_entries[13] = {
    /* 0 */ { MAP_OUTPUT, "TractionForce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, TractionForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "BrakingFroce", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, BrakingFroce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_T_B_Lever_Math_Operators, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L27), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L40), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_float32), offsetof(outC_T_B_Lever_Math_Operators, _L41), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_INSTANCE, "Math_Operators::ForceGradient 2", NULL, sizeof(outC_ForceGradient_Math_Operators), offsetof(outC_T_B_Lever_Math_Operators, Context_ForceGradient_2), NULL, NULL, NULL, &scope_144, 1, 11 },
    /* 12 */ { MAP_INSTANCE, "Math_Operators::ForceGradient 3", NULL, sizeof(outC_ForceGradient_Math_Operators), offsetof(outC_T_B_Lever_Math_Operators, Context_ForceGradient_3), NULL, NULL, NULL, &scope_144, 1, 12 }
};
const MappingScope scope_143 = {
    "Math_Operators::T_B_Lever/ T_B_Lever_Math_Operators",
    scope_143_entries, 13
};

const MappingEntry scope_142_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Sum_of_traction_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, Sum_of_traction_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Sum_of_Braking_forces", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, Sum_of_Braking_forces), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Sum_of_Forces_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Math_Operators, _L6), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_5), offsetof(outC_Sum_of_Forces_Math_Operators, _L7), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 7 }
};
const MappingScope scope_142 = {
    "Math_Operators::Sum_of_Forces/ Sum_of_Forces_Math_Operators",
    scope_142_entries, 8
};

const MappingEntry scope_141_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_141 = {
    "array_bool_4",
    scope_141_entries, 1
};

const MappingEntry scope_140_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_140 = {
    "array_bool_1",
    scope_140_entries, 1
};

const MappingEntry scope_139_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_139 = {
    "array_int32_4",
    scope_139_entries, 1
};

const MappingEntry scope_138_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_138 = {
    "array_int32_1",
    scope_138_entries, 1
};

const MappingEntry scope_137_entries[35] = {
    /* 0 */ { MAP_OUTPUT, "Traction_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Traction_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Braking_force_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Braking_force_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Speed_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Speed_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Accelartion_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Accelartion_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "Mass_Array", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Math_Operators, Mass_Array), &_Type_array_int32_5_Utils, NULL, NULL, &scope_125, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "brakelinepressurearray", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, brakelinepressurearray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "holdingbrakestatus", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Math_Operators, holdingbrakestatus), &_Type_array_bool_5_Utils, NULL, NULL, &scope_126, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L4), &_Type_array_float32_1_Utils, NULL, NULL, &scope_136, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L3", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L3), &_Type_array_float32_4_Utils, NULL, NULL, &scope_135, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L8), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L7), &_Type_array_float32_1_Utils, NULL, NULL, &scope_136, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L6", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L6), &_Type_array_float32_4_Utils, NULL, NULL, &scope_135, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_int32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L13), &_Type_array_int32_1_Utils, NULL, NULL, &scope_138, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L11", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L11), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Math_Operators, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L18), &_Type_array_int32_5_Utils, NULL, NULL, &scope_125, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_int32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L19), &_Type_array_int32_4_Utils, NULL, NULL, &scope_139, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int32), offsetof(outC_TrainConfiguration0_Math_Operators, _L20), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Math_Operators, _L28), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L33", NULL, sizeof(array_bool_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L33), &_Type_array_bool_1_Utils, NULL, NULL, &scope_140, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L32", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L32), &_Type_array_bool_5_Utils, NULL, NULL, &scope_126, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_bool_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L31), &_Type_array_bool_4_Utils, NULL, NULL, &scope_141, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration0_Math_Operators, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration0_Math_Operators, _L37), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L44", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration0_Math_Operators, _L44), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L41", NULL, sizeof(array_float32_4), offsetof(outC_TrainConfiguration0_Math_Operators, _L41), &_Type_array_float32_4_Utils, NULL, NULL, &scope_135, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L40", NULL, sizeof(array_float32_1), offsetof(outC_TrainConfiguration0_Math_Operators, _L40), &_Type_array_float32_1_Utils, NULL, NULL, &scope_136, 1, 34 }
};
const MappingScope scope_137 = {
    "Math_Operators::TrainConfiguration0/ TrainConfiguration0_Math_Operators",
    scope_137_entries, 35
};

const MappingEntry scope_136_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_136 = {
    "array_float32_1",
    scope_136_entries, 1
};

const MappingEntry scope_135_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_135 = {
    "array_float32_4",
    scope_135_entries, 1
};

const MappingEntry scope_134_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "OutputArray", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, OutputArray), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L15", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, _L15), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L22", NULL, sizeof(array_float32_4), offsetof(outC_Shift_Array_Math_Operators, _L22), &_Type_array_float32_4_Utils, NULL, NULL, &scope_135, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L23", NULL, sizeof(array_float32_5), offsetof(outC_Shift_Array_Math_Operators, _L23), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L24", NULL, sizeof(array_float32_1), offsetof(outC_Shift_Array_Math_Operators, _L24), &_Type_array_float32_1_Utils, NULL, NULL, &scope_136, 1, 4 }
};
const MappingScope scope_134 = {
    "Math_Operators::Shift_Array/ Shift_Array_Math_Operators",
    scope_134_entries, 5
};

const MappingEntry scope_133_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, Output1_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L1_NumericToFloat32_1_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L2_NumericToFloat32_1_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_133 = {
    "Math_Operators::LCF_Calculation/ LCF_Calculation_Math_Operators/math::NumericToFloat32 1",
    scope_133_entries, 3
};

const MappingEntry scope_132_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_132 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes/math::NumericToFloat32 2",
    scope_132_entries, 3
};

const MappingEntry scope_131_entries[19] = {
    /* 0 */ { MAP_OUTPUT, "AppliedPneumaticBrakingforce", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, AppliedPneumaticBrakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Brakepressure", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, Brakepressure), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Pneumaticbrakes_Brakes, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int32), offsetof(outC_Pneumaticbrakes_Brakes, _L17), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L18), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Pneumaticbrakes_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_132, 1, 18 }
};
const MappingScope scope_131 = {
    "Brakes::Pneumaticbrakes/ Pneumaticbrakes_Brakes",
    scope_131_entries, 19
};

const MappingEntry scope_130_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Output1_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Holding_brake_Brakes, _L1_NumericToFloat32_2_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2_NumericToFloat32_2_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_130 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes/math::NumericToFloat32 2",
    scope_130_entries, 3
};

const MappingEntry scope_129_entries[22] = {
    /* 0 */ { MAP_OUTPUT, "AppliedHoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, AppliedHoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Max_HoldingBrakeForce", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, Max_HoldingBrakeForce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L19), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_Holding_brake_Brakes, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L21), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_Holding_brake_Brakes, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_EXPANDED, "math::NumericToFloat32 2", NULL, 0, 0, NULL, NULL, NULL, &scope_130, 1, 21 }
};
const MappingScope scope_129 = {
    "Brakes::Holding_brake/ Holding_brake_Brakes",
    scope_129_entries, 22
};

const MappingEntry scope_128_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "outbraking", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, outbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeedcorrection_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeedcorrection_Math_Operators, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_128 = {
    "Math_Operators::negativespeedcorrection/ negativespeedcorrection_Math_Operators",
    scope_128_entries, 6
};

const MappingEntry scope_127_entries[29] = {
    /* 0 */ { MAP_OUTPUT, "unit_traction", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, unit_traction), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "unittotalbraking", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, unittotalbraking), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "L_Couplingforce", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, L_Couplingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L12), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L16), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L17), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_LCF_Calculation_Math_Operators, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int32), offsetof(outC_LCF_Calculation_Math_Operators, _L27), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_LCF_Calculation_Math_Operators, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_LCF_Calculation_Math_Operators, Context_Resistance_force_1), NULL, NULL, NULL, &scope_118, 1, 24 },
    /* 25 */ { MAP_INSTANCE, "Math_Operators::negativespeedcorrection 1", NULL, sizeof(outC_negativespeedcorrection_Math_Operators), offsetof(outC_LCF_Calculation_Math_Operators, Context_negativespeedcorrection_1), NULL, NULL, NULL, &scope_128, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Brakes::Holding_brake 1", NULL, sizeof(outC_Holding_brake_Brakes), offsetof(outC_LCF_Calculation_Math_Operators, Context_Holding_brake_1), NULL, NULL, NULL, &scope_129, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Brakes::Pneumaticbrakes 1", NULL, sizeof(outC_Pneumaticbrakes_Brakes), offsetof(outC_LCF_Calculation_Math_Operators, Context_Pneumaticbrakes_1), NULL, NULL, NULL, &scope_131, 1, 27 },
    /* 28 */ { MAP_EXPANDED, "math::NumericToFloat32 1", NULL, 0, 0, NULL, NULL, NULL, &scope_133, 1, 28 }
};
const MappingScope scope_127 = {
    "Math_Operators::LCF_Calculation/ LCF_Calculation_Math_Operators",
    scope_127_entries, 29
};

const MappingEntry scope_126_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_126 = {
    "array_bool_5",
    scope_126_entries, 1
};

const MappingEntry scope_125_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_int32), 0, &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_125 = {
    "array_int32_5",
    scope_125_entries, 1
};

const MappingEntry scope_124_entries[30] = {
    /* 0 */ { MAP_OUTPUT, "LCF_Array", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, LCF_Array), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Total_Tractionforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Tractionforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "Total_Brakingforce", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, Total_Brakingforce), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L5), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L12", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L12), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L13", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L13), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L14", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L14), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L16", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L16), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(array_int32_5), offsetof(outC_TrainConfiguration_And_LCF, _L21), &_Type_array_int32_5_Utils, NULL, NULL, &scope_125, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L20", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L20), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L19), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L18), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L17", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L17), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L23), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L22), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_float32), offsetof(outC_TrainConfiguration_And_LCF, _L26), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_TrainConfiguration_And_LCF, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L28", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L28), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L29", NULL, sizeof(array_bool_5), offsetof(outC_TrainConfiguration_And_LCF, _L29), &_Type_array_bool_5_Utils, NULL, NULL, &scope_126, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L30", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L30), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L31", NULL, sizeof(array_float32_5), offsetof(outC_TrainConfiguration_And_LCF, _L31), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 25 },
    /* 26 */ { MAP_INSTANCE, "Math_Operators::LCF_Calculation 1", &iter_map_5, sizeof(outC_LCF_Calculation_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_LCF_Calculation_1), NULL, NULL, NULL, &scope_127, 1, 26 },
    /* 27 */ { MAP_INSTANCE, "Math_Operators::Shift_Array 1", NULL, sizeof(outC_Shift_Array_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_Shift_Array_1), NULL, NULL, NULL, &scope_134, 1, 27 },
    /* 28 */ { MAP_INSTANCE, "Math_Operators::TrainConfiguration0 1", NULL, sizeof(outC_TrainConfiguration0_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_TrainConfiguration0_1), NULL, NULL, NULL, &scope_137, 1, 28 },
    /* 29 */ { MAP_INSTANCE, "Math_Operators::Sum_of_Forces 1", NULL, sizeof(outC_Sum_of_Forces_Math_Operators), offsetof(outC_TrainConfiguration_And_LCF, Context_Sum_of_Forces_1), NULL, NULL, NULL, &scope_142, 1, 29 }
};
const MappingScope scope_124 = {
    "TrainConfiguration_And_LCF/ TrainConfiguration_And_LCF",
    scope_124_entries, 30
};

const MappingEntry scope_123_entries[8] = {
    /* 0 */ { MAP_OUTPUT, "Distance_travelled", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, Distance_travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L11), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Distance_Calculation, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_123 = {
    "Distance_Calculation/ Distance_Calculation",
    scope_123_entries, 8
};

const MappingEntry scope_122_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "Friction_Force", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, Friction_Force), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Friction_force_External_forces, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_122 = {
    "External_forces::Friction_force/ Friction_force_External_forces",
    scope_122_entries, 7
};

const MappingEntry scope_121_entries[6] = {
    /* 0 */ { MAP_OUTPUT, "F_Gradient", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, F_Gradient), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_F_gradient_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 }
};
const MappingScope scope_121 = {
    "External_forces::F_gradient/ F_gradient_External_forces",
    scope_121_entries, 6
};

const MappingEntry scope_120_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Square_Out", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, Square_Out_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L1_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Square_mathext_float32, _L2_float32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_120 = {
    "mathext::Square/ Square_mathext_float32",
    scope_120_entries, 3
};

const MappingEntry scope_119_entries[9] = {
    /* 0 */ { MAP_OUTPUT, "F_Air", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, F_Air), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_F_Airdrag_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "mathext::Square 1", NULL, sizeof(outC_Square_mathext_float32), offsetof(outC_F_Airdrag_External_forces, Context_Square_1), NULL, NULL, NULL, &scope_120, 1, 8 }
};
const MappingScope scope_119 = {
    "External_forces::F_Airdrag/ F_Airdrag_External_forces",
    scope_119_entries, 9
};

const MappingEntry scope_118_entries[10] = {
    /* 0 */ { MAP_OUTPUT, "Total_resistance", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, Total_resistance), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Resistance_force_External_forces, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_INSTANCE, "External_forces::F_Airdrag 1", NULL, sizeof(outC_F_Airdrag_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_Airdrag_1), NULL, NULL, NULL, &scope_119, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "External_forces::F_gradient 1", NULL, sizeof(outC_F_gradient_External_forces), offsetof(outC_Resistance_force_External_forces, Context_F_gradient_1), NULL, NULL, NULL, &scope_121, 1, 8 },
    /* 9 */ { MAP_INSTANCE, "External_forces::Friction_force 1", NULL, sizeof(outC_Friction_force_External_forces), offsetof(outC_Resistance_force_External_forces, Context_Friction_force_1), NULL, NULL, NULL, &scope_122, 1, 9 }
};
const MappingScope scope_118 = {
    "External_forces::Resistance_force/ Resistance_force_External_forces",
    scope_118_entries, 10
};

const MappingEntry scope_117_entries[12] = {
    /* 0 */ { MAP_OUTPUT, "oacceleration", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, oacceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "ospeed", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, ospeed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L9), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_negativespeed_Math_Operators, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_negativespeed_Math_Operators, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 }
};
const MappingScope scope_117 = {
    "Math_Operators::negativespeed/ negativespeed_Math_Operators",
    scope_117_entries, 12
};

const MappingEntry scope_116_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "Output1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Output1_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L1_NumericToFloat32_3_int32), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2_NumericToFloat32_3_int32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_116 = {
    "Train_dynamics/ Train_dynamics/math::NumericToFloat32 3",
    scope_116_entries, 3
};

const MappingEntry scope_115_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "train_speed", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Distance_Travelled", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, Distance_Travelled), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L3), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L7), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L8), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L10), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int32), offsetof(outC_Train_dynamics, _L25), &_Type_kcg_int32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L29), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L28), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L30), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L31), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_float32), offsetof(outC_Train_dynamics, _L32), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_EXPANDED, "math::NumericToFloat32 3", NULL, 0, 0, NULL, NULL, NULL, &scope_116, 1, 20 },
    /* 21 */ { MAP_INSTANCE, "Math_Operators::negativespeed 1", NULL, sizeof(outC_negativespeed_Math_Operators), offsetof(outC_Train_dynamics, Context_negativespeed_1), NULL, NULL, NULL, &scope_117, 1, 21 },
    /* 22 */ { MAP_INSTANCE, "External_forces::Resistance_force 1", NULL, sizeof(outC_Resistance_force_External_forces), offsetof(outC_Train_dynamics, Context_Resistance_force_1), NULL, NULL, NULL, &scope_118, 1, 22 },
    /* 23 */ { MAP_INSTANCE, "Distance_Calculation 1", NULL, sizeof(outC_Distance_Calculation), offsetof(outC_Train_dynamics, Context_Distance_Calculation_1), NULL, NULL, NULL, &scope_123, 1, 23 }
};
const MappingScope scope_115 = {
    "Train_dynamics/ Train_dynamics",
    scope_115_entries, 24
};

const MappingEntry scope_114_entries[21] = {
    /* 0 */ { MAP_OUTPUT, "Train_Speed", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_Speed), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Train_acceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train, Train_acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "LCF_Values", NULL, sizeof(LCF_Data), offsetof(outC_Train, LCF_Values), &_Type_LCF_Data_Utils, NULL, NULL, &scope_112, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "Distance_Travelled_by_Train", NULL, sizeof(kcg_float32), offsetof(outC_Train, Distance_Travelled_by_Train), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L34), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L35), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L60", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L60), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L59", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L59), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L62", NULL, sizeof(array_float32_5), offsetof(outC_Train, _L62), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L64", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L64), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L65), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L67), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L66", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L66), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_Train, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L70), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L71", NULL, sizeof(kcg_float32), offsetof(outC_Train, _L71), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L72", NULL, sizeof(LCF_Data), offsetof(outC_Train, _L72), &_Type_LCF_Data_Utils, NULL, NULL, &scope_112, 1, 18 },
    /* 19 */ { MAP_INSTANCE, "Train_dynamics 1", NULL, sizeof(outC_Train_dynamics), offsetof(outC_Train, Context_Train_dynamics_1), NULL, NULL, NULL, &scope_115, 1, 19 },
    /* 20 */ { MAP_INSTANCE, "TrainConfiguration_And_LCF", NULL, sizeof(outC_TrainConfiguration_And_LCF), offsetof(outC_Train, Context_TrainConfiguration_And_LCF), NULL, NULL, NULL, &scope_124, 1, 20 }
};
const MappingScope scope_114 = {
    "Train/ Train",
    scope_114_entries, 21
};

const MappingEntry scope_113_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_5, sizeof(kcg_float32), 0, &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_113 = {
    "array_float32_5",
    scope_113_entries, 1
};

const MappingEntry scope_112_entries[1] = {
    /* 0 */ { MAP_FIELD, ".LCF_Values", NULL, sizeof(array_float32_5), offsetof(LCF_Data, LCF_Values), &_Type_array_float32_5_Utils, NULL, NULL, &scope_113, 1, 0 }
};
const MappingScope scope_112 = {
    "LCF_Data",
    scope_112_entries, 1
};

const MappingEntry scope_111_entries[24] = {
    /* 0 */ { MAP_OUTPUT, "Distance_Covered", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, Distance_Covered), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Current_TrainSpeed", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, Current_TrainSpeed), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "CurrentTrainAcceleration", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, CurrentTrainAcceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L4), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(LCF_Data), offsetof(outC_Train_with_TandB_Lever, _L3), &_Type_LCF_Data_Utils, NULL, NULL, &scope_112, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L2), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L1), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L6), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L5), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int8), offsetof(outC_Train_with_TandB_Lever, _L7), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Train_with_TandB_Lever, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int8), offsetof(outC_Train_with_TandB_Lever, _L10), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_Train_with_TandB_Lever, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L12), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L13), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L14), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L15), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, _L17), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int16), offsetof(outC_Train_with_TandB_Lever, _L18), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L20), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L24), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_Train_with_TandB_Lever, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_INSTANCE, "Train 1", NULL, sizeof(outC_Train), offsetof(outC_Train_with_TandB_Lever, Context_Train_1), NULL, NULL, NULL, &scope_114, 1, 22 },
    /* 23 */ { MAP_INSTANCE, "Math_Operators::T_B_Lever 1", NULL, sizeof(outC_T_B_Lever_Math_Operators), offsetof(outC_Train_with_TandB_Lever, Context_T_B_Lever_1), NULL, NULL, NULL, &scope_143, 1, 23 }
};
const MappingScope scope_111 = {
    "Train_with_TandB_Lever/ Train_with_TandB_Lever",
    scope_111_entries, 24
};

const MappingEntry scope_110_entries[9] = {
    /* 0 */ { MAP_OUTPUT, "Train_Outputs", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Physics_Train, Train_Outputs), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L29", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Physics_Train, _L29), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_float32), offsetof(outC_Train_Physics_Train, _L25), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int16), offsetof(outC_Train_Physics_Train, _L24), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int16), offsetof(outC_Train_Physics_Train, _L23), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int8), offsetof(outC_Train_Physics_Train, _L30), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_Train_Physics_Train, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int8), offsetof(outC_Train_Physics_Train, _L32), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INSTANCE, "Train_with_TandB_Lever 4", NULL, sizeof(outC_Train_with_TandB_Lever), offsetof(outC_Train_Physics_Train, Context_Train_with_TandB_Lever_4), NULL, NULL, NULL, &scope_111, 1, 8 }
};
const MappingScope scope_110 = {
    "Train::Train_Physics/ Train_Physics_Train",
    scope_110_entries, 9
};

const MappingEntry scope_109_entries[3] = {
    /* 0 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L4_then_IfBlock2), &_Type_kcg_int8_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L3_then_IfBlock2), &_Type_kcg_int8_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L1_then_IfBlock2), &_Type_kcg_bool_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 }
};
const MappingScope scope_109 = {
    "Train_Driver/ Train_DriverIfBlock2:then:",
    scope_109_entries, 3
};

const MappingEntry scope_108_entries[3] = {
    /* 0 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L5_else_IfBlock2), &_Type_kcg_int8_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L6_else_IfBlock2), &_Type_kcg_bool_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L7_else_IfBlock2), &_Type_kcg_int8_Utils, &scope_107_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 2 }
};
const MappingScope scope_108 = {
    "Train_Driver/ Train_DriverIfBlock2:else:",
    scope_108_entries, 3
};

const MappingEntry scope_107_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, IfBlock2_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_107_entries[0], isActive_kcg_bool_kcg_false, &scope_108, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_107_entries[0], isActive_kcg_bool_kcg_true, &scope_109, 1, 2 }
};
const MappingScope scope_107 = {
    "Train_Driver/ Train_DriverIfBlock2:",
    scope_107_entries, 3
};

const MappingEntry scope_106_entries[49] = {
    /* 0 */ { MAP_OUTPUT, "HMI_Display_Textbox", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, HMI_Display_Textbox), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "Out_ETCS_OB", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, Out_ETCS_OB), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "ETCS_HMI_Data", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, ETCS_HMI_Data), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_LOCAL, "HMItoETCSOB_Message", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, HMItoETCSOB_Message), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "ETCS_MSG", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, ETCS_MSG), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "Data_in", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, Data_in), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 5 },
    /* 6 */ { MAP_LOCAL, "Data_Out", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, Data_Out), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L1), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L3), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L4), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_modes), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L5), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L6", NULL, sizeof(ATO_modes), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L6), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L7), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L9), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L10", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L10), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L11", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L11), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L12", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L12), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L13", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L13), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L14", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L14), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L15", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L15), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L16", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L16), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L17", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L17), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L18", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L18), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L22", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L22), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L23", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L23), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L24", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L24), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L19", NULL, sizeof(array_char_30), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L19), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L26", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L26), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L31", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L31), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int8), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L30), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_int8), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L29), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 34 },
    /* 35 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L28), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35 },
    /* 36 */ { MAP_LOCAL, "_L32", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L32), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 36 },
    /* 37 */ { MAP_LOCAL, "_L46", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L46), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 37 },
    /* 38 */ { MAP_LOCAL, "_L47", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L47), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 38 },
    /* 39 */ { MAP_LOCAL, "_L48", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L48), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 39 },
    /* 40 */ { MAP_LOCAL, "_L49", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L49), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 40 },
    /* 41 */ { MAP_LOCAL, "_L50", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L50), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 41 },
    /* 42 */ { MAP_LOCAL, "_L51", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L51), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 42 },
    /* 43 */ { MAP_LOCAL, "_L52", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L52), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 43 },
    /* 44 */ { MAP_LOCAL, "_L53", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L53), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 44 },
    /* 45 */ { MAP_LOCAL, "_L54", NULL, sizeof(kcg_bool), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L54), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45 },
    /* 46 */ { MAP_LOCAL, "_L55", NULL, sizeof(kcg_int8), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L55), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 46 },
    /* 47 */ { MAP_LOCAL, "_L56", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L56), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 47 },
    /* 48 */ { MAP_LOCAL, "_L57", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions, _L57), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 48 }
};
const MappingScope scope_106 = {
    "ETCSHMI_Functions::Read_and_Send_ETCSOB_Data/ Read_and_Send_ETCSOB_Data_ETCSHMI_Functions",
    scope_106_entries, 49
};

const MappingEntry scope_105_entries[41] = {
    /* 0 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(FVAHMIPacket), offsetof(outC_Train_Driver, to_FVA), &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, to_ETCS_OB), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "External_ATORSC_Status", NULL, sizeof(ExternalindicatorStates), offsetof(outC_Train_Driver, External_ATORSC_Status), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "ETCSHMI_TextBox", NULL, sizeof(array_char_30), offsetof(outC_Train_Driver, ETCSHMI_TextBox), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "Train_Physics_Output", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Driver, Train_Physics_Output), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "ETCSHMI_Data_Out", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Train_Driver, ETCSHMI_Data_Out), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 5 },
    /* 6 */ { MAP_LOCAL, "Local_ATORSCSwitchPosition", NULL, sizeof(ATORSCSwitchPosition), offsetof(outC_Train_Driver, Local_ATORSCSwitchPosition), &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "T_B_Leverinput", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, T_B_Leverinput), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "HoldingBrakeApplied", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, HoldingBrakeApplied), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "TrainBrakePos", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, TrainBrakePos), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L2", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L2), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L4", NULL, sizeof(ExternalindicatorStates), offsetof(outC_Train_Driver, _L4), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L5", NULL, sizeof(ATORSCSwitchPosition), offsetof(outC_Train_Driver, _L5), &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L32), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L40", NULL, sizeof(array_char_30), offsetof(outC_Train_Driver, _L40), &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L41", NULL, sizeof(Tain_Physics_Outputs), offsetof(outC_Train_Driver, _L41), &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L42), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_int8), offsetof(outC_Train_Driver, _L44), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L45", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L45), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L51", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L51), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L52", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L52), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L53", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L53), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L54", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L54), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L55", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L55), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L56", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L56), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L57", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L57), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L58", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L58), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L59", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L59), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L64", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L64), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L67", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Train_Driver, _L67), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L68", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Train_Driver, _L68), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L69", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Train_Driver, _L69), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_bool), offsetof(outC_Train_Driver, _L70), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L71", NULL, sizeof(FVAHMIPacket), offsetof(outC_Train_Driver, _L71), &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 34 },
    /* 35 */ { MAP_INSTANCE, "ETCSHMI_Functions::Read_and_Send_ETCSOB_Data", NULL, sizeof(outC_Read_and_Send_ETCSOB_Data_ETCSHMI_Functions), offsetof(outC_Train_Driver, Context_Read_and_Send_ETCSOB_Data), NULL, NULL, NULL, &scope_106, 1, 35 },
    /* 36 */ { MAP_IF, "IfBlock2:", NULL, 0, 0, NULL, NULL, NULL, &scope_107, 1, 36 },
    /* 37 */ { MAP_INSTANCE, "Train::Train_Physics 3", NULL, sizeof(outC_Train_Physics_Train), offsetof(outC_Train_Driver, Context_Train_Physics_3), NULL, NULL, NULL, &scope_110, 1, 37 },
    /* 38 */ { MAP_INSTANCE, "ETCSHMI_Functions::Send_FS_Selected 1", NULL, sizeof(outC_Send_FS_Selected_ETCSHMI_Functions), offsetof(outC_Train_Driver, Context_Send_FS_Selected_1), NULL, NULL, NULL, &scope_145, 1, 38 },
    /* 39 */ { MAP_INSTANCE, "ETCSHMI_Functions::Send_GoA2_Selected 1", NULL, sizeof(outC_Send_GoA2_Selected_ETCSHMI_Functions), offsetof(outC_Train_Driver, Context_Send_GoA2_Selected_1), NULL, NULL, NULL, &scope_146, 1, 39 },
    /* 40 */ { MAP_INSTANCE, "ETCSHMI_Functions::Send_GoA4_Selected 1", NULL, sizeof(outC_Send_GoA4_Selected_ETCSHMI_Functions), offsetof(outC_Train_Driver, Context_Send_GoA4_Selected_1), NULL, NULL, NULL, &scope_147, 1, 40 }
};
const MappingScope scope_105 = {
    "Train_Driver/ Train_Driver",
    scope_105_entries, 41
};

const MappingEntry scope_104_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "to_System", NULL, sizeof(kcg_bool), offsetof(outC_Signal_Operator, to_System), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Signal_Operator, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Signal_Operator, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_104 = {
    "Signal_Operator/ Signal_Operator",
    scope_104_entries, 3
};

const MappingEntry scope_103_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "to_Perception_TS", NULL, sizeof(kcg_bool), offsetof(outC_RSC_Operator, to_Perception_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_RSC_TS", NULL, sizeof(kcg_bool), offsetof(outC_RSC_Operator, to_RSC_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_RSC_Operator, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_RSC_Operator, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_RSC_Operator, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 }
};
const MappingScope scope_103 = {
    "RSC_Operator/ RSC_Operator",
    scope_103_entries, 5
};

const MappingEntry scope_102_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_ClassB_Systems", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, to_ClassB_Systems), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_Vehicle_Management_System, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_102 = {
    "Vehicle_Management_System/ Vehicle_Management_System",
    scope_102_entries, 7
};

const MappingEntry scope_101_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "to_RSC_Operator", NULL, sizeof(kcg_bool), offsetof(outC_RSC_TS, to_RSC_Operator), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_RSC_TS, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_RSC_TS, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_RSC_TS, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_RSC_TS, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 }
};
const MappingScope scope_101 = {
    "RSC_TS/ RSC_TS",
    scope_101_entries, 5
};

const MappingEntry scope_100_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Intitial_Connecting_1_Intitial_SM1, NULL, 1, 0 }
};
const MappingScope scope_100 = {
    "RSC_OB/ RSC_OBSM1:Intitial:<1",
    scope_100_entries, 1
};

const MappingEntry scope_99_entries[1] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Intitial_Connecting_1_Intitial_SM1, &scope_100, 1, 0 }
};
const MappingScope scope_99 = {
    "RSC_OB/ RSC_OBSM1:Intitial:",
    scope_99_entries, 1
};

const MappingEntry scope_98_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1, NULL, 1, 0 }
};
const MappingScope scope_98 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteControl:<3",
    scope_98_entries, 1
};

const MappingEntry scope_97_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1, NULL, 1, 0 }
};
const MappingScope scope_97 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteControl:<2",
    scope_97_entries, 1
};

const MappingEntry scope_96_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1, NULL, 1, 0 }
};
const MappingScope scope_96 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteControl:<1",
    scope_96_entries, 1
};

const MappingEntry scope_95_entries[3] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteControl_Remote_Control_1_InterruptedRemoteControl_SM1, &scope_96, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__5_SSM_TR_InterruptedRemoteControl_Remote_Supervision_2_InterruptedRemoteControl_SM1, &scope_97, 1, 1 },
    /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__6_SSM_TR_InterruptedRemoteControl_Connecting_3_InterruptedRemoteControl_SM1, &scope_98, 1, 2 }
};
const MappingScope scope_95 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteControl:",
    scope_95_entries, 3
};

const MappingEntry scope_94_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1, NULL, 1, 0 }
};
const MappingScope scope_94 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteSupervision:<2",
    scope_94_entries, 1
};

const MappingEntry scope_93_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1, NULL, 1, 0 }
};
const MappingScope scope_93 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteSupervision:<1",
    scope_93_entries, 1
};

const MappingEntry scope_92_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_InterruptedRemoteSupervision_Remote_Supervision_1_InterruptedRemoteSupervision_SM1, &scope_93, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1__7_SSM_TR_InterruptedRemoteSupervision_Connecting_2_InterruptedRemoteSupervision_SM1, &scope_94, 1, 1 }
};
const MappingScope scope_92 = {
    "RSC_OB/ RSC_OBSM1:InterruptedRemoteSupervision:",
    scope_92_entries, 2
};

const MappingEntry scope_91_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1, NULL, 1, 0 }
};
const MappingScope scope_91 = {
    "RSC_OB/ RSC_OBSM1:Remote_Control:<3",
    scope_91_entries, 1
};

const MappingEntry scope_90_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1, NULL, 1, 0 }
};
const MappingScope scope_90 = {
    "RSC_OB/ RSC_OBSM1:Remote_Control:<2",
    scope_90_entries, 1
};

const MappingEntry scope_89_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Available_1_Remote_Control_SM1, NULL, 1, 0 }
};
const MappingScope scope_89 = {
    "RSC_OB/ RSC_OBSM1:Remote_Control:<1",
    scope_89_entries, 1
};

const MappingEntry scope_88_entries[3] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Available_1_Remote_Control_SM1, &scope_89, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_Remote_Supervision_2_Remote_Control_SM1, &scope_90, 1, 1 },
    /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Control_InterruptedRemoteControl_3_Remote_Control_SM1, &scope_91, 1, 2 }
};
const MappingScope scope_88 = {
    "RSC_OB/ RSC_OBSM1:Remote_Control:",
    scope_88_entries, 3
};

const MappingEntry scope_87_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1, NULL, 1, 0 }
};
const MappingScope scope_87 = {
    "RSC_OB/ RSC_OBSM1:Remote_Supervision:<3",
    scope_87_entries, 1
};

const MappingEntry scope_86_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1, NULL, 1, 0 }
};
const MappingScope scope_86 = {
    "RSC_OB/ RSC_OBSM1:Remote_Supervision:<2",
    scope_86_entries, 1
};

const MappingEntry scope_85_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1, NULL, 1, 0 }
};
const MappingScope scope_85 = {
    "RSC_OB/ RSC_OBSM1:Remote_Supervision:<1",
    scope_85_entries, 1
};

const MappingEntry scope_84_entries[3] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Available_1_Remote_Supervision_SM1, &scope_85, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_Remote_Control_2_Remote_Supervision_SM1, &scope_86, 1, 1 },
    /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Remote_Supervision_InterruptedRemoteSupervision_3_Remote_Supervision_SM1, &scope_87, 1, 2 }
};
const MappingScope scope_84 = {
    "RSC_OB/ RSC_OBSM1:Remote_Supervision:",
    scope_84_entries, 3
};

const MappingEntry scope_83_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Available_Remote_Supervision_1_Available_SM1, NULL, 1, 0 }
};
const MappingScope scope_83 = {
    "RSC_OB/ RSC_OBSM1:Available:<1",
    scope_83_entries, 1
};

const MappingEntry scope_82_entries[1] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Available_Remote_Supervision_1_Available_SM1, &scope_83, 1, 0 }
};
const MappingScope scope_82 = {
    "RSC_OB/ RSC_OBSM1:Available:",
    scope_82_entries, 1
};

const MappingEntry scope_81_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Connecting_Available_1_Connecting_SM1, NULL, 1, 0 }
};
const MappingScope scope_81 = {
    "RSC_OB/ RSC_OBSM1:Connecting:<1",
    scope_81_entries, 1
};

const MappingEntry scope_80_entries[1] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_79_entries[5], isActive_SSM_TR_SM1_SSM_TR_Connecting_Available_1_Connecting_SM1, &scope_81, 1, 0 }
};
const MappingScope scope_80 = {
    "RSC_OB/ RSC_OBSM1:Connecting:",
    scope_80_entries, 1
};

const MappingEntry scope_79_entries[14] = {
    /* 0 */ { MAP_LOCAL, "@active_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_RSC_OB, SM1_state_act), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_LOCAL, "@reset_active_state", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, SM1_reset_act), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1 },
    /* 2 */ { MAP_LOCAL, "@next_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_RSC_OB, SM1_state_nxt), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 2 },
    /* 3 */ { MAP_LOCAL, "@reset_next_state", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, SM1_reset_nxt), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 3 },
    /* 4 */ { MAP_LOCAL, "@selected_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_RSC_OB, SM1_state_sel), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 4 },
    /* 5 */ { MAP_LOCAL, "@active_strong_transition", NULL, sizeof(SSM_TR_SM1), offsetof(outC_RSC_OB, SM1_fired_strong), &_Type_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 5 },
    /* 6 */ { MAP_LOCAL, "@active_weak_transition", NULL, sizeof(SSM_TR_SM1), offsetof(outC_RSC_OB, SM1_fired), &_Type_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 6 },
    /* 7 */ { MAP_STATE, "Connecting:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_Connecting_SM1, &scope_80, 1, 7 },
    /* 8 */ { MAP_STATE, "Available:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_Available_SM1, &scope_82, 1, 8 },
    /* 9 */ { MAP_STATE, "Remote_Supervision:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_Remote_Supervision_SM1, &scope_84, 1, 9 },
    /* 10 */ { MAP_STATE, "Remote_Control:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_Remote_Control_SM1, &scope_88, 1, 10 },
    /* 11 */ { MAP_STATE, "InterruptedRemoteSupervision:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_InterruptedRemoteSupervision_SM1, &scope_92, 1, 11 },
    /* 12 */ { MAP_STATE, "InterruptedRemoteControl:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_InterruptedRemoteControl_SM1, &scope_95, 1, 12 },
    /* 13 */ { MAP_STATE, "Intitial:", NULL, 0, 0, NULL, &scope_79_entries[0], isActive_SSM_ST_SM1_SSM_st_Intitial_SM1, &scope_99, 1, 13 }
};
const MappingScope scope_79 = {
    "RSC_OB/ RSC_OBSM1:",
    scope_79_entries, 14
};

const MappingEntry scope_78_entries[14] = {
    /* 0 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_FVA_ss139", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, to_FVA_ss139), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_FVA_int2", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, to_FVA_int2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_Diagnostic_Platform", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, to_Diagnostic_Platform), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "RSC_PowerOn", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, RSC_PowerOn), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_RSC_OB, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_AUTOMATON, "SM1:", NULL, 0, 0, NULL, NULL, NULL, &scope_79, 1, 13 }
};
const MappingScope scope_78 = {
    "RSC_OB/ RSC_OB",
    scope_78_entries, 14
};

const MappingEntry scope_77_entries[17] = {
    /* 0 */ { MAP_OUTPUT, "to_ATO_OB", NULL, sizeof(ATO_Packet), offsetof(outC_Radio_Management, to_ATO_OB), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ATO_TS_ss126", NULL, sizeof(ATO_Packet), offsetof(outC_Radio_Management, to_ATO_TS_ss126), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_RSC_TS", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_RSC_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_DiagnosticPlatform", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_DiagnosticPlatform), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "to_Diagnostics_TS", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_Diagnostics_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "to_ETCS_TS", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_ETCS_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_OUTPUT, "to_RSC_OB", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, to_RSC_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L1", NULL, sizeof(ATO_Packet), offsetof(outC_Radio_Management, _L1), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L7", NULL, sizeof(ATO_Packet), offsetof(outC_Radio_Management, _L7), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_Radio_Management, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 }
};
const MappingScope scope_77 = {
    "Radio_Management/ Radio_Management",
    scope_77_entries, 17
};

const MappingEntry scope_76_entries[5] = {
    /* 0 */ { MAP_OUTPUT, "to_RSC_Operator", NULL, sizeof(kcg_bool), offsetof(outC_Perception_TS, to_RSC_Operator), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_Perception_OB", NULL, sizeof(kcg_bool), offsetof(outC_Perception_TS, to_Perception_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Perception_TS, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Perception_TS, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Perception_TS, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 }
};
const MappingScope scope_76 = {
    "Perception_TS/ Perception_TS",
    scope_76_entries, 5
};

const MappingEntry scope_75_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "to_Perception_TS", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, to_Perception_TS), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_EmergencyBrakeIO", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, to_EmergencyBrakeIO), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_Perception_OB, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_75 = {
    "Perception_OB/ Perception_OB",
    scope_75_entries, 7
};

const MappingEntry scope_74_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_74 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:RSC_Mode:<2",
    scope_74_entries, 1
};

const MappingEntry scope_73_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_73 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:RSC_Mode:<1",
    scope_73_entries, 1
};

const MappingEntry scope_72_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_ATO_Mode_1_RSC_Mode_OverrideSwitch_SM, &scope_73, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_RSC_Mode_Manual_Mode_2_RSC_Mode_OverrideSwitch_SM, &scope_74, 1, 1 }
};
const MappingScope scope_72 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:RSC_Mode:",
    scope_72_entries, 2
};

const MappingEntry scope_71_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_71 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:ATO_Mode:<2",
    scope_71_entries, 1
};

const MappingEntry scope_70_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_70 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:ATO_Mode:<1",
    scope_70_entries, 1
};

const MappingEntry scope_69_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_Manual_Mode_1_ATO_Mode_OverrideSwitch_SM, &scope_70, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_ATO_Mode_RSC_Mode_2_ATO_Mode_OverrideSwitch_SM, &scope_71, 1, 1 }
};
const MappingScope scope_69 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:ATO_Mode:",
    scope_69_entries, 2
};

const MappingEntry scope_68_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_68 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:Manual_Mode:<2",
    scope_68_entries, 1
};

const MappingEntry scope_67_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM, NULL, 1, 0 }
};
const MappingScope scope_67 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:Manual_Mode:<1",
    scope_67_entries, 1
};

const MappingEntry scope_66_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_ATO_Mode_1_Manual_Mode_OverrideSwitch_SM, &scope_67, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_65_entries[5], isActive_SSM_TR_OverrideSwitch_SM_SSM_TR_Manual_Mode_RSC_Mode_2_Manual_Mode_OverrideSwitch_SM, &scope_68, 1, 1 }
};
const MappingScope scope_66 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:Manual_Mode:",
    scope_66_entries, 2
};

const MappingEntry scope_65_entries[10] = {
    /* 0 */ { MAP_LOCAL, "@active_state", NULL, sizeof(SSM_ST_OverrideSwitch_SM), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_state_act), &_Type_SSM_ST_OverrideSwitch_SM_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_LOCAL, "@reset_active_state", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_reset_act), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1 },
    /* 2 */ { MAP_LOCAL, "@next_state", NULL, sizeof(SSM_ST_OverrideSwitch_SM), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_state_nxt), &_Type_SSM_ST_OverrideSwitch_SM_Utils, NULL, NULL, NULL, 0, 2 },
    /* 3 */ { MAP_LOCAL, "@reset_next_state", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_reset_nxt), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 3 },
    /* 4 */ { MAP_LOCAL, "@selected_state", NULL, sizeof(SSM_ST_OverrideSwitch_SM), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_state_sel), &_Type_SSM_ST_OverrideSwitch_SM_Utils, NULL, NULL, NULL, 0, 4 },
    /* 5 */ { MAP_LOCAL, "@active_strong_transition", NULL, sizeof(SSM_TR_OverrideSwitch_SM), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_fired_strong), &_Type_SSM_TR_OverrideSwitch_SM_Utils, NULL, NULL, NULL, 0, 5 },
    /* 6 */ { MAP_LOCAL, "@active_weak_transition", NULL, sizeof(SSM_TR_OverrideSwitch_SM), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitch_SM_fired), &_Type_SSM_TR_OverrideSwitch_SM_Utils, NULL, NULL, NULL, 0, 6 },
    /* 7 */ { MAP_STATE, "Manual_Mode:", NULL, 0, 0, NULL, &scope_65_entries[0], isActive_SSM_ST_OverrideSwitch_SM_SSM_st_Manual_Mode_OverrideSwitch_SM, &scope_66, 1, 7 },
    /* 8 */ { MAP_STATE, "ATO_Mode:", NULL, 0, 0, NULL, &scope_65_entries[0], isActive_SSM_ST_OverrideSwitch_SM_SSM_st_ATO_Mode_OverrideSwitch_SM, &scope_69, 1, 8 },
    /* 9 */ { MAP_STATE, "RSC_Mode:", NULL, 0, 0, NULL, &scope_65_entries[0], isActive_SSM_ST_OverrideSwitch_SM_SSM_st_RSC_Mode_OverrideSwitch_SM, &scope_72, 1, 9 }
};
const MappingScope scope_65 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_AdapterOverrideSwitch_SM:",
    scope_65_entries, 10
};

const MappingEntry scope_64_entries[1] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L1_then_IfBlock1), &_Type_kcg_bool_Utils, &scope_56_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 }
};
const MappingScope scope_64 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:then:",
    scope_64_entries, 1
};

const MappingEntry scope_63_entries[2] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L1_then_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_57_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L2_then_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_57_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 }
};
const MappingScope scope_63 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:then:",
    scope_63_entries, 2
};

const MappingEntry scope_62_entries[6] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L1_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L5_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L4_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L3_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L2_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L6_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5 }
};
const MappingScope scope_62 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:then:",
    scope_62_entries, 6
};

const MappingEntry scope_61_entries[6] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L1_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L8_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L7_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L6_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L5_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L9_then_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5 }
};
const MappingScope scope_61 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:then:",
    scope_61_entries, 6
};

const MappingEntry scope_60_entries[1] = {
    /* 0 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L2_else_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0 }
};
const MappingScope scope_60 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:else:",
    scope_60_entries, 1
};

const MappingEntry scope_59_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, else_clock_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_58_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_false, &scope_60, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_61, 1, 2 }
};
const MappingScope scope_59 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:",
    scope_59_entries, 3
};

const MappingEntry scope_58_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, else_clock_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_57_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_58_entries[0], isActive_kcg_bool_kcg_false, &scope_59, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_58_entries[0], isActive_kcg_bool_kcg_true, &scope_62, 1, 2 }
};
const MappingScope scope_58 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:",
    scope_58_entries, 3
};

const MappingEntry scope_57_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, else_clock_IfBlock1), &_Type_kcg_bool_Utils, &scope_56_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_57_entries[0], isActive_kcg_bool_kcg_false, &scope_58, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_57_entries[0], isActive_kcg_bool_kcg_true, &scope_63, 1, 2 }
};
const MappingScope scope_57 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:",
    scope_57_entries, 3
};

const MappingEntry scope_56_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_56_entries[0], isActive_kcg_bool_kcg_false, &scope_57, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_56_entries[0], isActive_kcg_bool_kcg_true, &scope_64, 1, 2 }
};
const MappingScope scope_56 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:",
    scope_56_entries, 3
};

const MappingEntry scope_55_entries[12] = {
    /* 0 */ { MAP_OUTPUT, "ExternalIndicationOut", NULL, sizeof(ExternalindicatorStates), offsetof(outC_ExternalStatusIndicator_Internal_functions, ExternalIndicationOut), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 0 },
    /* 1 */ { MAP_LOCAL, "Mem_State", NULL, sizeof(kcg_int8), offsetof(outC_ExternalStatusIndicator_Internal_functions, Mem_State), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "Red_light", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, Red_light), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "Green_light", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, Green_light), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "local_OverrideState", NULL, sizeof(Override_Switch_State), offsetof(outC_ExternalStatusIndicator_Internal_functions, local_OverrideState), &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int8), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L1), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L2), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(ExternalindicatorStates), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L5), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L6", NULL, sizeof(Override_Switch_State), offsetof(outC_ExternalStatusIndicator_Internal_functions, _L6), &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_56, 1, 11 }
};
const MappingScope scope_55 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functions",
    scope_55_entries, 12
};

const MappingEntry scope_54_entries[32] = {
    /* 0 */ { MAP_OUTPUT, "to_Perception_OB", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_Perception_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_Train_Driver", NULL, sizeof(ExternalindicatorStates), offsetof(outC_Functional_Vehicle_Adapter, to_Train_Driver), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_Driving_Style_Engine", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_Driving_Style_Engine), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_OpenIO_interface", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_OpenIO_interface), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "to_Vehicle_Management_System", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_Vehicle_Management_System), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "to_Diagnostic_Platform", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_Diagnostic_Platform), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_OUTPUT, "to_Open_Vehicle_Bus", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_Open_Vehicle_Bus), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_OUTPUT, "to_RSC_OB_int2", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_RSC_OB_int2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_OUTPUT, "to_RSC_OB_ss139", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, to_RSC_OB_ss139), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "ATORSCSwitchState", NULL, sizeof(kcg_int8), offsetof(outC_Functional_Vehicle_Adapter, ATORSCSwitchState), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "ExternalIndicatorState", NULL, sizeof(kcg_int8), offsetof(outC_Functional_Vehicle_Adapter, ExternalIndicatorState), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "OverrideSwitchState", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, OverrideSwitchState), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L12", NULL, sizeof(FVAHMIPacket), offsetof(outC_Functional_Vehicle_Adapter, _L12), &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L19", NULL, sizeof(ExternalindicatorStates), offsetof(outC_Functional_Vehicle_Adapter, _L19), &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int8), offsetof(outC_Functional_Vehicle_Adapter, _L21), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L23", NULL, sizeof(Override_Switch_State), offsetof(outC_Functional_Vehicle_Adapter, _L23), &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L22", NULL, sizeof(ATORSCSwitchPosition), offsetof(outC_Functional_Vehicle_Adapter, _L22), &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L26), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_Functional_Vehicle_Adapter, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29 },
    /* 30 */ { MAP_INSTANCE, "Internal_functions::ExternalStatusIndicator 1", NULL, sizeof(outC_ExternalStatusIndicator_Internal_functions), offsetof(outC_Functional_Vehicle_Adapter, Context_ExternalStatusIndicator_1), NULL, NULL, NULL, &scope_55, 1, 30 },
    /* 31 */ { MAP_AUTOMATON, "OverrideSwitch_SM:", NULL, 0, 0, NULL, NULL, NULL, &scope_65, 1, 31 }
};
const MappingScope scope_54 = {
    "Functional_Vehicle_Adapter/ Functional_Vehicle_Adapter",
    scope_54_entries, 32
};

const MappingEntry scope_53_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_TS, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_TS, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_TS, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_53 = {
    "ETCS_TS/ ETCS_TS",
    scope_53_entries, 3
};

const MappingEntry scope_52_entries[3] = {
    /* 0 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L4_then_IfBlock1), &_Type_ETCS_HMI_Msgs_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L2_then_IfBlock1), &_Type_kcg_bool_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L7_then_IfBlock1), &_Type_kcg_bool_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 }
};
const MappingScope scope_52 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:then:",
    scope_52_entries, 3
};

const MappingEntry scope_51_entries[4] = {
    /* 0 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L3_then_else_IfBlock1), &_Type_ETCS_HMI_Msgs_Utils, &scope_47_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L1_then_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_47_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L6_then_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_47_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L7_then_else_IfBlock1), &_Type_ETCSHMIPacketDataType_Utils, &scope_47_entries[0], isActive_kcg_bool_kcg_true, &scope_4, 1, 3 }
};
const MappingScope scope_51 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:else:then:",
    scope_51_entries, 4
};

const MappingEntry scope_50_entries[4] = {
    /* 0 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L4_then_else_else_IfBlock1), &_Type_ETCS_HMI_Msgs_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L1_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L6_then_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L7_then_else_else_IfBlock1), &_Type_ETCSHMIPacketDataType_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_true, &scope_4, 1, 3 }
};
const MappingScope scope_50 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:else:else:then:",
    scope_50_entries, 4
};

const MappingEntry scope_49_entries[2] = {
    /* 0 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L16_else_else_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L19", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L19_else_else_else_IfBlock1), &_Type_ETCS_HMI_Msgs_Utils, &scope_48_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1 }
};
const MappingScope scope_49 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:else:else:else:",
    scope_49_entries, 2
};

const MappingEntry scope_48_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, else_clock_else_IfBlock1), &_Type_kcg_bool_Utils, &scope_47_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_48_entries[0], isActive_kcg_bool_kcg_false, &scope_49, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_48_entries[0], isActive_kcg_bool_kcg_true, &scope_50, 1, 2 }
};
const MappingScope scope_48 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:else:else:",
    scope_48_entries, 3
};

const MappingEntry scope_47_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, else_clock_IfBlock1), &_Type_kcg_bool_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_47_entries[0], isActive_kcg_bool_kcg_false, &scope_48, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_47_entries[0], isActive_kcg_bool_kcg_true, &scope_51, 1, 2 }
};
const MappingScope scope_47 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:else:",
    scope_47_entries, 3
};

const MappingEntry scope_46_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_47, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_52, 1, 2 }
};
const MappingScope scope_46 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_MsgsIfBlock1:",
    scope_46_entries, 3
};

const MappingEntry scope_45_entries[56] = {
    /* 0 */ { MAP_OUTPUT, "Send_HMI_Packet", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_Receive_HMI_Msgs, Send_HMI_Packet), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ATO_TBD", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, to_ATO_TBD), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "to_HMI_Data", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, to_HMI_Data), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_LOCAL, "TrainData_from_HMI", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, TrainData_from_HMI), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 3 },
    /* 4 */ { MAP_LOCAL, "ATO_Data_Acknowledged", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, ATO_Data_Acknowledged), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "ETCS_Data_Acknowledged", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, ETCS_Data_Acknowledged), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "TrainDataAvailable", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, TrainDataAvailable), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "MessageCondition", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, MessageCondition), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "UpdatedMsgCondition", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, UpdatedMsgCondition), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "Msg", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, Msg), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L16), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L14", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_Receive_HMI_Msgs, _L14), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L12), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L10", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L10), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L8", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_Receive_HMI_Msgs, _L8), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L9", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L9), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L17", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L17), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L18", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L18), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L20", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L20), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L21", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L21), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L22", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L22), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L25", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_Receive_HMI_Msgs, _L25), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L27", NULL, sizeof(ATO_modes), offsetof(outC_Send_Receive_HMI_Msgs, _L27), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L26", NULL, sizeof(ETCS_modes), offsetof(outC_Send_Receive_HMI_Msgs, _L26), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L32", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L32), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L33), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L34", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_Receive_HMI_Msgs, _L34), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L40), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L39", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_Send_Receive_HMI_Msgs, _L39), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L38", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_Send_Receive_HMI_Msgs, _L38), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L37", NULL, sizeof(ETCS_modes), offsetof(outC_Send_Receive_HMI_Msgs, _L37), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L36", NULL, sizeof(ATO_modes), offsetof(outC_Send_Receive_HMI_Msgs, _L36), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 34 },
    /* 35 */ { MAP_LOCAL, "_L35", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L35), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 35 },
    /* 36 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L41), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36 },
    /* 37 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L42), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 37 },
    /* 38 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38 },
    /* 39 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L44), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 39 },
    /* 40 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L45), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 40 },
    /* 41 */ { MAP_LOCAL, "_L46", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L46), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 41 },
    /* 42 */ { MAP_LOCAL, "_L62", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L62), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 42 },
    /* 43 */ { MAP_LOCAL, "_L64", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L64), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 43 },
    /* 44 */ { MAP_LOCAL, "_L73", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L73), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 44 },
    /* 45 */ { MAP_LOCAL, "_L72", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L72), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45 },
    /* 46 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L70), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 46 },
    /* 47 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L69), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 47 },
    /* 48 */ { MAP_LOCAL, "_L68", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L68), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 48 },
    /* 49 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L67), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 49 },
    /* 50 */ { MAP_LOCAL, "_L66", NULL, sizeof(ETCSHMIPacket), offsetof(outC_Send_Receive_HMI_Msgs, _L66), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 50 },
    /* 51 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_int8), offsetof(outC_Send_Receive_HMI_Msgs, _L65), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 51 },
    /* 52 */ { MAP_LOCAL, "_L76", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L76), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 52 },
    /* 53 */ { MAP_LOCAL, "_L71", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_Send_Receive_HMI_Msgs, _L71), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 53 },
    /* 54 */ { MAP_LOCAL, "_L77", NULL, sizeof(kcg_bool), offsetof(outC_Send_Receive_HMI_Msgs, _L77), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 54 },
    /* 55 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_46, 1, 55 }
};
const MappingScope scope_45 = {
    "Send_Receive_HMI_Msgs/ Send_Receive_HMI_Msgs",
    scope_45_entries, 56
};

const MappingEntry scope_44_entries[17] = {
    /* 0 */ { MAP_OUTPUT, "ATOMode", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, ATOMode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "temp_ATOMode", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, temp_ATOMode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_bool), offsetof(outC_SetATOMode, _L38), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_bool), offsetof(outC_SetATOMode, _L37), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L36", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, _L36), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_SetATOMode, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L34", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, _L34), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L33", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, _L33), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L32", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, _L32), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L28", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_SetATOMode, _L28), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L29", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_SetATOMode, _L29), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L30", NULL, sizeof(ETCS_modes), offsetof(outC_SetATOMode, _L30), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L31", NULL, sizeof(ATO_modes), offsetof(outC_SetATOMode, _L31), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L27", NULL, sizeof(ETCSHMIPacket), offsetof(outC_SetATOMode, _L27), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L40", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_SetATOMode, _L40), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L39", NULL, sizeof(kcg_bool), offsetof(outC_SetATOMode, _L39), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_bool), offsetof(outC_SetATOMode, _L41), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 }
};
const MappingScope scope_44 = {
    "SetATOMode/ SetATOMode",
    scope_44_entries, 17
};

const MappingEntry scope_43_entries[17] = {
    /* 0 */ { MAP_OUTPUT, "ETCSMode", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, ETCSMode), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "temp_ETCSMode", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, temp_ETCSMode), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(ETCSHMIPacket), offsetof(outC_SetETCSMode, _L1), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L5", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(outC_SetETCSMode, _L5), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(ETCS_HMI_Msgs), offsetof(outC_SetETCSMode, _L4), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, _L3), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(ATO_modes), offsetof(outC_SetETCSMode, _L2), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, _L6), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, _L7), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L12", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, _L12), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L13", NULL, sizeof(ETCS_modes), offsetof(outC_SetETCSMode, _L13), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_SetETCSMode, _L16), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_SetETCSMode, _L15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_SetETCSMode, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L18", NULL, sizeof(ETCSHMIPacketDataType), offsetof(outC_SetETCSMode, _L18), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_bool), offsetof(outC_SetETCSMode, _L17), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_SetETCSMode, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 }
};
const MappingScope scope_43 = {
    "SetETCSMode/ SetETCSMode",
    scope_43_entries, 17
};

const MappingEntry scope_42_entries[39] = {
    /* 0 */ { MAP_OUTPUT, "to_ATO_OB", NULL, sizeof(ETCSATOPacket), offsetof(outC_ETCS_OB, to_ATO_OB), &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_Train_Driver", NULL, sizeof(ETCSHMIPacket), offsetof(outC_ETCS_OB, to_Train_Driver), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_EmergencyBrakeIO", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_EmergencyBrakeIO), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_OpenIO_Interface", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_OpenIO_Interface), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_Vehicle_Management_System", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_Vehicle_Management_System), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_OUTPUT, "to_Diagnostic_platform", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_Diagnostic_platform), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_OUTPUT, "to_RSC_OB", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_RSC_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "ETCSMode", NULL, sizeof(ETCS_modes), offsetof(outC_ETCS_OB, ETCSMode), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "ATOmode", NULL, sizeof(ATO_modes), offsetof(outC_ETCS_OB, ATOmode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "temp_overrideswitchstate", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, temp_overrideswitchstate), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L12", NULL, sizeof(ETCSHMIPacket), offsetof(outC_ETCS_OB, _L12), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L39", NULL, sizeof(ETCSHMIPacket), offsetof(outC_ETCS_OB, _L39), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L40", NULL, sizeof(ETCS_modes), offsetof(outC_ETCS_OB, _L40), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L41", NULL, sizeof(ETCSHMIPacket), offsetof(outC_ETCS_OB, _L41), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L42", NULL, sizeof(ATO_modes), offsetof(outC_ETCS_OB, _L42), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L44", NULL, sizeof(ETCSHMIPacket), offsetof(outC_ETCS_OB, _L44), &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L45), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L46", NULL, sizeof(ETCSATOPacket), offsetof(outC_ETCS_OB, _L46), &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L47", NULL, sizeof(ATO_modes), offsetof(outC_ETCS_OB, _L47), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L48", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L48), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L49", NULL, sizeof(ETCSATOPacket), offsetof(outC_ETCS_OB, _L49), &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L50", NULL, sizeof(ETCSATOPacket), offsetof(outC_ETCS_OB, _L50), &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L51", NULL, sizeof(kcg_bool), offsetof(outC_ETCS_OB, _L51), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L52", NULL, sizeof(ETCS_modes), offsetof(outC_ETCS_OB, _L52), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 34 },
    /* 35 */ { MAP_LOCAL, "_L53", NULL, sizeof(kcg_int8), offsetof(outC_ETCS_OB, _L53), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 35 },
    /* 36 */ { MAP_INSTANCE, "SetETCSMode 1", NULL, sizeof(outC_SetETCSMode), offsetof(outC_ETCS_OB, Context_SetETCSMode_1), NULL, NULL, NULL, &scope_43, 1, 36 },
    /* 37 */ { MAP_INSTANCE, "SetATOMode 1", NULL, sizeof(outC_SetATOMode), offsetof(outC_ETCS_OB, Context_SetATOMode_1), NULL, NULL, NULL, &scope_44, 1, 37 },
    /* 38 */ { MAP_INSTANCE, "Send_Receive_HMI_Msgs 8", NULL, sizeof(outC_Send_Receive_HMI_Msgs), offsetof(outC_ETCS_OB, Context_Send_Receive_HMI_Msgs_8), NULL, NULL, NULL, &scope_45, 1, 38 }
};
const MappingScope scope_42 = {
    "ETCS_OB/ ETCS_OB",
    scope_42_entries, 39
};

const MappingEntry scope_41_entries[7] = {
    /* 0 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ATO_OB_ss139", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, to_ATO_OB_ss139), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_ATO_OB_C15", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, to_ATO_OB_C15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Driving_Style_Engine, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 }
};
const MappingScope scope_41 = {
    "Driving_Style_Engine/ Driving_Style_Engine",
    scope_41_entries, 7
};

const MappingEntry scope_40_entries[3] = {
    /* 0 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostics_TS, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostics_TS, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostics_TS, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_40 = {
    "Diagnostics_TS/ Diagnostics_TS",
    scope_40_entries, 3
};

const MappingEntry scope_39_entries[11] = {
    /* 0 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, to_RM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_ATO_OB", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, to_ATO_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_RSC_OB", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, to_RSC_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_FVA", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, to_FVA), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_Diagnostic_Platform, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 }
};
const MappingScope scope_39 = {
    "Diagnostic_Platform/ Diagnostic_Platform",
    scope_39_entries, 11
};

const MappingEntry scope_38_entries[12] = {
    /* 0 */ { MAP_OUTPUT, "to_RM_ss126", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_TS, to_RM_ss126), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_TS, _L3), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_TS, _L4), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int8), offsetof(outC_ATO_TS, _L6), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int8), offsetof(outC_ATO_TS, _L8), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_ATO_TS, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int8), offsetof(outC_ATO_TS, _L15), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 11 }
};
const MappingScope scope_38 = {
    "ATO_TS/ ATO_TS",
    scope_38_entries, 12
};

const MappingEntry scope_37_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1, NULL, 1, 0 }
};
const MappingScope scope_37 = {
    "ATO_OB/ ATO_OBSM1:ATO_Failure:<1",
    scope_37_entries, 1
};

const MappingEntry scope_36_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_ATO_Failure_No_Power_1_ATO_Failure_SM1, &scope_37, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L2_ATO_Failure_SM1), &_Type_kcg_int8_Utils, &scope_11_entries[0], isActive__2_SSM_ST_SM1_SSM_st_ATO_Failure_SM1, NULL, 1, 1 }
};
const MappingScope scope_36 = {
    "ATO_OB/ ATO_OBSM1:ATO_Failure:",
    scope_36_entries, 2
};

const MappingEntry scope_35_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_35 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Disengaging:<2",
    scope_35_entries, 1
};

const MappingEntry scope_34_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_34 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Disengaging:<1",
    scope_34_entries, 1
};

const MappingEntry scope_33_entries[3] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Engaged_1_ATO_Disengaging_SM2_Power_On_SM1, &scope_34, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Disengaging_ATO_Not_Available_2_ATO_Disengaging_SM2_Power_On_SM1, &scope_35, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L2_ATO_Disengaging_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Disengaging_SM2_Power_On_SM1, NULL, 1, 2 }
};
const MappingScope scope_33 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Disengaging:",
    scope_33_entries, 3
};

const MappingEntry scope_32_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_32 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Engaged:<3",
    scope_32_entries, 1
};

const MappingEntry scope_31_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_31 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Engaged:<2",
    scope_31_entries, 1
};

const MappingEntry scope_30_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_30 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Engaged:<1",
    scope_30_entries, 1
};

const MappingEntry scope_29_entries[4] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Disengaging_1_ATO_Engaged_SM2_Power_On_SM1, &scope_30, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Not_Available_2_ATO_Engaged_SM2_Power_On_SM1, &scope_31, 1, 1 },
    /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Engaged_ATO_Available_3_ATO_Engaged_SM2_Power_On_SM1, &scope_32, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L2_ATO_Engaged_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Engaged_SM2_Power_On_SM1, NULL, 1, 3 }
};
const MappingScope scope_29 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Engaged:",
    scope_29_entries, 4
};

const MappingEntry scope_28_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_28 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Ready:<3",
    scope_28_entries, 1
};

const MappingEntry scope_27_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_27 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Ready:<2",
    scope_27_entries, 1
};

const MappingEntry scope_26_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_26 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Ready:<1",
    scope_26_entries, 1
};

const MappingEntry scope_25_entries[4] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Engaged_1_ATO_Ready_SM2_Power_On_SM1, &scope_26, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Not_Available_2_ATO_Ready_SM2_Power_On_SM1, &scope_27, 1, 1 },
    /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Ready_ATO_Available_3_ATO_Ready_SM2_Power_On_SM1, &scope_28, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L3_ATO_Ready_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Ready_SM2_Power_On_SM1, NULL, 1, 3 }
};
const MappingScope scope_25 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Ready:",
    scope_25_entries, 4
};

const MappingEntry scope_24_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_24 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Available:<1",
    scope_24_entries, 1
};

const MappingEntry scope_23_entries[1] = {
    /* 0 */ { MAP_WEAK_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_23 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Available:<2",
    scope_23_entries, 1
};

const MappingEntry scope_22_entries[3] = {
    /* 0 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Ready_2_ATO_Available_SM2_Power_On_SM1, &scope_23, 1, 0 },
    /* 1 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[5], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Available_ATO_Not_Available_1_ATO_Available_SM2_Power_On_SM1, &scope_24, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L4_ATO_Available_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Available_SM2_Power_On_SM1, NULL, 1, 2 }
};
const MappingScope scope_22 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Available:",
    scope_22_entries, 3
};

const MappingEntry scope_21_entries[1] = {
    /* 0 */ { MAP_WEAK_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_21 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Not_Available:<1",
    scope_21_entries, 1
};

const MappingEntry scope_20_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Not_Available_ATO_Available_1_ATO_Not_Available_SM2_Power_On_SM1, &scope_21, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L2_ATO_Not_Available_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Not_Available_SM2_Power_On_SM1, NULL, 1, 1 }
};
const MappingScope scope_20 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Not_Available:",
    scope_20_entries, 2
};

const MappingEntry scope_19_entries[1] = {
    /* 0 */ { MAP_WEAK_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_19 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Configuration:<1",
    scope_19_entries, 1
};

const MappingEntry scope_18_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_17_entries[6], isActive_SSM_TR_SM2_Power_On_SM1_SSM_TR_ATO_Configuration_ATO_Not_Available_1_ATO_Configuration_SM2_Power_On_SM1, &scope_19, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L3_ATO_Configuration_SM2_Power_On_SM1), &_Type_kcg_int8_Utils, &scope_10_entries[38], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Configuration_SM2_Power_On_SM1, NULL, 1, 1 }
};
const MappingScope scope_18 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:ATO_Configuration:",
    scope_18_entries, 2
};

const MappingEntry scope_17_entries[13] = {
    /* 0 */ { MAP_LOCAL, "@active_state", NULL, sizeof(SSM_ST_SM2_Power_On_SM1), offsetof(outC_ATO_OB, SM2_state_act_Power_On_SM1), &_Type_SSM_ST_SM2_Power_On_SM1_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_LOCAL, "@reset_active_state", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, SM2_reset_act_Power_On_SM1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1 },
    /* 2 */ { MAP_LOCAL, "@next_state", NULL, sizeof(SSM_ST_SM2_Power_On_SM1), offsetof(outC_ATO_OB, SM2_state_nxt_Power_On_SM1), &_Type_SSM_ST_SM2_Power_On_SM1_Utils, NULL, NULL, NULL, 0, 2 },
    /* 3 */ { MAP_LOCAL, "@reset_next_state", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, SM2_reset_nxt_Power_On_SM1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 3 },
    /* 4 */ { MAP_LOCAL, "@selected_state", NULL, sizeof(SSM_ST_SM2_Power_On_SM1), offsetof(outC_ATO_OB, SM2_state_sel_Power_On_SM1), &_Type_SSM_ST_SM2_Power_On_SM1_Utils, NULL, NULL, NULL, 0, 4 },
    /* 5 */ { MAP_LOCAL, "@active_strong_transition", NULL, sizeof(SSM_TR_SM2_Power_On_SM1), offsetof(outC_ATO_OB, SM2_fired_strong_Power_On_SM1), &_Type_SSM_TR_SM2_Power_On_SM1_Utils, NULL, NULL, NULL, 0, 5 },
    /* 6 */ { MAP_LOCAL, "@active_weak_transition", NULL, sizeof(SSM_TR_SM2_Power_On_SM1), offsetof(outC_ATO_OB, SM2_fired_Power_On_SM1), &_Type_SSM_TR_SM2_Power_On_SM1_Utils, NULL, NULL, NULL, 0, 6 },
    /* 7 */ { MAP_STATE, "ATO_Configuration:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Configuration_SM2_Power_On_SM1, &scope_18, 1, 7 },
    /* 8 */ { MAP_STATE, "ATO_Not_Available:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Not_Available_SM2_Power_On_SM1, &scope_20, 1, 8 },
    /* 9 */ { MAP_STATE, "ATO_Available:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Available_SM2_Power_On_SM1, &scope_22, 1, 9 },
    /* 10 */ { MAP_STATE, "ATO_Ready:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Ready_SM2_Power_On_SM1, &scope_25, 1, 10 },
    /* 11 */ { MAP_STATE, "ATO_Engaged:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Engaged_SM2_Power_On_SM1, &scope_29, 1, 11 },
    /* 12 */ { MAP_STATE, "ATO_Disengaging:", NULL, 0, 0, NULL, &scope_17_entries[0], isActive_SSM_ST_SM2_Power_On_SM1_SSM_st_ATO_Disengaging_SM2_Power_On_SM1, &scope_33, 1, 12 }
};
const MappingScope scope_17 = {
    "ATO_OB/ ATO_OBSM1:Power_On:SM2:",
    scope_17_entries, 13
};

const MappingEntry scope_16_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_16 = {
    "ATO_OB/ ATO_OBSM1:Power_On:<2",
    scope_16_entries, 1
};

const MappingEntry scope_15_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_Power_On_No_Power_1_Power_On_SM1, NULL, 1, 0 }
};
const MappingScope scope_15 = {
    "ATO_OB/ ATO_OBSM1:Power_On:<1",
    scope_15_entries, 1
};

const MappingEntry scope_14_entries[3] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_Power_On_No_Power_1_Power_On_SM1, &scope_15, 1, 0 },
    /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_Power_On_ATO_Failure_2_Power_On_SM1, &scope_16, 1, 1 },
    /* 2 */ { MAP_AUTOMATON, "SM2:", NULL, 0, 0, NULL, NULL, NULL, &scope_17, 1, 2 }
};
const MappingScope scope_14 = {
    "ATO_OB/ ATO_OBSM1:Power_On:",
    scope_14_entries, 3
};

const MappingEntry scope_13_entries[1] = {
    /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_No_Power_Power_On_1_No_Power_SM1, NULL, 1, 0 }
};
const MappingScope scope_13 = {
    "ATO_OB/ ATO_OBSM1:No_Power:<1",
    scope_13_entries, 1
};

const MappingEntry scope_12_entries[2] = {
    /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_11_entries[5], isActive__3_SSM_TR_SM1_SSM_TR_No_Power_Power_On_1_No_Power_SM1, &scope_13, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L2_No_Power_SM1), &_Type_kcg_int8_Utils, &scope_11_entries[0], isActive__2_SSM_ST_SM1_SSM_st_No_Power_SM1, NULL, 1, 1 }
};
const MappingScope scope_12 = {
    "ATO_OB/ ATO_OBSM1:No_Power:",
    scope_12_entries, 2
};

const MappingEntry scope_11_entries[10] = {
    /* 0 */ { MAP_LOCAL, "@active_state", NULL, sizeof(_2_SSM_ST_SM1), offsetof(outC_ATO_OB, SM1_state_act), &_Type__2_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_LOCAL, "@reset_active_state", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, SM1_reset_act), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1 },
    /* 2 */ { MAP_LOCAL, "@next_state", NULL, sizeof(_2_SSM_ST_SM1), offsetof(outC_ATO_OB, SM1_state_nxt), &_Type__2_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 2 },
    /* 3 */ { MAP_LOCAL, "@reset_next_state", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, SM1_reset_nxt), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 3 },
    /* 4 */ { MAP_LOCAL, "@selected_state", NULL, sizeof(_2_SSM_ST_SM1), offsetof(outC_ATO_OB, SM1_state_sel), &_Type__2_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 4 },
    /* 5 */ { MAP_LOCAL, "@active_strong_transition", NULL, sizeof(_3_SSM_TR_SM1), offsetof(outC_ATO_OB, SM1_fired_strong), &_Type__3_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 5 },
    /* 6 */ { MAP_LOCAL, "@active_weak_transition", NULL, sizeof(_3_SSM_TR_SM1), offsetof(outC_ATO_OB, SM1_fired), &_Type__3_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 6 },
    /* 7 */ { MAP_STATE, "No_Power:", NULL, 0, 0, NULL, &scope_11_entries[0], isActive__2_SSM_ST_SM1_SSM_st_No_Power_SM1, &scope_12, 1, 7 },
    /* 8 */ { MAP_STATE, "Power_On:", NULL, 0, 0, NULL, &scope_11_entries[0], isActive__2_SSM_ST_SM1_SSM_st_Power_On_SM1, &scope_14, 1, 8 },
    /* 9 */ { MAP_STATE, "ATO_Failure:", NULL, 0, 0, NULL, &scope_11_entries[0], isActive__2_SSM_ST_SM1_SSM_st_ATO_Failure_SM1, &scope_36, 1, 9 }
};
const MappingScope scope_11 = {
    "ATO_OB/ ATO_OBSM1:",
    scope_11_entries, 10
};

const MappingEntry scope_10_entries[40] = {
    /* 0 */ { MAP_OUTPUT, "to_ETCS_OB", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, to_ETCS_OB), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "to_Driving_Style_Engine_ss139", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, to_Driving_Style_Engine_ss139), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "to_Diagnostic_Platform", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, to_Diagnostic_Platform), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_OUTPUT, "to_Driving_Style_Engine_C15", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, to_Driving_Style_Engine_C15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_OUTPUT, "to_RM", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_OB, to_RM), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 4 },
    /* 5 */ { MAP_LOCAL, "ATO_State", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, ATO_State), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "ATO_Power_On", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, ATO_Power_On), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "ATO_Data_Received", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, ATO_Data_Received), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "Override_Switch_State", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, Override_Switch_State), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "Journey_Profile_Received", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, Journey_Profile_Received), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "ATO_Mode_Selected", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, ATO_Mode_Selected), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "ATO_Active_VM", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, ATO_Active_VM), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_LOCAL, "_L3", NULL, sizeof(ETCSATOPacket), offsetof(outC_ATO_OB, _L3), &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 14 },
    /* 15 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "_L14", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_OB, _L14), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 17 },
    /* 18 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L32), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L30), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 20 },
    /* 21 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L29), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L28), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "_L33", NULL, sizeof(ATO_Packet), offsetof(outC_ATO_OB, _L33), &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 24 },
    /* 25 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L34), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "_L36", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L36), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L37), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28 },
    /* 29 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_int8), offsetof(outC_ATO_OB, _L38), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 29 },
    /* 30 */ { MAP_LOCAL, "_L39", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L39), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30 },
    /* 31 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L40), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31 },
    /* 32 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L41), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32 },
    /* 33 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "_L46", NULL, sizeof(ATO_modes), offsetof(outC_ATO_OB, _L46), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 34 },
    /* 35 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L45), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35 },
    /* 36 */ { MAP_LOCAL, "_L47", NULL, sizeof(kcg_bool), offsetof(outC_ATO_OB, _L47), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36 },
    /* 37 */ { MAP_AUTOMATON, "SM1:", NULL, 0, 0, NULL, NULL, NULL, &scope_11, 1, 37 },
    /* 38 */ { MAP_LOCAL, "@kcg1", NULL, sizeof(SSM_ST_SM2_Power_On_SM1), offsetof(outC_ATO_OB, _1_SM2_clock_Power_On_SM1), &_Type_SSM_ST_SM2_Power_On_SM1_Utils, &scope_10_entries[39], isActive__2_SSM_ST_SM1_SSM_st_Power_On_SM1, NULL, 0, 38 },
    /* 39 */ { MAP_LOCAL, "@kcg2", NULL, sizeof(_2_SSM_ST_SM1), offsetof(outC_ATO_OB, SM1_state_act), &_Type__2_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 39 }
};
const MappingScope scope_10 = {
    "ATO_OB/ ATO_OB",
    scope_10_entries, 40
};

const MappingEntry scope_9_entries[3] = {
    /* 0 */ { MAP_FIELD, ".Distance_Covered", NULL, sizeof(kcg_int16), offsetof(Tain_Physics_Outputs, Distance_Covered), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".Train_Speed", NULL, sizeof(kcg_int16), offsetof(Tain_Physics_Outputs, Train_Speed), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".Train_Acceleration", NULL, sizeof(kcg_float32), offsetof(Tain_Physics_Outputs, Train_Acceleration), &_Type_kcg_float32_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_9 = {
    "Tain_Physics_Outputs",
    scope_9_entries, 3
};

const MappingEntry scope_8_entries[2] = {
    /* 0 */ { MAP_FIELD, ".OverrideSwitch", NULL, sizeof(Override_Switch_State), offsetof(FVAHMIPacket, OverrideSwitch), &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".ATORSCSwitch", NULL, sizeof(ATORSCSwitchPosition), offsetof(FVAHMIPacket, ATORSCSwitch), &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 1 }
};
const MappingScope scope_8 = {
    "FVAHMIPacket",
    scope_8_entries, 2
};

const MappingEntry scope_7_entries[6] = {
    /* 0 */ { MAP_FIELD, ".isvalid", NULL, sizeof(kcg_bool), offsetof(ETCSHMIPacket, isvalid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".Header", NULL, sizeof(ETCS_HMI_MsgHeaders), offsetof(ETCSHMIPacket, Header), &_Type_ETCS_HMI_MsgHeaders_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".Message", NULL, sizeof(ETCS_HMI_Msgs), offsetof(ETCSHMIPacket, Message), &_Type_ETCS_HMI_Msgs_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_FIELD, ".currentETCSmode", NULL, sizeof(ETCS_modes), offsetof(ETCSHMIPacket, currentETCSmode), &_Type_ETCS_modes_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_FIELD, ".currentATOmode", NULL, sizeof(ATO_modes), offsetof(ETCSHMIPacket, currentATOmode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_FIELD, ".ETCSHMIPacketData", NULL, sizeof(ETCSHMIPacketDataType), offsetof(ETCSHMIPacket, ETCSHMIPacketData), &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 5 }
};
const MappingScope scope_7 = {
    "ETCSHMIPacket",
    scope_7_entries, 6
};

const MappingEntry scope_6_entries[3] = {
    /* 0 */ { MAP_FIELD, ".ATO_selected_mode", NULL, sizeof(ATO_modes), offsetof(ETCSATOPacket, ATO_selected_mode), &_Type_ATO_modes_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".ATO_DataAcknowledged", NULL, sizeof(kcg_bool), offsetof(ETCSATOPacket, ATO_DataAcknowledged), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".temp_Override_SwitchState", NULL, sizeof(kcg_bool), offsetof(ETCSATOPacket, temp_Override_SwitchState), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_6 = {
    "ETCSATOPacket",
    scope_6_entries, 3
};

const MappingEntry scope_5_entries[2] = {
    /* 0 */ { MAP_FIELD, ".Header", NULL, sizeof(kcg_int8), offsetof(ATO_Packet, Header), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".Value", NULL, sizeof(kcg_bool), offsetof(ATO_Packet, Value), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 }
};
const MappingScope scope_5 = {
    "ATO_Packet",
    scope_5_entries, 2
};

const MappingEntry scope_4_entries[8] = {
    /* 0 */ { MAP_FIELD, ".label1", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label1), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".label2", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label2), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".label3", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label3), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_FIELD, ".label4", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label4), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_FIELD, ".label5", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label5), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_FIELD, ".label6", NULL, sizeof(kcg_int8), offsetof(ETCSHMIPacketDataType, label6), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_FIELD, ".label7", NULL, sizeof(kcg_int16), offsetof(ETCSHMIPacketDataType, label7), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_FIELD, ".label8", NULL, sizeof(kcg_int16), offsetof(ETCSHMIPacketDataType, label8), &_Type_kcg_int16_Utils, NULL, NULL, NULL, 1, 7 }
};
const MappingScope scope_4 = {
    "ETCSHMIPacketDataType",
    scope_4_entries, 8
};

const MappingEntry scope_3_entries[1] = {
    /* 0 */ { MAP_ARRAY, "", &iter_array_30, sizeof(kcg_char), 0, &_Type_kcg_char_Utils, NULL, NULL, NULL, 1, 0 }
};
const MappingScope scope_3 = {
    "array_char_30",
    scope_3_entries, 1
};

const MappingEntry scope_2_entries[3] = {
    /* 0 */ { MAP_FIELD, ".IndicatorState", NULL, sizeof(kcg_int8), offsetof(ExternalindicatorStates, IndicatorState), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".RedLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, RedLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".GreenLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, GreenLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_2 = {
    "ExternalindicatorStates",
    scope_2_entries, 3
};

const MappingEntry scope_1_entries[261] = {
    /* 0 */ { MAP_OUTPUT, "External_Status_Indication_Status", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx.External_Status_Indication_Status, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 0 },
    /* 1 */ { MAP_OUTPUT, "ETCSHMI_TextBox", NULL, sizeof(array_char_30), (size_t)&outputs_ctx.ETCSHMI_TextBox, &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 1 },
    /* 2 */ { MAP_OUTPUT, "ETCS_HMI_Data_Out", NULL, sizeof(ETCSHMIPacketDataType), (size_t)&outputs_ctx.ETCS_HMI_Data_Out, &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 2 },
    /* 3 */ { MAP_INPUT, "SystemtoSignalOperator", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.SystemtoSignalOperator, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_INPUT, "ATO_ONSwitch_GUI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.ATO_ONSwitch_GUI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_INPUT, "RSC_ONSwitch_GUI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.RSC_ONSwitch_GUI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_INPUT, "ATORSC_SwitchPosition", NULL, sizeof(ATORSCSwitchPosition), (size_t)&inputs_ctx.ATORSC_SwitchPosition, &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_INPUT, "SendMsgto_ETCS_HMI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.SendMsgto_ETCS_HMI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_INPUT, "FSbutton_ETCS_HMI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.FSbutton_ETCS_HMI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_INPUT, "GoA2button_ETCS_HMI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.GoA2button_ETCS_HMI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_INPUT, "GoA4button_ETCs_HMI", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.GoA4button_ETCs_HMI, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_INPUT, "T_B_Lever", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.T_B_Lever, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 11 },
    /* 12 */ { MAP_INPUT, "Train_Brake_Lever", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.Train_Brake_Lever, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_INPUT, "ApplyHoldingBrake", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.ApplyHoldingBrake, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13 },
    /* 14 */ { MAP_INPUT, "ETCS_HMI_Data_in", NULL, sizeof(ETCSHMIPacketDataType), (size_t)&inputs_ctx.ETCS_HMI_Data_in, &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 14 },
    /* 15 */ { MAP_INPUT, "OverrideSwitch", NULL, sizeof(kcg_bool), (size_t)&inputs_ctx.OverrideSwitch, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15 },
    /* 16 */ { MAP_LOCAL, "ATO_OBtoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ATO_OBtoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16 },
    /* 17 */ { MAP_LOCAL, "ATO_OBtoDSE_ss139", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ATO_OBtoDSE_ss139, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17 },
    /* 18 */ { MAP_LOCAL, "ATO_OBtoDiagnosticPlatfom", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ATO_OBtoDiagnosticPlatfom, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18 },
    /* 19 */ { MAP_LOCAL, "ATO_OBtoDSE_C15", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ATO_OBtoDSE_C15, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19 },
    /* 20 */ { MAP_LOCAL, "ATO_TStoRM_ss126", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx.ATO_TStoRM_ss126, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 20 },
    /* 21 */ { MAP_LOCAL, "Diagnostic_PlatformtoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Diagnostic_PlatformtoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21 },
    /* 22 */ { MAP_LOCAL, "Diagnostic_PlatformtoATO_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Diagnostic_PlatformtoATO_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22 },
    /* 23 */ { MAP_LOCAL, "Diagnostic_PlatformtoRSC_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Diagnostic_PlatformtoRSC_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 23 },
    /* 24 */ { MAP_LOCAL, "Diagnostic_PlatformtoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Diagnostic_PlatformtoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24 },
    /* 25 */ { MAP_LOCAL, "Diagnostic_PlatformtoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Diagnostic_PlatformtoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25 },
    /* 26 */ { MAP_LOCAL, "Dianostics_TStoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Dianostics_TStoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26 },
    /* 27 */ { MAP_LOCAL, "DSEtoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.DSEtoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 27 },
    /* 28 */ { MAP_LOCAL, "DSEtoATO_OB_ss139", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.DSEtoATO_OB_ss139, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28 },
    /* 29 */ { MAP_LOCAL, "DSEtoATO_OB_C15", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.DSEtoATO_OB_C15, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29 },
    /* 30 */ { MAP_LOCAL, "ETCS_OBtoATO_OB", NULL, sizeof(ETCSATOPacket), (size_t)&outputs_ctx.ETCS_OBtoATO_OB, &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 30 },
    /* 31 */ { MAP_LOCAL, "ETCS_OBtoTrainDriver", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx.ETCS_OBtoTrainDriver, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 31 },
    /* 32 */ { MAP_LOCAL, "ETCS_OBtoEmergencyBrake_EB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoEmergencyBrake_EB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32 },
    /* 33 */ { MAP_LOCAL, "ETCS_OBtoOpenIO_Interface", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoOpenIO_Interface, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33 },
    /* 34 */ { MAP_LOCAL, "ETCS_OBtoVehicle_Management", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoVehicle_Management, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 34 },
    /* 35 */ { MAP_LOCAL, "ETCS_OBtoDiagnostic_Platform", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoDiagnostic_Platform, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35 },
    /* 36 */ { MAP_LOCAL, "ETCS_OBtoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36 },
    /* 37 */ { MAP_LOCAL, "ETCS_OBtoRSC_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoRSC_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 37 },
    /* 38 */ { MAP_LOCAL, "ETCS_OBtoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_OBtoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38 },
    /* 39 */ { MAP_LOCAL, "ETCS_TStoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ETCS_TStoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 39 },
    /* 40 */ { MAP_LOCAL, "FVAtoPerception_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoPerception_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 40 },
    /* 41 */ { MAP_LOCAL, "FVAtoTrainDriver", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx.FVAtoTrainDriver, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 41 },
    /* 42 */ { MAP_LOCAL, "FVAtoETCSOB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoETCSOB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 42 },
    /* 43 */ { MAP_LOCAL, "FVAtoDSE", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoDSE, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 43 },
    /* 44 */ { MAP_LOCAL, "FVAtoOpenIO_Interface", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoOpenIO_Interface, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 44 },
    /* 45 */ { MAP_LOCAL, "FVAtoVehicleMangement", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoVehicleMangement, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45 },
    /* 46 */ { MAP_LOCAL, "FVAtoDiagnostic_Platform", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoDiagnostic_Platform, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 46 },
    /* 47 */ { MAP_LOCAL, "FVAtoRollingStock_OperatingSystem", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoRollingStock_OperatingSystem, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 47 },
    /* 48 */ { MAP_LOCAL, "FVAtoRSC_OB_int2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoRSC_OB_int2, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 48 },
    /* 49 */ { MAP_LOCAL, "FVAtoRSC_OB_ss139", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.FVAtoRSC_OB_ss139, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 49 },
    /* 50 */ { MAP_LOCAL, "Perception_OBtoPerception_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Perception_OBtoPerception_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 50 },
    /* 51 */ { MAP_LOCAL, "Perception_OBtoEmergencyBrake_EB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Perception_OBtoEmergencyBrake_EB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 51 },
    /* 52 */ { MAP_LOCAL, "Perception_OBtoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Perception_OBtoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 52 },
    /* 53 */ { MAP_LOCAL, "Perception_TStoRSC_Operator", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Perception_TStoRSC_Operator, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 53 },
    /* 54 */ { MAP_LOCAL, "Perception_TStoPerception_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Perception_TStoPerception_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 54 },
    /* 55 */ { MAP_LOCAL, "RMtoATO_OB", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx.RMtoATO_OB, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 55 },
    /* 56 */ { MAP_LOCAL, "RMtoRSC_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoRSC_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 56 },
    /* 57 */ { MAP_LOCAL, "RMtoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 57 },
    /* 58 */ { MAP_LOCAL, "RMtoDiagnosticPlatform", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoDiagnosticPlatform, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 58 },
    /* 59 */ { MAP_LOCAL, "RMtoDiagnostic_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoDiagnostic_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 59 },
    /* 60 */ { MAP_LOCAL, "RMtoETCS_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoETCS_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 60 },
    /* 61 */ { MAP_LOCAL, "RSC_OBtoFVA_ss139", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OBtoFVA_ss139, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 61 },
    /* 62 */ { MAP_LOCAL, "RSC_OBtoFVA_int2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OBtoFVA_int2, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 62 },
    /* 63 */ { MAP_LOCAL, "RSC_OBtoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OBtoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 63 },
    /* 64 */ { MAP_LOCAL, "RSC_OBtoDiagnostic_Platform", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OBtoDiagnostic_Platform, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 64 },
    /* 65 */ { MAP_LOCAL, "RSC_TStoRSC_Operator", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_TStoRSC_Operator, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 65 },
    /* 66 */ { MAP_LOCAL, "RSC_TStoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_TStoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 66 },
    /* 67 */ { MAP_LOCAL, "Vehicle_Management_toFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Vehicle_Management_toFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 67 },
    /* 68 */ { MAP_LOCAL, "Vehicle_ManagementtoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Vehicle_ManagementtoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 68 },
    /* 69 */ { MAP_LOCAL, "Vehicle_ManagementtoClassB_Systems", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Vehicle_ManagementtoClassB_Systems, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 69 },
    /* 70 */ { MAP_LOCAL, "RSC_OperatortoPerception_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OperatortoPerception_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 70 },
    /* 71 */ { MAP_LOCAL, "RSC_OperatortoRSC_TS", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OperatortoRSC_TS, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 71 },
    /* 72 */ { MAP_LOCAL, "Signal_OperatortoSystem", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Signal_OperatortoSystem, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 72 },
    /* 73 */ { MAP_LOCAL, "TrainDriver_to_FVA", NULL, sizeof(FVAHMIPacket), (size_t)&outputs_ctx.TrainDriver_to_FVA, &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 73 },
    /* 74 */ { MAP_LOCAL, "TrainDriver_to_ETCS_OB", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx.TrainDriver_to_ETCS_OB, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 74 },
    /* 75 */ { MAP_LOCAL, "ClassB_Systems_to_VehicleManagement", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.ClassB_Systems_to_VehicleManagement, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 75 },
    /* 76 */ { MAP_LOCAL, "RollingStock_OperatingSystemtoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RollingStock_OperatingSystemtoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 76 },
    /* 77 */ { MAP_LOCAL, "OpenIO_InterfacetoETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.OpenIO_InterfacetoETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 77 },
    /* 78 */ { MAP_LOCAL, "OpenIO_InterfacetoFVA", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.OpenIO_InterfacetoFVA, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 78 },
    /* 79 */ { MAP_LOCAL, "Vehicle_EmergencyBrake_EBto_ETCS_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Vehicle_EmergencyBrake_EBto_ETCS_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 79 },
    /* 80 */ { MAP_LOCAL, "VehicleEmergencyBrake_EB_to_Perception_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.VehicleEmergencyBrake_EB_to_Perception_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 80 },
    /* 81 */ { MAP_LOCAL, "ATO_OBtoRM", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx.ATO_OBtoRM, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 81 },
    /* 82 */ { MAP_LOCAL, "RMtoATO_TS", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx.RMtoATO_TS, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 82 },
    /* 83 */ { MAP_LOCAL, "RMtoRSC_OB", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RMtoRSC_OB, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 83 },
    /* 84 */ { MAP_LOCAL, "RSC_OBtoRM", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.RSC_OBtoRM, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 84 },
    /* 85 */ { MAP_LOCAL, "Train_PhysicsOutputs", NULL, sizeof(Tain_Physics_Outputs), (size_t)&outputs_ctx.Train_PhysicsOutputs, &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 85 },
    /* 86 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L4, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 86 },
    /* 87 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L3, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 87 },
    /* 88 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L2, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 88 },
    /* 89 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 89 },
    /* 90 */ { MAP_LOCAL, "_L5", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L5, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 90 },
    /* 91 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L11, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 91 },
    /* 92 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L10, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 92 },
    /* 93 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L9, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 93 },
    /* 94 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L8, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 94 },
    /* 95 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L7, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 95 },
    /* 96 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L12, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 96 },
    /* 97 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L15, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 97 },
    /* 98 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L14, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 98 },
    /* 99 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L13, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 99 },
    /* 100 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L24, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 100 },
    /* 101 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L23, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 101 },
    /* 102 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L22, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 102 },
    /* 103 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L21, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 103 },
    /* 104 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L20, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 104 },
    /* 105 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L19, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 105 },
    /* 106 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L18, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 106 },
    /* 107 */ { MAP_LOCAL, "_L17", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L17, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 107 },
    /* 108 */ { MAP_LOCAL, "_L16", NULL, sizeof(ETCSATOPacket), (size_t)&outputs_ctx._L16, &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 108 },
    /* 109 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L25, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 109 },
    /* 110 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L35, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 110 },
    /* 111 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L34, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 111 },
    /* 112 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L33, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 112 },
    /* 113 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L32, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 113 },
    /* 114 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L31, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 114 },
    /* 115 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L30, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 115 },
    /* 116 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L29, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 116 },
    /* 117 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L28, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 117 },
    /* 118 */ { MAP_LOCAL, "_L27", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx._L27, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 118 },
    /* 119 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L26, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 119 },
    /* 120 */ { MAP_LOCAL, "_L39", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L39, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 120 },
    /* 121 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L38, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 121 },
    /* 122 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L37, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 122 },
    /* 123 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L43, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 123 },
    /* 124 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L42, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 124 },
    /* 125 */ { MAP_LOCAL, "_L53", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L53, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 125 },
    /* 126 */ { MAP_LOCAL, "_L52", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L52, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 126 },
    /* 127 */ { MAP_LOCAL, "_L51", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L51, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 127 },
    /* 128 */ { MAP_LOCAL, "_L50", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L50, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 128 },
    /* 129 */ { MAP_LOCAL, "_L49", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L49, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 129 },
    /* 130 */ { MAP_LOCAL, "_L48", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L48, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 130 },
    /* 131 */ { MAP_LOCAL, "_L47", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L47, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 131 },
    /* 132 */ { MAP_LOCAL, "_L59", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L59, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 132 },
    /* 133 */ { MAP_LOCAL, "_L58", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L58, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 133 },
    /* 134 */ { MAP_LOCAL, "_L57", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L57, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 134 },
    /* 135 */ { MAP_LOCAL, "_L56", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L56, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 135 },
    /* 136 */ { MAP_LOCAL, "_L55", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L55, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 136 },
    /* 137 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L65, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 137 },
    /* 138 */ { MAP_LOCAL, "_L64", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L64, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 138 },
    /* 139 */ { MAP_LOCAL, "_L70", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L70, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 139 },
    /* 140 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L69, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 140 },
    /* 141 */ { MAP_LOCAL, "_L68", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L68, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 141 },
    /* 142 */ { MAP_LOCAL, "_L72", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L72, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 142 },
    /* 143 */ { MAP_LOCAL, "_L71", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L71, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 143 },
    /* 144 */ { MAP_LOCAL, "_L73", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L73, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 144 },
    /* 145 */ { MAP_LOCAL, "_L75", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L75, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 145 },
    /* 146 */ { MAP_LOCAL, "_L74", NULL, sizeof(FVAHMIPacket), (size_t)&outputs_ctx._L74, &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 146 },
    /* 147 */ { MAP_LOCAL, "_L76", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L76, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 147 },
    /* 148 */ { MAP_LOCAL, "_L77", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L77, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 148 },
    /* 149 */ { MAP_LOCAL, "_L79", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L79, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 149 },
    /* 150 */ { MAP_LOCAL, "_L78", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L78, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 150 },
    /* 151 */ { MAP_LOCAL, "_L81", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L81, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 151 },
    /* 152 */ { MAP_LOCAL, "_L80", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L80, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 152 },
    /* 153 */ { MAP_LOCAL, "_L85", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L85, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 153 },
    /* 154 */ { MAP_LOCAL, "_L86", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L86, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 154 },
    /* 155 */ { MAP_LOCAL, "_L87", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L87, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 155 },
    /* 156 */ { MAP_LOCAL, "_L88", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx._L88, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 156 },
    /* 157 */ { MAP_LOCAL, "_L89", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L89, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 157 },
    /* 158 */ { MAP_LOCAL, "_L90", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L90, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 158 },
    /* 159 */ { MAP_LOCAL, "_L91", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L91, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 159 },
    /* 160 */ { MAP_LOCAL, "_L92", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L92, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 160 },
    /* 161 */ { MAP_LOCAL, "_L93", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L93, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 161 },
    /* 162 */ { MAP_LOCAL, "_L94", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L94, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 162 },
    /* 163 */ { MAP_LOCAL, "_L95", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L95, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 163 },
    /* 164 */ { MAP_LOCAL, "_L96", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L96, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 164 },
    /* 165 */ { MAP_LOCAL, "_L97", NULL, sizeof(ETCSATOPacket), (size_t)&outputs_ctx._L97, &_Type_ETCSATOPacket_Utils, NULL, NULL, &scope_6, 1, 165 },
    /* 166 */ { MAP_LOCAL, "_L98", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L98, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 166 },
    /* 167 */ { MAP_LOCAL, "_L99", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L99, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 167 },
    /* 168 */ { MAP_LOCAL, "_L100", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L100, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 168 },
    /* 169 */ { MAP_LOCAL, "_L101", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L101, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 169 },
    /* 170 */ { MAP_LOCAL, "_L102", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L102, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 170 },
    /* 171 */ { MAP_LOCAL, "_L103", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L103, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 171 },
    /* 172 */ { MAP_LOCAL, "_L106", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L106, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 172 },
    /* 173 */ { MAP_LOCAL, "_L108", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L108, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 173 },
    /* 174 */ { MAP_LOCAL, "_L109", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L109, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 174 },
    /* 175 */ { MAP_LOCAL, "_L110", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L110, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 175 },
    /* 176 */ { MAP_LOCAL, "_L111", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L111, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 176 },
    /* 177 */ { MAP_LOCAL, "_L112", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L112, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 177 },
    /* 178 */ { MAP_LOCAL, "_L113", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L113, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 178 },
    /* 179 */ { MAP_LOCAL, "_L115", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L115, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 179 },
    /* 180 */ { MAP_LOCAL, "_L117", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L117, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 180 },
    /* 181 */ { MAP_LOCAL, "_L118", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L118, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 181 },
    /* 182 */ { MAP_LOCAL, "_L119", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L119, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 182 },
    /* 183 */ { MAP_LOCAL, "_L120", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L120, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 183 },
    /* 184 */ { MAP_LOCAL, "_L121", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L121, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 184 },
    /* 185 */ { MAP_LOCAL, "_L123", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L123, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 185 },
    /* 186 */ { MAP_LOCAL, "_L124", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L124, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 186 },
    /* 187 */ { MAP_LOCAL, "_L125", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L125, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 187 },
    /* 188 */ { MAP_LOCAL, "_L126", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L126, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 188 },
    /* 189 */ { MAP_LOCAL, "_L127", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L127, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 189 },
    /* 190 */ { MAP_LOCAL, "_L128", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L128, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 190 },
    /* 191 */ { MAP_LOCAL, "_L129", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L129, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 191 },
    /* 192 */ { MAP_LOCAL, "_L130", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L130, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 192 },
    /* 193 */ { MAP_LOCAL, "_L131", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L131, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 193 },
    /* 194 */ { MAP_LOCAL, "_L132", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L132, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 194 },
    /* 195 */ { MAP_LOCAL, "_L133", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L133, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 195 },
    /* 196 */ { MAP_LOCAL, "_L134", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L134, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 196 },
    /* 197 */ { MAP_LOCAL, "_L135", NULL, sizeof(FVAHMIPacket), (size_t)&outputs_ctx._L135, &_Type_FVAHMIPacket_Utils, NULL, NULL, &scope_8, 1, 197 },
    /* 198 */ { MAP_LOCAL, "_L136", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L136, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 198 },
    /* 199 */ { MAP_LOCAL, "_L137", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L137, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 199 },
    /* 200 */ { MAP_LOCAL, "_L138", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L138, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 200 },
    /* 201 */ { MAP_LOCAL, "_L139", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L139, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 201 },
    /* 202 */ { MAP_LOCAL, "_L140", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L140, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 202 },
    /* 203 */ { MAP_LOCAL, "_L141", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L141, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 203 },
    /* 204 */ { MAP_LOCAL, "_L142", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L142, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 204 },
    /* 205 */ { MAP_LOCAL, "_L143", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L143, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 205 },
    /* 206 */ { MAP_LOCAL, "_L144", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L144, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 206 },
    /* 207 */ { MAP_LOCAL, "_L145", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L145, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 207 },
    /* 208 */ { MAP_LOCAL, "_L146", NULL, sizeof(ETCSHMIPacket), (size_t)&outputs_ctx._L146, &_Type_ETCSHMIPacket_Utils, NULL, NULL, &scope_7, 1, 208 },
    /* 209 */ { MAP_LOCAL, "_L147", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L147, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 209 },
    /* 210 */ { MAP_LOCAL, "_L148", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L148, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 210 },
    /* 211 */ { MAP_LOCAL, "_L149", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L149, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 211 },
    /* 212 */ { MAP_LOCAL, "_L150", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L150, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 212 },
    /* 213 */ { MAP_LOCAL, "_L151", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L151, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 213 },
    /* 214 */ { MAP_LOCAL, "_L152", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L152, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 214 },
    /* 215 */ { MAP_LOCAL, "_L153", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L153, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 215 },
    /* 216 */ { MAP_LOCAL, "_L154", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L154, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 216 },
    /* 217 */ { MAP_LOCAL, "_L155", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L155, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 217 },
    /* 218 */ { MAP_LOCAL, "_L156", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L156, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 218 },
    /* 219 */ { MAP_LOCAL, "_L157", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx._L157, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 219 },
    /* 220 */ { MAP_LOCAL, "_L158", NULL, sizeof(ATORSCSwitchPosition), (size_t)&outputs_ctx._L158, &_Type_ATORSCSwitchPosition_Utils, NULL, NULL, NULL, 1, 220 },
    /* 221 */ { MAP_LOCAL, "_L159", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L159, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 221 },
    /* 222 */ { MAP_LOCAL, "_L168", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L168, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 222 },
    /* 223 */ { MAP_LOCAL, "_L169", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L169, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 223 },
    /* 224 */ { MAP_LOCAL, "_L167", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L167, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 224 },
    /* 225 */ { MAP_LOCAL, "_L170", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L170, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 225 },
    /* 226 */ { MAP_LOCAL, "_L171", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L171, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 226 },
    /* 227 */ { MAP_LOCAL, "_L172", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L172, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 227 },
    /* 228 */ { MAP_LOCAL, "_L173", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L173, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 228 },
    /* 229 */ { MAP_LOCAL, "_L174", NULL, sizeof(ATO_Packet), (size_t)&outputs_ctx._L174, &_Type_ATO_Packet_Utils, NULL, NULL, &scope_5, 1, 229 },
    /* 230 */ { MAP_LOCAL, "_L175", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L175, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 230 },
    /* 231 */ { MAP_LOCAL, "_L176", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L176, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 231 },
    /* 232 */ { MAP_LOCAL, "_L177", NULL, sizeof(array_char_30), (size_t)&outputs_ctx._L177, &_Type_array_char_30_Utils, NULL, NULL, &scope_3, 1, 232 },
    /* 233 */ { MAP_LOCAL, "_L179", NULL, sizeof(Tain_Physics_Outputs), (size_t)&outputs_ctx._L179, &_Type_Tain_Physics_Outputs_Utils, NULL, NULL, &scope_9, 1, 233 },
    /* 234 */ { MAP_LOCAL, "_L180", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L180, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 234 },
    /* 235 */ { MAP_LOCAL, "_L181", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L181, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 235 },
    /* 236 */ { MAP_LOCAL, "_L182", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L182, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 236 },
    /* 237 */ { MAP_LOCAL, "_L183", NULL, sizeof(ETCSHMIPacketDataType), (size_t)&outputs_ctx._L183, &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 237 },
    /* 238 */ { MAP_LOCAL, "_L184", NULL, sizeof(ETCSHMIPacketDataType), (size_t)&outputs_ctx._L184, &_Type_ETCSHMIPacketDataType_Utils, NULL, NULL, &scope_4, 1, 238 },
    /* 239 */ { MAP_LOCAL, "_L185", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L185, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 239 },
    /* 240 */ { MAP_INSTANCE, "ATO_OB 1", NULL, sizeof(outC_ATO_OB), (size_t)&outputs_ctx.Context_ATO_OB_1, NULL, NULL, NULL, &scope_10, 1, 240 },
    /* 241 */ { MAP_INSTANCE, "ATO_TS 1", NULL, sizeof(outC_ATO_TS), (size_t)&outputs_ctx.Context_ATO_TS_1, NULL, NULL, NULL, &scope_38, 1, 241 },
    /* 242 */ { MAP_INSTANCE, "Diagnostic_Platform 1", NULL, sizeof(outC_Diagnostic_Platform), (size_t)&outputs_ctx.Context_Diagnostic_Platform_1, NULL, NULL, NULL, &scope_39, 1, 242 },
    /* 243 */ { MAP_INSTANCE, "Diagnostics_TS 1", NULL, sizeof(outC_Diagnostics_TS), (size_t)&outputs_ctx.Context_Diagnostics_TS_1, NULL, NULL, NULL, &scope_40, 1, 243 },
    /* 244 */ { MAP_INSTANCE, "Driving_Style_Engine 1", NULL, sizeof(outC_Driving_Style_Engine), (size_t)&outputs_ctx.Context_Driving_Style_Engine_1, NULL, NULL, NULL, &scope_41, 1, 244 },
    /* 245 */ { MAP_INSTANCE, "ETCS_OB 1", NULL, sizeof(outC_ETCS_OB), (size_t)&outputs_ctx.Context_ETCS_OB_1, NULL, NULL, NULL, &scope_42, 1, 245 },
    /* 246 */ { MAP_INSTANCE, "ETCS_TS 1", NULL, sizeof(outC_ETCS_TS), (size_t)&outputs_ctx.Context_ETCS_TS_1, NULL, NULL, NULL, &scope_53, 1, 246 },
    /* 247 */ { MAP_INSTANCE, "Functional_Vehicle_Adapter 1", NULL, sizeof(outC_Functional_Vehicle_Adapter), (size_t)&outputs_ctx.Context_Functional_Vehicle_Adapter_1, NULL, NULL, NULL, &scope_54, 1, 247 },
    /* 248 */ { MAP_INSTANCE, "Perception_OB 1", NULL, sizeof(outC_Perception_OB), (size_t)&outputs_ctx.Context_Perception_OB_1, NULL, NULL, NULL, &scope_75, 1, 248 },
    /* 249 */ { MAP_INSTANCE, "Perception_TS 1", NULL, sizeof(outC_Perception_TS), (size_t)&outputs_ctx.Context_Perception_TS_1, NULL, NULL, NULL, &scope_76, 1, 249 },
    /* 250 */ { MAP_INSTANCE, "Radio_Management 1", NULL, sizeof(outC_Radio_Management), (size_t)&outputs_ctx.Context_Radio_Management_1, NULL, NULL, NULL, &scope_77, 1, 250 },
    /* 251 */ { MAP_INSTANCE, "RSC_OB 1", NULL, sizeof(outC_RSC_OB), (size_t)&outputs_ctx.Context_RSC_OB_1, NULL, NULL, NULL, &scope_78, 1, 251 },
    /* 252 */ { MAP_INSTANCE, "RSC_TS 1", NULL, sizeof(outC_RSC_TS), (size_t)&outputs_ctx.Context_RSC_TS_1, NULL, NULL, NULL, &scope_101, 1, 252 },
    /* 253 */ { MAP_INSTANCE, "Vehicle_Management_System 1", NULL, sizeof(outC_Vehicle_Management_System), (size_t)&outputs_ctx.Context_Vehicle_Management_System_1, NULL, NULL, NULL, &scope_102, 1, 253 },
    /* 254 */ { MAP_INSTANCE, "RSC_Operator 1", NULL, sizeof(outC_RSC_Operator), (size_t)&outputs_ctx.Context_RSC_Operator_1, NULL, NULL, NULL, &scope_103, 1, 254 },
    /* 255 */ { MAP_INSTANCE, "Signal_Operator 1", NULL, sizeof(outC_Signal_Operator), (size_t)&outputs_ctx.Context_Signal_Operator_1, NULL, NULL, NULL, &scope_104, 1, 255 },
    /* 256 */ { MAP_INSTANCE, "Train_Driver 1", NULL, sizeof(outC_Train_Driver), (size_t)&outputs_ctx.Context_Train_Driver_1, NULL, NULL, NULL, &scope_105, 1, 256 },
    /* 257 */ { MAP_INSTANCE, "Train::ClassB_Systems 1", NULL, sizeof(outC_ClassB_Systems_Train), (size_t)&outputs_ctx.Context_ClassB_Systems_1, NULL, NULL, NULL, &scope_148, 1, 257 },
    /* 258 */ { MAP_INSTANCE, "Train::RollingStock_Operating_System 1", NULL, sizeof(outC_RollingStock_Operating_System_Train), (size_t)&outputs_ctx.Context_RollingStock_Operating_System_1, NULL, NULL, NULL, &scope_149, 1, 258 },
    /* 259 */ { MAP_INSTANCE, "Train::OpenIO_Interface 1", NULL, sizeof(outC_OpenIO_Interface_Train), (size_t)&outputs_ctx.Context_OpenIO_Interface_1, NULL, NULL, NULL, &scope_150, 1, 259 },
    /* 260 */ { MAP_INSTANCE, "Train::Vehicle_EmergencyBrake_EB 1", NULL, sizeof(outC_Vehicle_EmergencyBrake_EB_Train), (size_t)&outputs_ctx.Context_Vehicle_EmergencyBrake_EB_1, NULL, NULL, NULL, &scope_151, 1, 260 }
};
const MappingScope scope_1 = {
    "System_Integration/ System_Integration",
    scope_1_entries, 261
};

const MappingEntry scope_0_entries[1] = {
    /* 0 */ { MAP_ROOT, "System_Integration", NULL, 0, 0, NULL, NULL, NULL, &scope_1, 1, 0 }
};
const MappingScope scope_0 = {
    "",
    scope_0_entries, 1
};

/* entry point */
const MappingScope* pTop = &scope_0;
