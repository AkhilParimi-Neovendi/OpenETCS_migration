/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */
#ifndef _LCF_Calculation_Math_Operators_H_
#define _LCF_Calculation_Math_Operators_H_

#include "kcg_types.h"
#include "Pneumaticbrakes_Brakes.h"
#include "Holding_brake_Brakes.h"
#include "negativespeedcorrection_Math_Operators.h"
#include "Resistance_force_External_forces.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_float32 /* unit_traction/ */ unit_traction;
  kcg_float32 /* unittotalbraking/ */ unittotalbraking;
  kcg_float32 /* L_Couplingforce/ */ L_Couplingforce;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_negativespeedcorrection_Math_Operators /* _L14=(Math_Operators::negativespeedcorrection#1)/ */ Context_negativespeedcorrection_1;
  outC_Resistance_force_External_forces /* _L13=(External_forces::Resistance_force#1)/ */ Context_Resistance_force_1;
  outC_Holding_brake_Brakes /* _L17=(Brakes::Holding_brake#1)/ */ Context_Holding_brake_1;
  outC_Pneumaticbrakes_Brakes /* _L24=(Brakes::Pneumaticbrakes#1)/ */ Context_Pneumaticbrakes_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_float32 /* @1/Output1/ */ Output1_NumericToFloat32_1_int32;
  kcg_int32 /* @1/Input1/ */ Input1_NumericToFloat32_1_int32;
  kcg_float32 /* @1/_L2/ */ _L2_NumericToFloat32_1_int32;
  kcg_int32 /* @1/_L1/ */ _L1_NumericToFloat32_1_int32;
  kcg_float32 /* _L1/ */ _L1;
  kcg_float32 /* _L2/ */ _L2;
  kcg_float32 /* _L3/ */ _L3;
  kcg_float32 /* _L4/ */ _L4;
  kcg_float32 /* _L5/ */ _L5;
  kcg_float32 /* _L6/ */ _L6;
  kcg_float32 /* _L7/ */ _L7;
  kcg_float32 /* _L8/ */ _L8;
  kcg_float32 /* _L10/ */ _L10;
  kcg_float32 /* _L11/ */ _L11;
  kcg_int32 /* _L12/ */ _L12;
  kcg_float32 /* _L13/ */ _L13;
  kcg_float32 /* _L14/ */ _L14;
  kcg_float32 /* _L15/ */ _L15;
  kcg_float32 /* _L16/ */ _L16;
  kcg_float32 /* _L17/ */ _L17;
  kcg_float32 /* _L24/ */ _L24;
  kcg_bool /* _L25/ */ _L25;
  kcg_float32 /* _L26/ */ _L26;
  kcg_int32 /* _L27/ */ _L27;
  kcg_float32 /* _L28/ */ _L28;
} outC_LCF_Calculation_Math_Operators;

/* ===========  node initialization and cycle functions  =========== */
/* Math_Operators::LCF_Calculation/ */
extern void LCF_Calculation_Math_Operators(
  /* Unit_Traction/ */
  kcg_float32 Unit_Traction,
  /* Unit_dynbrakingforce/ */
  kcg_float32 Unit_dynbrakingforce,
  /* unit_speed/ */
  kcg_float32 unit_speed,
  /* unit_acceleration/ */
  kcg_float32 unit_acceleration,
  /* Unit_Mass/ */
  kcg_int32 Unit_Mass,
  /* Unit_brakelinepressure/ */
  kcg_float32 Unit_brakelinepressure,
  /* Unit_holdingbrakestatus/ */
  kcg_bool Unit_holdingbrakestatus,
  /* R_Coupling_force/ */
  kcg_float32 R_Coupling_force,
  outC_LCF_Calculation_Math_Operators *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void LCF_Calculation_reset_Math_Operators(
  outC_LCF_Calculation_Math_Operators *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void LCF_Calculation_init_Math_Operators(
  outC_LCF_Calculation_Math_Operators *outC);
#endif /* KCG_USER_DEFINED_INIT */

/*
  Expanded instances for: Math_Operators::LCF_Calculation/
  @1: (math::NumericToFloat32#1)
*/

#endif /* _LCF_Calculation_Math_Operators_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** LCF_Calculation_Math_Operators.h
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

