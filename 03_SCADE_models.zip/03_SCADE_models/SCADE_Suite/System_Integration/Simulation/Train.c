/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Train.h"

/* Train/ */
void Train(
  /* Traction_Force/ */
  kcg_float32 Traction_Force,
  /* Dynamic_Braking_Force/ */
  kcg_float32 Dynamic_Braking_Force,
  /* Holdingbrakestatus/ */
  kcg_bool Holdingbrakestatus,
  /* pneumaticbrakepressure/ */
  kcg_float32 pneumaticbrakepressure,
  outC_Train *outC)
{
  outC->_L59 = outC->_L35;
  /* _L60= */
  if (outC->init) {
    outC->_L60 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L60 = outC->_L59;
  }
  outC->_L1 = Traction_Force;
  outC->_L2 = Dynamic_Braking_Force;
  outC->_L69 = Holdingbrakestatus;
  outC->_L70 = pneumaticbrakepressure;
  outC->_L66 = outC->_L34;
  /* _L67= */
  if (outC->init) {
    outC->_L67 = kcg_lit_float32(0.0);
  }
  else {
    outC->_L67 = outC->_L66;
  }
  /* _L62=(TrainConfiguration_And_LCF)/ */
  TrainConfiguration_And_LCF(
    outC->_L60,
    outC->_L1,
    outC->_L2,
    outC->_L69,
    outC->_L70,
    outC->_L67,
    &outC->Context_TrainConfiguration_And_LCF);
  kcg_copy_array_float32_5(
    &outC->_L62,
    &outC->Context_TrainConfiguration_And_LCF.LCF_Array);
  outC->_L64 = outC->Context_TrainConfiguration_And_LCF.Total_Tractionforce;
  outC->_L65 = outC->Context_TrainConfiguration_And_LCF.Total_Brakingforce;
  kcg_copy_array_float32_5(&outC->_L72.LCF_Values, &outC->_L62);
  /* _L35=(Train_dynamics#1)/ */
  Train_dynamics(outC->_L64, outC->_L65, &outC->Context_Train_dynamics_1);
  outC->_L35 = outC->Context_Train_dynamics_1.train_speed;
  outC->_L71 = outC->Context_Train_dynamics_1.Distance_Travelled;
  outC->_L34 = outC->Context_Train_dynamics_1.train_acceleration;
  outC->Distance_Travelled_by_Train = outC->_L71;
  kcg_copy_LCF_Data(&outC->LCF_Values, &outC->_L72);
  outC->Train_acceleration = outC->_L34;
  outC->Train_Speed = outC->_L35;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void Train_init(outC_Train *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_size idx2;

  for (idx = 0; idx < 5; idx++) {
    outC->_L72.LCF_Values[idx] = kcg_lit_float32(0.0);
  }
  outC->_L71 = kcg_lit_float32(0.0);
  outC->_L70 = kcg_lit_float32(0.0);
  outC->_L69 = kcg_true;
  outC->_L66 = kcg_lit_float32(0.0);
  outC->_L67 = kcg_lit_float32(0.0);
  outC->_L65 = kcg_lit_float32(0.0);
  outC->_L64 = kcg_lit_float32(0.0);
  for (idx1 = 0; idx1 < 5; idx1++) {
    outC->_L62[idx1] = kcg_lit_float32(0.0);
  }
  outC->_L59 = kcg_lit_float32(0.0);
  outC->_L60 = kcg_lit_float32(0.0);
  outC->_L1 = kcg_lit_float32(0.0);
  outC->_L2 = kcg_lit_float32(0.0);
  outC->_L35 = kcg_lit_float32(0.0);
  outC->_L34 = kcg_lit_float32(0.0);
  outC->init = kcg_true;
  outC->Distance_Travelled_by_Train = kcg_lit_float32(0.0);
  for (idx2 = 0; idx2 < 5; idx2++) {
    outC->LCF_Values.LCF_Values[idx2] = kcg_lit_float32(0.0);
  }
  outC->Train_acceleration = kcg_lit_float32(0.0);
  outC->Train_Speed = kcg_lit_float32(0.0);
  /* _L35=(Train_dynamics#1)/ */
  Train_dynamics_init(&outC->Context_Train_dynamics_1);
  /* _L62=(TrainConfiguration_And_LCF)/ */
  TrainConfiguration_And_LCF_init(&outC->Context_TrainConfiguration_And_LCF);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Train_reset(outC_Train *outC)
{
  outC->init = kcg_true;
  /* _L35=(Train_dynamics#1)/ */
  Train_dynamics_reset(&outC->Context_Train_dynamics_1);
  /* _L62=(TrainConfiguration_And_LCF)/ */
  TrainConfiguration_And_LCF_reset(&outC->Context_TrainConfiguration_And_LCF);
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Train.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

