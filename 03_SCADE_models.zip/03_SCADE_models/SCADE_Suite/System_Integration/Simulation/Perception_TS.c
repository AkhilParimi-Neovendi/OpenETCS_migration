/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/System_Integration/Simulation/config.txt
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "Perception_TS.h"

/* Perception_TS/ */
void Perception_TS(
  /* from_RSC_Operator/ */
  kcg_bool from_RSC_Operator,
  /* from_Perception_OB/ */
  kcg_bool from_Perception_OB,
  outC_Perception_TS *outC)
{
  kcg_bool noname;
  kcg_bool _1_noname;

  outC->_L3 = kcg_false;
  outC->to_Perception_OB = outC->_L3;
  outC->to_RSC_Operator = outC->_L3;
  outC->_L2 = from_Perception_OB;
  _1_noname = outC->_L2;
  outC->_L1 = from_RSC_Operator;
  noname = outC->_L1;
}

#ifndef KCG_USER_DEFINED_INIT
void Perception_TS_init(outC_Perception_TS *outC)
{
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_true;
  outC->_L1 = kcg_true;
  outC->to_Perception_OB = kcg_true;
  outC->to_RSC_Operator = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void Perception_TS_reset(outC_Perception_TS *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Perception_TS.c
** Generation date: 2023-11-21T15:35:12
*************************************************************$ */

