/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ATO_TS/Simulation/config.txt
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ATO_TS.h"

/* ATO_TS/ */
void ATO_TS(inC_ATO_TS *inC, outC_ATO_TS *outC)
{
  outC->_L15 = kcg_lit_int8(2);
  outC->_L13 = kcg_false;
  outC->_L12 = kcg_true;
  kcg_copy_ATO_Packet(&outC->_L3, &inC->from_RM_ss126);
  outC->_L5 = outC->_L3.Value;
  outC->_L6 = outC->_L3.Header;
  outC->_L8 = kcg_lit_int8(1);
  outC->_L7 = outC->_L8 == outC->_L6;
  outC->_L10 = outC->_L7 & outC->_L5;
  /* _L11= */
  if (outC->_L10) {
    outC->_L11 = outC->_L12;
  }
  else {
    outC->_L11 = outC->_L13;
  }
  outC->_L4.Header = outC->_L15;
  outC->_L4.Value = outC->_L11;
  kcg_copy_ATO_Packet(&outC->to_RM_ss126, &outC->_L4);
}

#ifndef KCG_USER_DEFINED_INIT
void ATO_TS_init(outC_ATO_TS *outC)
{
  outC->_L15 = kcg_lit_int8(0);
  outC->_L13 = kcg_true;
  outC->_L12 = kcg_true;
  outC->_L11 = kcg_true;
  outC->_L10 = kcg_true;
  outC->_L8 = kcg_lit_int8(0);
  outC->_L7 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L6 = kcg_lit_int8(0);
  outC->_L4.Header = kcg_lit_int8(0);
  outC->_L4.Value = kcg_true;
  outC->_L3.Header = kcg_lit_int8(0);
  outC->_L3.Value = kcg_true;
  outC->to_RM_ss126.Header = kcg_lit_int8(0);
  outC->to_RM_ss126.Value = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ATO_TS_reset(outC_ATO_TS *outC)
{
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ATO_TS.c
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

