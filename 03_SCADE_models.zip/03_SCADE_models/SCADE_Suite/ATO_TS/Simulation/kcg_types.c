/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ATO_TS/Simulation/config.txt
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

#include "kcg_types.h"

#ifdef kcg_use_ATO_Packet
kcg_bool kcg_comp_ATO_Packet(ATO_Packet *kcg_c1, ATO_Packet *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Value == kcg_c2->Value);
  kcg_equ = kcg_equ & (kcg_c1->Header == kcg_c2->Header);
  return kcg_equ;
}
#endif /* kcg_use_ATO_Packet */

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.c
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

