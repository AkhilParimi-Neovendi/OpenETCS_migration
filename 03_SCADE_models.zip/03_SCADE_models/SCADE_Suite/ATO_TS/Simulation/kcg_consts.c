/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ATO_TS/Simulation/config.txt
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

#include "kcg_consts.h"

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_consts.c
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

