/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/ATO_TS/Simulation/config.txt
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */
#ifndef _ATO_TS_H_
#define _ATO_TS_H_

#include "kcg_types.h"

/* ========================  input structure  ====================== */
typedef struct { ATO_Packet /* from_RM_ss126/ */ from_RM_ss126; } inC_ATO_TS;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  ATO_Packet /* to_RM_ss126/ */ to_RM_ss126;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  ATO_Packet /* _L3/ */ _L3;
  ATO_Packet /* _L4/ */ _L4;
  kcg_int8 /* _L6/ */ _L6;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L7/ */ _L7;
  kcg_int8 /* _L8/ */ _L8;
  kcg_bool /* _L10/ */ _L10;
  kcg_bool /* _L11/ */ _L11;
  kcg_bool /* _L12/ */ _L12;
  kcg_bool /* _L13/ */ _L13;
  kcg_int8 /* _L15/ */ _L15;
} outC_ATO_TS;

/* ===========  node initialization and cycle functions  =========== */
/* ATO_TS/ */
extern void ATO_TS(inC_ATO_TS *inC, outC_ATO_TS *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void ATO_TS_reset(outC_ATO_TS *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void ATO_TS_init(outC_ATO_TS *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _ATO_TS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ATO_TS.h
** Generation date: 2023-11-13T17:08:59
*************************************************************$ */

