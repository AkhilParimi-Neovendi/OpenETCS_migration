/* Functional_Vehicle_Adapter_mapping.h */
