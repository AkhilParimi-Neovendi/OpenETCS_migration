/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Functional_Vehicle_Adapter/Simulation/config.txt
** Generation date: 2023-11-13T15:10:52
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "ExternalStatusIndicator_Internal_functions.h"

/* Internal_functions::ExternalStatusIndicator/ */
void ExternalStatusIndicator_Internal_functions(
  inC_ExternalStatusIndicator_Internal_functions *inC,
  outC_ExternalStatusIndicator_Internal_functions *outC)
{
  kcg_size idx;
  kcg_size idx1;
  kcg_bool tmp;
  kcg_bool tmp2;
  /* Red_light/ */
  kcg_bool Red_light_partial;
  /* Green_light/ */
  kcg_bool Green_light_partial;
  /* Red_light/ */
  kcg_bool _3_Red_light_partial;
  /* Green_light/ */
  kcg_bool _4_Green_light_partial;
  /* Red_light/ */
  kcg_bool _5_Red_light_partial;
  /* Green_light/ */
  kcg_bool _6_Green_light_partial;
  /* Red_light/ */
  kcg_bool _7_Red_light_partial;
  /* Green_light/ */
  kcg_bool _8_Green_light_partial;
  /* Green_light/ */
  kcg_bool _9_Green_light_partial;
  /* Red_light/ */
  kcg_bool _10_Red_light_partial;
  /* Green_light/ */
  kcg_bool _11_Green_light_partial;
  /* Red_light/ */
  kcg_bool _12_Red_light_partial;
  /* Green_light/ */
  kcg_bool _13_Green_light_partial;
  /* Red_light/ */
  kcg_bool _14_Red_light_partial;
  /* Green_light/ */
  kcg_bool _15_Green_light_partial;
  /* Red_light/ */
  kcg_bool _16_Red_light_partial;

  outC->_L6 = inC->Overrideswitchstate;
  outC->local_OverrideState = outC->_L6;
  outC->_L1 = inC->IndicationState_in;
  outC->Mem_State = outC->_L1;
  outC->_L2 = outC->Mem_State;
  outC->IfBlock1_clock = (outC->Mem_State == kcg_lit_int8(0)) &
    (!outC->local_OverrideState);
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    outC->_L1_then_IfBlock1 = kcg_false;
    Red_light_partial = outC->_L1_then_IfBlock1;
    outC->Red_light = Red_light_partial;
  }
  else {
    outC->else_clock_IfBlock1 = (outC->Mem_State == kcg_lit_int8(1)) |
      outC->local_OverrideState;
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      outC->_L2_then_else_IfBlock1 = kcg_false;
      _16_Red_light_partial = outC->_L2_then_else_IfBlock1;
      _3_Red_light_partial = _16_Red_light_partial;
    }
    else {
      outC->else_clock_else_IfBlock1 = outC->Mem_State == kcg_lit_int8(2);
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L6_then_else_else_IfBlock1 = kcg_true;
        outC->_L4_then_else_else_IfBlock1 = !outC->_L6_then_else_else_IfBlock1;
        tmp2 = kcg_false;
        /* IfBlock1:else:else:then:_L5= */
        if (outC->init1) {
          /* IfBlock1:else:else:then:_L5= */
          for (idx1 = 0; idx1 < 6; idx1++) {
            outC->fby_1.items[idx1] = tmp2;
          }
          outC->fby_1.idx = 0;
        }
        outC->_L5_then_else_else_IfBlock1 = outC->fby_1.items[outC->fby_1.idx];
        outC->_L3_then_else_else_IfBlock1 = outC->_L5_then_else_else_IfBlock1 ==
          outC->_L6_then_else_else_IfBlock1;
        /* IfBlock1:else:else:then:_L2= */
        if (outC->_L3_then_else_else_IfBlock1) {
          outC->_L2_then_else_else_IfBlock1 = outC->_L4_then_else_else_IfBlock1;
        }
        else {
          outC->_L2_then_else_else_IfBlock1 = outC->_L6_then_else_else_IfBlock1;
        }
        outC->fby_1.items[outC->fby_1.idx] = outC->_L2_then_else_else_IfBlock1;
        outC->fby_1.idx = (outC->fby_1.idx + 1) % 6;
        _5_Red_light_partial = outC->_L2_then_else_else_IfBlock1;
        _14_Red_light_partial = _5_Red_light_partial;
      }
      else {
        outC->else_clock_else_else_IfBlock1 = outC->Mem_State == kcg_lit_int8(3);
        /* IfBlock1:else:else:else: */
        if (outC->else_clock_else_else_IfBlock1) {
          outC->_L5_then_else_else_else_IfBlock1 = kcg_true;
          outC->_L7_then_else_else_else_IfBlock1 =
            !outC->_L5_then_else_else_else_IfBlock1;
          tmp = kcg_false;
          /* IfBlock1:else:else:else:then:_L6= */
          if (outC->init) {
            /* IfBlock1:else:else:else:then:_L6= */
            for (idx = 0; idx < 3; idx++) {
              outC->fby_3.items[idx] = tmp;
            }
            outC->fby_3.idx = 0;
          }
          outC->_L6_then_else_else_else_IfBlock1 = outC->fby_3.items[outC->fby_3.idx];
          outC->_L8_then_else_else_else_IfBlock1 =
            outC->_L6_then_else_else_else_IfBlock1 ==
            outC->_L5_then_else_else_else_IfBlock1;
          /* IfBlock1:else:else:else:then:_L9= */
          if (outC->_L8_then_else_else_else_IfBlock1) {
            outC->_L9_then_else_else_else_IfBlock1 = outC->_L7_then_else_else_else_IfBlock1;
          }
          else {
            outC->_L9_then_else_else_else_IfBlock1 = outC->_L5_then_else_else_else_IfBlock1;
          }
          outC->fby_3.items[outC->fby_3.idx] = outC->_L9_then_else_else_else_IfBlock1;
          outC->fby_3.idx = (outC->fby_3.idx + 1) % 3;
          _12_Red_light_partial = outC->_L9_then_else_else_else_IfBlock1;
          _7_Red_light_partial = _12_Red_light_partial;
        }
        else {
          outC->_L2_else_else_else_else_IfBlock1 = kcg_true;
          _10_Red_light_partial = outC->_L2_else_else_else_else_IfBlock1;
          _7_Red_light_partial = _10_Red_light_partial;
        }
        _14_Red_light_partial = _7_Red_light_partial;
      }
      _3_Red_light_partial = _14_Red_light_partial;
    }
    outC->Red_light = _3_Red_light_partial;
  }
  outC->_L4 = outC->Red_light;
  /* IfBlock1: */
  if (outC->IfBlock1_clock) {
    Green_light_partial = outC->_L1_then_IfBlock1;
    outC->Green_light = Green_light_partial;
  }
  else {
    /* IfBlock1:else: */
    if (outC->else_clock_IfBlock1) {
      outC->_L1_then_else_IfBlock1 = kcg_true;
      _15_Green_light_partial = outC->_L1_then_else_IfBlock1;
      _4_Green_light_partial = _15_Green_light_partial;
    }
    else {
      /* IfBlock1:else:else: */
      if (outC->else_clock_else_IfBlock1) {
        outC->_L1_then_else_else_IfBlock1 = kcg_false;
        _6_Green_light_partial = outC->_L1_then_else_else_IfBlock1;
        _13_Green_light_partial = _6_Green_light_partial;
      }
      else {
        /* IfBlock1:else:else:else: */
        if (outC->else_clock_else_else_IfBlock1) {
          outC->_L1_then_else_else_else_IfBlock1 = kcg_false;
          _11_Green_light_partial = outC->_L1_then_else_else_else_IfBlock1;
          _8_Green_light_partial = _11_Green_light_partial;
        }
        else {
          _9_Green_light_partial = outC->_L2_else_else_else_else_IfBlock1;
          _8_Green_light_partial = _9_Green_light_partial;
        }
        _13_Green_light_partial = _8_Green_light_partial;
      }
      _4_Green_light_partial = _13_Green_light_partial;
    }
    outC->Green_light = _4_Green_light_partial;
  }
  outC->_L3 = outC->Green_light;
  outC->_L5.IndicatorState = outC->_L2;
  outC->_L5.RedLight = outC->_L4;
  outC->_L5.GreenLight = outC->_L3;
  kcg_copy_ExternalindicatorStates(&outC->ExternalIndicationOut, &outC->_L5);
  if (outC->IfBlock1_clock) {
  }
  else if (outC->else_clock_IfBlock1) {
  }
  else if (outC->else_clock_else_IfBlock1) {
    outC->init1 = kcg_false;
  }
  else if (outC->else_clock_else_else_IfBlock1) {
    outC->init = kcg_false;
  }
}

#ifndef KCG_USER_DEFINED_INIT
void ExternalStatusIndicator_init_Internal_functions(
  outC_ExternalStatusIndicator_Internal_functions *outC)
{
  kcg_size idx;
  kcg_size idx1;

  outC->_L6 = kcg_true;
  outC->_L5.IndicatorState = kcg_lit_int8(0);
  outC->_L5.RedLight = kcg_true;
  outC->_L5.GreenLight = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L2 = kcg_lit_int8(0);
  outC->_L1 = kcg_lit_int8(0);
  outC->local_OverrideState = kcg_true;
  outC->Green_light = kcg_true;
  outC->Red_light = kcg_true;
  outC->Mem_State = kcg_lit_int8(0);
  outC->IfBlock1_clock = kcg_true;
  outC->_L2_then_else_IfBlock1 = kcg_true;
  outC->_L1_then_else_IfBlock1 = kcg_true;
  outC->else_clock_else_IfBlock1 = kcg_true;
  outC->_L9_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L5_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L6_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L7_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L8_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L1_then_else_else_else_IfBlock1 = kcg_true;
  outC->_L2_else_else_else_else_IfBlock1 = kcg_true;
  outC->else_clock_else_else_IfBlock1 = kcg_true;
  outC->_L1_then_else_else_IfBlock1 = kcg_true;
  outC->_L5_then_else_else_IfBlock1 = kcg_true;
  outC->_L4_then_else_else_IfBlock1 = kcg_true;
  outC->_L3_then_else_else_IfBlock1 = kcg_true;
  outC->_L2_then_else_else_IfBlock1 = kcg_true;
  outC->_L6_then_else_else_IfBlock1 = kcg_true;
  outC->else_clock_IfBlock1 = kcg_true;
  outC->_L1_then_IfBlock1 = kcg_true;
  outC->init1 = kcg_true;
  outC->init = kcg_true;
  outC->fby_1.idx = 0;
  for (idx = 0; idx < 6; idx++) {
    outC->fby_1.items[idx] = kcg_true;
  }
  outC->fby_3.idx = 0;
  for (idx1 = 0; idx1 < 3; idx1++) {
    outC->fby_3.items[idx1] = kcg_true;
  }
  outC->ExternalIndicationOut.IndicatorState = kcg_lit_int8(0);
  outC->ExternalIndicationOut.RedLight = kcg_true;
  outC->ExternalIndicationOut.GreenLight = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void ExternalStatusIndicator_reset_Internal_functions(
  outC_ExternalStatusIndicator_Internal_functions *outC)
{
  outC->init1 = kcg_true;
  outC->init = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */



/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** ExternalStatusIndicator_Internal_functions.c
** Generation date: 2023-11-13T15:10:52
*************************************************************$ */

