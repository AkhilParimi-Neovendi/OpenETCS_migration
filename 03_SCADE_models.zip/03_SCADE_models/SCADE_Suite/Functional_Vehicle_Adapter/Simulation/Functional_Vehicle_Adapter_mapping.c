/* Functional_Vehicle_Adapter_mapping.c */

#include "Functional_Vehicle_Adapter_type.h"
#include "Functional_Vehicle_Adapter_interface.h"
#include "Functional_Vehicle_Adapter_mapping.h"

#include "SmuTypes.h"
#include "SmuMapping.h"

#include "kcg_sensors.h"

/* mapping declaration */

#define DECL_ITER(name) extern const MappingIterator iter_##name


#define DECL_SCOPE(name, count) extern const MappingEntry name##_entries[count]; extern const MappingScope name

DECL_SCOPE(scope_11, 1);
DECL_SCOPE(scope_10, 2);
DECL_SCOPE(scope_9, 6);
DECL_SCOPE(scope_8, 6);
DECL_SCOPE(scope_7, 1);
DECL_SCOPE(scope_6, 3);
DECL_SCOPE(scope_5, 3);
DECL_SCOPE(scope_4, 3);
DECL_SCOPE(scope_3, 3);
DECL_SCOPE(scope_2, 3);
DECL_SCOPE(scope_1, 14);
DECL_SCOPE(scope_0, 1);

/* clock definition */

static int isActive_kcg_bool_kcg_false(void* pHandle) { return *(kcg_bool*)pHandle == kcg_false; }
static int isActive_kcg_bool_kcg_true(void* pHandle) { return *(kcg_bool*)pHandle == kcg_true; }

/* mapping definition */


const MappingEntry scope_11_entries[1] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1_then_IfBlock1, &_Type_kcg_bool_Utils, &scope_3_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 }
};
const MappingScope scope_11 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:then:",
    scope_11_entries, 1
};

const MappingEntry scope_10_entries[2] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1_then_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_4_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L2_then_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_4_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 }
};
const MappingScope scope_10 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:then:",
    scope_10_entries, 2
};

const MappingEntry scope_9_entries[6] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L5_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L4_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L3_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L2_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L6_then_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5 }
};
const MappingScope scope_9 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:then:",
    scope_9_entries, 6
};

const MappingEntry scope_8_entries[6] = {
    /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L1_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0 },
    /* 1 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L8_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1 },
    /* 2 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L7_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L6_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L5_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L9_then_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5 }
};
const MappingScope scope_8 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:then:",
    scope_8_entries, 6
};

const MappingEntry scope_7_entries[1] = {
    /* 0 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L2_else_else_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_6_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0 }
};
const MappingScope scope_7 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:else:",
    scope_7_entries, 1
};

const MappingEntry scope_6_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.else_clock_else_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_5_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_6_entries[0], isActive_kcg_bool_kcg_false, &scope_7, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_6_entries[0], isActive_kcg_bool_kcg_true, &scope_8, 1, 2 }
};
const MappingScope scope_6 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:else:",
    scope_6_entries, 3
};

const MappingEntry scope_5_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.else_clock_else_IfBlock1, &_Type_kcg_bool_Utils, &scope_4_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_5_entries[0], isActive_kcg_bool_kcg_false, &scope_6, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_5_entries[0], isActive_kcg_bool_kcg_true, &scope_9, 1, 2 }
};
const MappingScope scope_5 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:else:",
    scope_5_entries, 3
};

const MappingEntry scope_4_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.else_clock_IfBlock1, &_Type_kcg_bool_Utils, &scope_3_entries[0], isActive_kcg_bool_kcg_false, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_4_entries[0], isActive_kcg_bool_kcg_false, &scope_5, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_4_entries[0], isActive_kcg_bool_kcg_true, &scope_10, 1, 2 }
};
const MappingScope scope_4 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:else:",
    scope_4_entries, 3
};

const MappingEntry scope_3_entries[3] = {
    /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.IfBlock1_clock, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0 },
    /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_3_entries[0], isActive_kcg_bool_kcg_false, &scope_4, 1, 1 },
    /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_3_entries[0], isActive_kcg_bool_kcg_true, &scope_11, 1, 2 }
};
const MappingScope scope_3 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functionsIfBlock1:",
    scope_3_entries, 3
};

const MappingEntry scope_2_entries[3] = {
    /* 0 */ { MAP_FIELD, ".IndicatorState", NULL, sizeof(kcg_int8), offsetof(ExternalindicatorStates, IndicatorState), &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 0 },
    /* 1 */ { MAP_FIELD, ".RedLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, RedLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_FIELD, ".GreenLight", NULL, sizeof(kcg_bool), offsetof(ExternalindicatorStates, GreenLight), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2 }
};
const MappingScope scope_2 = {
    "ExternalindicatorStates",
    scope_2_entries, 3
};

const MappingEntry scope_1_entries[14] = {
    /* 0 */ { MAP_OUTPUT, "ExternalIndicationOut", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx.ExternalIndicationOut, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 0 },
    /* 1 */ { MAP_INPUT, "IndicationState_in", NULL, sizeof(kcg_int8), (size_t)&inputs_ctx.IndicationState_in, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 1 },
    /* 2 */ { MAP_INPUT, "Overrideswitchstate", NULL, sizeof(Override_Switch_State), (size_t)&inputs_ctx.Overrideswitchstate, &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 2 },
    /* 3 */ { MAP_LOCAL, "Mem_State", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx.Mem_State, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 3 },
    /* 4 */ { MAP_LOCAL, "Red_light", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Red_light, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4 },
    /* 5 */ { MAP_LOCAL, "Green_light", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.Green_light, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5 },
    /* 6 */ { MAP_LOCAL, "local_OverrideState", NULL, sizeof(Override_Switch_State), (size_t)&outputs_ctx.local_OverrideState, &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 6 },
    /* 7 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L1, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 7 },
    /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int8), (size_t)&outputs_ctx._L2, &_Type_kcg_int8_Utils, NULL, NULL, NULL, 1, 8 },
    /* 9 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L3, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9 },
    /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L4, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10 },
    /* 11 */ { MAP_LOCAL, "_L5", NULL, sizeof(ExternalindicatorStates), (size_t)&outputs_ctx._L5, &_Type_ExternalindicatorStates_Utils, NULL, NULL, &scope_2, 1, 11 },
    /* 12 */ { MAP_LOCAL, "_L6", NULL, sizeof(Override_Switch_State), (size_t)&outputs_ctx._L6, &_Type_Override_Switch_State_Utils, NULL, NULL, NULL, 1, 12 },
    /* 13 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_3, 1, 13 }
};
const MappingScope scope_1 = {
    "Internal_functions::ExternalStatusIndicator/ ExternalStatusIndicator_Internal_functions",
    scope_1_entries, 14
};

const MappingEntry scope_0_entries[1] = {
    /* 0 */ { MAP_ROOT, "Internal_functions::ExternalStatusIndicator", NULL, 0, 0, NULL, NULL, NULL, &scope_1, 1, 0 }
};
const MappingScope scope_0 = {
    "",
    scope_0_entries, 1
};

/* entry point */
const MappingScope* pTop = &scope_0;
