/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/DBC/GitHub_Repo/MBSE-ATO-Betuweroute/01_Models/03_SCADE_models/SCADE_Suite/Functional_Vehicle_Adapter/Simulation/config.txt
** Generation date: 2023-11-13T15:10:52
*************************************************************$ */

#include "kcg_types.h"

#ifdef kcg_use_array_bool_6
kcg_bool kcg_comp_array_bool_6(array_bool_6 *kcg_c1, array_bool_6 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 6; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_6 */

#ifdef kcg_use_array_bool_3
kcg_bool kcg_comp_array_bool_3(array_bool_3 *kcg_c1, array_bool_3 *kcg_c2)
{
  kcg_bool kcg_equ;
  kcg_size kcg_ci;

  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 3; kcg_ci++) {
    kcg_equ = kcg_equ & ((*kcg_c1)[kcg_ci] == (*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}
#endif /* kcg_use_array_bool_3 */

#ifdef kcg_use_struct_524
kcg_bool kcg_comp_struct_524(struct_524 *kcg_c1, struct_524 *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array_bool_3(&kcg_c1->items, &kcg_c2->items);
  kcg_equ = kcg_equ & (kcg_c1->idx == kcg_c2->idx);
  return kcg_equ;
}
#endif /* kcg_use_struct_524 */

#ifdef kcg_use_struct_534
kcg_bool kcg_comp_struct_534(struct_534 *kcg_c1, struct_534 *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array_bool_6(&kcg_c1->items, &kcg_c2->items);
  kcg_equ = kcg_equ & (kcg_c1->idx == kcg_c2->idx);
  return kcg_equ;
}
#endif /* kcg_use_struct_534 */

#ifdef kcg_use_ExternalindicatorStates
kcg_bool kcg_comp_ExternalindicatorStates(
  ExternalindicatorStates *kcg_c1,
  ExternalindicatorStates *kcg_c2)
{
  kcg_bool kcg_equ;

  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->GreenLight == kcg_c2->GreenLight);
  kcg_equ = kcg_equ & (kcg_c1->RedLight == kcg_c2->RedLight);
  kcg_equ = kcg_equ & (kcg_c1->IndicatorState == kcg_c2->IndicatorState);
  return kcg_equ;
}
#endif /* kcg_use_ExternalindicatorStates */

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_types.c
** Generation date: 2023-11-13T15:10:52
*************************************************************$ */

