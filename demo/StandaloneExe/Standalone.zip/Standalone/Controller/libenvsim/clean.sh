#!/bin/bash
rm -rf build/darwin
rm -rf build/win32
